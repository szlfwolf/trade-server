/*
package com.smartpay.cbp.core;

import com.smartpay.cbp.common.sms.service.SmsService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

*/
/**
 * @author Carer
 * @desc
 * @date 2022/11/25 14:47
 *//*


@RunWith(SpringRunner.class)
@SpringBootTest(classes = CoreApplication.class,webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class MySpringBootTest {

    @Autowired
    @Qualifier("kltChannelService")
    private SmsService smsService;

    @Test
    public void ttt(){
        smsService.sendSmsVerificationCode("大家好，这是测试短信！","13675682853");
    }
}
*/
