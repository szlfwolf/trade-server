package com.smartpay.cbp.core.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * @author Carer
 * @desc
 * @date 2022/11/7 16:55
 */
@ApiModel(value = "基础字段请求抽象实体")
@Data
@EqualsAndHashCode(callSuper = false)
public abstract class BaseReqDto implements Serializable {
    private static final long serialVersionUID = 8983135077998598910L;

    /**
     * 商户号
     */
    @ApiModelProperty(value = "商户号",required = true)
    @NotBlank(message = "商户号(merchantNo)-{javax.validation.constraints.NotBlank.message}")
    private String merchantNo;

    /**
     * 请求流水号
     */
    @ApiModelProperty(value = "请求流水号",required = true)
    @NotBlank(message = "请求流水号(reqId)-{javax.validation.constraints.NotBlank.message}")
    private String reqId;

    /**
     * 数据来源,1-在岸api,2-在岸商服，3离岸api,4-离岸商服
     */
    @ApiModelProperty(value = "数据来源,1-在岸api,2-在岸商服，3离岸api,4-离岸商服",allowableValues = "range[1, 4]",required = true)
    @NotBlank(message = "数据来源(sourceFrom)-{javax.validation.constraints.NotBlank.message}")
    private String sourceFrom;
}
