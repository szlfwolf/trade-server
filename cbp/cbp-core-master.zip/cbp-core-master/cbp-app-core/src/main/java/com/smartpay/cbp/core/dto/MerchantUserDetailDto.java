package com.smartpay.cbp.core.dto;

import com.smartpay.cbp.core.constant.RegisterStatus;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author Carer
 * @desc 商户用户详情响应字段
 * @date 2022/11/22 10:43
 */
@ApiModel(value = "商户用户详情响应字段")
@Data
@EqualsAndHashCode(callSuper = false)
public class MerchantUserDetailDto implements Serializable {
    private static final long serialVersionUID = -1170027074857800330L;

    /**
     * 系统商户号
     */
    @ApiModelProperty(value = "系统商户号")
    private String merchantNo;

    /**
     * 系统用户号
     */
    @ApiModelProperty(value = "系统用户号")
    private String userNo;

    /**
     * 备案渠道号
     */
    @ApiModelProperty(value = "备案渠道号")
    private String channelNo;

    /**
     * 渠道用户号
     */
    @ApiModelProperty(value = "渠道用户号")
    private String openUserNo;

    /**
     * 商户侧用户编号
     */
    @ApiModelProperty(value = "商户侧用户编号")
    private String merchantUserNo;

    /**
     * 卖家平台注册时间
     */
    @ApiModelProperty(value = "卖家平台注册时间")
    private String regTime;

    /**
     * 备案请求号
     */
    @ApiModelProperty(value = "备案请求号")
    private String regReqId;

    /**
     * 状态，${@link RegisterStatus}
     */
    @ApiModelProperty(value = "状态")
    private String status;

    /**
     * 数据来源,${@link com.smartpay.cbp.core.constant.SourceFrom}
     */
    @ApiModelProperty(value = "数据来源")
    private String sourceFrom;

    /**
     * 用户类型,1-企业，2-个人
     */
    @ApiModelProperty(value = "用户类型")
    private String userType;

    /**
     * 国别
     */
    @ApiModelProperty(value = "国别")
    private String nationality;

    /**
     * 姓名、法人姓名-脱敏
     */
    @ApiModelProperty(value = "姓名-脱敏")
    private String nameMask;

    /**
     * 手机号-加密
     */
    @ApiModelProperty(value = "手机号-脱敏")
    private String mobileNoMask;

    /**
     * 证件类型
     */
    @ApiModelProperty(value = "证件类型")
    private String certType;

    /**
     * 证件号-加密
     */
    @ApiModelProperty(value = "证件号-脱敏")
    private String certIdMask;

    /**
     * 证件有效期始
     */
    @ApiModelProperty(value = "证件有效期始")
    private String certExpBeginDate;

    /**
     * 证件有效期止
     */
    @ApiModelProperty(value = "证件有效期止")
    private String certExpEndDate;

    /**
     * 开户成功时间
     */
    @ApiModelProperty(value = "开户成功时间")
    private LocalDateTime registerTime;

    /**
     * 邮箱地址
     */
    @ApiModelProperty(value = "邮箱地址")
    private String email;

    /**
     * 联系地址
     */
    @ApiModelProperty(value = "联系地址")
    private String address;

    /**
     * 职业代码
     */
    @ApiModelProperty(value = "职业代码")
    private String professionCode;

    /**
     * 职业名称
     */
    @ApiModelProperty(value = "职业名称")
    private String professionName;

    /**
     * 开户银行
     */
    @ApiModelProperty(value = "开户银行")
    private String bankName;

    /**
     * 银行账号
     */
    @ApiModelProperty(value = "银行账号")
    private String bankAcct;

    /**
     * 统一社会信用代码
     */
    @ApiModelProperty(value = "统一社会信用代码")
    private String licenseNo;

    /**
     * 营业执照起始时间
     */
    @ApiModelProperty(value = "营业执照起始时间")
    private String licenseStartDate;

    /**
     * 营业执照结束时间
     */
    @ApiModelProperty(value = "营业执照结束时间")
    private String licenseEndDate;

    /**
     * 审批状态，${@link com.smartpay.cbp.core.constant.ApproveStatus}
     */
    @ApiModelProperty(value = "审批状态")
    private String approveStatus;

    /**
     * 企业简称
     */
    @ApiModelProperty(value = "企业简称")
    private String shortName;

    /**
     * 企业类型 1-个体工商户 2-企业
     */
    @ApiModelProperty(value = "企业类型")
    private String bizType;

    /**
     * 经营范围
     */
    @ApiModelProperty(value = "经营范围")
    private String bizScope;

    /**
     * 邮编
     */
    @ApiModelProperty(value = "邮编")
    private String postCode;

    /**
     * 经营地址
     */
    @ApiModelProperty(value = "经营地址")
    private String opAddr;

    /**
     * 账户类型
     */
    @ApiModelProperty(value = "账户类型")
    private String acctType;

    /**
     * 账户名称
     */
    @ApiModelProperty(value = "账户名称")
    private String acctName;

    @ApiModelProperty(value = "省编码")
    private String provinceCode;

    @ApiModelProperty(value = "市编码")
    private String cityCode;

    @ApiModelProperty(value = "区编码")
    private String areaCode;

    private String areaName;

    /**
     * 支行联行号
     */
    @ApiModelProperty(value = "支行联行号")
    private String bankCode;

    /**
     * 支行名称
     */
    @ApiModelProperty(value = "支行名称")
    private String branchName;

    /**
     * 所属行业属性代码
     */
    @ApiModelProperty(value = "所属行业属性代码")
    private String industryCode;

    /**
     * 经济类型代码
     */
    @ApiModelProperty(value = "经济类型代码")
    private String attrCode;

    /**
     * 是否特殊经济区内企业
     */
    @ApiModelProperty(value = "是否特殊经济区内企业")
    private String isTaxFree;

    /**
     * 特殊经济区内企业类型
     */
    @ApiModelProperty(value = "特殊经济区内企业类型")
    private String taxFreeCode;

    /**
     * 外方投资者国别信息
     */
    @ApiModelProperty(value = "外方投资者国别信息")
    private String invCountryCode;

    /**
     * 店铺网址
     */
    @ApiModelProperty(value = "店铺网址")
    private String storeLink;

    /**
     * 备案备注
     */
    @ApiModelProperty(value = "备案备注")
    private String registerRemark;

    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;

    /**
     * 证件正面照文件Id
     */
    @ApiModelProperty(value = "证件正面照文件Id")
    private String certFrontFileId;

    /**
     * 证件反面照文件Id
     */
    @ApiModelProperty(value = "证件反面照文件Id")
    private String certBackFileId;

    /**
     * 营业执照文件Id
     */
    @ApiModelProperty(value = "营业执照文件Id")
    private String licenseFileId;

    /**
     * 创建时间
     */
    @ApiModelProperty(value = "创建时间")
    private LocalDateTime crtTime;

}
