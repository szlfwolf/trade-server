package com.smartpay.cbp.core.service.impl;

import com.smartpay.cbp.core.config.MinIoConfig;
import com.smartpay.cbp.core.constant.StoreType;
import com.smartpay.cbp.core.dto.FileInfoObj;
import com.smartpay.cbp.core.dto.FileUploadDto;
import com.smartpay.cbp.core.util.FileUploadUtils;
import io.minio.GetObjectArgs;
import io.minio.MinioClient;
import io.minio.PutObjectArgs;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

/**
 * @author Carer
 * @desc
 * @date 2022/11/7 17:25
 */
@Service("minIoStorage")
@RequiredArgsConstructor
@Slf4j
public class MinIoFileStorageServiceImpl extends AbstractFileStorageServiceImpl {

    private final MinIoConfig minIoConfig;

    private final MinioClient client;
    /**
     * 文件上传
     *
     * @param file 文件
     * @return 文件路径
     */
    @SneakyThrows
    @Override
    public FileInfoObj upload(MultipartFile file) {
        String pathName = FileUploadUtils.extractFilename(file);
        PutObjectArgs args = PutObjectArgs.builder()
                .bucket(minIoConfig.getBucketName())
                .object(pathName)
                .stream(file.getInputStream(), file.getSize(), -1)
                .contentType(file.getContentType())
                .build();
        client.putObject(args);
        return FileInfoObj.builder()
                .fileUrl(minIoConfig.getUrl() + "/" + minIoConfig.getBucketName() + "/" + pathName)
                .filePathName(pathName)
                .build();
    }

    @Override
    public String getStoreType() {
        return StoreType.MIN_IO.getCode();
    }

    /**
     * 文件上传
     *
     * @param file 文件
     * @return 文件路径
     */
    @SneakyThrows
    @Override
    public String upload(FileUploadDto file) {
        PutObjectArgs args = PutObjectArgs.builder()
                .bucket(minIoConfig.getBucketName())
                .object(file.getFilePathName())
                .stream(new ByteArrayInputStream(file.getFileData()), file.getFileData().length, -1)
                .build();
        client.putObject(args);
        return minIoConfig.getUrl() + "/" + minIoConfig.getBucketName() + "/" + file.getFileName();
    }

    @SneakyThrows
    @Override
    public InputStream downloadFile(String fileName) {
        return client.getObject(GetObjectArgs.builder()
                .bucket(minIoConfig.getBucketName()).object(fileName).build());
    }
}
