package com.smartpay.cbp.core.dto;

import com.smartpay.cbp.core.constant.UserType;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author Carer
 * @desc 个人开户请求实体
 * @date 2022/11/8 11:00
 */
@ApiModel(value = "个人开户请求实体",parent = UserRegisterReqDto.class)
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public final class PersonRegisterDto extends UserRegisterReqDto{
    private static final long serialVersionUID = 2940443301807845058L;

    /**
     * 用户类型,${@link UserType}
     */
    @ApiModelProperty(value = "用户类型",allowableValues = "2",hidden = true)
    private String userType = UserType.PERSON.getCode();

    /**
     * 职业代码
     */
    @ApiModelProperty(value = "职业代码")
    private String professionCode;

    /**
     * 职业名称
     */
    @ApiModelProperty(value = "职业名称")
    private String professionName;

}
