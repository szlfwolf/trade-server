package com.smartpay.cbp.core.vo;

import com.smartpay.cbp.common.core.annotation.Excel;
import lombok.Data;

import java.io.Serializable;

/**
 * 商户下发明细表
 *
 * @TableName t_remit_order
 */
@Data
public class RemitOrderExportVo implements Serializable {


    @Excel(name = "提现订单号")
    private String orderNo;

    @Excel(name = "金额")
    private Long amt;

    @Excel(name = "卖家编号")
    private String platformUserNo;

    @Excel(name = "银行名称")
    private String bankName;

    @Excel(name = "代发类型")
    private String remitTypeName;

    @Excel(name = "到账类型")
    private String timeTypeName;

    @Excel(name = "账号")
    private String bankAccountNo;

    @Excel(name = "户名")
    private String bankAccountName;

    @Excel(name = "证件类型")
    private String accountIdType;

    @Excel(name = "证件号码")
    private String accountIdNo;

    @Excel(name = "省份")
    private String province;

    @Excel(name = "地区")
    private String city;

    @Excel(name = "支行名")
    private String bankBranchName;

    @Excel(name = "联行号")
    private String cnapsNo;

    @Excel(name = "用途")
    private String purpose;

    @Excel(name = "备注")
    private String remark;

    @Excel(name = "预留手机号")
    private String mobilePhone;

    @Excel(name = "业务类型")
    private String businessCode;

    @Excel(name = "平台名称")
    private String platformName;

    @Excel(name = "备注2")
    private String remark2;

    @Excel(name = "备注3")
    private String remark3;

    @Excel(name = "备注4")
    private String remark4;

    @Excel(name = "产品类型")
    private String productCode;

    @Excel(name = "错误信息")
    private String errorMsg;

}