package com.smartpay.cbp.core.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.LocalDateTimeUtil;
import cn.hutool.core.text.CharSequenceUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.smartpay.cbp.common.security.utils.SecurityUtils;
import com.smartpay.cbp.core.constant.RegisterStatus;
import com.smartpay.cbp.core.constant.UserType;
import com.smartpay.cbp.core.constants.Constants;
import com.smartpay.cbp.core.dto.*;
import com.smartpay.cbp.core.entity.ApproveInfoEntity;
import com.smartpay.cbp.core.entity.MerchantUserEntity;
import com.smartpay.cbp.core.mapstruct.MerchantUserStruct;
import com.smartpay.cbp.core.repository.ApproveInfoRepository;
import com.smartpay.cbp.core.repository.MerchantUserRepository;
import com.smartpay.cbp.core.service.MerchantUserService;
import com.smartpay.cbp.system.api.model.LoginUser;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author Carer
 * @desc
 * @date 2022/11/18 17:09
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class MerchantUserServiceImpl implements MerchantUserService {

    private final MerchantUserRepository merchantUserRepository;

    private final MerchantUserStruct merchantUserStruct;

    private final ApproveInfoRepository approveInfoRepository;

    private final AmqpTemplate amqpTemplate;

    /**
     * 校验外部用户编号是否备案成功
     *
     * @param merchantUserRegCheckReqDto 外部用户编号
     * @return 未备案成功的外部用户编号
     */
    @Override
    public List<String> checkRegister(MerchantUserRegCheckReqDto merchantUserRegCheckReqDto) {
        List<MerchantUserEntity> succList = merchantUserRepository.list(Wrappers.<MerchantUserEntity>lambdaQuery()
                .eq(MerchantUserEntity::getMerchantNo, merchantUserRegCheckReqDto.getMerchantNo())
                .eq(MerchantUserEntity::getStatus, RegisterStatus.REGISTER_SUCCESS.getCode())
                .in(MerchantUserEntity::getMerchantUserNo, merchantUserRegCheckReqDto.getMerchantUserNos())
        );
        Set<String> sucRegMerUserNos = succList.parallelStream().map(MerchantUserEntity::getMerchantUserNo)
                .collect(Collectors.toSet());
        return CollUtil.subtractToList(merchantUserRegCheckReqDto.getMerchantUserNos(),sucRegMerUserNos);
    }

    /**
     * 获取分页用户信息
     *
     * @param merchantUserPageReqDto 分页查询入参
     * @return 响应内容
     */
    @Override
    public List<MerchantUserPageRspDto> pageList(MerchantUserPageReqDto merchantUserPageReqDto) {
        List<MerchantUserEntity> entityList = merchantUserRepository.list(Wrappers.<MerchantUserEntity>lambdaQuery()
                .eq(CharSequenceUtil.isNotBlank(merchantUserPageReqDto.getMerchantNo())
                        , MerchantUserEntity::getMerchantNo, merchantUserPageReqDto.getMerchantNo())
                .eq(CharSequenceUtil.isNotBlank(merchantUserPageReqDto.getStatus())
                        , MerchantUserEntity::getStatus, merchantUserPageReqDto.getStatus())
                .eq(CharSequenceUtil.isNotBlank(merchantUserPageReqDto.getMerchantUserNo())
                        , MerchantUserEntity::getMerchantUserNo, merchantUserPageReqDto.getMerchantUserNo())
                .eq(CharSequenceUtil.isNotBlank(merchantUserPageReqDto.getUserNo())
                        , MerchantUserEntity::getUserNo, merchantUserPageReqDto.getUserNo())
                .eq(CharSequenceUtil.isNotBlank(merchantUserPageReqDto.getOpenUserNo())
                        , MerchantUserEntity::getOpenUserNo, merchantUserPageReqDto.getOpenUserNo())
                .eq(CharSequenceUtil.isNotBlank(merchantUserPageReqDto.getUserType())
                        , MerchantUserEntity::getUserType, merchantUserPageReqDto.getUserType())
                //TODO 姓名加密查询
                .eq(CharSequenceUtil.isNotBlank(merchantUserPageReqDto.getName())
                        , MerchantUserEntity::getNameEnc, merchantUserPageReqDto.getName())
                //TODO 证件号加密
                .eq(CharSequenceUtil.isNotBlank(merchantUserPageReqDto.getCertId())
                        , MerchantUserEntity::getCertIdEnc, merchantUserPageReqDto.getCertId())
                .ge(!Objects.isNull(merchantUserPageReqDto.getCrtStart())
                        ,MerchantUserEntity::getCrtTime
                        , beginOfDay(merchantUserPageReqDto.getCrtStart()))
                .le(!Objects.isNull(merchantUserPageReqDto.getCrtEnd())
                        ,MerchantUserEntity::getCrtTime
                        , endOfDay(merchantUserPageReqDto.getCrtEnd()))
        );
        if(CollUtil.isEmpty(entityList)){
            return Collections.emptyList();
        }
        return entityList.stream().map(merchantUserStruct::toRspDto).collect(Collectors.toList());
    }

    /**
     * 根据主键查询商户用户信息
     *
     * @param id 主键
     * @return 商户用户详情
     */
    @Override
    public MerchantUserDetailDto detailById(String id) {
        MerchantUserEntity merchantUserEntity = merchantUserRepository.getById(id);
        if(Objects.isNull(merchantUserEntity)){
            return null;
        }
        return merchantUserStruct.toDetailDto(merchantUserEntity);
    }

    /**
     * 审批
     *
     * @param approveReqDto 审批入参
     * @return 审批结果
     */
    @Override
    public Boolean approve(ApproveReqDto approveReqDto) {
        MerchantUserEntity merchantUserEntity = Optional.ofNullable(merchantUserRepository
                .getById(approveReqDto.getRelId())).orElseThrow(()-> new RuntimeException("商户用户信息不存在！"));
        if(!merchantUserEntity.getStatus()
                .equals(RegisterStatus.REGISTER_ING.getCode())){
            throw new RuntimeException("当前状态已是终态不支持审批！");
        }
        merchantUserEntity.setApproveStatus(approveReqDto.getApproveAction());
        LoginUser loginUser = SecurityUtils.getLoginUser();
        merchantUserEntity.setApprovePerson(CharSequenceUtil
                .concat(true,loginUser.getSysUser().getNickName(),"(",loginUser.getUsername(),")"));
        //判断企业审批之前是否备案过，备案过直接备案成功，否则推Mq执行后续备案流程
        if(merchantUserEntity.getUserType().equals(UserType.COMPANY.getCode())
                &&merchantUserEntity.getStatus().equals(RegisterStatus.REGISTER_ING.getCode())){
            sameCompanyRegisterCheck(merchantUserEntity);
        }
        merchantUserRepository.updateById(merchantUserEntity);
        saveApproveInfo(approveReqDto,merchantUserEntity.getApprovePerson());
        return Boolean.TRUE;
    }

    /**
     * 保存审批信息
     * @param approveReqDto 审批信息
     */
    private void saveApproveInfo(ApproveReqDto approveReqDto,String approvePerson) {
        ApproveInfoEntity approveInfoEntity = new ApproveInfoEntity();
        approveInfoEntity.setBusinessId(approveReqDto.getRelId());
        approveInfoEntity.setApproveUser(approvePerson);
        approveInfoEntity.setApproveAction(approveReqDto.getApproveAction());
        approveInfoEntity.setApproveRemark(approveReqDto.getApproveRemark());
        approveInfoEntity.setApproveTime(LocalDateTime.now());
        approveInfoRepository.save(approveInfoEntity);
    }

    private void sameCompanyRegisterCheck(MerchantUserEntity merchantUserEntity){
        //相同企业备案校验
        List<MerchantUserEntity> merchantUserList = merchantUserRepository
                .queryCompanysByInfo(merchantUserEntity.getLicenseNo(),merchantUserEntity.getChannelNo());
        if(CollUtil.isEmpty(merchantUserList)){
            return;
        }
        List<MerchantUserEntity> sucAncProcList = merchantUserList.parallelStream()
                .filter(item -> item.isSuc()||item.isProcessing())
                .collect(Collectors.toList());
        if(sucAncProcList.isEmpty()){
            amqpTemplate.convertAndSend(Constants.CORE_EXCHANGE,Constants.REGISTER_QUEUE
                    ,merchantUserEntity.getId());
            return;
        }
        merchantUserEntity.setStatus(RegisterStatus.REGISTER_SUCCESS.getCode());
        merchantUserEntity.setRegisterTime(LocalDateTimeUtil.now());
        merchantUserEntity.setRegisterRemark("同渠道历史备案已成功！");
        merchantUserEntity.setOpenUserNo(sucAncProcList.get(0).getOpenUserNo());
    }

    private LocalDateTime beginOfDay(LocalDate localDate){
        if(Objects.isNull(localDate)){
            return null;
        }
        return LocalDateTimeUtil.beginOfDay(localDate.atStartOfDay());
    }

    private LocalDateTime endOfDay(LocalDate localDate){
        if(Objects.isNull(localDate)){
            return null;
        }
        return LocalDateTimeUtil.endOfDay(localDate.atStartOfDay());
    }

}
