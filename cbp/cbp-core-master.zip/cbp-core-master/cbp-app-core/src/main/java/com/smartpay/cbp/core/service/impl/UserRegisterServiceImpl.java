package com.smartpay.cbp.core.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.text.CharSequenceUtil;
import cn.hutool.core.util.ArrayUtil;
import cn.hutool.core.util.IdUtil;
import com.smartpay.cbp.channel.constant.NotifyStatus;
import com.smartpay.cbp.channel.dto.RegisterNotifyInfoDto;
import com.smartpay.cbp.console.dto.ChannelInfoFeignDto;
import com.smartpay.cbp.core.constant.*;
import com.smartpay.cbp.core.constants.Constants;
import com.smartpay.cbp.core.dto.CompanyRegisterDto;
import com.smartpay.cbp.core.dto.NotifyRegisterReqDto;
import com.smartpay.cbp.core.dto.PersonRegisterDto;
import com.smartpay.cbp.core.dto.UserRegisterReqDto;
import com.smartpay.cbp.core.entity.MerchantUserEntity;
import com.smartpay.cbp.core.repository.FileInfoRepository;
import com.smartpay.cbp.core.repository.MerchantUserRepository;
import com.smartpay.cbp.core.service.ConsoleRemoteApiService;
import com.smartpay.cbp.core.service.UserRegisterService;
import com.smartpay.cbp.core.util.KltMaskUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author Carer
 * @desc
 * @date 2022/11/8 11:36
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class UserRegisterServiceImpl implements UserRegisterService {

    private final ConsoleRemoteApiService consoleRemoteApiService;

    private final FileInfoRepository fileInfoRepository;

    private final MerchantUserRepository merchantUserRepository;

    private final AmqpTemplate amqpTemplate;

    /**
     * 个人开户
     *
     * @param personRegisterDto 个人请求实体
     * @return 开户请求结果
     */
    @Override
    public Boolean personRegister(PersonRegisterDto personRegisterDto) {
        //校验商户
        consoleRemoteApiService.checkMerchantStatus(personRegisterDto.getMerchantNo());
        //校验影像件是否存在系统中
        fileInfoRepository.checkExit(personRegisterDto.getCertBackFileId(),personRegisterDto.getCertFrontFileId());
        Optional<ChannelInfoFeignDto> channelInfoFeignDto = consoleRemoteApiService.routeChannel();
        String channelNo = channelInfoFeignDto.orElseThrow(() ->new RuntimeException("没有可用银行渠道！")).getChannelCode();
        List<MerchantUserEntity> merchantUsers = merchantUserRepository
                .queryPersonsByMerchantInfo(personRegisterDto.getMerchantNo(),personRegisterDto.getMerchantUserNo());
        //数据幂等校验
        idemCheck(merchantUsers);
        //相同人备案校验处理
        boolean continueFlag = samePersonRegisterCheck(personRegisterDto,channelNo);
        if(continueFlag){
            //继续备案流程
            MerchantUserEntity merchantUser = new MerchantUserEntity();
            coverPersonMerchantUser(merchantUser,personRegisterDto,channelNo);
            merchantUser.setStatus(RegisterStatus.INIT.getCode());
            merchantUserRepository.save(merchantUser);
            amqpTemplate.convertAndSend(Constants.CORE_EXCHANGE,Constants.REGISTER_QUEUE
                    ,merchantUser.getId());
        }
        return Boolean.TRUE;
    }

    private void idemCheck(List<MerchantUserEntity> merchantUsers) {
        if(CollUtil.isEmpty(merchantUsers)){
            return;
        }
        List<MerchantUserEntity> sucList = merchantUsers.parallelStream().filter(MerchantUserEntity::isSuc)
                .collect(Collectors.toList());
        if(!sucList.isEmpty()){
            throw new RuntimeException("该商户平台用户号已开户成功！");
        }
        List<MerchantUserEntity> processingList = merchantUsers.parallelStream().filter(MerchantUserEntity::isProcessing)
                .collect(Collectors.toList());
        if(!processingList.isEmpty()){
            throw new RuntimeException("该商户平台用户号开户中！");
        }
    }

    private boolean samePersonRegisterCheck(PersonRegisterDto personRegisterDto,String channelNo){
        List<MerchantUserEntity> merchantUserEntityList = merchantUserRepository
                .queryPersonsByInfo(personRegisterDto.getName(),personRegisterDto.getCertType()
                        ,personRegisterDto.getCertId(),channelNo);
        if(CollUtil.isEmpty(merchantUserEntityList)){
            return true;
        }
        List<MerchantUserEntity> sucList = merchantUserEntityList.parallelStream().filter(MerchantUserEntity::isSuc)
                .collect(Collectors.toList());
        if(!sucList.isEmpty()){
            //存在相同渠道下的相同人备案，则当前备案用户信息直接成功
            MerchantUserEntity merchantUser = sucList.get(0);
            coverPersonMerchantUser(merchantUser,personRegisterDto,channelNo);
            merchantUser.setId(null);
            merchantUser.setStatus(RegisterStatus.REGISTER_SUCCESS.getCode());
            merchantUserRepository.save(merchantUser);
            return false;
        }else {
            List<MerchantUserEntity> failList = merchantUserEntityList.parallelStream()
                    .filter(MerchantUserEntity::isProcessing).collect(Collectors.toList());
            if(!failList.isEmpty()){
                //存在相同渠道下的相同人备案，则当前备案用户信息直接进行中
                MerchantUserEntity merchantUser = failList.get(0);
                coverPersonMerchantUser(merchantUser,personRegisterDto,channelNo);
                merchantUser.setId(null);
                merchantUser.setStatus(RegisterStatus.REGISTER_ING.getCode());
                merchantUserRepository.save(merchantUser);
                return false;
            }
            return true;
        }
    }

    /**
     * 对象转换
     * @param merchantUser      转换的对象
     * @param source            数据源
     * @param channelNo         渠道号
     */
    private void coverPersonMerchantUser(MerchantUserEntity merchantUser, PersonRegisterDto source,String channelNo) {
        commonCoverMerchantUser(merchantUser,source,channelNo);
        merchantUser.setUserType(source.getUserType());
        merchantUser.setProfessionCode(source.getProfessionCode());
        merchantUser.setProfessionName(source.getProfessionName());
    }

    /**
     * 公共转换器
     * @param merchantUser 原始商户备案用户信息
     * @param source       原数据
     * @param channelNo    渠道信息
     */
    private void commonCoverMerchantUser(MerchantUserEntity merchantUser, UserRegisterReqDto source,String channelNo){
        merchantUser.setMerchantNo(source.getMerchantNo());
        merchantUser.setUserNo(IdUtil.getSnowflake().nextIdStr());
        merchantUser.setOpenUserNo(CharSequenceUtil.isBlank(merchantUser.getOpenUserNo())?
                IdUtil.getSnowflake().nextIdStr():merchantUser.getOpenUserNo());
        merchantUser.setChannelNo(channelNo);
        merchantUser.setMerchantUserNo(source.getMerchantUserNo());
        merchantUser.setRegTime(source.getRegTime());
        merchantUser.setSourceFrom(source.getSourceFrom());
        merchantUser.setNationality(source.getNationality());
        merchantUser.setNameEnc(source.getName());
        merchantUser.setNameMask(KltMaskUtil.nameMask(source.getName()));
        merchantUser.setMobileNoEnc(source.getMobileNo());
        merchantUser.setMobileNoMask(KltMaskUtil.phoneNoMask(source.getMobileNo()));
        merchantUser.setCertType(source.getCertType());
        merchantUser.setCertIdEnc(source.getCertId());
        merchantUser.setCertIdMask(KltMaskUtil.idNoMask(source.getCertId()));
        merchantUser.setCertExpBeginDate(source.getCertExpBeginDate());
        merchantUser.setCertExpEndDate(source.getCertExpEndDate());
        merchantUser.setAddress(source.getAddress());
        merchantUser.setEmail(source.getEmail());
        merchantUser.setBankAcct(source.getBankAcct());
        merchantUser.setBankName(source.getBankName());
        merchantUser.setStoreLink(source.getStoreLink());
        merchantUser.setCertFrontFileId(source.getCertFrontFileId());
        merchantUser.setCertBackFileId(source.getCertBackFileId());
    }

    /**
     * 企业开户
     *
     * @param companyRegisterDto 企业请求实体
     * @return 开户请求结果
     */
    @Override
    public Boolean companyRegister(CompanyRegisterDto companyRegisterDto) {
        //校验商户
        consoleRemoteApiService.checkMerchantStatus(companyRegisterDto.getMerchantNo());
        //校验影像件是否存在系统中
        fileInfoRepository.checkExit(companyRegisterDto.getCertBackFileId()
                ,companyRegisterDto.getCertFrontFileId(),companyRegisterDto.getLicenseFileId());
        Optional<ChannelInfoFeignDto> channelInfoFeignDto = consoleRemoteApiService.routeChannel();
        String channelNo = channelInfoFeignDto.orElseThrow(() ->new RuntimeException("没有可用银行渠道！")).getChannelCode();
        List<MerchantUserEntity> merchantUsers = merchantUserRepository
                .queryPersonsByMerchantInfo(companyRegisterDto.getMerchantNo(),companyRegisterDto.getMerchantUserNo());
        //数据幂等校验
        idemCheck(merchantUsers);
        MerchantUserEntity merchantUser = new MerchantUserEntity();
        coverCompanyMerchantUser(merchantUser,companyRegisterDto,channelNo);
        merchantUser.setOpenUserNo(null);
        merchantUser.setStatus(RegisterStatus.REGISTER_ING.getCode());
        merchantUser.setApproveStatus(ApproveStatus.APPROVE_PENDING.getCode());
        merchantUserRepository.save(merchantUser);
        return Boolean.TRUE;
    }

    /**
     * 回调通知
     *
     * @param notifyRegisterReqDto 通知结果
     * @return 通知结果
     */
    @Override
    public Boolean notifyRegisterResult(NotifyRegisterReqDto notifyRegisterReqDto) {
        Optional<MerchantUserEntity> merchantUserOpt = merchantUserRepository
                .queryOneByUserNo(notifyRegisterReqDto.getUserNo());
        MerchantUserEntity merchantUser = merchantUserOpt.orElseThrow(() -> new RuntimeException("备案用户信息不存在！"));
        List<MerchantUserEntity> merchantUserEntities;
        if(UserType.PERSON.getCode().equals(merchantUser.getUserType())){
            merchantUserEntities = merchantUserRepository
                    .queryPersonsByEncInfoUnSuc(merchantUser.getNameEnc(),merchantUser.getCertType()
                            ,merchantUser.getCertIdEnc(),merchantUser.getChannelNo());
        }else {
            merchantUserEntities = merchantUserRepository.queryCompanysByInfoUnsuc(merchantUser.getLicenseNo()
                    ,merchantUser.getChannelNo());
        }
        merchantUserEntities.parallelStream().forEach(item ->{
            if(NotifyResults.SUCCESS.getCode().equals(notifyRegisterReqDto.getNotifyResult())){
                item.setStatus(RegisterStatus.REGISTER_SUCCESS.getCode());
                item.setRegisterTime(notifyRegisterReqDto.getNotifyTime());
            }else {
                merchantUser.setStatus(RegisterStatus.REGISTER_FAIL.getCode());
                merchantUser.setRegisterRemark(notifyRegisterReqDto.getRemark());
            }
        });
        merchantUserRepository.updateBatchById(merchantUserEntities);
        merchantUserEntities.parallelStream().forEach(this::notifyOutSide);
        return Boolean.TRUE;
    }

    /**
     * 处理渠道回调
     *
     * @param registerNotifyInfo 回调信息
     */
    @Override
    public void dealRegisterNotify(RegisterNotifyInfoDto registerNotifyInfo) {
        MerchantUserEntity merchantUserEntity = merchantUserRepository.queryByReqId(registerNotifyInfo.getReqNo());
        if(NotifyStatus.SUCCESS.getCode().equals(registerNotifyInfo.getNotifyResult())){
            merchantUserEntity.setStatus(RegisterStatus.REGISTER_SUCCESS.getCode());
            merchantUserEntity.setRegisterTime(registerNotifyInfo.getNotifyTime());
            merchantUserRepository.updateById(merchantUserEntity);
            notifyOut(Collections.singletonList(merchantUserEntity));
            List<MerchantUserEntity> merchantPersonEntities = UserType.PERSON.getCode()
                    .equals(merchantUserEntity.getUserType())?
                    merchantUserRepository.queryPersonsByEncInfoStatus(
                    merchantUserEntity.getNameEnc(),merchantUserEntity.getCertType(),merchantUserEntity.getCertIdEnc()
                    , merchantUserEntity.getChannelNo(),RegisterStatus.REGISTER_ING)
                    :merchantUserRepository.queryCompanysByInfoStatus(merchantUserEntity.getLicenseNo()
                    ,merchantUserEntity.getChannelNo(),RegisterStatus.REGISTER_ING);
            if(CollUtil.isNotEmpty(merchantPersonEntities)){
                merchantPersonEntities.parallelStream().forEach(item -> {
                    item.setStatus(RegisterStatus.REGISTER_SUCCESS.getCode());
                    item.setRegisterTime(registerNotifyInfo.getNotifyTime());
                });
                merchantUserRepository.updateBatchById(merchantPersonEntities);
                notifyOut(merchantPersonEntities);
            }
        }else {
            merchantUserEntity.setStatus(RegisterStatus.REGISTER_FAIL.getCode());
            merchantUserEntity.setRegisterRemark(registerNotifyInfo.getRemark());
            merchantUserRepository.updateById(merchantUserEntity);
            notifyOut(Collections.singletonList(merchantUserEntity));
            if(Boolean.TRUE.equals(registerNotifyInfo.getModifyAll())){
                //后续通知的失败备案需要修改原成功状态
                List<MerchantUserEntity> merchantPersonEntities = UserType.PERSON.getCode()
                        .equals(merchantUserEntity.getUserType())?
                        merchantUserRepository.queryPersonsByEncInfoStatus(
                                merchantUserEntity.getNameEnc(),merchantUserEntity.getCertType(),merchantUserEntity.getCertIdEnc()
                                , merchantUserEntity.getChannelNo(),RegisterStatus.REGISTER_SUCCESS)
                        :merchantUserRepository.queryCompanysByInfoStatus(merchantUserEntity.getLicenseNo()
                        ,merchantUserEntity.getChannelNo(),RegisterStatus.REGISTER_SUCCESS);
                if(CollUtil.isNotEmpty(merchantPersonEntities)){
                    merchantPersonEntities.parallelStream().forEach(item -> {
                        item.setStatus(RegisterStatus.REGISTER_FAIL.getCode());
                        item.setRegisterRemark(registerNotifyInfo.getRemark());
                    });
                    merchantUserRepository.updateBatchById(merchantPersonEntities);
                    notifyOut(merchantPersonEntities);
                }
            }
        }
    }

    /**
     * 通知离岸
     * @param merchantUserEntities 已获取终态的备案用户信息
     */
    private void notifyOut(Collection<MerchantUserEntity> merchantUserEntities){
        merchantUserEntities.parallelStream().forEach(item ->{
            if(ArrayUtil.contains(new String[]{SourceFrom.OUTSIDE_API.getCode(),SourceFrom.OUTSIDE_CONSOLE.getCode()}
            ,item.getSourceFrom())){
                //需要通知离岸
                amqpTemplate.convertAndSend(Constants.CORE_EXCHANGE,Constants.REGISTER_NOTIFY_OUTSIDE_QUEUE
                        ,item.getId());
            }
        });
    }

    /**
     * 通知离岸
     * @param merchantUser 备案用户信息
     */
    private void notifyOutSide(MerchantUserEntity merchantUser){
        if(SourceFrom.OUTSIDE_API.getCode().equals(merchantUser.getSourceFrom())
                ||SourceFrom.OUTSIDE_CONSOLE.getCode().equals(merchantUser.getSourceFrom())){
            amqpTemplate.convertAndSend(Constants.CORE_EXCHANGE,Constants.NOTIFY_OUTSIDE_QUEUE
                    ,merchantUser.getId());
        }
    }

    private void coverCompanyMerchantUser(MerchantUserEntity merchantUser, CompanyRegisterDto source, String channelNo) {
        commonCoverMerchantUser(merchantUser,source,channelNo);
        merchantUser.setUserType(source.getUserType());
        merchantUser.setShortName(source.getShortName());
        merchantUser.setBizType(source.getBizType());
        merchantUser.setBizScope(source.getBizScope());
        merchantUser.setPostCode(source.getPostCode());
        merchantUser.setOpAddr(source.getOpAddr());
        merchantUser.setAcctType(source.getAcctType());
        merchantUser.setAcctName(source.getAcctName());
        merchantUser.setProvinceCode(source.getProvinceCode());
        merchantUser.setCityCode(source.getCityCode());
        merchantUser.setAreaCode(source.getAreaCode());
        merchantUser.setBranchName(source.getBranchName());
        merchantUser.setBankCode(source.getBankCode());
        merchantUser.setIndustryCode(source.getIndustryCode());
        merchantUser.setAttrCode(source.getAttrCode());
        merchantUser.setIsTaxFree(source.getIsTaxFree());
        merchantUser.setTaxFreeCode(source.getTaxFreeCode());
        merchantUser.setInvCountryCode(source.getInvCountryCode());
        merchantUser.setLicenseNo(source.getLicenseNo());
        merchantUser.setLicenseFileId(source.getLicenseFileId());
    }
}
