package com.smartpay.cbp.core.enums;

/**
 * @author ：jmwang
 * @version ：V1.0
 * @description ：工厂类型
 * @date ：2022/11/8 15:40
 */
public enum ProviderType {

    /**
     * 文件类型
     */
    CSV("csv", "csv文件处理"),
    EXCEL("excel", "xls/xlsx文件处理"),

    /**
     * 渠道类型
     */
    /*KLT("kltong", "开联通"),
    BCM("bcm", "交通银行"),*/
    ;

    private final String code;
    private final String desc;

    ProviderType(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    public boolean equals(String code) {
        return this.code.equals(code);
    }

    public static ProviderType byCode(String code) {
        for (ProviderType t : values()) {
            if (t.getCode().equals(code)) {
                return t;
            }
        }
        return null;
    }
}
