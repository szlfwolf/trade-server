package com.smartpay.cbp.core.dto;

import com.smartpay.cbp.core.constant.UserType;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

/**
 * @author Carer
 * @desc 企业开户请求实体
 * @date 2022/11/8 11:00
 */
@ApiModel(value = "企业开户请求实体",parent = UserRegisterReqDto.class)
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public final class CompanyRegisterDto extends UserRegisterReqDto{
    private static final long serialVersionUID = 2940443301807845058L;

    /**
     * 用户类型,${@link UserType}
     */
    @ApiModelProperty(value = "用户类型",allowableValues = "1",hidden = true)
    private String userType = UserType.COMPANY.getCode();

    @ApiModelProperty(value = "企业简称")
    @Size(max = 20, message = "企业简称(shortName)-格式不正确，长度超20")
    private String shortName;

    /**
     * 企业类型 1-个体工商户 2-企业 不可空
     */
    @ApiModelProperty(value = "企业简称",required = true)
    @NotBlank(message = "企业类型(bizType)-{javax.validation.constraints.NotBlank.message}")
    private String bizType;

    /**
     * 经营范围
     */
    @ApiModelProperty(value = "经营范围")
    @Size(max = 2048, message = "经营范围(bizScope)-格式不正确，{javax.validation.constraints.Size.message}")
    private String bizScope;

    /**
     * 邮编
     */
    @ApiModelProperty(value = "邮编",required = true)
    @NotBlank(message = "邮编(postCode)-{javax.validation.constraints.NotBlank.message}")
    @Size(max = 6, message = "邮编(postCode)-格式不正确，{javax.validation.constraints.Size.message}")
    private String postCode;

    /**
     * 经营地址
     */
    @ApiModelProperty(value = "经营地址",required = true)
    @NotBlank(message = "经营地址(opAddr)-{javax.validation.constraints.NotBlank.message}")
    @Size(max = 128, message = "经营地址(opAddr)-格式不正确，{javax.validation.constraints.Size.message}")
    private String opAddr;

    @ApiModelProperty(value = "账户类型",required = true)
    @NotBlank(message = "账户类型acctType不能为空")
    @Size(max = 1, message = "账户类型acctType格式不正确，长度超1")
    private String acctType;

    @ApiModelProperty(value = "账户名称",required = true)
    @NotBlank(message = "账户名称acctName不能为空")
    @Size(max = 50, message = "账户名称acctName格式不正确，长度超50")
    private String acctName;

    @ApiModelProperty(value = "省")
    @Size(max = 8, message = "省provinceCode格式不正确，长度超8")
    private String provinceCode;

    @ApiModelProperty(value = "市")
    @Size(max = 8, message = "市cityCode格式不正确，长度超8")
    private String cityCode;

    @ApiModelProperty(value = "支行名称")
    @Size(max = 50, message = "支行名称branchName格式不正确，长度超50")
    private String branchName;

    @ApiModelProperty(value = "支行联行号",required = true)
    @NotBlank(message = "支行[bankCode]联行号不能为空")
    @Size(max = 20, message = "支行[bankCode]联行号格式不正确，长度超20")
    private String bankCode;


    @ApiModelProperty(value = "住所/营业场所代码",required = true)
    @NotBlank(message = "[areaCode]住所/营业场所代码不能为空")
    @Size(max = 6, message = "[areaCode]住所/营业场所代码格式不正确，长度超20")
    private String areaCode;


    @ApiModelProperty(value = "所属行业属性代码",required = true)
    @NotBlank(message = "[industryCode]所属行业属性代码不能为空")
    @Size(max = 4, message = "[industryCode]所属行业属性代码格式不正确，长度超4")
    private String industryCode;

    @ApiModelProperty(value = "经济类型代码",required = true)
    @NotBlank(message = "[attrCode]经济类型代码不能为空")
    @Size(max = 3, message = "[attrCode]格式不正确，长度超3")
    private String attrCode;

    @ApiModelProperty(value = "是否特殊经济区内企业",required = true)
    @NotBlank(message = "[isTaxFree]是否特殊经济区内企业不能为空")
    @Size(max = 1, message = "[isTaxFree]是否特殊经济区内企业格式不正确，长度超1")
    private String isTaxFree;

    @ApiModelProperty(value = "特殊经济区内企业类型",required = true)
    @NotBlank(message = "[taxFreeCode] 特殊经济区内企业类型不能为空")
    @Size(max = 2, message = "[taxFreeCode]特殊经济区内企业类型格式不正确，长度超2")
    private String taxFreeCode;

    /**
     * 外方投资者国别信息
     */
    @ApiModelProperty(value = "外方投资者国别信息")
    private String invCountryCode;

    /**
     * 统一社会信用代码
     */
    @ApiModelProperty(value = "统一社会信用代码")
    private String licenseNo;

    /**
     * 营业执照文件Id
     */
    @ApiModelProperty(value = "营业执照文件Id",required = true)
    @NotBlank(message = "营业执照文件Id(licenseFileId)-{javax.validation.constraints.NotBlank.message}")
    private String licenseFileId;

    @ApiModelProperty(value = "补充材料1",hidden = true)
    @Size(max = 100, message = "[otherFile1]补充材料1格式不正确，长度超100")
    private String otherFile1;

    @ApiModelProperty(value = "补充材料2",hidden = true)
    @Size(max = 100, message = "[otherFile2]补充材料2格式不正确，长度超100")
    private String otherFile2;

    @ApiModelProperty(value = "补充材料3",hidden = true)
    @Size(max = 100, message = "[otherFile3]补充材料3格式不正确，长度超100")
    private String otherFile3;

    @ApiModelProperty(value = "补充材料4",hidden = true)
    @Size(max = 100, message = "[otherFile4]补充材料4格式不正确，长度超100")
    private String otherFile4;
}
