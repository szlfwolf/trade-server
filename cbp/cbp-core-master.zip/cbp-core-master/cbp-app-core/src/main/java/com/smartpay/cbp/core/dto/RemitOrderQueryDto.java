package com.smartpay.cbp.core.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.util.Date;

/**
 * @Description: 提现订单的查询dto
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/21 11:02
 * @Version: 1.0
 */
@Data
public class RemitOrderQueryDto {

    @ApiModelProperty("商户号")
    private String merchantNo;

    @ApiModelProperty("订单批次号")
    private String batchNo;

    @ApiModelProperty("订单编号")
    private String orderNo;

    @ApiModelProperty("收款人名称")
    private String bankAccountName;

    @ApiModelProperty("收款人账号")
    private String bankAccountNo;

    @ApiModelProperty("账户类型")
    private String remitType;

    @ApiModelProperty("创建开始时间")
    private Date crtStartTime;

    @ApiModelProperty("创建结束时间")
    private Date crtEndTime;

    @ApiModelProperty("订单状态")
    private String status;


}
