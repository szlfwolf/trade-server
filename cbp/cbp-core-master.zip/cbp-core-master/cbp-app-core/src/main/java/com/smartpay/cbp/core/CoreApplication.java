package com.smartpay.cbp.core;

import com.smartpay.cbp.common.security.annotation.EnableCustomConfig;
import com.smartpay.cbp.common.security.annotation.EnableRyFeignClients;
import com.smartpay.cbp.common.swagger.annotation.EnableCustomSwagger2;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Carer
 * @desc   核心业务主启动类
 * @date 2022/10/26 17:37
 */
@EnableCustomConfig
@EnableCustomSwagger2
@EnableRyFeignClients
@SpringBootApplication
public class CoreApplication {

    public static void main(String[] args) {
        SpringApplication.run(CoreApplication.class, args);
    }
}
