package com.smartpay.cbp.core.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.smartpay.cbp.core.annotation.ExcelField;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 商户提现订单校验失败表
 *
 * @TableName t_remit_order_fail
 */
@TableName(value = "t_remit_order_fail")
@Data
public class RemitOrderFail implements Serializable {
    /**
     * 主键id
     */
    @TableId(value = "id")
    private String id;

    /**
     * 代付请求id
     */
    @TableField(value = "remit_req_id")
    private String remitReqId;

    /**
     * 商户号
     */
    @TableField(value = "merchant_no")
    private String merchantNo;

    /**
     * 批次号
     */
    @ExcelField(name = "提现订单号")
    @TableField(value = "batch_no")
    private String batchNo;

    /**
     * 订单编号
     */
    @TableField(value = "order_no")
    private String orderNo;

    /**
     * 业务类型
     */
    @ExcelField(name = "业务类型")
    @TableField(value = "business_type")
    private String businessType;

    /**
     * 手机号
     */
    @ExcelField(name = "银行预留手机号")
    @TableField(value = "mobile_phone")
    private String mobilePhone;

    /**
     * 产品编码
     */
    @ExcelField(name = "产品类型")
    @TableField(value = "product_code")
    private String productCode;

    /**
     * 货币类型
     */
    @TableField(value = "currency_type")
    private String currencyType;

    /**
     * 用途
     */
    @ExcelField(name = "用途")
    @TableField(value = "purpose")
    private String purpose;

    /**
     * 出款用户号
     */
    @TableField(value = "pay_user_no")
    private String payUserNo;

    /**
     * 付款金额
     */
    @ExcelField(name = "金额(单位:元)")
    @TableField(value = "amt")
    private Long amt;

    /**
     * 收款联行号
     */
    @ExcelField(name = "联行号")
    @TableField(value = "cnaps_no")
    private String cnapsNo;

    /**
     * 代发类型
     */
    @ExcelField(name = "代发类型")
    @TableField(value = "remit_type")
    private String remitType;

    /**
     * 到账类型
     */
    @ExcelField(name = "到账类型")
    @TableField(value = "time_type")
    private String timeType;

    /**
     * 账户类型
     */
    @TableField(value = "account_type")
    private String accountType;

    /**
     * 收款银行代码
     */
    @TableField(value = "bank_code")
    private String bankCode;

    /**
     * 收款银行名称
     */
    @ExcelField(name = "银行名称")
    @TableField(value = "bank_name")
    private String bankName;

    /**
     * 收款银行账号
     */
    @ExcelField(name = "账号")
    @TableField(value = "bank_account_no")
    private String bankAccountNo;

    /**
     * 收款账户名
     */
    @ExcelField(name = "户名")
    @TableField(value = "bank_account_name")
    private String bankAccountName;

    /**
     * 收款人证件类型
     */
    @ExcelField(name = "证件类型")
    @TableField(value = "account_id_type")
    private String accountIdType;

    /**
     * 收款人证件号
     */
    @ExcelField(name = "证件号码")
    @TableField(value = "account_id_no")
    private String accountIdNo;

    /**
     * 省份
     */
    @ExcelField(name = "省份")
    @TableField(value = "province")
    private String province;

    /**
     * 城市
     */
    @ExcelField(name = "地区")
    @TableField(value = "city")
    private String city;

    /**
     * 收款行支行名称
     */
    @ExcelField(name = "支行名")
    @TableField(value = "bank_branch_name")
    private String bankBranchName;

    /**
     * 卖家类型
     */
    @TableField(value = "platform_type")
    private String platformType;

    /**
     * 卖家编号
     */
    @ExcelField(name = "卖家编号")
    @TableField(value = "platform_user_no")
    private String platformUserNo;

    /**
     * 备注
     */
    @ExcelField(name = "备注")
    @TableField(value = "remark")
    private String remark;

    /**
     * 备注1
     */
    @ExcelField(name = "备注1")
    @TableField(value = "remark1")
    private String remark1;

    /**
     * 备注2
     */
    @ExcelField(name = "备注2")
    @TableField(value = "remark2")
    private String remark2;

    /**
     * 备注3
     */
    @ExcelField(name = "备注3")
    @TableField(value = "remark3")
    private String remark3;

    /**
     * 备注4
     */
    @ExcelField(name = "备注4")
    @TableField(value = "remark4")
    private String remark4;

    /**
     * 平台名称
     */
    @TableField(value = "platform_name")
    private String platformName;

    /**
     * 失败原因
     */
    @ExcelField(name = "校验结果")
    @TableField(value = "fail_reason")
    private String failReason;

    /**
     * 创建人
     */
    @TableField(value = "crt_by")
    private String crtBy;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField(value = "crt_time")
    private Date crtTime;

    /**
     * 修改人
     */
    @TableField(value = "upt_by")
    private String uptBy;

    /**
     * 修改时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField(value = "upt_time")
    private Date uptTime;

    /**
     * 是否删除
     */
    @TableField(value = "del_flag")
    private Boolean delFlag;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}