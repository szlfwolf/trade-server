package com.smartpay.cbp.core.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author ：jmwang
 * @version ：V1.0
 * @description ：订单MQ配置
 * @date ：2022/11/9 11:05
 */
@Configuration
public class OrderDirectRabbitConfig {

    /**
     * 订单解析队列
     * 订单解析、校验、保存
     */
    public static final String ORDER_APPLY_QUEUE = "ORDER_APPLY_QUEUE";
    /**
     * 订单文件队列
     * 生成成功/失败文件/渠道文件
     */
    public static final String ORDER_FILE_QUEUE = "ORDER_FILE_QUEUE";
    /**
     * 订单数据同步队列
     * 渠道文件同步渠道系统
     */
    //public static final String ORDER_CHANNEL_QUEUE = "ORDER_CHANNEL_QUEUE";


    /**
     * 订单交换机
     */
    public static final String ORDER_EXCHANGE = "ORDER_EXCHANGE";


    /**
     * 订单申报队列
     *
     * @return
     */
    @Bean
    public Queue orderApplyQueue() {
        return new Queue(ORDER_APPLY_QUEUE, true);
    }

    /**
     * 订单文件处理队列
     *
     * @return
     */
    @Bean
    public Queue orderFileQueue() {
        return new Queue(ORDER_FILE_QUEUE, true);
    }

    /**
     * 订单交换机
     *
     * @return
     */
    @Bean
    public DirectExchange orderDirectExchange() {
        return new DirectExchange(ORDER_EXCHANGE, true, false);
    }

    /**
     * 队列绑定交换机
     *
     * @return
     */
    @Bean
    public Binding bindingOrderApply() {
        return BindingBuilder.bind(orderApplyQueue()).to(orderDirectExchange()).with(ORDER_APPLY_QUEUE);
    }

    @Bean
    public Binding bindingOrderFile() {
        return BindingBuilder.bind(orderFileQueue()).to(orderDirectExchange()).with(ORDER_FILE_QUEUE);
    }
}
