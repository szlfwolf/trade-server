package com.smartpay.cbp.core.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * @author Carer
 * @desc
 * @date 2022/11/21 9:46
 */
@ApiModel(value = "用户信息查询参数")
@Data
@EqualsAndHashCode(callSuper = false)
public class MerchantUserPageReqDto implements Serializable {

    private static final long serialVersionUID = 6081568369041703403L;

    /**
     * 商户号
     */
    @ApiModelProperty(value = "商户号")
    private String merchantNo;

    /**
     * 创建起始日期
     */
    @ApiModelProperty(value = "创建起始日期：yyyy-MM-dd")
    private LocalDate crtStart;

    /**
     * 创建结束日期
     */
    @ApiModelProperty(value = "创建结束日期：yyyy-MM-dd")
    private LocalDate crtEnd;

    /**
     * 状态
     */
    @ApiModelProperty(value = "状态")
    private String status;

    /**
     * 卖家编号
     */
    @ApiModelProperty(value = "卖家编号")
    private String merchantUserNo;

    /**
     * 用户编号
     */
    @ApiModelProperty(value = "用户编号")
    private String userNo;

    /**
     * 渠道用户号
     */
    @ApiModelProperty(value = "渠道用户号")
    private String openUserNo;

    /**
     * 用户类型,${@link com.smartpay.cbp.core.constant.UserType}
     */
    @ApiModelProperty(value = "用户类型")
    private String userType;

    /**
     * 用户名称
     */
    @ApiModelProperty(value = "用户名称")
    private String name;

    /**
     * 证件号
     */
    @ApiModelProperty(value = "证件号")
    private String certId;
}
