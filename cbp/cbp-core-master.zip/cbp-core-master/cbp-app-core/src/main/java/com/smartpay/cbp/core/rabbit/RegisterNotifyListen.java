package com.smartpay.cbp.core.rabbit;

import com.smartpay.cbp.channel.constant.ServerChannelConstants;
import com.smartpay.cbp.channel.dto.RegisterNotifyInfoDto;
import com.smartpay.cbp.core.service.ChannelRemoteApiService;
import com.smartpay.cbp.core.service.UserRegisterService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.amqp.rabbit.annotation.*;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

/**
 * @author Carer
 * @desc
 * @date 2022/11/17 16:51
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class RegisterNotifyListen {

    private final RedissonClient redissonClient;

    private final ChannelRemoteApiService channelRemoteApiService;

    private final UserRegisterService userRegisterService;

    /**
     * 监听 备案银行回调 队列的处理器
     * @param message 消息
     */
    @RabbitListener(bindings = {@QueueBinding(value = @Queue(value = ServerChannelConstants.REGISTER_NOTIFY_QUEUE)
            ,exchange = @Exchange(ServerChannelConstants.CHANNEL_EXCHANGE)
            ,key = ServerChannelConstants.REGISTER_NOTIFY_QUEUE )} )
    @RabbitHandler
    public void onMessage(Message<String> message) {
        log.info("备案回调监听到回调信息：{}",message.getPayload());
        RLock lock = redissonClient.getLock(message.getPayload());
        try {
            if (!lock.tryLock()) {
                log.warn("备案回调监听获取锁失败！");
                return;
            }
            RegisterNotifyInfoDto registerNotifyInfo = channelRemoteApiService.getRegisterNotifyInfoById(message.getPayload());
            userRegisterService.dealRegisterNotify(registerNotifyInfo);
            channelRemoteApiService.updateNotifyDealResult(message.getPayload());
        }finally {
            lock.unlock();
        }
    }
}
