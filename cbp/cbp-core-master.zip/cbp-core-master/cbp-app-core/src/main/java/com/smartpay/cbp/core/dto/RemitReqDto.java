package com.smartpay.cbp.core.dto;

import com.smartpay.cbp.core.enums.CurrencyType;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @Description: 发起提现请求DTO
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/3 20:56
 * @Version: 1.0
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ApiModel("提现请求")
public class RemitReqDto {

    @ApiModelProperty("批次号")
    private String batchNo;

    @NotBlank(message = "汇款币种不能为空")
    @ApiModelProperty(value = "汇款币种",required = true)
    private CurrencyType remitCur;

    @ApiModelProperty("商户号")
    private String merchantNo;

    @NotBlank(message = "短信验证码不能为空")
    @ApiModelProperty(value = "短信验证码",required = true)
    private String code;

    @NotBlank(message = "手机号不能为空")
    @ApiModelProperty(value = "手机号",required = true)
    private String phoneNo;

    @NotBlank(message = "汇款文件id不能为空")
    @ApiModelProperty(value = "汇款文件id",required = true)
    private String fileId;

    @ApiModelProperty("提现来源")
    private String source;

}
