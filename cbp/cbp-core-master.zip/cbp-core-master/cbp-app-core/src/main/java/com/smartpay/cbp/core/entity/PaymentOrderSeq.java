package com.smartpay.cbp.core.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.util.Date;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 订单批次表
 * </p>
 *
 * @author cbp-system
 * @since 2022-11-07
 */
@Getter
@Setter
@TableName("t_payment_order_seq")
@ApiModel(value = "PaymentOrderSeq对象", description = "订单批次表")
public class PaymentOrderSeq implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private String id;

    @ApiModelProperty("批次号")
    private String batchNo;

    @ApiModelProperty("用户号")
    private String merchantNo;

    @ApiModelProperty("支付币种")
    private String payCur;

    @ApiModelProperty("数据来源：on_shore off_shore")
    private String sourceSys;

    @ApiModelProperty("文件名")
    private String fileName;

    @ApiModelProperty("文件类型")
    private String fileType;

    @ApiModelProperty("文件ID")
    private String fileId;

    @ApiModelProperty("总笔数")
    private Long totalCnt;

    @ApiModelProperty("总金额")
    private Long totalAmt;

    @ApiModelProperty("成功笔数")
    private Long successCnt;

    @ApiModelProperty("成功金额")
    private Long successAmt;

    @ApiModelProperty("成功文件名")
    private String successFileName;

    @ApiModelProperty("成功文件ID")
    private String successFileId;

    @ApiModelProperty("失败笔数")
    private Long failCnt;

    @ApiModelProperty("失败金额")
    private Long failAmt;

    @ApiModelProperty("失败文件名")
    private String failFileName;

    @ApiModelProperty("失败文件ID")
    private String failFileId;

    @ApiModelProperty("渠道文件名")
    private String channelFileName;

    @ApiModelProperty("渠道文件ID")
    private String channelFileId;

    @ApiModelProperty("批次异常原因")
    private String errorMsg;

    @ApiModelProperty("状态：10-初始化 20-校验成功 30-部分成功 40-失败")
    private String status;

    @ApiModelProperty("备注")
    private String remark;

    @ApiModelProperty("创建时间")
    private Date crtTime;

    @ApiModelProperty("创建人")
    private String crtBy;

    @ApiModelProperty("更新人")
    private String uptBy;

    @ApiModelProperty("更新时间")
    private Date uptTime;


}
