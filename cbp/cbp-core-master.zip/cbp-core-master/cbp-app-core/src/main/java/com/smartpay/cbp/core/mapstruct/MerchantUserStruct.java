package com.smartpay.cbp.core.mapstruct;

import com.smartpay.cbp.channel.constant.ServerChannelConstants;
import com.smartpay.cbp.channel.dto.MerchantUserInfoReqDto;
import com.smartpay.cbp.core.dto.MerchantUserDetailDto;
import com.smartpay.cbp.core.dto.MerchantUserPageRspDto;
import com.smartpay.cbp.core.entity.MerchantUserEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * @author Carer
 * @desc
 * @date 2022/11/15 17:08
 */
@Mapper(componentModel = "spring",imports = {ServerChannelConstants.class})
public interface MerchantUserStruct {

    /**
     * 转换
     * @param merchantUserEntity 原始对象
     * @return DTO
     */
    @Mapping(target = "uploadFiles", ignore = true)
    @Mapping(target = "name", source = "nameEnc")
    @Mapping(target = "mobileNo", source = "mobileNoEnc")
    @Mapping(target = "certId", source = "certIdEnc")
    MerchantUserInfoReqDto toDto(MerchantUserEntity merchantUserEntity);

    /**
     * 转换
     * @param merchantUserEntity 原始对象
     * @return 分页对象
     */
    @Mapping(target = "merchantName", ignore = true)
    @Mapping(target = "checkPerson", source = "approvePerson")
    MerchantUserPageRspDto toRspDto(MerchantUserEntity merchantUserEntity);

    /**
     * 转换
     *
     * @param merchantUserEntity 原始对象
     * @return DTO
     */
    @Mapping(target = "areaName", expression = "java(ServerChannelConstants.getAreaCodeMap().get(merchantUserEntity.getAreaCode()))")
    MerchantUserDetailDto toDetailDto(MerchantUserEntity merchantUserEntity);
}
