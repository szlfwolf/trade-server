package com.smartpay.cbp.core.rabbit;

import com.smartpay.cbp.core.constants.Constants;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.*;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

/**
 * @author Carer
 * @desc
 * @date 2022/11/9 14:19
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class NotifyOutSideListen {

    /**
     * 监听 离岸通知 队列的处理器
     * @param message 消息
     */
    @RabbitListener(bindings = {@QueueBinding(value = @Queue(value = Constants.NOTIFY_OUTSIDE_QUEUE)
            ,exchange = @Exchange(Constants.CORE_EXCHANGE),key = Constants.NOTIFY_OUTSIDE_QUEUE )} )
    @RabbitHandler
    public void onMessage(Message<String> message) {
        log.info("离岸结果通知监听发送，通知原数据key:{}",message.getPayload());
    }
}
