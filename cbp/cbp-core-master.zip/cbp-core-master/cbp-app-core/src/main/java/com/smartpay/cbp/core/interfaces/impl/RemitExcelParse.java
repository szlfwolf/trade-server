package com.smartpay.cbp.core.interfaces.impl;

import cn.hutool.poi.excel.ExcelReader;
import cn.hutool.poi.excel.ExcelUtil;
import com.smartpay.cbp.core.dto.RemitOrderDto;
import com.smartpay.cbp.core.interfaces.RemitFileParse;
import com.smartpay.cbp.core.util.ExcelFieldUtil;

import java.io.InputStream;
import java.util.List;

/**
 * @Description: 提现excel文件解析
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/14 17:27
 * @Version: 1.0
 */
public class RemitExcelParse implements RemitFileParse {
    @Override
    public List<RemitOrderDto> parse(InputStream is) {
        ExcelReader reader = ExcelUtil.getReader(is);
        reader.setHeaderAlias(ExcelFieldUtil.getHeaderAlias(RemitOrderDto.class, ExcelFieldUtil.HeaderAliasType.Reader));
        return reader.read(1, 1, RemitOrderDto.class);
    }
}
