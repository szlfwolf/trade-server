package com.smartpay.cbp.core.dto;

import cn.hutool.core.collection.CollUtil;
import lombok.Data;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author ：jmwang
 * @version ：V1.0
 * @description ：失败订单对象
 * @date ：2022/11/11 15:28
 */
@Data
public class PaymentOrderFailDto extends PaymentOrderDto{

    /**
     * 失败明细
     */
    List<String> message;

    public String buildMessage() {
        if (CollUtil.isEmpty(message)) {
            return "";
        }
        return message.stream().collect(Collectors.joining(","));
    }

}
