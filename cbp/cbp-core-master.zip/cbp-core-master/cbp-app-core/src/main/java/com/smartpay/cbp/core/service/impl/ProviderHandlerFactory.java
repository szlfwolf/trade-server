package com.smartpay.cbp.core.service.impl;

import com.smartpay.cbp.core.annotation.ProviderHandler;
import com.smartpay.cbp.core.enums.ProviderType;
import com.smartpay.cbp.core.service.FileParseHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author ：jmwang
 * @version ：V1.0
 * @description ：接口实现注册工厂
 * @date ：2022/11/8 15:40
 */
@Component
public class ProviderHandlerFactory {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ApplicationContext context;

    private static final Map<ProviderType, FileParseHandler> fileParseHandlers = new ConcurrentHashMap<>();
    //private static final Map<ProviderType, SyncRemitHandler> syncRemitHandlers = new ConcurrentHashMap<>();

    @PostConstruct
    private void init() {
        for (FileParseHandler e : context.getBeansOfType(FileParseHandler.class).values()) {
            putHandler(fileParseHandlers, e);
        }
        /*for (SyncRemitHandler e : context.getBeansOfType(SyncRemitHandler.class).values()) {
            putHandler(syncRemitHandlers, e);
        }*/
    }

    public FileParseHandler getFileParseHandler(ProviderType provider) {
        return fileParseHandlers.get(provider);
    }


    private <H> void putHandler(Map<ProviderType, H> map, H handler) {
        logger.debug("工厂处理器{}加载中..", handler.getClass().getSimpleName());
        ProviderHandler providerHandler = handler.getClass().getAnnotation(ProviderHandler.class);
        if (null != providerHandler) {
            if (null != map.putIfAbsent(providerHandler.provider(), handler)) {
                logger.error("工厂{}加载了重复的处理器{}！", providerHandler.provider().getDesc(), handler.getClass().getSimpleName());
                throw new RuntimeException("工厂处理器加载异常！");
            }
            logger.debug("工厂{}处理器{}加载成功", providerHandler.provider().getDesc(), handler.getClass().getSimpleName());
        }
    }
}
