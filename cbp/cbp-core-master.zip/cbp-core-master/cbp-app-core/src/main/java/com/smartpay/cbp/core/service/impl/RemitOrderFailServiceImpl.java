package com.smartpay.cbp.core.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.smartpay.cbp.core.entity.RemitOrderFail;
import com.smartpay.cbp.core.mapper.RemitOrderFailMapper;
import com.smartpay.cbp.core.service.RemitOrderFailService;
import org.springframework.stereotype.Service;

import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * @author admin
 * @description 针对表【t_remit_order_fail(商户提现订单校验失败表)】的数据库操作Service实现
 * @createDate 2022-11-09 11:21:39
 */
@Service
public class RemitOrderFailServiceImpl extends ServiceImpl<RemitOrderFailMapper, RemitOrderFail>
        implements RemitOrderFailService {

    /**
     * 根据提现请求id查询校验失败订单
     *
     * @param remitReqId 提现请求id
     * @return
     */
    @Override
    public List<RemitOrderFail> listByRemitReqId(@NotNull String remitReqId) {
        return lambdaQuery().eq(RemitOrderFail::getRemitReqId, remitReqId)
                .eq(RemitOrderFail::getDelFlag, false)
                .list();
    }
}




