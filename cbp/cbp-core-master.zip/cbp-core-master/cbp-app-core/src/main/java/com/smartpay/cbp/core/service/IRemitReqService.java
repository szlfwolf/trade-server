package com.smartpay.cbp.core.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.smartpay.cbp.core.dto.RemitOrderQueryDto;
import com.smartpay.cbp.core.dto.RemitReqDto;
import com.smartpay.cbp.core.dto.RemitReqQueryDto;
import com.smartpay.cbp.core.dto.RemitReviewDto;
import com.smartpay.cbp.core.entity.RemitOrder;
import com.smartpay.cbp.core.entity.RemitReq;

import java.util.List;

/**
 * @author guogangqiang
 * @description 针对表【t_remit_req】的数据库操作Service
 * @createDate 2022-11-03 20:49:19
 */
public interface IRemitReqService extends IService<RemitReq> {

    /**
     * 发起提现申请
     *
     * @param remitReqDTO {@link RemitReqDto} 提现请求DTO
     */
    void remitApply(RemitReqDto remitReqDTO);


    /**
     * 提现审核
     *
     * @param remitReviewDTO {@link RemitReviewDto} 提现审核DTO
     */
    void remitReview(RemitReviewDto remitReviewDTO);

    boolean existFileId(String merchantNo, String fileId);

    boolean existBatchNo(String merchantNo,String batchNo);

    /**
     * 条件查询
     *
     * @param condition 条件筛选实体
     * @return 提现订单
     */
    List<RemitReq> list(RemitReqQueryDto condition);

}
