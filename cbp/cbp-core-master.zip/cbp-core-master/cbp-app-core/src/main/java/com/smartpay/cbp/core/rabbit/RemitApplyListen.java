package com.smartpay.cbp.core.rabbit;

import com.alibaba.fastjson.JSON;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.collect.Sets;
import com.rabbitmq.client.Channel;
import com.smartpay.cbp.console.dto.MerchantChargeFeignDto;
import com.smartpay.cbp.core.config.IdGenerator;
import com.smartpay.cbp.core.config.RemitRabbitConfig;
import com.smartpay.cbp.core.constants.Constants;
import com.smartpay.cbp.core.dto.FileInfoDto;
import com.smartpay.cbp.core.dto.MerchantUserRegCheckReqDto;
import com.smartpay.cbp.core.dto.RemitOrderDto;
import com.smartpay.cbp.core.dto.RemitOrderFailMqDto;
import com.smartpay.cbp.core.entity.RemitOrder;
import com.smartpay.cbp.core.entity.RemitOrderFail;
import com.smartpay.cbp.core.entity.RemitReq;
import com.smartpay.cbp.core.enums.*;
import com.smartpay.cbp.core.factory.RemitFileParseFactory;
import com.smartpay.cbp.core.handler.RemoteCallHandler;
import com.smartpay.cbp.core.interfaces.RemitFileParse;
import com.smartpay.cbp.core.mapstruct.RemitOrderFailMapStruct;
import com.smartpay.cbp.core.mapstruct.RemitOrderMapStruct;
import com.smartpay.cbp.core.service.FileService;
import com.smartpay.cbp.core.service.IRemitOrderService;
import com.smartpay.cbp.core.service.IRemitReqService;
import com.smartpay.cbp.core.service.RemitOrderFailService;
import com.smartpay.cbp.core.util.SequenceUtil;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.*;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Supplier;
import java.util.stream.Collectors;

/**
 * @Description:提现申请监听
 * @Author:Guogangqiang
 * @CreateDate:2022/11/9 14:21
 * @Version:1.0
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class RemitApplyListen {

    private final RemitOrderFailService remitOrderFailService;

    private final FileService fileService;

    private final IRemitReqService remitReqService;

    private final RabbitTemplate rabbitTemplate;
    private final IdGenerator idGenerator;

    private final RemitOrderFailMapStruct remitOrderFailMapStruct;

    private final RemitOrderMapStruct remitOrderMapStruct;

    private final RemoteCallHandler remoteCallHandler;

    private final IRemitOrderService remitOrderService;

    private final RedissonClient redissonClient;

    /**
     * 存储手续费信息
     */
    private static final Cache<String, MerchantChargeFeignDto> CHARGE_CACHE = CacheBuilder.newBuilder()
            .concurrencyLevel(Runtime.getRuntime().availableProcessors())
            .maximumSize(20)
            .expireAfterWrite(3, TimeUnit.MINUTES)
            .build();


    /**
     * 监听提现生成失败文件
     *
     * @param message mq消息
     */
    @SneakyThrows
    @RabbitListener(bindings = {@QueueBinding(value = @Queue(value = RemitRabbitConfig.REMIT_APPLY_QUEUE)
            , exchange = @Exchange(RemitRabbitConfig.REMIT_EXCHANGE), key = RemitRabbitConfig.REMIT_APPLY_QUEUE)}
            , ackMode = "MANUAL")
    @RabbitHandler
    public void onMessage(Message message, Channel channel, String msg) {
        MessageProperties messageProperties = message.getMessageProperties();
        try {
            //预取模式：10条处理完成再次消费
            channel.basicQos(0, 10, false);
            if (log.isInfoEnabled()) {
                log.info("【开始】解析提现申请文件，提现申请id：{}", msg);
            }

            RemitReq remitReq = remitReqService.getById(msg);
            if (Objects.nonNull(remitReq)) {
                //获取文件解析订单数据
                FileInfoDto fileInfoDto = fileService.getFileByFileId(remitReq.getFileId(), true);
                if (Objects.isNull(fileInfoDto)) {
                    log.error("【结束】提现文件获取为空，提现请求id:{}", msg);
                    channel.basicAck(messageProperties.getDeliveryTag(), true);
                    return;
                }

                RemitFileParse fileParse = RemitFileParseFactory.instance(FileType.suffixToFileType(fileInfoDto.getSuffix()));
                List<RemitOrderDto> remitOrderDtoList = fileParse.parse(fileInfoDto.getFileData());
                if (CollectionUtils.isEmpty(remitOrderDtoList)) {
                    log.error("【结束】提现文件内容为空，提现请求id:{}", msg);
                    channel.basicAck(messageProperties.getDeliveryTag(), true);
                    return;
                }

                AtomicReference<List<RemitOrderDto>> successOrderDTOAtomic = new AtomicReference<>();
                AtomicReference<List<RemitOrderDto>> failOrderDTOAtomic = new AtomicReference<>();
                //校验提现订单数据并将校验成功订单入库
                boolean success = saveRemitOrder(remitReq, fileInfoDto.getFullName(), remitOrderDtoList, successOrderDTOAtomic, failOrderDTOAtomic);
                if (!success) {
                    return;
                }
                //保存校验失败订单
                saveFailOrders(failOrderDTOAtomic.get(), msg, remitReq.getMerchantNo());
                if (log.isInfoEnabled()) {
                    int failSize = failOrderDTOAtomic.get().size();
                    log.info("【解析】校验成功提现订单数:{}", remitOrderDtoList.size() - failSize);
                    log.info("【解析】校验失败提现订单数:{}", failSize);
                }
            } else {
                log.error("【结束】MQ未查询到提现请求,提现请求id:{}", msg);
            }
            log.info("【结束】提现请求文件解析成功，提现请求id:{},提现请求批次号：{}", msg, remitReq.getBatchNo());
            channel.basicAck(messageProperties.getDeliveryTag(), true);
        } catch (IOException e) {
            log.error("【异常】MQ消费生成提现订单校验失败文件异常", e);
            channel.basicNack(messageProperties.getDeliveryTag(), false, true);
        }
    }

    /**
     * 校验并保存提现请求
     *
     * @param remitReq              提现请求
     * @param fileName              提现文件名称
     * @param remitOrderDtos        文件解析提现订单数据
     * @param successOrderDTOAtomic 校验成功订单
     * @param failOrderDTOAtomic    校验失败订单
     * @return 提现请求id
     */
    private boolean saveRemitOrder(RemitReq remitReq, String fileName, List<RemitOrderDto> remitOrderDtos,
                                   AtomicReference<List<RemitOrderDto>> successOrderDTOAtomic,
                                   AtomicReference<List<RemitOrderDto>> failOrderDTOAtomic) {
        return lockHandle(remitReq.getBatchNo(), () -> {
            //校验提现订单
            Map<ValidateResult, List<RemitOrderDto>> validateResultMap = validateRemitOrder(remitReq, remitOrderDtos);
            successOrderDTOAtomic.set(Optional.ofNullable(validateResultMap.get(ValidateResult.SUCCESS))
                    .orElse(new ArrayList<>()));
            failOrderDTOAtomic.set(Optional.ofNullable(validateResultMap.get(ValidateResult.FAIL))
                    .orElse(new ArrayList<>()));
            //校验成功提现订单
            List<RemitOrderDto> successOrderDTOs = successOrderDTOAtomic.get();
            //校验失败提现订单
            List<RemitOrderDto> failOrderDTOs = failOrderDTOAtomic.get();
            //保存校验成功订单
            List<RemitOrderDto> failOrders = saveSuccessOrders(successOrderDTOs, remitReq.getId(), remitReq.getMerchantNo());
            //计算校验成功总金额
            long totalSuccessAmount = successOrderDTOs.stream().mapToLong(remitOrder -> centuplicate(remitOrder.getAmt())).sum();
            //计算批次总金额
            long totalAmount = remitOrderDtos.stream().mapToLong(remitOrder -> centuplicate(remitOrder.getAmt())).sum();
            if (CollectionUtils.isNotEmpty(failOrders)) {
                long failAmount = failOrders.stream().mapToLong(remitOrder -> centuplicate(remitOrder.getAmt())).sum();
                totalSuccessAmount = totalSuccessAmount - failAmount;
                failOrders.addAll(failOrderDTOAtomic.get());
                failOrderDTOAtomic.set(failOrders);
            }
            //设置请求状态
            String status;
            if (CollectionUtils.isEmpty(successOrderDTOs)) {
                status = String.valueOf(RemitReqStatus.VERIFY_FAIL.ordinal());
            } else {
                status = CollectionUtils.isEmpty(failOrderDTOs)
                        ? String.valueOf(RemitReqStatus.VERIFY_SUCCESS_ALL.ordinal())
                        : String.valueOf(RemitReqStatus.VERIFY_SUCCESS_PART.ordinal());
            }
            remitReq.setTotalAmount(totalAmount)
                    .setTotalCount(remitOrderDtos.size())
                    .setTotalSuccessCount(successOrderDTOs.size() - failOrders.size())
                    .setTotalSuccessAmount(totalSuccessAmount)
                    .setStatus(status)
                    .setFileName(fileName)
                    .setRemitCur(remitReq.getRemitCur())
                    .setRemitNo(SequenceUtil.genSerialNo(SequenceType.REMIT_APPLY));
            //修改提现请求
            remitReqService.updateById(remitReq);
            return true;
        });
    }

    /**
     * 保存成功订单
     *
     * @param successOrders 校验通过订单
     * @param remitReqId    提现请求id
     * @param merchantNo    商户号
     * @return 保存失败订单
     */
    private List<RemitOrderDto> saveSuccessOrders(List<RemitOrderDto> successOrders, String remitReqId, String merchantNo) {
        List<RemitOrderDto> failOrders = new ArrayList<>();
        //保存校验成功提现请求明细
        List<RemitOrder> successOrderList = successOrders.stream()
                .map(remitOrderDTO -> {
                    //查询该商户该产品类型手续费配置
                    MerchantChargeFeignDto chargeInfo = getChargeInfo(merchantNo, remitOrderDTO.getProductCode());
                    if (Objects.isNull(chargeInfo)) {
                        StringBuilder errorMsg = new StringBuilder(",不支持的产品类型");
                        remitOrderDTO.setValidateResult(ValidateResult.FAIL);
                        remitOrderDTO.setValidateErrMsg(splitFirstComma(errorMsg));
                        failOrders.add(remitOrderDTO);
                        return null;
                    }
                    RemitOrder remitOrder = remitOrderMapStruct.toRemitOrder(remitOrderDTO);
                    remitOrder.setAmt(centuplicate(remitOrderDTO.getAmt()));
                    //计算手续费
                    long feeAmt = getFeeAmt(chargeInfo, remitOrder.getAmt());
                    remitOrder.setFeeCurrencyType(chargeInfo.getChargeCurrency())
                            .setFeeAmt(feeAmt)
                            .setRemitReqId(remitReqId)
                            .setStatus(String.valueOf(RemitOrderStatus.INIT.ordinal()))
                            .setMerchantNo(merchantNo)
                            //金额乘100
                            .setAmt(centuplicate(String.valueOf(remitOrder.getAmt())))
                            .setId(idGenerator.nextId());
                    return remitOrder;
                })
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
        //保存提现明细
        if (CollectionUtils.isNotEmpty(successOrderList)) {
            remitOrderService.saveBatch(successOrderList);
        }
        return failOrders;
    }

    /**
     * 计算手续费
     *
     * @param chargeInfo
     * @param amt
     * @return
     */
    private long getFeeAmt(MerchantChargeFeignDto chargeInfo, Long amt) {
        String calculatePattern = Optional.ofNullable(chargeInfo.getCalculatePattern()).orElse("3");
        switch (calculatePattern) {
            case "1":
                BigDecimal amtDecimal = new BigDecimal(amt + "");
                BigDecimal ratePerTxnDecimal = new BigDecimal(chargeInfo.getRatePerTxn());
                long feeAmt = amtDecimal.multiply(ratePerTxnDecimal).divide(BigDecimal.valueOf(10000), 0, RoundingMode.DOWN).longValue();
                long feeMax = Long.parseLong(chargeInfo.getFeeMax());
                long feeMin = Long.parseLong(chargeInfo.getFeeMin());
                if (feeAmt > feeMax) {
                    return feeMax;
                } else if (feeAmt < feeMin) {
                    return feeMin;
                }
                return feeAmt;
            case "2":
                return Long.parseLong(chargeInfo.getFixedAmount());
            default:
                return 0L;
        }
    }


    /**
     * 获取手续费信息
     *
     * @param merchantNo
     * @param productCode
     * @return
     */
    private MerchantChargeFeignDto getChargeInfo(String merchantNo, String productCode) {
        MerchantChargeFeignDto chargeInfoCache = CHARGE_CACHE.getIfPresent(String.format("%s:%s", merchantNo, productCode));
        if (Objects.isNull(chargeInfoCache)) {
            MerchantChargeFeignDto chargeInfo = remoteCallHandler.getChargeInfo(merchantNo, productCode);
            if (Objects.isNull(chargeInfo)) {
                return null;
            }
            CHARGE_CACHE.put(String.format("%s:%s", merchantNo, productCode), chargeInfo);
            return chargeInfo;
        }
        return chargeInfoCache;
    }


    /**
     * 保存校验失败订单
     *
     * @param failOrderDTOs 失败订单
     * @param remitReqId    提现请求id
     * @param merchantNo    商户号
     */
    private void saveFailOrders(List<RemitOrderDto> failOrderDTOs, String remitReqId, String merchantNo) {
        //保存校验失败订单,投递mq生成失败文件
        List<RemitOrderFail> orderFailList = failOrderDTOs.stream().map(remitOrderDTO -> {
                    RemitOrderFail remitOrderFail = remitOrderFailMapStruct.toRemitOrderFail(remitOrderDTO);
                    remitOrderFail.setRemitReqId(remitReqId);
                    remitOrderFail.setMerchantNo(merchantNo);
                    remitOrderFail.setAmt(centuplicate(remitOrderDTO.getAmt()));
                    remitOrderFail.setId(idGenerator.nextId());
                    return remitOrderFail;
                })
                .collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(orderFailList)) {
            RemitOrderFailMqDto failOrderMqDTO = RemitOrderFailMqDto.builder()
                    .remitReqId(remitReqId)
                    .build();
            //保存失败订单
            remitOrderFailService.saveBatch(orderFailList);
            //投递mq
            rabbitTemplate.convertAndSend(RemitRabbitConfig.REMIT_EXCHANGE,
                    RemitRabbitConfig.REMIT_FAIL_FILE_QUEUE,
                    JSON.toJSONString(failOrderMqDTO));
        }
    }


    /**
     * 校验提现明细（数据库唯一性校验）
     *
     * @param remitReq          提现请求
     * @param remitOrderDtoList 提现明细
     * @return 校验结果
     */
    private Map<ValidateResult, List<RemitOrderDto>> validateRemitOrder(RemitReq remitReq, List<RemitOrderDto> remitOrderDtoList) {
        Set<String> repeatOrderNo = Sets.newHashSet();
        Map<ValidateResult, List<RemitOrderDto>> resultListMap = remitOrderDtoList.stream()
                .peek(remitOrderDTO -> {
                    remitOrderDTO.setCurrencyType(remitReq.getRemitCur())
                            .setMerchantNo(remitReq.getMerchantNo())
                            .setPlatformName(remitOrderDTO.getRemark1())
                            .setRemitType(String.valueOf(RemitType.nameToEnum(remitOrderDTO.getRemitType()).ordinal()))
                            .setBatchNo(remitReq.getBatchNo());
                })
                .peek(remitOrderDTO -> validate(remitOrderDTO, repeatOrderNo))
                .collect(Collectors.groupingBy(RemitOrderDto::getValidateResult));
        List<RemitOrderDto> successRemitOrders = Optional.ofNullable(resultListMap.get(ValidateResult.SUCCESS)).orElse(new ArrayList<>());
        List<RemitOrderDto> failRemitOrders = Optional.ofNullable(resultListMap.get(ValidateResult.FAIL)).orElse(new ArrayList<>());
        if (CollectionUtils.isNotEmpty(successRemitOrders)) {
            //校验订单提现号是否重复
            Set<String> orderNos = successRemitOrders.stream().map(RemitOrderDto::getOrderNo).collect(Collectors.toSet());
            Set<String> repeatOrderNos = remitOrderService.existOrderNo(remitReq.getMerchantNo(), orderNos);
            //校验卖家编号是否在该商户下备案
            MerchantUserRegCheckReqDto merchantUserRegCheckReqDto = new MerchantUserRegCheckReqDto();
            merchantUserRegCheckReqDto.setMerchantNo(remitReq.getMerchantNo());
            merchantUserRegCheckReqDto.setMerchantUserNos(successRemitOrders.stream().map(RemitOrderDto::getPlatformUserNo).collect(Collectors.toSet()));
            List<String> checkFails = remoteCallHandler.checkRegistedBatch(merchantUserRegCheckReqDto);
            for (RemitOrderDto remitOrder : successRemitOrders) {
                StringBuilder errMsg = new StringBuilder();
                if (repeatOrderNos.contains(remitOrder.getOrderNo())) {
                    errMsg.append(",提现订单号已经在系统中存在");
                    remitOrder.setValidateResult(ValidateResult.FAIL);
                }
                if (checkFails.contains(remitOrder.getMerchantNo())) {
                    errMsg.append(",卖家未在该商户下备案");
                    remitOrder.setValidateResult(ValidateResult.FAIL);
                }
                remitOrder.setValidateErrMsg(splitFirstComma(errMsg));
            }
        }
        //失败成功订单重新合并分组
        failRemitOrders.addAll(successRemitOrders);
        return failRemitOrders.stream().collect(Collectors.groupingBy(RemitOrderDto::getValidateResult));
    }


    /**
     * 校验提现订单必填字段(不涉及数据库操作)
     *
     * @param remitOrderDTO {@link RemitOrderDto}
     * @return {@link boolean} 是否校验通过
     */
    private boolean validate(@NotNull RemitOrderDto remitOrderDTO, Set<String> repeatOrderNo) {
        //必填字段校验
        Set<ConstraintViolation<RemitOrderDto>> validateResult = Validation.buildDefaultValidatorFactory()
                .getValidator()
                .validate(remitOrderDTO);
        StringBuilder errMsg = new StringBuilder(validateResult.stream()
                .map(ConstraintViolation::getMessage)
                .collect(Collectors.joining(",")));
        if (Objects.equals(remitOrderDTO.getRemitType(), RemitType.C.name())) {
            if (StringUtils.isBlank(remitOrderDTO.getCnapsNo())) {
                errMsg.append(",对公付款联行号不能为空");
            }
            if (StringUtils.isBlank(remitOrderDTO.getBankBranchName())) {
                errMsg.append(",对公支行名称不能为空");
            }
        }
        //校验文件中是否存在重复订单号
        if (repeatOrderNo.contains(remitOrderDTO.getOrderNo())) {
            errMsg.append(",提现订单号重复");
        } else {
            repeatOrderNo.add(remitOrderDTO.getOrderNo());
        }
        //校验信息写入实体
        remitOrderDTO.setValidateErrMsg(splitFirstComma(errMsg));
        remitOrderDTO.setValidateResult(StringUtils.isBlank(errMsg)
                ? ValidateResult.SUCCESS
                : ValidateResult.FAIL);
        return StringUtils.isBlank(errMsg);
    }


    /**
     * 加锁操作
     *
     * @param batchNo
     * @param supplier
     * @return
     */
    private boolean lockHandle(String batchNo, Supplier supplier) {
        RLock lock = redissonClient.getLock(Constants.REMIT_APPLY_LOCK);
        try {
            boolean locked = lock.tryLock(20, TimeUnit.SECONDS);
            if (!locked) {
                log.error("提现申请请求获取锁失败，提现批次号：{}", batchNo);
                return false;
            }
            supplier.get();
            return true;
        } catch (InterruptedException e) {
            log.error("提现申请请求获取锁失败，提现批次号：{}", batchNo);
            throw new RuntimeException("订单批次[" + batchNo + "]获取锁失败，线程中止");
        } finally {
            lock.forceUnlock();
        }
    }

    /**
     * 乘一百
     *
     * @param amt 金额数值
     * @return 空值返回0
     */
    private long centuplicate(String amt) {
        return new BigDecimal(Optional.ofNullable(amt)
                .orElse(Constants.ZERO))
                .multiply(new BigDecimal(Constants.HUNDRED))
                .longValue();
    }

    /**
     * 去除第一个逗号
     *
     * @param errMsg
     * @return
     */
    private StringBuilder splitFirstComma(StringBuilder errMsg) {
        if (Objects.nonNull(errMsg) && errMsg.length() > 0) {
            String msg = errMsg.toString();
            if (msg.startsWith(",")) {
                return new StringBuilder(msg.substring(1));
            }
        }
        return errMsg;
    }


}
