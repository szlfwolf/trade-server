package com.smartpay.cbp.core.dto;

import com.smartpay.cbp.common.core.annotation.Excel;
import com.smartpay.cbp.core.constant.RegisterStatus;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author Carer
 * @desc  商户用户管理列表页响应字段
 * @date 2022/11/21 9:54
 */
@ApiModel(value = "商户用户管理列表页响应字段")
@Data
@EqualsAndHashCode(callSuper = false)
public class MerchantUserPageRspDto implements Serializable {
    private static final long serialVersionUID = 1467425193775141680L;

    /**
     * 数据主键
     */
    @Excel(name = "数据主键")
    @ApiModelProperty(value = "数据主键")
    private String id;

    /**
     * 系统商户号
     */
    @Excel(name = "系统商户号")
    @ApiModelProperty(value = "系统商户号")
    private String merchantNo;

    /**
     * 商户名称
     */
    @Excel(name = "商户名称")
    @ApiModelProperty(value = "商户名称")
    private String merchantName;

    /**
     * 商户侧用户编号-卖家编号
     */
    @Excel(name = "卖家编号")
    @ApiModelProperty(value = "卖家编号")
    private String merchantUserNo;

    /**
     * 系统用户号-用户编号
     */
    @Excel(name = "用户编号")
    @ApiModelProperty(value = "用户编号")
    private String userNo;

    /**
     * 渠道用户号
     */
    @Excel(name = "渠道用户号")
    @ApiModelProperty(value = "渠道用户号")
    private String openUserNo;

    /**
     * 用户名称，姓名、法人姓名-脱敏
     */
    @Excel(name = "用户名称")
    @ApiModelProperty(value = "用户名称")
    private String nameMask;

    /**
     * 用户类型,${@link com.smartpay.cbp.core.constant.UserType}
     */
    @Excel(name = "用户类型", readConverterExp = "1=企业,2=个人")
    @ApiModelProperty(value = "用户类型")
    private String userType;

    /**
     * 证件号-脱敏
     */
    @Excel(name = "证件号")
    @ApiModelProperty(value = "证件号")
    private String certIdMask;

    /**
     * 状态，${@link RegisterStatus}
     */
    @Excel(name = "状态", readConverterExp = "1=初始化,2=备案中,3=已备案,4=备案失败,5=备案失效")
    @ApiModelProperty(value = "状态")
    private String status;

    /**
     * 创建时间
     */
    @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss", type = Excel.Type.EXPORT)
    @ApiModelProperty(value = "创建时间")
    private LocalDateTime crtTime;

    /**
     * 更新时间
     */
    @Excel(name = "更新时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss", type = Excel.Type.EXPORT)
    @ApiModelProperty(value = "更新时间")
    private LocalDateTime updTime;

    /**
     * 备案备注
     */
    @Excel(name = "备案备注")
    @ApiModelProperty(value = "备案备注")
    private String registerRemark;

    /**
     * 备注
     */
    @Excel(name = "备注")
    @ApiModelProperty(value = "备注")
    private String remark;

    /**
     * 审批人
     */
    @Excel(name = "审批人")
    @ApiModelProperty(value = "审批人")
    private String checkPerson;
}
