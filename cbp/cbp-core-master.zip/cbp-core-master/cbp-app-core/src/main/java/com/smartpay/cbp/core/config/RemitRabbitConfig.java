package com.smartpay.cbp.core.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @Description: Rabbit提现直连交换机配置
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/7 17:45
 * @Version: 1.0
 */
@Configuration
public class RemitRabbitConfig {

    /**
     * 处理提现申请队列
     */
    public static final String REMIT_APPLY_QUEUE = "REMIT_APPLY_QUEUE";
    /**
     * 处理提现申请队列
     */
    public static final String PAYMENT_APPLY_QUEUE = "PAYMENT_APPLY_QUEUE";
    /**
     * 处理提现失败文件队列
     */
    public static final String REMIT_FAIL_FILE_QUEUE = "REMIT_FAIL_FILE_QUEUE";
    /**
     * 提现交换机
     */
    public static final String REMIT_EXCHANGE = "REMIT_EXCHANGE";


    /**
     * 处理提现请求队列
     *
     * @return
     */
    @Bean
    public Queue remitApplyQueue() {
        return new Queue(REMIT_APPLY_QUEUE, true);
    }

    /**
     * 渠道端处理提现请求队列
     *
     * @return
     */
    @Bean
    public Queue paymentApplyQueue() {
        return new Queue(PAYMENT_APPLY_QUEUE, true);
    }

    /**
     * 处理提现校验失败明细生成失败文件
     *
     * @return
     */
    @Bean
    public Queue remitFailFileQueue() {
        return new Queue(REMIT_FAIL_FILE_QUEUE, true);
    }

    /**
     * 提现交换机
     *
     * @return
     */
    @Bean
    public DirectExchange remitDirectExchange() {
        return new DirectExchange(REMIT_EXCHANGE, true, false);
    }

    /**
     * 队列绑定交换机
     *
     * @return
     */
    @Bean
    public Binding bindingRemitApply() {
        return BindingBuilder.bind(remitApplyQueue()).to(remitDirectExchange()).with(REMIT_APPLY_QUEUE);
    }

    @Bean
    public Binding bindingPaymentApply() {
        return BindingBuilder.bind(paymentApplyQueue()).to(remitDirectExchange()).with(PAYMENT_APPLY_QUEUE);
    }

    @Bean
    public Binding bindingRemitFailFile() {
        return BindingBuilder.bind(remitFailFileQueue()).to(remitDirectExchange()).with(REMIT_FAIL_FILE_QUEUE);
    }

}
