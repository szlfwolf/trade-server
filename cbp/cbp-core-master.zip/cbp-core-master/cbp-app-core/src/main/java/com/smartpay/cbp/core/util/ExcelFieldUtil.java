package com.smartpay.cbp.core.util;

import com.smartpay.cbp.core.annotation.ExcelField;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @Description: 获取excel对应表头名称
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/8 16:50
 * @Version: 1.0
 */
public class ExcelFieldUtil {

    /**
     * 获取读取表头别名
     *
     * @param clazz
     * @return
     */
    public static Map<String, String> getHeaderAlias(Class<?> clazz, HeaderAliasType headerAliasType) {
        Field[] declaredFields = clazz.getDeclaredFields();
        HashMap<String, String> map = new LinkedHashMap<>();
        for (Field field : declaredFields) {
            field.setAccessible(true);
            ExcelField annotation = field.getAnnotation(ExcelField.class);
            if (annotation != null) {
                if (HeaderAliasType.Reader == headerAliasType) {
                    map.put(annotation.name(), field.getName());
                } else {
                    map.put(field.getName(), annotation.name());
                }
            }
        }
        return map;
    }


    /**
     * 表头类型
     */
    public enum HeaderAliasType {
        Reader("读取数据表头"),
        writer("写数据表头"),
        ;
        public final String desc;

        HeaderAliasType(String desc) {
            this.desc = desc;
        }

    }

}

