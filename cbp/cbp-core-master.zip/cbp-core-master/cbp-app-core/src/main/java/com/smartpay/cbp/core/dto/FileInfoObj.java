package com.smartpay.cbp.core.dto;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;

import java.io.Serializable;

/**
 * @author Carer
 * @desc
 * @date 2022/11/15 20:40
 */
@Getter
@Builder
@EqualsAndHashCode(callSuper = false)
public class FileInfoObj implements Serializable {
    private static final long serialVersionUID = -9115299181140778310L;

    private final String filePathName;

    private final String fileUrl;
}
