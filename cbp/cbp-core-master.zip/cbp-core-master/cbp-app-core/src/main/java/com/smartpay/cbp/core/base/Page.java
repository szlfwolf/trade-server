package com.smartpay.cbp.core.base;

import com.github.pagehelper.PageInfo;
import com.smartpay.cbp.common.core.domain.R;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.Collection;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/14 13:42
 */
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class Page<E> extends R<Collection<E>> {

    private Long total;

    private int pageNum;

    private int pageSize;

    private int pages;

    public static <E> Page<E> ok(Collection<E> collection, PageInfo pageInfo) {
        Page<E> page = new Page<>();
        page.setCode(R.SUCCESS);
        page.setMsg("success");
        page.setData(collection);
        page.setTotal(pageInfo.getTotal());
        page.setPageNum(pageInfo.getPageNum());
        page.setPageSize(pageInfo.getPageSize());
        page.setPages(pageInfo.getPages());
        return page;
    }
}
