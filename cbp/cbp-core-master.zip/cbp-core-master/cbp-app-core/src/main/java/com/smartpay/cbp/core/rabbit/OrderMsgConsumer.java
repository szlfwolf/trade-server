package com.smartpay.cbp.core.rabbit;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.alibaba.fastjson.JSON;
import com.smartpay.cbp.core.config.OrderDirectRabbitConfig;
import com.smartpay.cbp.core.dto.FileInfoDto;
import com.smartpay.cbp.core.dto.OrderApplyMqDto;
import com.smartpay.cbp.core.dto.OrderValidateDto;
import com.smartpay.cbp.core.dto.PaymentOrderDto;
import com.smartpay.cbp.core.entity.PaymentOrderSeq;
import com.smartpay.cbp.core.enums.OrderApplyStatus;
import com.smartpay.cbp.core.enums.ProviderType;
import com.smartpay.cbp.core.service.*;
import com.smartpay.cbp.core.service.impl.ProviderHandlerFactory;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author ：jmwang
 * @version ：V1.0
 * @description ：订单处理消费
 * @date ：2022/11/9 11:26
 */
@Slf4j
@AllArgsConstructor
@Component
public class OrderMsgConsumer {

    private final IPaymentOrderSeqService paymentOrderSeqService;
    private final IPaymentOrderService paymentOrderService;
    private final OrderValidateService orderValidateService;
    private final ProviderHandlerFactory providerHandlerFactory;
    private final FileService fileService;

    private final RabbitTemplate rabbitTemplate;

    /**
     * Step1: 订单文件解析/数据落库
     *
     * @param message
     */
    @RabbitListener(queues = OrderDirectRabbitConfig.ORDER_APPLY_QUEUE)
    @RabbitHandler
    public void processOrderApply(String message) {
        log.info("开始处理订单批次申报请求：{}", message);
        OrderApplyMqDto dto = JSONUtil.toBean(message, OrderApplyMqDto.class);
        PaymentOrderSeq orderSeq = paymentOrderSeqService.getById(dto.getId());

        if (ObjectUtil.isNull(orderSeq)) {
            log.error("订单申报数据不存在：{}", message);
            return;
        }

        if (!StrUtil.equals(orderSeq.getStatus(), OrderApplyStatus.INIT.getCode())) {
            log.error("订单申报处理状态不正确：{}，status：{}", message, orderSeq.getStatus());
            return;
        }

        FileInfoDto file = fileService.getFileByFileId(orderSeq.getFileId(), true);
        if (ObjectUtil.isNull(file) || file.getFileData() == null) {
            log.error("订单申报文件不存在：{}，fileId：{}", message, orderSeq.getFileId());
            return;
        }

        // 更新处理状态
        orderSeq.setStatus(OrderApplyStatus.PROCESS.getCode());
        paymentOrderSeqService.updateById(orderSeq);

        // 解析订单数据
        FileParseHandler fileParseHandler = providerHandlerFactory.getFileParseHandler(ProviderType.byCode(orderSeq.getFileType()));
        List<PaymentOrderDto> orders = fileParseHandler.parseOrder(file.getFileData());

        // 校验订单数据
        OrderValidateDto validateDto = orderValidateService.validate(orderSeq, orders);

        // todo 失败订单缓存

        // 保存订单
        paymentOrderService.saveBatch(orderSeq, validateDto.getSuccessOrders());

        // 更新批次
        orderSeq.setSuccessCnt(validateDto.getSuccessCnt());
        orderSeq.setFailCnt(validateDto.getFailCnt());
        orderSeq.setTotalAmt(validateDto.getSuccessCnt() + validateDto.getFailCnt());
        orderSeq.setSuccessAmt(validateDto.getSuccessAmt());
        orderSeq.setFailAmt(validateDto.getFailAmt());
        orderSeq.setTotalAmt(validateDto.getSuccessAmt() + validateDto.getFailAmt());
        paymentOrderSeqService.updateById(orderSeq);

        // 异步处理订单文件
        rabbitTemplate.convertAndSend(OrderDirectRabbitConfig.ORDER_EXCHANGE,
                OrderDirectRabbitConfig.ORDER_FILE_QUEUE,
                JSON.toJSONString(message));

        log.info("结束处理订单批次申报请求：{}", message);
    }


    /**
     * Step2：生成成功文件、失败文件、渠道文件
     * @param message
     */
    @RabbitListener(queues = OrderDirectRabbitConfig.ORDER_FILE_QUEUE)
    @RabbitHandler
    public void processOrderFile(String message) {
        log.info("开始处理订单批次文件请求：{}", message);
        OrderApplyMqDto dto = JSONUtil.toBean(message, OrderApplyMqDto.class);
        PaymentOrderSeq orderSeq = paymentOrderSeqService.getById(dto.getId());

        // 生成失败文件
        if (orderSeq.getFailCnt() > 0 && StrUtil.isBlank(orderSeq.getFailFileId())) {
            // todo 生成失败文件
            String fileId = null;

            orderSeq.setFailFileId(fileId);
            orderSeq.setStatus(OrderApplyStatus.COMPLETE.getCode());
            paymentOrderSeqService.updateById(orderSeq);
        }

        // 成功订单文件
        if (orderSeq.getSuccessCnt() > 0 && StrUtil.isBlank(orderSeq.getSuccessFileId())) {
            //todo 生成成功文件
        }

        if (orderSeq.getFailCnt() > 0 && StrUtil.isBlank(orderSeq.getChannelFileId())) {
            // todo 生成渠道文件
            // todo 订单数据同步渠道系统
        }

        // 渠道订单文件
        log.info("结束处理订单批次申报请求：{}", message);
    }



}
