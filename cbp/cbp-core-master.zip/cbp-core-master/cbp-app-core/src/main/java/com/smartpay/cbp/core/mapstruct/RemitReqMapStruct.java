package com.smartpay.cbp.core.mapstruct;

import com.smartpay.cbp.core.dto.RemitReqDto;
import com.smartpay.cbp.core.entity.RemitReq;
import com.smartpay.cbp.core.vo.RemitReqVo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * @Description: 提现请求转换接口
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/7 10:13
 * @Version: 1.0
 */
@Mapper(componentModel = "spring")
public interface RemitReqMapStruct {

    RemitReq toRemitReq(RemitReqDto remitReqDTO);

    @Mapping(expression = "java(remitReq.getStatusName())",target = "statusName")
    RemitReqVo toRemitReqVo(RemitReq remitReq);

}
