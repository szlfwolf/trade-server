package com.smartpay.cbp.core.mapstruct;

import com.smartpay.cbp.core.dto.PaymentOrderDto;
import com.smartpay.cbp.core.entity.PaymentOrder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

/**
 * @author ：jmwang
 * @version ：V1.0
 * @description ：订单明细struct
 * @date ：2022/11/9 09:48
 */
@Mapper(componentModel = "spring")
public interface PaymentOrderStruct {

    /**
     * 文件解析DTO转数据库entity
     * @param dto
     * @return
     */
    @Mapping(source = "orderTime", target = "orderTime", dateFormat = "yyyy-MM-dd HH:mm:ss")
    PaymentOrder convert(PaymentOrderDto dto);

    /**
     * 转换投递MQ实体
     *
     * @param values
     * @return
     */
    default PaymentOrderDto convert(List<String> values) {
        PaymentOrderDto dto = new PaymentOrderDto();
        dto.setSerialNo(values.get(1));
        dto.setOrderNo(values.get(2));
        dto.setOrderTime(values.get(3));
        dto.setPayCur(values.get(4));
        dto.setPayAmtStr(values.get(5));
        dto.setApplyType(values.get(6));
        dto.setRemitBatchNo(values.get(7));
        dto.setOriCur(values.get(8));
        dto.setOriAmtStr(values.get(9));
        dto.setOriRateStr(values.get(10));
        dto.setProductName(values.get(11));
        dto.setProductCode(values.get(12));
        dto.setProductType(values.get(13));
        dto.setProductDesc(values.get(14));
        dto.setProductPrice(values.get(15));
        dto.setProductCount(values.get(16));
        dto.setPlatformName(values.get(17));
        dto.setPlatformType(values.get(18));
        dto.setStoreNo(values.get(19));
        dto.setStoreUrl(values.get(20));
        dto.setLogisticsCompany(values.get(21));
        dto.setLogisticsOrder(values.get(22));
        dto.setPayerName(values.get(23));
        dto.setPayerCountry(values.get(24));
        dto.setPayerAccount(values.get(25));
        dto.setPayeeName(values.get(26));
        dto.setPayeeIdType(values.get(27));
        dto.setPayeeIdNo(values.get(28));
        dto.setPayeeAccount(values.get(29));
        dto.setPayeeAddress(values.get(30));
        dto.setPayeePhone(values.get(31));
        dto.setPayeeType(values.get(32));
        return dto;
    }

}
