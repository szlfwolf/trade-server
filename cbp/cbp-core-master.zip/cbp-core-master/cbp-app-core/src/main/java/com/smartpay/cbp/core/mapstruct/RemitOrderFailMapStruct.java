package com.smartpay.cbp.core.mapstruct;

import com.smartpay.cbp.core.dto.RemitOrderDto;
import com.smartpay.cbp.core.entity.RemitOrderFail;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * @Description: 提现订单校验失败mapstruct接口
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/4 17:44
 * @Version: 1.0
 */
@Mapper(componentModel = "spring")
public interface RemitOrderFailMapStruct {

    @Mapping(target = "failReason",source = "validateErrMsg")
    @Mapping(target = "amt",source = "amt",ignore = true)
    RemitOrderFail toRemitOrderFail(RemitOrderDto remitOrderDTO);

}
