package com.smartpay.cbp.core.service;

import com.smartpay.cbp.core.dto.OrderValidateDto;
import com.smartpay.cbp.core.dto.PaymentOrderDto;
import com.smartpay.cbp.core.entity.PaymentOrderSeq;

import java.util.List;

/**
 * @author ：jmwang
 * @version ：V1.0
 * @description ：
 * @date ：2022/11/10 09:50
 */
public interface OrderValidateService {

    /**
     * 校验订单原始数据
     *
     * @param orderSeq
     * @param orders
     * @return
     */
    OrderValidateDto validate(PaymentOrderSeq orderSeq, List<PaymentOrderDto> orders);

}
