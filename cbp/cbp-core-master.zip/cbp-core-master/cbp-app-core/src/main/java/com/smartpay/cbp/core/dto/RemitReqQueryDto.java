package com.smartpay.cbp.core.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.Date;

/**
 * @Description: 提现请求的查询dto
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/21 11:02
 * @Version: 1.0
 */
@Data
public class RemitReqQueryDto {

    @ApiModelProperty("商户号")
    private String merchantNo;

    @ApiModelProperty("订单批次号")
    private String batchNo;

    @ApiModelProperty("上传文件名")
    private String fileName;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @ApiModelProperty("创建开始时间")
    private Date crtStartTime;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @ApiModelProperty("创建结束时间")
    private Date crtEndTime;

    @ApiModelProperty("订单状态")
    private String status;


}
