package com.smartpay.cbp.core.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.util.Date;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 *
 * </p>
 *
 * @author cbp-system
 * @since 2022-11-07
 */
@Getter
@Setter
@TableName("t_payment_order")
@ApiModel(value = "PaymentOrder对象", description = "")
public class PaymentOrder implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private String id;

    @ApiModelProperty("用户编号")
    private String userNo;

    @ApiModelProperty("渠道备案ID")
    private String userChannelNo;

    @ApiModelProperty("请求批次ID")
    private String seqId;

    @ApiModelProperty("批次号")
    private String batchNo;

    @ApiModelProperty("流水号")
    private String serialNo;

    @ApiModelProperty("订单号")
    private String orderNo;

    @ApiModelProperty("订单时间")
    private Date orderTime;

    @ApiModelProperty("支付币种")
    private String payCur;

    @ApiModelProperty("支付金额")
    private Long payAmt;

    @ApiModelProperty("申报方式，1-卖家申报 2-收款人申报")
    private String applyType;

    @ApiModelProperty("订单状态，10-初始化 20-待报送 30-申报成功 40-申报失败")
    private String status;

    @ApiModelProperty("审核状态，0-待审核 1-通过 2-失败")
    private String reviewStatus;

    @ApiModelProperty("核查状态，0-待审核 1-通过 2-失败")
    private String verifyStatus;

    @ApiModelProperty("附件ID")
    private String fileId;

    @ApiModelProperty("汇款批次号")
    private String remitBatchNo;

    @ApiModelProperty("原始币种")
    private String oriCur;

    @ApiModelProperty("原始金额")
    private Long oriAmt;

    @ApiModelProperty("境外折算汇率")
    private Long oriRate;

    @ApiModelProperty("产品名称")
    private String productName;

    @ApiModelProperty("产品代码")
    private String productCode;

    @ApiModelProperty("产品类型")
    private String productType;

    @ApiModelProperty("产品描述")
    private String productDesc;

    @ApiModelProperty("商品单价")
    private String productPrice;

    @ApiModelProperty("商品数量")
    private String productCount;

    @ApiModelProperty("平台名称，1-境内平台 2-境外平台")
    private String platformName;

    @ApiModelProperty("平台类型")
    private String platformType;

    @ApiModelProperty("店铺编号")
    private String storeNo;

    @ApiModelProperty("店铺链接")
    private String storeUrl;

    @ApiModelProperty("物流公司")
    private String logisticsCompany;

    @ApiModelProperty("物流单号")
    private String logisticsOrder;

    @ApiModelProperty("付款人名称")
    private String payerName;

    @ApiModelProperty("付款人名称_加密")
    private String payerNameEntry;

    @ApiModelProperty("付款人国别")
    private String payerCountry;

    @ApiModelProperty("付款人账号")
    private String payerAccount;

    @ApiModelProperty("付款人账号_加密")
    private String payerAccountEntry;

    @ApiModelProperty("收款人名称")
    private String payeeName;

    @ApiModelProperty("收款人名称_加密")
    private String payeeNameEntry;

    @ApiModelProperty("收款人证件类型")
    private String payeeIdType;

    @ApiModelProperty("收款人证件号")
    private String payeeIdNo;

    @ApiModelProperty("收款人证件号_加密")
    private String payeeIdNoEntry;

    @ApiModelProperty("收款人银行账号")
    private String payeeAccount;

    @ApiModelProperty("收款人银行账号_加密")
    private String payeeAccountEntry;

    @ApiModelProperty("收款人地址")
    private String payeeAddress;

    @ApiModelProperty("收款人电话")
    private String payeePhone;

    @ApiModelProperty("收款人电话_加密")
    private String payeePhoneEntry;

    @ApiModelProperty("收款人类型，10-供应商 11-物流商 99-其他")
    private String payeeType;

    @ApiModelProperty("创建人")
    private String crtBy;

    @ApiModelProperty("创建时间")
    private Date crtTime;

    @ApiModelProperty("更新人")
    private String uptBy;

    @ApiModelProperty("更新时间")
    private Date uptTime;


}
