package com.smartpay.cbp.core.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.smartpay.cbp.core.entity.FileInfoEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author admin
 */
@Mapper
public interface FileInfoMapper extends BaseMapper<FileInfoEntity> {

}