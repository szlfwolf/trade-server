package com.smartpay.cbp.core.service;

import com.smartpay.cbp.core.entity.PaymentOrderSeq;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 订单批次表 服务类
 * </p>
 *
 * @author cbp-system
 * @since 2022-11-07
 */
public interface IPaymentOrderSeqService extends IService<PaymentOrderSeq> {

}
