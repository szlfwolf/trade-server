package com.smartpay.cbp.core.service.impl;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.smartpay.cbp.core.config.IdGenerator;
import com.smartpay.cbp.core.config.RemitRabbitConfig;
import com.smartpay.cbp.core.dto.*;
import com.smartpay.cbp.core.entity.RemitOrder;
import com.smartpay.cbp.core.entity.RemitReq;
import com.smartpay.cbp.core.enums.AppCode;
import com.smartpay.cbp.core.enums.RemitOrderStatus;
import com.smartpay.cbp.core.enums.RemitReqStatus;
import com.smartpay.cbp.core.enums.SequenceType;
import com.smartpay.cbp.core.mapper.RemitReqMapper;
import com.smartpay.cbp.core.mapstruct.RemitOrderMapStruct;
import com.smartpay.cbp.core.mapstruct.RemitReqMapStruct;
import com.smartpay.cbp.core.service.FileService;
import com.smartpay.cbp.core.service.IRemitOrderService;
import com.smartpay.cbp.core.service.IRemitReqService;
import com.smartpay.cbp.core.util.LoginUserUtils;
import com.smartpay.cbp.core.util.SequenceUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * @author guogangqiang
 * @description 针对表【t_remit_req】的数据库操作Service实现
 * @createDate 2022-11-07 11:23:30
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class RemitReqServiceImpl extends ServiceImpl<RemitReqMapper, RemitReq> implements IRemitReqService {

    private final IRemitOrderService remitOrderService;

    private final RemitOrderMapStruct remitOrderMapStruct;
    @Lazy
    @Autowired
    private IRemitReqService remitReqService;

    private final RemitReqMapStruct remitReqMapStruct;

    private final RabbitTemplate rabbitTemplate;
    private final FileService fileService;
    private final IdGenerator idGenerator;


    /**
     * 发起提现申请
     *
     * @param remitReqDTO {@link RemitReqDto} 提现请求DTO
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void remitApply(@Valid @NotNull RemitReqDto remitReqDTO) {

        if (log.isInfoEnabled()) {
            log.info("【开始】接收到提现请求：{}", JSON.toJSONString(remitReqDTO));
        }

        //校验验证码
/*        RBucket<String> phoneCodeBucket = redissonClient.getBucket(String.format("%s_%s", RedisKey.REMIT_PHONE_CODE.name(), remitReqDTO.getPhoneNo()));
        AppCode.B03001.assertHasTrue(Objects.equals(phoneCodeBucket.get(), remitReqDTO.getCode()), "验证码错误手机号:%s", remitReqDTO.getPhoneNo());*/
        //生成批次号
        if (StringUtils.isBlank(remitReqDTO.getBatchNo())) {
            remitReqDTO.setBatchNo(SequenceUtil.genSerialNo(SequenceType.REMIT_APPLY));
        }
        //批次号不能重复
        boolean existBatchNo = remitReqService.existBatchNo(remitReqDTO.getMerchantNo(), remitReqDTO.getBatchNo());
        AppCode.B03007.assertHasFalse(existBatchNo);

        //获取文件解析订单数据
        FileInfoDto fileInfoDto = fileService.getFileByFileId(remitReqDTO.getFileId(), true);
        AppCode.B03004.assertNonNull(fileInfoDto, "提现文件不存在");

        //组装提现请求
        RemitReq remitReq = remitReqMapStruct.toRemitReq(remitReqDTO);
        remitReq.setStatus(String.valueOf(RemitReqStatus.INIT.ordinal()))
                .setFileName(fileInfoDto.getName())
                .setId(idGenerator.nextId())
                .setRemitNo(remitReqDTO.getBatchNo())
                .setCrtBy(LoginUserUtils.getUserId().orElse(null))
                .setUptBy(LoginUserUtils.getUserId().orElse(null));
        //保存提现请求
        remitReqService.save(remitReq);

        //发送MQ后续读取文件处理
        rabbitTemplate.convertAndSend(RemitRabbitConfig.REMIT_EXCHANGE,
                RemitRabbitConfig.REMIT_APPLY_QUEUE,
                remitReq.getId());
        log.info("【结束】提现请求处理成功，请求id:{}", remitReq.getId());

    }

    /**
     * 提现审核
     *
     * @param remitReviewDTO {@link RemitReviewDto} 提现审核DTO
     */
    @Override
    @Transactional
    public void remitReview(@Valid @NotNull RemitReviewDto remitReviewDTO) {
        String userId = LoginUserUtils.getUserId().orElse(null);
        RemitReq remitReq = Optional.ofNullable(remitReqService.getById(remitReviewDTO.getRemitReqId())).orElseThrow(AppCode.B03005::toCodeException);
        //审核通过过不再处理审核逻辑
        if (Objects.equals(remitReq.getStatus(), String.valueOf(RemitReqStatus.REVIEW_PASS.ordinal())) ||
                Objects.equals(remitReq.getStatus(), String.valueOf(RemitReqStatus.PROCESSING.ordinal())) ||
                Objects.equals(remitReq.getStatus(), String.valueOf(RemitReqStatus.PROCESSING_SUCCESS.ordinal())) ||
                Objects.equals(remitReq.getStatus(), String.valueOf(RemitReqStatus.INIT.ordinal()))) {
            throw AppCode.B03010.toCodeException();
        }
        switch (remitReviewDTO.getReviewStatus()) {
            case REFUSE:
                remitReq.setStatus(String.valueOf(RemitReqStatus.REVIEW_NO_PASS.ordinal()));
                remitReq.setReviewTime(new Date());
                break;
            case PASS:
                remitReq.setStatus(String.valueOf(RemitReqStatus.REVIEW_PASS.ordinal()));
                remitReq.setReviewTime(new Date());
                List<RemitOrder> remitOrders = remitOrderService.listByRemitReqId(remitReviewDTO.getRemitReqId());
                //修改提现订单状态为处理中
                remitOrderService.updateStatusByRemitReqId(remitReviewDTO.getRemitReqId(), RemitOrderStatus.PROCESSING, userId);
                //投递mq,进行后续互联网代付
                remitOrders.forEach(remitOrder -> {
                    RemitOrderMqDto remitOrderMqDTO = remitOrderMapStruct.toRemitOrderMqDTO(remitOrder);
                    rabbitTemplate.convertAndSend(RemitRabbitConfig.REMIT_EXCHANGE,
                            RemitRabbitConfig.PAYMENT_APPLY_QUEUE,
                            JSON.toJSONString(remitOrderMqDTO));
                });
                break;
        }
        //修改提现审核状态
        remitReq.setUptBy(userId);
        remitReqService.updateById(remitReq);

    }

    @Override
    public boolean existFileId(String merchantNo, String fileId) {
        return remitReqService.lambdaQuery()
                .eq(RemitReq::getMerchantNo, merchantNo)
                .eq(RemitReq::getFileId, fileId)
                .eq(RemitReq::getDelFlag, false)
                .exists();
    }

    @Override
    public boolean existBatchNo(String merchantNo, String batchNo) {
        return remitReqService.lambdaQuery()
                .eq(RemitReq::getMerchantNo, merchantNo)
                .eq(RemitReq::getFileId, batchNo)
                .eq(RemitReq::getDelFlag, false)
                .exists();
    }

    /**
     * 条件查询
     *
     * @param condition 条件筛选实体
     * @return
     */
    @Override
    public List<RemitReq> list(RemitReqQueryDto condition) {
        return lambdaQuery().eq(StringUtils.isNotBlank(condition.getFileName()), RemitReq::getFileName, condition.getFileName())
                .eq(StringUtils.isNotBlank(condition.getStatus()), RemitReq::getStatus, condition.getStatus())
                .eq(StringUtils.isNotBlank(condition.getMerchantNo()), RemitReq::getMerchantNo, condition.getMerchantNo())
                .eq(StringUtils.isNotBlank(condition.getBatchNo()), RemitReq::getBatchNo, condition.getBatchNo())
                .ge(Objects.nonNull(condition.getCrtStartTime()), RemitReq::getCrtTime, condition.getCrtStartTime())
                .le(Objects.nonNull(condition.getCrtEndTime()), RemitReq::getCrtTime, condition.getCrtEndTime())
                .eq(RemitReq::getDelFlag, false)
                .orderByDesc(RemitReq::getId)
                .list();
    }


}




