package com.smartpay.cbp.core.enums;

import java.util.Arrays;
import java.util.Objects;

/**
 * @Description: 到账类型
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/18 15:47
 * @Version: 1.0
 */
public enum TimeType {

    T_0("当天到账"),
    T_1("明日到账"),

    ;

    public final String comment;

    TimeType(String comment) {
        this.comment = comment;
    }

    public static TimeType ordinalToEnum(String ordinal) {
        return Arrays.stream(TimeType.values()).filter(timeType -> Objects.equals(timeType.ordinal(), Integer.parseInt(ordinal)))
                .findFirst()
                .orElse(T_0);
    }


}
