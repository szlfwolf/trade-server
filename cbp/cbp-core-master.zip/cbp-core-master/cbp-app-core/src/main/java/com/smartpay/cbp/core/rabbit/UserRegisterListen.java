package com.smartpay.cbp.core.rabbit;

import com.smartpay.cbp.channel.dto.MerchantUserInfoReqDto;
import com.smartpay.cbp.channel.dto.UploadRspDto;
import com.smartpay.cbp.core.constant.RegisterStatus;
import com.smartpay.cbp.core.constants.Constants;
import com.smartpay.cbp.core.entity.MerchantUserEntity;
import com.smartpay.cbp.core.mapstruct.MerchantUserStruct;
import com.smartpay.cbp.core.repository.MerchantUserRepository;
import com.smartpay.cbp.core.service.ChannelRemoteApiService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.amqp.rabbit.annotation.*;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author Carer
 * @desc
 * @date 2022/11/8 20:25
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class UserRegisterListen {

    private final RedissonClient redissonClient;

    private final MerchantUserRepository merchantUserRepository;

    private final ChannelRemoteApiService channelRemoteApiService;

    private final MerchantUserStruct merchantUserStruct;
    /**
     * 监听 用户创建 队列的处理器
     * @param message 消息
     */
    @RabbitListener(bindings = {@QueueBinding(value = @Queue(value = Constants.REGISTER_QUEUE)
            ,exchange = @Exchange(Constants.CORE_EXCHANGE),key = Constants.REGISTER_QUEUE )} )
    @RabbitHandler
    public void onMessage(Message<String> message) {
        log.info("用户备案渠道监听发送，渠道备案原数据key:{}",message.getPayload());
        RLock lock = redissonClient.getLock(message.getPayload());
        try {
            if(!lock.tryLock()){
                log.warn("备案获取锁失败！");
                return;
            }
            MerchantUserEntity merchantUserEntity = merchantUserRepository.getById(message.getPayload());
            List<UploadRspDto> uploadRspDtos = channelRemoteApiService.uploadRegisterFile(merchantUserEntity.getChannelNo()
                    , merchantUserEntity.getCertFrontFileId(), merchantUserEntity.getCertBackFileId()
                    , merchantUserEntity.getLicenseFileId());
            MerchantUserInfoReqDto merchantUserInfoReqDto = buildMerchantUserInfo(merchantUserEntity,uploadRspDtos);
            merchantUserEntity.setRegReqId(channelRemoteApiService.channelSend(merchantUserInfoReqDto));
            merchantUserEntity.setStatus(RegisterStatus.REGISTER_ING.getCode());
            merchantUserRepository.updateById(merchantUserEntity);
        }finally {
            lock.unlock();
        }
    }

    private MerchantUserInfoReqDto buildMerchantUserInfo(MerchantUserEntity merchantUserEntity
            , List<UploadRspDto> uploadRspDtos) {
        MerchantUserInfoReqDto merchantUserInfoReqDto = merchantUserStruct.toDto(merchantUserEntity);
        merchantUserInfoReqDto.setUploadFiles(uploadRspDtos);
        return merchantUserInfoReqDto;
    }
}
