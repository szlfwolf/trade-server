package com.smartpay.cbp.core.repository;

import com.baomidou.mybatisplus.extension.service.IService;
import com.smartpay.cbp.core.entity.FileInfoEntity;

import java.io.Serializable;
import java.util.Optional;

/**
 * @author Carer
 * @desc
 * @date 2022/11/7 16:46
 */
public interface FileInfoRepository extends IService<FileInfoEntity> {

    /**
     * 根据主键获取对象
     * @param id 主键
     * @return 非空对象
     */
    Optional<FileInfoEntity> getNonByFileId(Serializable id);

    /**
     * 校验文件是否在系统中
     * @param fileIds 文件主键
     */
    void checkExit(String... fileIds);
}
