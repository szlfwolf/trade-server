package com.smartpay.cbp.core.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.smartpay.cbp.core.entity.RemitOrderFail;

import java.util.List;

/**
 * @author admin
 * @description 针对表【t_remit_order_fail(商户提现订单校验失败表)】的数据库操作Service
 * @createDate 2022-11-09 11:21:39
 */
public interface RemitOrderFailService extends IService<RemitOrderFail> {

    /**
     * 根据提现请求id查询校验失败订单
     *
     * @param remitReqId 提现请求id
     * @return
     */
    List<RemitOrderFail> listByRemitReqId(String remitReqId);


}
