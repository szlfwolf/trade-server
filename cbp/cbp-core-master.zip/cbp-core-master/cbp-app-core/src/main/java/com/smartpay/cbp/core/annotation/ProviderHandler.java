package com.smartpay.cbp.core.annotation;

import com.smartpay.cbp.core.enums.ProviderType;

import java.lang.annotation.*;

/**
 * @author ：jmwang
 * @version ：V1.0
 * @description ：工厂类型注解
 * @date ：2022/11/8 15:40
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
public @interface ProviderHandler {

    ProviderType provider();
}
