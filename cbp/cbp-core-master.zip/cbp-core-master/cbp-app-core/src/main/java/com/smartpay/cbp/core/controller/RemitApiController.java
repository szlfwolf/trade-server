package com.smartpay.cbp.core.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.smartpay.cbp.common.core.domain.R;
import com.smartpay.cbp.common.core.utils.PageUtils;
import com.smartpay.cbp.common.core.utils.poi.ExcelUtil;
import com.smartpay.cbp.core.base.Page;
import com.smartpay.cbp.core.dto.*;
import com.smartpay.cbp.core.entity.RemitOrder;
import com.smartpay.cbp.core.entity.RemitReq;
import com.smartpay.cbp.core.enums.AppCode;
import com.smartpay.cbp.core.handler.RemoteCallHandler;
import com.smartpay.cbp.core.mapstruct.RemitOrderMapStruct;
import com.smartpay.cbp.core.mapstruct.RemitReqMapStruct;
import com.smartpay.cbp.core.response.RemitOrderResponse;
import com.smartpay.cbp.core.service.FileService;
import com.smartpay.cbp.core.service.IRemitOrderService;
import com.smartpay.cbp.core.service.IRemitReqService;
import com.smartpay.cbp.core.util.LoginUserUtils;
import com.smartpay.cbp.core.vo.RemitOrderExportVo;
import com.smartpay.cbp.core.vo.RemitOrderVo;
import com.smartpay.cbp.core.vo.RemitReqVo;
import com.smartpay.cbp.system.api.domain.SysUser;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @Description: 提现控制器
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/8 17:38
 * @Version: 1.0
 */
@Controller
@Slf4j
@RequestMapping("/remit/api")
@Api("提现相关（API）")
@RequiredArgsConstructor
public class RemitApiController {

    private final IRemitReqService remitReqService;

    private final RemitReqMapStruct remitReqMapStruct;

    private final RemoteCallHandler remoteCallHandler;

    private final IRemitOrderService remitOrderService;

    private final RemitOrderMapStruct remitOrderMapStruct;

    private final FileService fileService;


    @GetMapping("/{remitOrderId}")
    @ResponseBody
    @ApiOperation("根据提现订单id获取订单明细")
    public R<RemitOrderResponse> getRemitOrder(@PathVariable("remitOrderId") @NotNull(message = "提现订单id不能为空") String remitOrderId) {
        if (log.isInfoEnabled()) {
            log.info("开始查询提现订单：{}", remitOrderId);
        }
        RemitOrder remitOrder = remitOrderService.getById(remitOrderId);
        return R.ok(remitOrderMapStruct.toRemitOrderResponse(remitOrder));
    }

    @ApiOperation("通知代付结果")
    @PostMapping("/notify")
    @ResponseBody
    public R<Void> notifyRemitResult(@RequestBody @Valid RemitResultDTO remitResultDTO) {
        remitOrderService.notifyResult(remitResultDTO);
        return R.ok();
    }

}
