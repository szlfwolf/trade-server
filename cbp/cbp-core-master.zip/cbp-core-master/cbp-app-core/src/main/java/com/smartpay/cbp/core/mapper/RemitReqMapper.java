package com.smartpay.cbp.core.mapper;

import com.smartpay.cbp.core.entity.RemitReq;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author guogangqiang
* @description 针对表【t_remit_req】的数据库操作Mapper
* @createDate 2022-11-07 11:23:30
* @Entity com.smartpay.cbp.core.entity.RemitReq
*/
public interface RemitReqMapper extends BaseMapper<RemitReq> {

}




