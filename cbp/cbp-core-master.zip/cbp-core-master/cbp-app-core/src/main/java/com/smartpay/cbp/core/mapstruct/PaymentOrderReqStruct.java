package com.smartpay.cbp.core.mapstruct;

import com.smartpay.cbp.core.dto.OrderApplyMqDto;
import com.smartpay.cbp.core.entity.PaymentOrderSeq;
import org.mapstruct.Mapper;

/**
 * @author ：jmwang
 * @version ：V1.0
 * @description ：订单批次struct
 * @date ：2022/11/9 09:48
 */
@Mapper(componentModel = "spring")
public interface PaymentOrderReqStruct {

    /**
     * 转换投递MQ实体
     *
     * @param orderSeq
     * @return
     */
    OrderApplyMqDto convertMq(PaymentOrderSeq orderSeq);

}
