package com.smartpay.cbp.core.interfaces.impl;

import cn.hutool.core.io.IoUtil;
import cn.hutool.core.io.LineHandler;
import cn.hutool.core.util.StrUtil;
import com.smartpay.cbp.core.constants.Constants;
import com.smartpay.cbp.core.dto.RemitOrderDto;
import com.smartpay.cbp.core.interfaces.RemitFileParse;
import lombok.RequiredArgsConstructor;
import org.apache.commons.compress.utils.Lists;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * @Description: 提现csv解析
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/14 17:26
 * @Version: 1.0
 */
@RequiredArgsConstructor
public class RemitCsvParse implements RemitFileParse {


    @Override
    public List<RemitOrderDto> parse(InputStream is) {
        ArrayList<RemitOrderDto> remitOrderDtos = Lists.newArrayList();
        IoUtil.readUtf8Lines(is, (LineHandler) row -> {
            List<String> values = StrUtil.split(row, Constants.CSV_SPLIT);
            RemitOrderDto dto = csvConvert(values);
            remitOrderDtos.add(dto);
        });
        return remitOrderDtos;
    }

    /**
     * 读取csv转换为RemitOrderDTO
     *
     * @param row
     * @return
     */
    private RemitOrderDto csvConvert(List<String> row) {
        return RemitOrderDto.builder()
                .orderNo(row.get(0))
                .amt(row.get(1))
                .platformUserNo(row.get(2))
                .bankName(row.get(3))
                .remitType(row.get(4))
                .timeType(row.get(5))
                .bankAccountNo(row.get(6))
                .bankAccountName(row.get(7))
                .accountIdType(row.get(8))
                .accountIdNo(row.get(9))
                .province(row.get(10))
                .city(row.get(11))
                .bankBranchName(row.get(12))
                .cnapsNo(row.get(13))
                .purpose(row.get(14))
                .remark(row.get(15))
                .mobilePhone(row.get(16))
                .businessType(row.get(17))
                .remark1(row.get(18))
                .remark2(row.get(19))
                .remark3(row.get(20))
                .remark4(row.get(21))
                .productCode(row.get(22))
                .build();
    }
}
