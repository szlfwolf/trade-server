package com.smartpay.cbp.core.dto;

import com.smartpay.cbp.console.dto.MerchantInfoForeignDto;
import com.smartpay.cbp.core.enums.ProviderType;
import lombok.Data;

/**
 * @author ：jmwang
 * @version ：V1.0
 * @description ：
 * @date ：2022/11/8 15:18
 */
@Data
public class OrderApplyDto {

    private String requestId;

    private String sourceSys;

    private String currency;

    private MerchantInfoForeignDto merchant;

    private FileInfoDto file;

    private String fileType;
}
