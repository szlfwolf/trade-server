package com.smartpay.cbp.core.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * @author ：jmwang
 * @version ：V1.0
 * @description ：订单MQ投递参数
 * @date ：2022/11/9 09:45
 */
@Data
public class OrderApplyMqDto implements Serializable {

    private String id;

    private String batchNo;

}
