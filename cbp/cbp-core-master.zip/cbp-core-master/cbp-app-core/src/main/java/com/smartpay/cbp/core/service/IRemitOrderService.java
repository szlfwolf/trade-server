package com.smartpay.cbp.core.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.smartpay.cbp.common.core.domain.R;
import com.smartpay.cbp.core.dto.RemitOrderQueryDto;
import com.smartpay.cbp.core.dto.RemitResultDTO;
import com.smartpay.cbp.core.entity.RemitOrder;
import com.smartpay.cbp.core.enums.RemitOrderStatus;

import java.util.List;
import java.util.Set;

/**
 * @author guogangqiang
 * @description 针对表【t_remit_order(商户下发明细表)】的数据库操作Service
 * @createDate 2022-11-03 20:18:17
 */
public interface IRemitOrderService extends IService<RemitOrder> {

    /**
     * 根据提现id查询提现明细
     *
     * @param remitReqId 提现请求id
     * @return 提现订单明细
     */
    List<RemitOrder> listByRemitReqId(String remitReqId);

    /**
     * 根据提现请求id修改状态
     *
     * @param remitReqId       提现请求id
     * @param remitOrderStatus 提现订单状态
     */
    void updateStatusByRemitReqId(String remitReqId, RemitOrderStatus remitOrderStatus, String uptUserId);

    /**
     * 查询重复的提现订单号
     *
     * @param merchantNo 商户号
     * @param orderNos   订单集合
     * @return
     */
    Set<String> existOrderNo(String merchantNo, Set<String> orderNos);


    /**
     * 条件查询
     *
     * @param condition 条件筛选实体
     * @return 提现订单
     */
    List<RemitOrder> list(RemitOrderQueryDto condition);


    /**
     * 同步代付结果
     *
     * @param remitResultDTO 代付结果
     */
    void notifyResult(RemitResultDTO remitResultDTO);


}
