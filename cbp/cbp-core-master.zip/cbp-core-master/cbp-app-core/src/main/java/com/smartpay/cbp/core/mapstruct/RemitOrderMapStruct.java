package com.smartpay.cbp.core.mapstruct;

import com.smartpay.cbp.core.dto.RemitOrderDto;
import com.smartpay.cbp.core.dto.RemitOrderMqDto;
import com.smartpay.cbp.core.entity.RemitOrder;
import com.smartpay.cbp.core.response.RemitOrderResponse;
import com.smartpay.cbp.core.vo.RemitOrderDetailVo;
import com.smartpay.cbp.core.vo.RemitOrderExportVo;
import com.smartpay.cbp.core.vo.RemitOrderVo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * @Description: 提现订单mapstruct接口
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/4 17:44
 * @Version: 1.0
 */
@Mapper(componentModel = "spring")
public interface RemitOrderMapStruct {

    @Mapping(target = "amt", source = "amt", ignore = true)
    RemitOrder toRemitOrder(RemitOrderDto remitOrderDTO);

    @Mapping(source = "id", target = "remitOrderId")
    RemitOrderMqDto toRemitOrderMqDTO(RemitOrder remitOrder);

    RemitOrderResponse toRemitOrderResponse(RemitOrder remitOrder);

    RemitOrderVo toRemitOrderVo(RemitOrder remitOrder);

    RemitOrderExportVo toRemitOrderExportVo(RemitOrder remitOrder);

    @Mapping(target = "remitTypeName", expression = "java(remitOrder.getRemitTypeName())")
    @Mapping(target = "timeTypeName", expression = "java(remitOrder.getTimeTypeName())")
    RemitOrderDetailVo toRemitOrderDetailVo(RemitOrder remitOrder);

}
