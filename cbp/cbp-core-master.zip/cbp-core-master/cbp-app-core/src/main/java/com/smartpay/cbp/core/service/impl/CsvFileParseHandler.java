package com.smartpay.cbp.core.service.impl;

import cn.hutool.core.io.IoUtil;
import cn.hutool.core.io.LineHandler;
import cn.hutool.core.util.StrUtil;
import com.smartpay.cbp.core.annotation.ProviderHandler;
import com.smartpay.cbp.core.constants.Constants;
import com.smartpay.cbp.core.dto.PaymentOrderDto;
import com.smartpay.cbp.core.enums.ProviderType;
import com.smartpay.cbp.core.mapstruct.PaymentOrderStruct;
import com.smartpay.cbp.core.service.FileParseHandler;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.io.*;
import java.util.ArrayList;
import java.util.List;


/**
 * @author ：jmwang
 * @version ：V1.0
 * @description ：CSV文件解析
 * @date ：2022/11/8 15:41
 */
@ProviderHandler(provider = ProviderType.CSV)
@AllArgsConstructor
@Service
public class CsvFileParseHandler implements FileParseHandler {

    private final PaymentOrderStruct paymentOrderStruct;

    @Override
    public List<PaymentOrderDto> parseOrder(InputStream is) {
        List<PaymentOrderDto> orders = new ArrayList<>();
        IoUtil.readUtf8Lines(is, (LineHandler) row -> {
            List<String> values = StrUtil.split(row, Constants.CSV_SPLIT);
            PaymentOrderDto dto = paymentOrderStruct.convert(values);
            orders.add(dto);
        });
        return orders;
    }
}
