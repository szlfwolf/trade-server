package com.smartpay.cbp.core.service;

import com.smartpay.cbp.console.dto.ChannelInfoFeignDto;
import com.smartpay.cbp.console.dto.MerchantInfoForeignDto;

import java.util.Optional;

/**
 * @author Carer
 * @desc
 * @date 2022/11/8 13:45
 */
public interface ConsoleRemoteApiService {

    /**
     * 根据商户号获取商户信息
     * @param merchantNo 商户号
     * @return 商户信息
     */
    Optional<MerchantInfoForeignDto> getMerchantInfoByMerchantNo(String merchantNo);

    /**
     * 获取可用渠道
     * @return 渠道信息
     */
    Optional<ChannelInfoFeignDto> routeChannel();

    /**
     * 校验商户状态
     * @param merchantNo 商户号
     */
    void checkMerchantStatus(String merchantNo);
}
