package com.smartpay.cbp.core.service.impl;

import com.smartpay.cbp.core.entity.PaymentOrderSeq;
import com.smartpay.cbp.core.mapper.PaymentOrderSeqMapper;
import com.smartpay.cbp.core.service.IPaymentOrderSeqService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 订单批次表 服务实现类
 * </p>
 *
 * @author cbp-system
 * @since 2022-11-07
 */
@Service
public class PaymentOrderSeqServiceImpl extends ServiceImpl<PaymentOrderSeqMapper, PaymentOrderSeq> implements IPaymentOrderSeqService {

}
