package com.smartpay.cbp.core.enums;

import java.util.Arrays;
import java.util.Objects;

/**
 * @Description: 提现请求状态枚举
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/4 11:09
 * @Version: 1.0
 */
public enum RemitReqStatus {

    INIT("初始化"),
    VERIFY_SUCCESS_ALL("校验成功"),
    VERIFY_SUCCESS_PART("校验部分成功"),
    VERIFY_FAIL("校验失败"),
    REVIEW_NO_PASS("审核不通过"),
    REVIEW_PASS("审核通过"),
    PROCESSING("处理中"),
    PROCESSING_SUCCESS("处理成功"),
    ;
    public final String comment;

    RemitReqStatus(String comment) {
        this.comment = comment;
    }

    public static RemitReqStatus toEnumByOrdinal(String ordinal) {
        return Arrays.stream(RemitReqStatus.values())
                .filter(status -> Objects.equals(String.valueOf(status.ordinal()), ordinal))
                .findFirst()
                .orElse(null);
    }

}
