package com.smartpay.cbp.core.repository.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.smartpay.cbp.core.entity.ApproveInfoEntity;
import com.smartpay.cbp.core.mapper.ApproveInfoMapper;
import com.smartpay.cbp.core.repository.ApproveInfoRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

/**
 * @author Carer
 * @desc
 * @date 2022/11/22 14:34
 */
@Repository
@RequiredArgsConstructor
@Slf4j
public class ApproveInfoRepositoryImpl extends ServiceImpl<ApproveInfoMapper, ApproveInfoEntity>
        implements ApproveInfoRepository {
}
