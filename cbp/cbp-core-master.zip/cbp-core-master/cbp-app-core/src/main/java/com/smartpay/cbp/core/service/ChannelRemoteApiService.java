package com.smartpay.cbp.core.service;

import com.smartpay.cbp.channel.dto.MerchantUserInfoReqDto;
import com.smartpay.cbp.channel.dto.RegisterNotifyInfoDto;
import com.smartpay.cbp.channel.dto.UploadRspDto;

import java.util.List;

/**
 * @author Carer
 * @desc   渠道api服务
 * @date 2022/11/15 15:36
 */
public interface ChannelRemoteApiService {

    /**
     * 批量文件上传
     * @param fileIds 文件上传文件Id集合
     * @param channelNo 渠道号
     * @return 文件上传后响应内容
     */
    List<UploadRspDto> uploadRegisterFile(String channelNo,String... fileIds);

    /**
     * 渠道发送
     * @param merchantUserInfoDto 发送内容
     * @return 请求编号
     */
    String channelSend(MerchantUserInfoReqDto merchantUserInfoDto);

    /**
     * 根据Id获取备案回调信息
     * @param id 主键信息
     * @return 备案回调信息
     */
    RegisterNotifyInfoDto getRegisterNotifyInfoById(String id);

    /**
     * 更新回调通知处理结果
     * @param id    处理主键
     */
    void updateNotifyDealResult(String id);
}
