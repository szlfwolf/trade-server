package com.smartpay.cbp.core.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.smartpay.cbp.core.entity.ApproveInfoEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author admin
 */
@Mapper
public interface ApproveInfoMapper extends BaseMapper<ApproveInfoEntity> {

}