package com.smartpay.cbp.core.dto;

import com.smartpay.cbp.core.enums.RemitReviewStatus;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @Description: 提现审核DTO
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/9 13:33
 * @Version: 1.0
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RemitReviewDto {

    @NotBlank(message = "提现id不能为空")
    @ApiModelProperty(value = "审核请求id",required = true)
    private String remitReqId;

    @ApiModelProperty("商户号")
    private String merchantNo;

    @ApiModelProperty("审核备注")
    private String reviewRemark;

    @NotBlank(message = "手机号码不能为空")
    @ApiModelProperty(value = "手机号码",required = true)
    private String phoneNo;

    @NotBlank(message = "手机验证码不能为空")
    @ApiModelProperty(value = "手机验证码",required = true)
    private String code;

    @NotNull(message = "审核状态不能为空")
    @ApiModelProperty(value = "审核状态",required = true)
    private RemitReviewStatus reviewStatus;

}
