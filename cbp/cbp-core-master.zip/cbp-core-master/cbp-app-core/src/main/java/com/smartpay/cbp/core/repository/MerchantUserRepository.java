package com.smartpay.cbp.core.repository;

import com.baomidou.mybatisplus.extension.service.IService;
import com.smartpay.cbp.core.constant.RegisterStatus;
import com.smartpay.cbp.core.entity.MerchantUserEntity;

import java.util.List;
import java.util.Optional;

/**
 * @author Carer
 * @desc
 * @date 2022/11/8 11:31
 */
public interface MerchantUserRepository extends IService<MerchantUserEntity> {

    /**
     * 查询同一渠道下是否存在相同的备案人
     * @param name      明文姓名
     * @param certType  证件类型
     * @param certId    明文证件号
     * @param channelNo 渠道号
     * @return 备案用户信息合集
     */
    List<MerchantUserEntity> queryPersonsByInfo(String name, String certType, String certId, String channelNo);

    /**
     * 根据商户号和外部用户编号查询备案人集合信息
     * @param merchantNo        商户号
     * @param merchantUserNo    商户侧用户号
     * @return 备案人集合信息
     */
    List<MerchantUserEntity> queryPersonsByMerchantInfo(String merchantNo, String merchantUserNo);

    /**
     * 根据统一社会信用代码获取案人集合信息
     * @param licenseNo 统一社会信用代码
     * @param channelNo 渠道号
     * @return 备案人集合信息
     */
    List<MerchantUserEntity> queryCompanysByInfo(String licenseNo,String channelNo);

    /**
     * 根据系统用户号查询备案用户
     * @param userNo 系统用户号
     * @return 备案用户信息
     */
    Optional<MerchantUserEntity> queryOneByUserNo(String userNo);

    /**
     * 根据姓名等信息查询不成功的备案信息
     * @param nameEnc       加密姓名
     * @param certType      证件类型
     * @param certIdEnc     证件号
     * @param channelNo     渠道号
     * @return              备案用户信息
     */
    List<MerchantUserEntity> queryPersonsByEncInfoUnSuc(String nameEnc,String certType,String certIdEnc,String channelNo);

    /**
     * 根据统一社会信用代码查询不成功备案用户
     * @param licenseNo 统一社会信用代码
     * @param channelNo 渠道号
     * @return 备案用户信息
     */
    List<MerchantUserEntity> queryCompanysByInfoUnsuc(String licenseNo,String channelNo);

    /**
     * 根据ReqNo查询备案用户
     * @param reqNo 备案请求流水号
     * @return 备案用户
     */
    MerchantUserEntity queryByReqId(String reqNo);

    /**
     * 查找对应状态的备案用户
     * @param nameEnc       姓名加密
     * @param certType      证件类型
     * @param certIdEnc     证件号加密
     * @param channelNo     渠道号
     * @param status        状态
     * @return 备案用户集合
     */
    List<MerchantUserEntity> queryPersonsByEncInfoStatus(String nameEnc, String certType, String certIdEnc
            , String channelNo, RegisterStatus status);

    /**
     * 查找对应状态的企业备案用户
     * @param licenseNo 统一社会信用代码
     * @param channelNo 渠道号
     * @param status 状态
     * @return 备案用户集合
     */
    List<MerchantUserEntity> queryCompanysByInfoStatus(String licenseNo, String channelNo, RegisterStatus status);
}
