package com.smartpay.cbp.core.util;

import com.smartpay.cbp.common.security.utils.SecurityUtils;
import com.smartpay.cbp.system.api.domain.SysUser;
import com.smartpay.cbp.system.api.model.LoginUser;

import java.util.Objects;
import java.util.Optional;

/**
 * @Description: 获取登录用户信息
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/24 20:37
 * @Version: 1.0
 */
public class LoginUserUtils {


    /**
     * 获取当前登录用户id
     *
     * @return userId
     */
    public static Optional<String> getUserId() {
        return Optional.ofNullable(String.valueOf(SecurityUtils.getUserId()));
    }


    /**
     * 获取当前登录用户名称
     *
     * @return 用户名称
     */
    public static Optional<String> getUserName() {
        return Optional.ofNullable(SecurityUtils.getUsername());
    }

    /**
     * 获取当前登录用户商户号
     *
     * @return 商户号
     */
    public static Optional<String> getMerchantNo() {
        LoginUser loginUser = SecurityUtils.getLoginUser();
        if (Objects.isNull(loginUser)) {
            return Optional.empty();
        }
        SysUser sysUser = loginUser.getSysUser();
        if (Objects.isNull(sysUser)) {
            return Optional.empty();
        }
        return Optional.ofNullable(sysUser.getMerchantNo());
    }

}
