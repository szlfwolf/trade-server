package com.smartpay.cbp.core.mapstruct;

import com.smartpay.cbp.core.dto.FileInfoRspDto;
import com.smartpay.cbp.core.entity.FileInfoEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * @author Carer
 * @desc
 * @date 2022/11/7 18:01
 */
@Mapper(componentModel = "spring")
public interface FileInfoMapStruct {

    /**
     * 转换成请求实体
     * @param fileInfoEntity 数据库映射
     * @return 请求实体
     */
    @Mapping(target = "filePath", source = "filePathName")
    FileInfoRspDto toDto(FileInfoEntity fileInfoEntity);

}
