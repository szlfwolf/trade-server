package com.smartpay.cbp.core.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

/**
 * @author Carer
 * @desc  用户备案公共字段
 * @date 2022/11/8 15:55
 */
@ApiModel(value = "用户备案公共字段请求实体",parent = BaseReqDto.class)
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class UserRegisterReqDto extends BaseReqDto{

    private static final long serialVersionUID = -3325968819970892592L;

    /**
     * 商户侧用户编号
     */
    @NotBlank(message = "外部用户编号(merchantUserNo)-{javax.validation.constraints.NotBlank.message}")
    @ApiModelProperty(value = "商户侧用户编号",required = true)
    private String merchantUserNo;

    /**
     * 平台注册时间
     */
    @ApiModelProperty(value = "平台注册时间",example = "2022-10-20 10:00",required = true)
    @NotBlank(message = "卖家平台注册时间不能为空")
    @Size(max = 16, message = "卖家平台注册时间格式不正确，长度超16")
    private String regTime;

    /**
     * 国别
     */
    @ApiModelProperty(value = "国别",example = "CHN",required = true)
    @NotBlank(message = "国别(nationality)-{javax.validation.constraints.NotBlank.message}")
    @Size(max = 3, message = "国家代码格式不正确，长度超3")
    private String nationality;

    /**
     * 姓名
     */
    @ApiModelProperty(value = "姓名",example = "张三",required = true)
    @NotBlank(message = "姓名(name)-{javax.validation.constraints.NotBlank.message}")
    private String name;

    /**
     * 手机号
     */
    @ApiModelProperty(value = "手机号",example = "16621009999",required = true)
    @NotBlank(message = "手机号(mobileNo)-{javax.validation.constraints.NotBlank.message}")
    private String mobileNo;

    /**
     * 证件类型
     */
    @ApiModelProperty(value = "证件类型",required = true)
    @NotBlank(message = "证件类型(certType)-{javax.validation.constraints.NotBlank.message}")
    private String certType;

    /**
     * 证件号
     */
    @ApiModelProperty(value = "证件号",example = "102310199210110092",required = true)
    @NotBlank(message = "证件号(certId)-{javax.validation.constraints.NotBlank.message}")
    @Size(max = 32, message = "证件号(certId)格式不正确，长度超32")
    private String certId;

    /**
     * 证件有效期始
     */
    @ApiModelProperty(value = "证件有效期始",example = "20011011",required = true)
    @NotBlank(message = "证件有效期始(certExpBeginDate)-{javax.validation.constraints.NotBlank.message}")
    @Size(max = 8, message = "证件有效期始(certExpBeginDate)格式不正确，长度超8")
    private String certExpBeginDate;

    /**
     * 证件有效期止
     */
    @ApiModelProperty(value = "证件有效期止",example = "20201029",required = true)
    @NotBlank(message = "证件有效期止(certExpEndDate)-{javax.validation.constraints.NotBlank.message}")
    @Size(max = 8, message = "证件有效期止(certExpEndDate)格式不正确，长度超8")
    private String certExpEndDate;

    /**
     * 联系地址
     */
    @ApiModelProperty(value = "联系地址")
    private String address;

    /**
     * 邮箱地址
     */
    @ApiModelProperty(value = "邮箱地址")
    private String email;

    /**
     * 开户银行
     */
    @ApiModelProperty(value = "开户银行")
    private String bankName;

    /**
     * 银行账号
     */
    @ApiModelProperty(value = "银行账号")
    private String bankAcct;

    /**
     * 店铺网址
     */
    @ApiModelProperty(value = "店铺网址")
    private String storeLink;

    /**
     * 证件正面照文件Id
     */
    @ApiModelProperty(value = "证件正面照文件Id",required = true)
    @NotBlank(message = "证件正面照文件Id(certFrontFileId)-{javax.validation.constraints.NotBlank.message}")
    private String certFrontFileId;

    /**
     * 证件反面照文件Id
     */
    @ApiModelProperty(value = "证件反面照文件Id",required = true)
    @NotBlank(message = "证件反面照文件Id(certBackFileId)-{javax.validation.constraints.NotBlank.message}")
    private String certBackFileId;
}
