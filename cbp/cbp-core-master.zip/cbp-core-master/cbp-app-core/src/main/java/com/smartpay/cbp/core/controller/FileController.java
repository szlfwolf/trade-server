package com.smartpay.cbp.core.controller;

import com.smartpay.cbp.common.core.domain.R;
import com.smartpay.cbp.common.core.domain.Result;
import com.smartpay.cbp.common.security.annotation.InnerAuth;
import com.smartpay.cbp.core.constant.SourceFrom;
import com.smartpay.cbp.core.dto.FileInfoRspDto;
import com.smartpay.cbp.core.dto.FileUploadReqDto;
import com.smartpay.cbp.core.service.FileService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.util.List;

/**
 * @author Carer
 * @desc   附件操作处理器
 * @date 2022/11/7 16:48
 */
@Api(tags = "通用文件上传")
@Controller
@Slf4j
@RequestMapping("/file")
@RequiredArgsConstructor
public class FileController {

    private final FileService fileService;


    /**
     * 通用文件上传
     * @param fileUploadReqDto 文件上传请求实体
     * @return 上传文件响应文件指纹Id
     */
    @ApiOperation(value = "通用文件上传-api专用",response = R.class)
    @PostMapping("/api")
    @ResponseBody
    public R<String> uploadFile(@Validated FileUploadReqDto fileUploadReqDto){
        log.info("通用文件上传接收入参：{}",fileUploadReqDto);
        return R.ok(fileService.uploadFile(fileUploadReqDto));
    }

    /**
     * 网页文件上传
     * @param file 文件上传请求实体
     * @return 上传文件响应文件指纹Id
     */
    @ApiOperation(value = "通用文件上传-网页专用",response = Result.class)
    @PostMapping("/page")
    @ResponseBody
    public Result<String> uploadPageFile(MultipartFile file){
        return Result.ok(fileService.uploadPageFile(file, SourceFrom.INSIDE_CONSOLE));
    }

    /**
     * 根据文件指纹Id获取文件url
     * @param fileId 文件指纹
     * @return 文件Url
     */
    @ApiOperation(value = "根据文件指纹Id获取文件url-内部接口",response = R.class)
    @InnerAuth
    @GetMapping(value = "/{fileId}", headers = "from-source=inner")
    @ResponseBody
    public R<String> getFileUrl(@PathVariable("fileId") String fileId){
        log.info("内部接口-根据文件指纹ID获取文件链接URL,文件指纹Id:{}",fileId);
        return R.ok(fileService.getFileUrlByFileId(fileId));
    }

    /**
     * 根据文件指纹Id获取文件对象信息集合
     * @param fileIds 文件指纹
     * @return 文件对象信息集合
     */
    @ApiOperation(value = "根据文件指纹Id获取文件对象信息集合-内部接口",response = R.class)
    @InnerAuth
    @GetMapping(value = "/fileIds", headers = "from-source=inner")
    @ResponseBody
    public R<List<FileInfoRspDto>> getFileInfos(List<String> fileIds){
        log.info("内部接口-批量获取文件对象信息集合,文件指纹集合:{}",fileIds);
        return R.ok(fileService.getFileInfoRspByFileIds(fileIds));
    }

    @ApiOperation(value = "通用文件下载")
    @GetMapping(value = "/download/{fileId}", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public ResponseEntity<StreamingResponseBody> download(@PathVariable("fileId") String fileId){
        log.info("通用文件下载入参：{}",fileId);
        return fileService.download(fileId);
    }
}
