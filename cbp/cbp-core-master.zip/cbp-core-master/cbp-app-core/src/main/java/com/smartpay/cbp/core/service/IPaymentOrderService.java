package com.smartpay.cbp.core.service;

import com.smartpay.cbp.core.dto.PaymentOrderDto;
import com.smartpay.cbp.core.entity.PaymentOrder;
import com.baomidou.mybatisplus.extension.service.IService;
import com.smartpay.cbp.core.entity.PaymentOrderSeq;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author cbp-system
 * @since 2022-11-07
 */
public interface IPaymentOrderService extends IService<PaymentOrder> {

    /**
     * 批量保存订单
     *
     * @param orderSeq
     * @param orders
     * @return
     */
    boolean saveBatch(PaymentOrderSeq orderSeq, List<PaymentOrderDto> orders);

}
