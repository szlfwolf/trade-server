package com.smartpay.cbp.core.service;

import com.smartpay.cbp.core.constant.SourceFrom;
import com.smartpay.cbp.core.dto.FileInfoDto;
import com.smartpay.cbp.core.dto.FileInfoRspDto;
import com.smartpay.cbp.core.dto.FileUploadDto;
import com.smartpay.cbp.core.dto.FileUploadReqDto;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.util.List;

/**
 * @author Carer
 * @desc 文件服务类
 * @date 2022/11/7 16:59
 */
public interface FileService {

    /**
     * 通用文件上传
     *
     * @param fileUploadReqDto 文件上传请求实体
     * @return 上传文件响应文件指纹Id
     */
    String uploadFile(FileUploadReqDto fileUploadReqDto);

    /**
     * 根据文件指纹Id获取文件url
     *
     * @param fileId 文件指纹
     * @return 文件Url
     */
    String getFileUrlByFileId(String fileId);

    /**
     * 根据文件指纹ID获取文件信息
     *
     * @param fileId      文件指纹
     * @param includeData 是否包含文件数据
     * @return 文件信息
     */
    FileInfoDto getFileByFileId(String fileId, boolean includeData);

    /**
     * 根据文件ID下载文件
     *
     * @param fileId 文件指纹Id
     * @return 文件响应流
     */
    ResponseEntity<StreamingResponseBody> download(String fileId);

    /**
     * 文件上传
     *
     * @param fileUploadDTO 文件上传基本信息
     * @return fileId 文件id
     */
    String uploadFile(FileUploadDto fileUploadDTO);

    /**
     * 根据文件指纹Id获取文件对象信息集合
     * @param fileIds 文件指纹
     * @return 文件对象信息集合
     */
    List<FileInfoRspDto> getFileInfoRspByFileIds(List<String> fileIds);

    /**
     * 网页文件上传
     * @param file 文件上传请求实体
     * @param sourceFrom 数据来源
     * @return 上传文件响应文件指纹Id
     */
    String uploadPageFile(MultipartFile file, SourceFrom sourceFrom);
}
