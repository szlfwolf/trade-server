package com.smartpay.cbp.core.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.smartpay.cbp.core.enums.RemitReqStatus;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @TableName t_remit_req
 */
@TableName(value = "t_remit_req")
@Data
@Accessors(chain = true)
public class RemitReq implements Serializable {
    /**
     * 主键id
     */
    @TableId(value = "id")
    private String id;

    /**
     * 请求流水号
     */
    @TableField(value = "remit_no")
    private String remitNo;

    /**
     * 商户号
     */
    @TableField(value = "merchant_no")
    private String merchantNo;

    /**
     * 批次号
     */
    @TableField(value = "batch_no")
    private String batchNo;

    /**
     * 汇款币别 {@link com.smartpay.cbp.core.enums.CurrencyType}
     */
    @TableField(value = "remit_cur")
    private String remitCur;

    /**
     * 请求来源 {@link com.smartpay.cbp.core.constant.SourceFrom}
     */
    @TableField(value = "source")
    private String source;

    /**
     * 文件关联id
     */
    @TableField(value = "file_id")
    private String fileId;

    /**
     * 文件名称
     */
    @TableField(value = "file_name")
    private String fileName;

    /**
     * 总条数
     */
    @TableField(value = "total_count")
    private Integer totalCount;

    /**
     * 总金额
     */
    @TableField(value = "total_amount")
    private Long totalAmount;

    /**
     * 总条数
     */
    @TableField(value = "total_success_count")
    private Integer totalSuccessCount;

    /**
     * 总金额
     */
    @TableField(value = "total_success_amount")
    private Long totalSuccessAmount;

    /**
     * 审核人id
     */
    @TableField(value = "review_user_id")
    private String reviewUserId;

    /**
     * 审核时间
     */
    @TableField(value = "review_time")
    private Date reviewTime;

    /**
     * 审核备注
     */
    @TableField(value = "review_remark")
    private String reviewRemark;

    /**
     * 审核状态 {@link RemitReqStatus}
     */
    @TableField(value = "status")
    private String status;

    /**
     * 失败文件id
     */
    @TableField(value = "fail_file_id")
    private String failFileId;

    /**
     * 失败文件名称
     */
    @TableField(value = "fail_file_name")
    private String failFileName;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField(value = "crt_time")
    private Date crtTime;

    /**
     * 创建人
     */
    @TableField(value = "crt_by")
    private String crtBy;

    /**
     * 修改时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField(value = "upt_time")
    private Date uptTime;

    /**
     * 更新人
     */
    @TableField(value = "upt_by")
    private String uptBy;

    /**
     * 是否删除
     */
    @TableField(value = "del_flag")
    private Boolean delFlag;

    /**
     * 枚举释义转换
     *
     * @return
     */
    public String getStatusName() {
        return Objects.isNull(status) ? null : RemitReqStatus.toEnumByOrdinal(status).comment;
    }

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}
