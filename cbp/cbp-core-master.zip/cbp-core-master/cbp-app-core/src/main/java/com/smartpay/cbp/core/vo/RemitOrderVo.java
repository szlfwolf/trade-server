package com.smartpay.cbp.core.vo;

import com.smartpay.cbp.common.core.annotation.Excel;
import com.smartpay.cbp.core.enums.RemitType;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;
import java.util.Objects;

/**
 * @Description: 提现订单vo
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/21 13:47
 * @Version: 1.0
 */
@Data
public class RemitOrderVo {

    @ApiModelProperty("主键id")
    private String id;

    @ApiModelProperty("批次号")
    private String batchNo;

    @ApiModelProperty("订单编号")
    private String orderNo;

    @ApiModelProperty("卖家编号")
    private String platformUserNo;

    @ApiModelProperty("货币类型")
    private String currencyType;

    @ApiModelProperty("金额")
    private Long amt;

    @ApiModelProperty("手续费金额")
    private Long feeAmt;

    @ApiModelProperty("账户名称")
    private String bankAccountName;

    @ApiModelProperty("提现类型")
    private String remitType;

    @ApiModelProperty("账号")
    private String bankAccountNo;

    @ApiModelProperty("银行名称")
    private String bankName;

    @ApiModelProperty("状态")
    private String status;

    @ApiModelProperty("错误信息")
    private String errorMsg;

    @ApiModelProperty("更新时间")
    private Date uptDate;

    @ApiModelProperty("创建时间")
    private Date crtDate;

    public String getRemitTypeName() {
        return Objects.isNull(remitType) ? null : RemitType.ordinalToEnum(remitType).getComment();
    }

}
