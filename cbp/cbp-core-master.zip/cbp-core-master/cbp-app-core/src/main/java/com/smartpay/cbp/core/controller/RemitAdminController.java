package com.smartpay.cbp.core.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.smartpay.cbp.common.core.utils.poi.ExcelUtil;
import com.smartpay.cbp.core.base.Page;
import com.smartpay.cbp.core.dto.RemitOrderQueryDto;
import com.smartpay.cbp.core.dto.RemitReqQueryDto;
import com.smartpay.cbp.core.entity.RemitOrder;
import com.smartpay.cbp.core.entity.RemitReq;
import com.smartpay.cbp.core.enums.AppCode;
import com.smartpay.cbp.core.handler.RemoteCallHandler;
import com.smartpay.cbp.core.mapstruct.RemitOrderMapStruct;
import com.smartpay.cbp.core.mapstruct.RemitReqMapStruct;
import com.smartpay.cbp.core.service.FileService;
import com.smartpay.cbp.core.service.IRemitOrderService;
import com.smartpay.cbp.core.service.IRemitReqService;
import com.smartpay.cbp.core.vo.RemitOrderExportVo;
import com.smartpay.cbp.core.vo.RemitReqVo;
import com.smartpay.cbp.system.api.domain.SysUser;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @Description: 提现控制器
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/8 17:38
 * @Version: 1.0
 */
@Controller
@Slf4j
@RequestMapping("/remit/admin")
@Api(tags = "提现相关(管理台)")
@RequiredArgsConstructor
public class RemitAdminController {

    private final IRemitReqService remitReqService;

    private final RemitReqMapStruct remitReqMapStruct;

    private final RemoteCallHandler remoteCallHandler;

    private final IRemitOrderService remitOrderService;

    private final RemitOrderMapStruct remitOrderMapStruct;

    private final FileService fileService;


    @GetMapping("/page-req/{number}/{size}")
    @ApiOperation(value = "分页查询提现请求", tags = {""})
    @ResponseBody
    public Page<RemitReqVo> pageReq(@ApiParam(required = true, value = "页码", example = "1") @PathVariable final int number,
                                    @ApiParam(required = true, value = "每页条数，最大值1000", example = "10") @PathVariable final int size,
                                    final RemitReqQueryDto condition) {
        PageHelper.startPage(number, size);
        List<RemitReq> remitReqs = remitReqService.list(condition);
        PageInfo<RemitReq> pageInfo = new PageInfo<>(remitReqs);
        Set<Long> userIds = remitReqs.stream().map(RemitReq::getCrtBy).filter(StringUtils::isNotBlank).map(Long::new).collect(Collectors.toSet());
        Set<Long> reviewUserIds = remitReqs.stream().map(RemitReq::getReviewUserId).filter(StringUtils::isNotBlank).map(Long::new).collect(Collectors.toSet());
        userIds.addAll(reviewUserIds);
        Map<Long, SysUser> userMap = new HashMap<>();
        if (CollectionUtils.isNotEmpty(userIds)) {
            userMap = remoteCallHandler.mapByUserIds(userIds);
        }
        //组装审核名，申请名
        Map<Long, SysUser> finalUserMap = userMap;
        List<RemitReqVo> list = remitReqs.stream().map(remitReq -> {
                    RemitReqVo remitReqVo = remitReqMapStruct.toRemitReqVo(remitReq);
                    if (StringUtils.isNotBlank(remitReq.getReviewUserId())) {
                        SysUser reviewUser = finalUserMap.get(Long.valueOf(remitReq.getReviewUserId()));
                        remitReqVo.setReviewUserName(Objects.isNull(reviewUser) ? "" : reviewUser.getUserName());
                    }
                    if (StringUtils.isNotBlank(remitReq.getCrtBy())) {
                        SysUser applyUser = finalUserMap.get(Long.valueOf(remitReq.getCrtBy()));
                        remitReqVo.setCrtUserName(Objects.isNull(applyUser) ? "" : applyUser.getUserName());
                    }
                    return remitReqVo;
                })
                .collect(Collectors.toList());
        return Page.ok(list, pageInfo);
    }

    @PostMapping("/export-order")
    @ApiOperation(value = "根据筛选条件导出提现订单", tags = {""})
    @ResponseBody
    public void export(HttpServletResponse response, @RequestBody final RemitOrderQueryDto condition) {

        List<RemitOrder> remitOrders = remitOrderService.list(condition);

        List<RemitOrderExportVo> list = remitOrders.stream().map(remitOrderMapStruct::toRemitOrderExportVo).collect(Collectors.toList());

        ExcelUtil<RemitOrderExportVo> excelUtil = new ExcelUtil<>(RemitOrderExportVo.class);
        excelUtil.exportExcel(response, list, "提现订单列表", "提现订单列表.xlsx");
    }


    @PostMapping("/export-req")
    @ApiOperation(value = "根据筛选条件导出提现请求", tags = {""})
    @ResponseBody
    public void export(HttpServletResponse response, @RequestBody final RemitReqQueryDto condition) {

        List<RemitReq> remitReqs = remitReqService.list(condition);

        List<RemitReqVo> list = remitReqs.stream().map(remitReqMapStruct::toRemitReqVo).collect(Collectors.toList());

        ExcelUtil<RemitReqVo> excelUtil = new ExcelUtil<>(RemitReqVo.class);
        excelUtil.exportExcel(response, list, "提现申请列表", "提现申请列表.xlsx");
    }


    @PostMapping("/export-success/{remitReqId}")
    @ApiOperation(value = "导出校验成功订单", tags = {""})
    @ResponseBody
    public void exportSuccessOrder(HttpServletResponse response, @PathVariable String remitReqId) {

        RemitReq remitReq = Optional.ofNullable(remitReqService.getById(remitReqId)).orElseThrow(AppCode.B03008::toCodeException);

        List<RemitOrder> remitOrders = remitOrderService.listByRemitReqId(remitReqId);
        List<RemitOrderExportVo> list = remitOrders.stream().map(remitOrderMapStruct::toRemitOrderExportVo).collect(Collectors.toList());

        ExcelUtil<RemitOrderExportVo> excelUtil = new ExcelUtil<>(RemitOrderExportVo.class);
        excelUtil.exportExcel(response, list, "校验成功订单", remitReq.getBatchNo() + "_校验成功订单.xlsx");
    }


    @PostMapping("/export-fail/{remitReqId}")
    @ApiOperation(value = "导出校验失败订单", tags = {""})
    @ResponseBody
    public String exportFailOrder(@PathVariable String remitReqId) {

        RemitReq remitReq = Optional.ofNullable(remitReqService.getById(remitReqId)).orElseThrow(AppCode.B03008::toCodeException);
        AppCode.B03009.assertNonNull(remitReq.getFailFileId());

        return fileService.getFileUrlByFileId(remitReq.getFailFileId());
    }

}
