package com.smartpay.cbp.core.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.smartpay.cbp.core.enums.RemitOrderStatus;
import com.smartpay.cbp.core.enums.RemitType;
import com.smartpay.cbp.core.enums.TimeType;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * 商户下发明细表
 *
 * @TableName t_remit_order
 */
@Data
@TableName(value = "t_remit_order")
@Accessors(chain = true)
public class RemitOrder implements Serializable {
    /**
     * 主键id
     */
    @TableId(value = "id")
    private String id;

    /**
     * 代付请求id
     */
    @TableField(value = "remit_req_id")
    private String remitReqId;

    /**
     * 商户号
     */
    @TableField(value = "merchant_no")
    private String merchantNo;

    /**
     * 批次号
     */
    @TableField(value = "batch_no")
    private String batchNo;

    /**
     * 订单编号
     */
    @TableField(value = "order_no")
    private String orderNo;

    /**
     * 订单明细状态 {@link RemitOrderStatus}
     */
    @TableField(value = "status")
    private String status;

    /**
     * 业务类型
     */
    @TableField(value = "business_code")
    private String businessCode;

    /**
     * 手机号
     */
    @TableField(value = "mobile_phone")
    private String mobilePhone;

    /**
     * 产品编码
     */
    @TableField(value = "product_code")
    private String productCode;

    /**
     * 货币类型 {@link com.smartpay.cbp.core.enums.CurrencyType}
     */
    @TableField(value = "currency_type")
    private String currencyType;

    /**
     * 用途
     */
    @TableField(value = "purpose")
    private String purpose;

    /**
     * 出款用户号
     */
    @TableField(value = "pay_user_no")
    private String payUserNo;

    /**
     * 付款金额
     */
    @TableField(value = "amt")
    private Long amt;

    /**
     * 手续费
     */
    @TableField(value = "fee_amt")
    private Long feeAmt;

    /**
     * 手续费货币类型
     */
    @TableField(value = "fee_currency_type")
    private String feeCurrencyType;

    /**
     * 结汇金额
     */
    @TableField(value = "settlement_amt")
    private Long settlementAmt;

    /**
     * 结汇汇率
     */
    @TableField(value = "settlement_rate")
    private String settlementRate;

    /**
     * 收款联行号
     */
    @TableField(value = "cnaps_no")
    private String cnapsNo;

    /**
     * 代发类型 {@link com.smartpay.cbp.core.enums.RemitType}
     */
    @TableField(value = "remit_type")
    private String remitType;

    /**
     * 到账类型 1:t+0,2:t+1
     */
    @TableField(value = "time_type")
    private String timeType;

    /**
     * 手续费交割方式
     */
    @TableField(value = "fee_delivery")
    private String feeDelivery;

    /**
     * 是否回退
     */
    @TableField(value = "fall_backed")
    private String fallBacked;

    /**
     * 账户类型
     */
    @TableField(value = "account_type")
    private String accountType;

    /**
     * 收款银行代码
     */
    @TableField(value = "bank_code")
    private String bankCode;

    /**
     * 收款银行代码
     */
    @TableField(value = "bank_name")
    private String bankName;


    /**
     * 收款银行账号
     */
    @TableField(value = "bank_account_no")
    private String bankAccountNo;

    /**
     * 收款账户名
     */
    @TableField(value = "bank_account_name")
    private String bankAccountName;

    /**
     * 收款人证件类型
     */
    @TableField(value = "account_id_type")
    private String accountIdType;

    /**
     * 收款人证件号
     */
    @TableField(value = "account_id_no")
    private String accountIdNo;

    /**
     * 省份
     */
    @TableField(value = "province")
    private String province;

    /**
     * 城市
     */
    @TableField(value = "city")
    private String city;

    /**
     * 收款行支行名称
     */
    @TableField(value = "bank_branch_name")
    private String bankBranchName;

    /**
     * 卖家类型
     */
    @TableField(value = "platform_type")
    private String platformType;

    /**
     * 卖家编号
     */
    @TableField(value = "platform_user_no")
    private String platformUserNo;

    /**
     * 备注
     */
    @TableField(value = "remark")
    private String remark;

    /**
     * 备注1
     */
    @TableField(value = "remark1")
    private String remark1;

    /**
     * 备注2
     */
    @TableField(value = "remark2")
    private String remark2;

    /**
     * 备注3
     */
    @TableField(value = "remark3")
    private String remark3;

    /**
     * 备注4
     */
    @TableField(value = "remark4")
    private String remark4;

    /**
     * 平台名称
     */
    @TableField(value = "platform_name")
    private String platformName;

    /**
     * 订单处理响应码
     */
    @TableField(value = "error_code")
    private String errorCode;

    /**
     * 订单处理响应信息
     */
    @TableField(value = "error_msg")
    private String errorMsg;

    /**
     * 创建人
     */
    @TableField(value = "crt_by")
    private String crtBy;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField(value = "crt_time")
    private Date crtTime;

    /**
     * 修改人
     */
    @TableField(value = "upt_by")
    private String uptBy;

    /**
     * 修改时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField(value = "upt_time")
    private Date uptTime;

    /**
     * 是否删除
     */
    @TableField(value = "del_flag")
    private Boolean delFlag;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;

    /**
     * 代发类型
     *
     * @return 中文描述
     */
    public String getRemitTypeName() {
        return remitType == null ? "" : RemitType.ordinalToEnum(remitType).comment;
    }

    /**
     * 到账类型
     *
     * @return 中文描述
     */
    public String getTimeTypeName() {
        return timeType == null ? "" : TimeType.ordinalToEnum(timeType).comment;
    }

}
