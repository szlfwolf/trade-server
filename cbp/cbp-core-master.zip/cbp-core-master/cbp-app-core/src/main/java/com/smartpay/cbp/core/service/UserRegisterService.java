package com.smartpay.cbp.core.service;

import com.smartpay.cbp.channel.dto.RegisterNotifyInfoDto;
import com.smartpay.cbp.core.dto.CompanyRegisterDto;
import com.smartpay.cbp.core.dto.NotifyRegisterReqDto;
import com.smartpay.cbp.core.dto.PersonRegisterDto;

/**
 * @author Carer
 * @desc
 * @date 2022/11/8 11:33
 */
public interface UserRegisterService {

    /**
     * 个人开户
     * @param personRegisterDto 个人请求实体
     * @return 开户请求结果
     */
    Boolean personRegister(PersonRegisterDto personRegisterDto);

    /**
     * 企业开户
     * @param companyRegisterDto 企业请求实体
     * @return 开户请求结果
     */
    Boolean companyRegister(CompanyRegisterDto companyRegisterDto);

    /**
     * 回调通知
     * @param notifyRegisterReqDto 通知结果
     * @return 通知结果
     */
    Boolean notifyRegisterResult(NotifyRegisterReqDto notifyRegisterReqDto);

    /**
     * 处理渠道回调
     * @param registerNotifyInfo 回调信息
     */
    void dealRegisterNotify(RegisterNotifyInfoDto registerNotifyInfo);
}
