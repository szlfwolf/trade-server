package com.smartpay.cbp.core.rabbit;

import cn.hutool.poi.excel.ExcelUtil;
import cn.hutool.poi.excel.ExcelWriter;
import com.alibaba.fastjson.JSON;
import com.rabbitmq.client.Channel;
import com.smartpay.cbp.common.core.utils.DateUtils;
import com.smartpay.cbp.core.config.RemitRabbitConfig;
import com.smartpay.cbp.core.constants.Constants;
import com.smartpay.cbp.core.dto.FileUploadDto;
import com.smartpay.cbp.core.dto.RemitOrderFailMqDto;
import com.smartpay.cbp.core.entity.RemitOrderFail;
import com.smartpay.cbp.core.entity.RemitReq;
import com.smartpay.cbp.core.service.FileService;
import com.smartpay.cbp.core.service.IRemitReqService;
import com.smartpay.cbp.core.service.RemitOrderFailService;
import com.smartpay.cbp.core.util.ExcelFieldUtil;
import lombok.Cleanup;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.annotation.*;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Objects;

/**
 * @Description:校验失败提现明细文件监听
 * @Author:Guogangqiang
 * @CreateDate:2022/11/9 14:21
 * @Version:1.0
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class RemitFailOrderListen {

    private final RemitOrderFailService remitOrderFailService;

    private final FileService fileService;

    private final IRemitReqService remitReqService;

    /**
     * 监听提现生成失败文件
     *
     * @param message mq消息
     */
    @SneakyThrows
    @RabbitListener(bindings = {@QueueBinding(value = @Queue(value = RemitRabbitConfig.REMIT_FAIL_FILE_QUEUE)
            , exchange = @Exchange(RemitRabbitConfig.REMIT_EXCHANGE), key = RemitRabbitConfig.REMIT_FAIL_FILE_QUEUE)}
            , ackMode = "MANUAL")
    @RabbitHandler
    public void onMessage(Message message, Channel channel, String msg) {
        MessageProperties messageProperties = message.getMessageProperties();
        try {
            //预取模式：10条处理完成再次消费
            channel.basicQos(0, 10, false);
            if (log.isInfoEnabled()) {
                log.info("【开始】生成提现校验失败订单文件,消息内容:{}", msg);
            }
            if (StringUtils.isBlank(msg)) {
                log.error("【结束】MQ消息为空");
                channel.basicAck(messageProperties.getDeliveryTag(), true);
                return;
            }
            RemitOrderFailMqDto remitOrderFailMqDTO = JSON.parseObject(msg, RemitOrderFailMqDto.class);
            RemitReq remitReq = remitReqService.getById(remitOrderFailMqDTO.getRemitReqId());
            if (Objects.isNull(remitReq)) {
                log.error("【结束】未查询到提现申请，提现申请id:{}", remitOrderFailMqDTO.getRemitReqId());
                channel.basicAck(messageProperties.getDeliveryTag(), true);
                return;
            }
            //校验失败订单明细
            List<RemitOrderFail> remitOrderFails = remitOrderFailService.listByRemitReqId(remitOrderFailMqDTO.getRemitReqId());
            //生成excel
            @Cleanup ExcelWriter writer = ExcelUtil.getWriter();
            @Cleanup ByteArrayOutputStream out = new ByteArrayOutputStream();
            writer.setHeaderAlias(ExcelFieldUtil.getHeaderAlias(RemitOrderFail.class, ExcelFieldUtil.HeaderAliasType.writer));
            writer.setOnlyAlias(true);
            writer.write(remitOrderFails, true);
            writer.flush(out);
            String failFileName = String.format("%s_%s", Constants.REMIT_FAIL_FILE_PRIFIX, remitReq.getFileName());
            FileUploadDto fileUploadDTO = FileUploadDto.builder()
                    .fileName(failFileName)
                    .filePathName(String.format("%s/%s/%s", Constants.REMIT_FAIL_FILE_NAME, DateUtils.datePath(), DigestUtils.md5Hex(out.toByteArray()) + ".xls"))
                    .fileType("xls")
                    .fileData(out.toByteArray())
                    .build();
            //excel文件上传Mino
            String fileId = fileService.uploadFile(fileUploadDTO);
            remitReq.setFailFileId(fileId);
            remitReq.setFailFileName(failFileName);
            remitReqService.updateById(remitReq);
            channel.basicAck(messageProperties.getDeliveryTag(), true);
            log.info("【结束】校验失败文件生成成功，提现请求id:{}", remitOrderFailMqDTO.getRemitReqId());
        } catch (IOException e) {
            log.error("【异常】MQ消费生成提现订单校验失败文件异常", e);
            channel.basicNack(messageProperties.getDeliveryTag(), false, true);
        }
    }
}
