package com.smartpay.cbp.core.service;

import com.smartpay.cbp.core.dto.FileInfoObj;
import com.smartpay.cbp.core.dto.FileUploadDto;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;

/**
 * @author Carer
 * @desc  文件存储类
 * @date 2022/11/7 17:22
 */
public interface FileStorageService {

    /**
     * 文件上传
     * @param file 文件
     * @return 文件路径
     */
    FileInfoObj upload(MultipartFile file);

    /**
     * 存储类型
     * @return 类型
     */
    String getStoreType();

    /**
     * 获取存储路径
     * @return 存储路径
     */
    String getStorePath();

    /**
     * 文件上传
     * @param file 文件
     * @return 文件路径
     */
    String upload(FileUploadDto file);

    /**
     * 获取下文文件
     * @param fileName 文件名
     * @return 下载对象
     */
    InputStream downloadFile(String fileName);
}
