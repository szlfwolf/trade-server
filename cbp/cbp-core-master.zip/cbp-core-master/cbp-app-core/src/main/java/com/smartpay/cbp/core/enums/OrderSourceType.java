package com.smartpay.cbp.core.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author ：jmwang
 * @version ：V1.0
 * @description ：订单来源
 * @date ：2022/11/8 17:39
 */
@Getter
@AllArgsConstructor
public enum OrderSourceType {
    /**
     * 订单数据来源
     */
    ON_SHORE_API("在岸API"),
    ON_SHORE_WEB("在岸WEB"),
    OFF_SHORE_API("离岸API"),
    OFF_SHORE_WEB("离岸WEB");

    private String comment;

}
