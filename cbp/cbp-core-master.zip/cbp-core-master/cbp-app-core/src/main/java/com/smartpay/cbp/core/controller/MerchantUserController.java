package com.smartpay.cbp.core.controller;

import com.smartpay.cbp.common.core.domain.R;
import com.smartpay.cbp.common.core.domain.Result;
import com.smartpay.cbp.common.core.utils.poi.ExcelUtil;
import com.smartpay.cbp.common.core.web.controller.BaseController;
import com.smartpay.cbp.common.core.web.page.TableDataInfo;
import com.smartpay.cbp.common.security.annotation.InnerAuth;
import com.smartpay.cbp.common.security.annotation.RequiresPermissions;
import com.smartpay.cbp.core.dto.*;
import com.smartpay.cbp.core.service.MerchantUserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @author Carer
 * @desc  备案用户控制器
 * @date 2022/11/18 15:40
 */
@Api(tags = "用户信息菜单")
@RestController
@RequestMapping("/merchantUser")
@RequiredArgsConstructor
@Slf4j
public class MerchantUserController extends BaseController {

    private final MerchantUserService merchantUserService;

    /**
     * 获取分页用户信息
     * @param merchantUserPageReqDto 分页查询入参
     * @return 响应内容
     */
    @ApiOperation(value = "获取分页用户信息",response = TableDataInfo.class)
    @RequiresPermissions("merchant:user:list")
    @GetMapping("/pages")
    public TableDataInfo pageList(MerchantUserPageReqDto merchantUserPageReqDto){
        log.info("用户管理分页查询入参：{}",merchantUserPageReqDto);
        startPage();
        List<MerchantUserPageRspDto> merchantUserPageRspDtoList = merchantUserService.pageList(merchantUserPageReqDto);
        return getDataTable(merchantUserPageRspDtoList);
    }

    /**
     * 导出
     * @param response                  响应体
     * @param merchantUserPageReqDto    分页查询入参
     */
    @ApiOperation(value = "导出商户用户信息")
    @RequiresPermissions("merchant:user:export")
    @PostMapping("/export")
    public void export(HttpServletResponse response,MerchantUserPageReqDto merchantUserPageReqDto){
        log.info("商户用户信息导出入参:{}",merchantUserPageReqDto);
        List<MerchantUserPageRspDto> merchantUserPageRspDtoList = merchantUserService.pageList(merchantUserPageReqDto);
        ExcelUtil<MerchantUserPageRspDto> util = new ExcelUtil<>(MerchantUserPageRspDto.class);
        util.exportExcel(response, merchantUserPageRspDtoList, "商户用户数据");
    }

    /**
     * 根据主键查询商户用户信息
     * @param id    主键
     * @return  商户用户详情
     */
    @ApiOperation(value = "根据主键查询商户用户详细信息",response = MerchantUserDetailDto.class)
    @GetMapping("/detail/{id}")
    public Result<MerchantUserDetailDto> detailById(@PathVariable("id")String id){
        log.info("查询详情入参主键：{}",id);
        return Result.ok(merchantUserService.detailById(id));
    }

    /**
     * 审批
     * @param approveReqDto 审批入参
     * @return  审批结果
     */
    @ApiOperation(value = "审批接口",response = Result.class)
    @PostMapping("/approve")
    public Result<Boolean> approveById(ApproveReqDto approveReqDto){
        log.info("用户审批入参：{}",approveReqDto);
        return Result.ok(merchantUserService.approve(approveReqDto));
    }

    /**
     * 校验传入商户下的外部用户编号是否已开户
     * @param merchantUserRegCheckReqDto 传入参数
     * @return 未备案的外部用户编号
     */
    @ApiOperation(value = "校验传入商户下的外部用户编号是否已开户",response = R.class)
    @InnerAuth
    @PostMapping("/check/batch")
    public R<List<String>> checkRegistedBatch(@RequestBody MerchantUserRegCheckReqDto merchantUserRegCheckReqDto){
        return R.ok(merchantUserService.checkRegister(merchantUserRegCheckReqDto));
    }
}
