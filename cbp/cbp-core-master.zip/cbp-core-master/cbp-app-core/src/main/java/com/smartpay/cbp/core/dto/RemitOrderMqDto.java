package com.smartpay.cbp.core.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Description: 提现明细MQ报文内容
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/8 14:16
 * @Version: 1.0
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RemitOrderMqDto {

    @ApiModelProperty("提现订单id")
    private String remitOrderId;

}
