package com.smartpay.cbp.core.interfaces;

import com.smartpay.cbp.core.dto.RemitOrderDto;

import java.io.InputStream;
import java.util.List;

/**
 * @Description: 文件解析工厂类
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/14 17:10
 * @Version: 1.0
 */
public interface RemitFileParse {

    /**
     * 解析文件
     *
     * @param is 流文件
     * @return 解析数据
     */
    List<RemitOrderDto> parse(InputStream is);

}
