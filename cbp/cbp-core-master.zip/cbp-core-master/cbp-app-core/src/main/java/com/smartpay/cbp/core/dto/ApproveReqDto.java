package com.smartpay.cbp.core.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * @author Carer
 * @desc  审批内容
 * @date 2022/11/22 11:44
 */
@ApiModel(value = "审批字段")
@Data
@EqualsAndHashCode(callSuper = false)
public class ApproveReqDto implements Serializable {
    private static final long serialVersionUID = 4599896702003168659L;

    /**
     * 审批关联Id
     */
    @ApiModelProperty(value = "审批关联Id",required = true)
    @NotBlank(message = "审批关联Id不能为空")
    private String relId;

    /**
     * 审批动作 ${@link com.smartpay.cbp.core.constant.ApproveStatus}
     */
    @ApiModelProperty(value = "审批动作：1-待审批，2-通过，3-拒绝",required = true)
    @NotBlank(message = "审批动作(approveAction)不能为空")
    private String approveAction;

    /**
     * 审批备注
     */
    @ApiModelProperty(value = "审批备注")
    private String approveRemark;

    /**
     * 指定下一审批人
     */
    private String nextApproveId;
}
