package com.smartpay.cbp.core.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.smartpay.cbp.core.entity.MerchantUserEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author carer
 */
@Mapper
public interface MerchantUserMapper extends BaseMapper<MerchantUserEntity> {

}