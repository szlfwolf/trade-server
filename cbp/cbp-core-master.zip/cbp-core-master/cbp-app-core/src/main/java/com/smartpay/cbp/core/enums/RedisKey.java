package com.smartpay.cbp.core.enums;

/**
 * @Description: redis key值枚举
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/4 11:09
 * @Version: 1.0
 */
public enum RedisKey {

    REMIT_PHONE_CODE("提现手机验证码");

    public final String comment;

    RedisKey(String comment) {
        this.comment = comment;
    }

}
