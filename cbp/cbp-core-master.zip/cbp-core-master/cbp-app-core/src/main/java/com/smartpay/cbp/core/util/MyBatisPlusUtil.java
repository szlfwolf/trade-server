package com.smartpay.cbp.core.util;

import com.baomidou.mybatisplus.annotation.DbType;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.generator.AutoGenerator;
import com.baomidou.mybatisplus.generator.config.*;
import com.baomidou.mybatisplus.generator.config.rules.DateType;
import com.baomidou.mybatisplus.generator.config.rules.NamingStrategy;
import com.baomidou.mybatisplus.generator.engine.VelocityTemplateEngine;

import java.util.ArrayList;

/**
 * @author 刘毅
 * @desc 自动生成mybatis plus的操作类
 * @return $
 * @create time 2021/9/5 21:03

 */
public class MyBatisPlusUtil {
    //要生成的表名
    private static final String[] TABLES= {
            "t_payment_order",
            "t_payment_order_seq"
    };

    //功能模块名称，生成的文件会存放到模块下
    private static final String MODULE_NAME = "cbp-app-core";

    //作者名
    private static final String AUTHOR = "cbp-system";
    //表table的前缀，不加到生成的类名中
    private static final String PREFIX = "t_";

    // 数据源配置
    private static final String JDBC_URL = "jdbc:mysql://192.168.103.59:3306/cbp_core?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=convertToNull&useSSL=false&serverTimezone=GMT%2B8";
    private static final String JDBC_USERNAME = "cbrmb";
    private static final String JDBC_PASSWORD = "Cbrmb@2021";
    private static final String BASE_PACKAGE = "com.smartpay.cbp.core";

    public static void main(String[] args) {
        DataSourceConfig.Builder dataSourceConfigBuilder = new DataSourceConfig
                .Builder(JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD);

        // 全局配置
        GlobalConfig.Builder globalConfigBuilder = new GlobalConfig.Builder();
        globalConfigBuilder.author(AUTHOR);
        // 代码生成目录
        String projectPath = System.getProperty("user.dir");
        globalConfigBuilder.outputDir(projectPath + "/" + MODULE_NAME + "/src/main/java");

        //设置作者
        globalConfigBuilder.dateType(DateType.ONLY_DATE);
        //生成完后是否打开输出目录
        globalConfigBuilder.disableOpenDir();
        //是否覆盖生成过的已有文件
        //开启 swagger2 模式,实体属性 Swagger2 注解,默认false
        globalConfigBuilder.enableSwagger();

        PackageConfig.Builder packageConfigBuilder = new PackageConfig.Builder();
        packageConfigBuilder.moduleName(null);
        packageConfigBuilder.parent(BASE_PACKAGE);//包路径
        packageConfigBuilder.controller("controller");
        packageConfigBuilder.service("service");
        packageConfigBuilder.serviceImpl("service.impl");
        packageConfigBuilder.entity("entity");
        packageConfigBuilder.mapper("mapper");
        packageConfigBuilder.xml("mapper");

        // 策略配置
        StrategyConfig.Builder strategyConfigBuilder = new StrategyConfig.Builder();
        // 设置需要映射的表名
        strategyConfigBuilder.addInclude(TABLES);//字符串数组，可以生成多个表

        /*globalConfig.setMapperName("%sMapper");
        globalConfig.setXmlName("%sMapper");
        globalConfig.setEntityName("%s");
        globalConfig.setServiceName("I%sService");
        globalConfig.setServiceImplName("%sServiceImpl");
        globalConfig.setControllerName("%sController");*/

        // 下划线转驼峰
        strategyConfigBuilder.addTablePrefix("t_")
                .entityBuilder()
                .naming(NamingStrategy.underline_to_camel)
                .columnNaming(NamingStrategy.underline_to_camel)
                .serviceBuilder().formatServiceFileName("I%sService")
                .formatServiceImplFileName("I%sServiceImpl");
        // 去除前缀"t_"
        strategyConfigBuilder.addTablePrefix("t_");

        // entity的Lombok
        strategyConfigBuilder.entityBuilder().enableLombok();

        // 逻辑删除
        //strategyConfigBuilder.entityBuilder().logicDeleteColumnName("deleted");
        //strategyConfigBuilder.entityBuilder().logicDeletePropertyName("deleted");

        // 创建时间
        //IFill gmtCreate = new Column("create_time", FieldFill.INSERT);
        // 更新时间
        //IFill gmtModified = new Column("update_time", FieldFill.INSERT_UPDATE);
        //strategyConfigBuilder.entityBuilder().addTableFills(gmtCreate, gmtModified);
        // 乐观锁
        //strategyConfigBuilder.entityBuilder().enableSerialVersionUID();
        //strategyConfigBuilder.entityBuilder().versionColumnName("version");
        //strategyConfigBuilder.entityBuilder().versionPropertyName("version");

        // 使用Restful风格的Controller
        strategyConfigBuilder.controllerBuilder().enableRestStyle();

        // 将请求地址转换为驼峰命名，如 http://localhost:8080/hello_id_2
        strategyConfigBuilder.controllerBuilder().enableHyphenStyle();

        // 创建代码生成器对象，加载配置
        AutoGenerator autoGenerator = new AutoGenerator(dataSourceConfigBuilder.build());
        autoGenerator.global(globalConfigBuilder.build());
        autoGenerator.packageInfo(packageConfigBuilder.build());
        autoGenerator.strategy(strategyConfigBuilder.build());

        // 执行
        autoGenerator.execute();
    }
}
