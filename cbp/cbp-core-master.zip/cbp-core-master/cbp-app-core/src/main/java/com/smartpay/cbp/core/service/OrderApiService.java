package com.smartpay.cbp.core.service;

import com.smartpay.cbp.core.dto.OrderApplyDto;
import com.smartpay.cbp.core.dto.OrderApplyResponse;

/**
 * @description ：订单申报API功能
 * @author ：jmwang
 * @version ：V1.0
 * @date ：2022/11/8 14:59
 */
public interface OrderApiService {

    /**
     * 订单申报API接口
     * @param applyDto
     * @return
     */
    OrderApplyResponse apply(OrderApplyDto applyDto);
}
