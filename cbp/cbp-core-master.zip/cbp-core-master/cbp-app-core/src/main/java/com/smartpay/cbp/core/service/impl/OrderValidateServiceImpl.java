package com.smartpay.cbp.core.service.impl;

import com.smartpay.cbp.core.dto.OrderValidateDto;
import com.smartpay.cbp.core.dto.PaymentOrderDto;
import com.smartpay.cbp.core.entity.PaymentOrderSeq;
import com.smartpay.cbp.core.service.OrderValidateService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author ：jmwang
 * @version ：V1.0
 * @description ：订单数据校验
 * @date ：2022/11/10 10:04
 */
@Service
public class OrderValidateServiceImpl implements OrderValidateService {

    @Override
    public OrderValidateDto validate(PaymentOrderSeq orderSeq, List<PaymentOrderDto> orders) {
        // todo
        return null;
    }
}
