package com.smartpay.cbp.core.enums;


import com.smartpay.cbp.common.core.utils.ICode;

/**
 * 全局响应代码，异常响应代码: 限制区间在 A00000 - A00999
 * 定义 com.support.mvc.entity.base.Result#setCode(Code) 返回编码
 */
public enum AppCode implements ICode {

    B03000("调用远程接口失败"),
    B03001("验证码不正确"),
    B03002("文件解析异常"),
    B03003("提现文件数据不能为空"),
    B03004("文件信息不存在"),
    B03005("审核提现不存在"),
    B03006("不支持的文件类型"),
    B03007("提现申请批次号重复"),

    B03008("该提现批次不存在"),
    B03009("不存在失败订单"),
    B03010("请确认当前状态，当前状态无法审核"),
    B03011("请先登录"),


    ;
    /**
     * 枚举属性说明
     */
    public final String comment;

    AppCode(String comment) {
        this.comment = comment;
    }

    @Override
    public String getComment() {
        return this.comment;
    }
}
