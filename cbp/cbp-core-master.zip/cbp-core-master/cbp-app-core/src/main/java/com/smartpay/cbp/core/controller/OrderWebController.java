package com.smartpay.cbp.core.controller;

import com.smartpay.cbp.common.core.domain.R;
import com.smartpay.cbp.common.log.annotation.Log;
import com.smartpay.cbp.common.log.enums.BusinessType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @description ：订单WEB接口
 * @author ：jmwang
 * @date ：2022/11/8 09:29
 * @version ：V1.0
 */
@RequestMapping("/web/order")
@RestController
public class OrderWebController {

    @Log(title = "订单申报", businessType = BusinessType.INSERT)
    @PostMapping("/apply")
    public R<Object> apply() {
        // todo
        return R.ok();
    }
}
