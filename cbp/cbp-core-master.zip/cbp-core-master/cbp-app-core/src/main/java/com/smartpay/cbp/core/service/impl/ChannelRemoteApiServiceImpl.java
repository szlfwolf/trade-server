package com.smartpay.cbp.core.service.impl;

import cn.hutool.core.collection.CollUtil;
import com.smartpay.cbp.channel.dto.MerchantUserInfoReqDto;
import com.smartpay.cbp.channel.dto.RegisterNotifyInfoDto;
import com.smartpay.cbp.channel.dto.UploadReqDto;
import com.smartpay.cbp.channel.dto.UploadRspDto;
import com.smartpay.cbp.channel.feign.RemoteChannelApiService;
import com.smartpay.cbp.common.core.constant.SecurityConstants;
import com.smartpay.cbp.common.core.domain.R;
import com.smartpay.cbp.core.service.ChannelRemoteApiService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Carer
 * @desc
 * @date 2022/11/15 15:36
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class ChannelRemoteApiServiceImpl implements ChannelRemoteApiService {

    private final RemoteChannelApiService remoteChannelApiService;

    /**
     * 批量文件上传
     * @param fileIds 文件上传文件Id集合
     * @param channelNo 渠道号
     * @return 文件上传后响应内容
     */
    @Override
    public List<UploadRspDto> uploadRegisterFile(String channelNo,String... fileIds) {
        UploadReqDto uploadReqDto = new UploadReqDto();
        uploadReqDto.setFileIds(CollUtil.toList(fileIds));
        uploadReqDto.setChannelNo(channelNo);
        log.info("渠道文件上传请求入参：{}",uploadReqDto);
        R<List<UploadRspDto>> listR = remoteChannelApiService.uploadRegisterFile(uploadReqDto, SecurityConstants.INNER);
        log.info("渠道文件上传响应：{}",listR);
        if(Boolean.TRUE.equals(R.isError(listR))){
            throw new RuntimeException("渠道文件上传异常!");
        }
        return listR.getData();
    }

    /**
     * 渠道发送
     *
     * @param merchantUserInfoDto 发送内容
     * @return 请求编号
     */
    @Override
    public String channelSend(MerchantUserInfoReqDto merchantUserInfoDto) {
        log.info("渠道备案请求内容：{}",merchantUserInfoDto);
        R<String> stringR = remoteChannelApiService.registerSend(merchantUserInfoDto, SecurityConstants.INNER);
        log.info("渠道备案响应内容：{}",stringR);
        if(Boolean.TRUE.equals(R.isError(stringR))){
            throw new RuntimeException("渠道备案异常！");
        }
        return stringR.getData();
    }

    /**
     * 根据Id获取备案回调信息
     *
     * @param id 主键信息
     * @return 备案回调信息
     */
    @Override
    public RegisterNotifyInfoDto getRegisterNotifyInfoById(String id) {
        log.info("根据Id获取备案回调信息入参Id:{}",id);
        R<RegisterNotifyInfoDto> registerNotifyInfoR = remoteChannelApiService.getRegisterNotifyInfo(id
                , SecurityConstants.INNER);
        log.info("根据Id获取渠道备案回调响应内容：{}",registerNotifyInfoR);
        if(Boolean.TRUE.equals(R.isError(registerNotifyInfoR))){
            throw new RuntimeException("获取渠道备案回调异常！");
        }
        return registerNotifyInfoR.getData();
    }

    @Override
    public void updateNotifyDealResult(String id) {
        log.info("更新回调通知处理结果入参：{}",id);
        R<Boolean> booleanR = remoteChannelApiService.updateNotifyFinish(id, SecurityConstants.INNER);
        log.info("更新回调通知处理结果响应内容：{}",booleanR);
    }
}
