package com.smartpay.cbp.core.service;

import com.smartpay.cbp.core.dto.PaymentOrderDto;

import java.io.InputStream;
import java.io.Reader;
import java.util.List;

/**
 * @author ：jmwang
 * @version ：V1.0
 * @description ：文件解析接口
 * @date ：2022/11/8 15:38
 */
public interface FileParseHandler {

    /**
     * 订单申报文件解析
     * @param is 文件流
     * @return
     */
    List<PaymentOrderDto> parseOrder(InputStream is);

}
