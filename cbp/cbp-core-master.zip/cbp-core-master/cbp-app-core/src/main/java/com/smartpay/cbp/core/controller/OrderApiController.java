package com.smartpay.cbp.core.controller;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.smartpay.cbp.common.core.domain.R;
import com.smartpay.cbp.common.log.annotation.Log;
import com.smartpay.cbp.common.log.enums.BusinessType;
import com.smartpay.cbp.console.dto.MerchantInfoForeignDto;
import com.smartpay.cbp.core.dto.FileInfoDto;
import com.smartpay.cbp.core.dto.OrderApplyDto;
import com.smartpay.cbp.core.dto.OrderApplyRequest;
import com.smartpay.cbp.core.dto.OrderApplyResponse;
import com.smartpay.cbp.core.enums.CurrencyType;
import com.smartpay.cbp.core.enums.ProviderType;
import com.smartpay.cbp.core.service.ConsoleRemoteApiService;
import com.smartpay.cbp.core.service.FileService;
import com.smartpay.cbp.core.service.OrderApiService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

/**
 * @description ：订单API接口
 * @author ：jmwang
 * @date ：2022/11/8 09:29
 * @version ：V1.0
 */
@RequestMapping("/api/order")
@RestController
@AllArgsConstructor
public class OrderApiController {

    private final ConsoleRemoteApiService consoleRemoteApiService;
    private final FileService fileService;
    private final OrderApiService orderApiService;

    @Log(title = "订单申报", businessType = BusinessType.INSERT)
    @PostMapping("/apply")
    public R<OrderApplyResponse> apply(OrderApplyRequest request) {
        // 检查商户
        Optional<MerchantInfoForeignDto> merchantOpt = consoleRemoteApiService.getMerchantInfoByMerchantNo(request.getMerchantId());
        if (!merchantOpt.isPresent()) {
            // todo 商户不存在
        }

        // 校验文件
        FileInfoDto file = fileService.getFileByFileId(request.getFileId(), false);
        if (ObjectUtil.isNull(file)) {
            // todo 文件不存在
        }
        if (!StrUtil.equals("csv", file.getSuffix())) {
            // todo 文件类型不正确
        }

        // 校验币种
        CurrencyType currencyType = CurrencyType.parse(request.getCurrency());
        if (ObjectUtil.isNull(currencyType)) {
            // todo 币种不存在
        }

        OrderApplyDto applyDto = new OrderApplyDto();
        applyDto.setRequestId(request.getRequestId());
        applyDto.setMerchant(applyDto.getMerchant());
        applyDto.setFileType(ProviderType.CSV.getCode());
        applyDto.setFile(file);

        OrderApplyResponse data = orderApiService.apply(applyDto);

        return R.ok(data);
    }

}
