package com.smartpay.cbp.core.repository;

import com.baomidou.mybatisplus.extension.service.IService;
import com.smartpay.cbp.core.entity.ApproveInfoEntity;

/**
 * @author Carer
 * @desc
 * @date 2022/11/22 14:33
 */
public interface ApproveInfoRepository extends IService<ApproveInfoEntity> {
}
