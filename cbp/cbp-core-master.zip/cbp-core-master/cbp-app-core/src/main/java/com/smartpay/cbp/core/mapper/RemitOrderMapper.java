package com.smartpay.cbp.core.mapper;

import com.smartpay.cbp.core.entity.RemitOrder;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Set;

/**
 * @author guogangqiang
 * @description 针对表【t_remit_order(商户下发明细表)】的数据库操作Mapper
 * @createDate 2022-11-03 20:18:17
 * @Entity com.smartpay.cbp.core.entity.RemitOrder
 */
public interface RemitOrderMapper extends BaseMapper<RemitOrder> {


    @Select("<script>" +
            "SELECT order_no " +
            "FROM t_remit_order " +
            "WHERE (merchant_no,order_no) in " +
            "<foreach collection='orderNos' index='index' item='orderNo' open='(' separator=',' close=')'>" +
            "(#{merchantNo},#{orderNo})" +
            "</foreach>" +
            "</script>")
    Set<String> existOrderNo(@Param("merchantNo") String merchantNo,@Param("orderNos") Set<String> orderNos);


}




