package com.smartpay.cbp.core.dto;

import cn.hutool.core.collection.CollUtil;
import lombok.Data;

import java.util.List;

/**
 * @author ：jmwang
 * @version ：V1.0
 * @description ：
 * @date ：2022/11/10 09:56
 */
@Data
public class OrderValidateDto {

    List<PaymentOrderDto> successOrders;

    List<PaymentOrderFailDto> failOrders;

    public long getSuccessCnt() {
        if (CollUtil.isEmpty(successOrders)) {
            return 0L;
        }
        return successOrders.size();
    }

    public long getFailCnt() {
        if (CollUtil.isEmpty(failOrders)) {
            return 0L;
        }
        return failOrders.size();
    }

    public long getSuccessAmt() {
        if (CollUtil.isEmpty(successOrders)) {
            return 0L;
        }
        return successOrders.stream().mapToLong(PaymentOrderDto::getPayAmt).sum();
    }

    public long getFailAmt() {
        if (CollUtil.isEmpty(failOrders)) {
            return 0L;
        }
        return failOrders.stream().mapToLong(PaymentOrderDto::getPayAmt).sum();
    }

}
