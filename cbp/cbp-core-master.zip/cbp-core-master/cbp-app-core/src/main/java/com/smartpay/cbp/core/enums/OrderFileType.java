package com.smartpay.cbp.core.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author ：jmwang
 * @version ：V1.0
 * @description ：订单文件类型
 * @date ：2022/11/8 17:23
 */
@Getter
@AllArgsConstructor
public enum OrderFileType {

    // api文件格式
    CSV("csv"),
    // web文件格式
    EXCEL("xls, xlsx");

    private String comment;

}
