package com.smartpay.cbp.core.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDateTime;

/**
 * t_file
 * @author carer
 */
@TableName("t_file")
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@ToString(callSuper = true)
public class FileInfoEntity extends Model<FileInfoEntity> {

    private static final long serialVersionUID = 1500474062919531768L;
    /**
     * 主键
     */
    private String id;

    /**
     * 数据来源,${@link com.smartpay.cbp.core.constant.SourceFrom}
     */
    private String sourceFrom;

    /**
     * 文件类型
     */
    private String fileType;

    /**
     * 文件名
     */
    private String fileName;

    /**
     * 文件路径名称
     */
    private String filePathName;

    /**
     * 文件链接
     */
    private String fileLink;

    /**
     * 文件大小
     */
    private Long fileSize;

    /**
     * 存储类型,0本地，1-sftp,2-对象存储
     */
    private String storeType;

    /**
     * 备注
     */
    private String remark;

    /**
     * 创建人
     */
    private String crtBy;

    /**
     * 创建时间
     */
    private LocalDateTime crtTime;

    /**
     * 更新人
     */
    private String uptBy;

    /**
     * 更新时间
     */
    private LocalDateTime uptTime;

}