package com.smartpay.cbp.core.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.img.ImgUtil;
import cn.hutool.core.io.FileUtil;
import cn.hutool.core.io.IoUtil;
import cn.hutool.core.util.ArrayUtil;
import com.smartpay.cbp.core.constant.SourceFrom;
import com.smartpay.cbp.core.constant.StoreType;
import com.smartpay.cbp.core.dto.*;
import com.smartpay.cbp.core.entity.FileInfoEntity;
import com.smartpay.cbp.core.mapstruct.FileInfoMapStruct;
import com.smartpay.cbp.core.repository.FileInfoRepository;
import com.smartpay.cbp.core.service.ConsoleRemoteApiService;
import com.smartpay.cbp.core.service.FileService;
import com.smartpay.cbp.core.service.FileStorageService;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.io.InputStream;
import java.net.URLEncoder;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author Carer
 * @desc 文件服务类
 * @date 2022/11/7 17:01
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class FileServiceImpl implements FileService {


    @Qualifier("minIoStorage")
    private final FileStorageService fileStorageService;

    private final FileInfoRepository fileInfoRepository;

    private final ConsoleRemoteApiService consoleRemoteApiService;

    private final FileInfoMapStruct fileInfoMapStruct;

    /**
     * 通用文件上传
     *
     * @param fileUploadReqDto 文件上传请求实体
     * @return 上传文件响应文件指纹Id
     */
    @SneakyThrows
    @Override
    public String uploadFile(FileUploadReqDto fileUploadReqDto) {
        //校验商户状态
        consoleRemoteApiService.checkMerchantStatus(fileUploadReqDto.getMerchantNo());
        //文件上传MinIo
        MultipartFile file = fileUploadReqDto.getFile();
        return uploadPageFile(file,SourceFrom.INSIDE_API);
    }

    /**
     * 根据文件指纹Id获取文件url
     *
     * @param fileId 文件指纹
     * @return 文件Url
     */
    @Override
    public String getFileUrlByFileId(String fileId) {
        FileInfoEntity fileInfoEntity = getFileInfoById(fileId);
        if (fileInfoEntity.getStoreType().equals(StoreType.MIN_IO.getCode())) {
            return fileInfoEntity.getFileLink();
        }
        log.warn("暂时没有其他文件存储方案，暂不开发！");
        return null;
    }

    @Override
    public FileInfoDto getFileByFileId(String fileId, boolean includeData) {
        FileInfoEntity fileInfoEntity = getFileInfoById(fileId);
        FileInfoDto fileInfoDto = new FileInfoDto();
        fileInfoDto.setId(fileId);
        fileInfoDto.setName(fileInfoEntity.getFileName());
        fileInfoDto.setFullName(fileInfoEntity.getFileName());
        fileInfoDto.setSuffix(fileInfoEntity.getFileType());
        if (includeData && fileInfoEntity.getStoreType().equals(StoreType.MIN_IO.getCode())) {
            fileInfoDto.setFileData(fileStorageService.downloadFile(fileInfoEntity.getFilePathName()));
        }
        return fileInfoDto;
    }

    private FileInfoEntity getFileInfoById(String fileId) {
        Optional<FileInfoEntity> fileInfoEntityOptional = fileInfoRepository.getNonByFileId(fileId);
        return fileInfoEntityOptional.orElseThrow(() -> new RuntimeException("文件信息不存在！"));
    }

    /**
     * 根据文件ID下载文件
     *
     * @param fileId 文件指纹Id
     * @return 文件响应流
     */
    @SneakyThrows
    @Override
    public ResponseEntity<StreamingResponseBody> download(String fileId) {
        FileInfoEntity fileInfoEntity = getFileInfoById(fileId);
        if (!fileInfoEntity.getStoreType().equals(StoreType.MIN_IO.getCode())) {
            return null;
        }
        HttpHeaders httpHeaders = new HttpHeaders();
        MediaType mediaType;
        if(ArrayUtil.contains(new String[]{ImgUtil.IMAGE_TYPE_GIF,ImgUtil.IMAGE_TYPE_JPG,ImgUtil.IMAGE_TYPE_JPEG
                ,ImgUtil.IMAGE_TYPE_BMP,ImgUtil.IMAGE_TYPE_PNG,ImgUtil.IMAGE_TYPE_PSD},fileInfoEntity.getFileType())){
            mediaType = new MediaType("image", fileInfoEntity.getFileType());
        }else if("pdf".equalsIgnoreCase(fileInfoEntity.getFileType())){
            mediaType = MediaType.APPLICATION_PDF;
        }else {
            httpHeaders.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" +
                    URLEncoder.encode(fileInfoEntity.getFileName(),"UTF-8"));
            mediaType = MediaType.valueOf("application/octet-stream;charset=gb2312");
        }
        return ResponseEntity.ok()
                .headers(httpHeaders)
                .contentType(mediaType)
                .contentLength(fileInfoEntity.getFileSize())
                .body(outputStream -> {
                    try (InputStream in = fileStorageService.downloadFile(fileInfoEntity.getFilePathName())) {
                        IoUtil.copy(in, outputStream, 1024);
                    }finally {
                        IoUtil.close(outputStream);
                    }
                });
    }

    @Override
    public String uploadFile(FileUploadDto file) {
        String fileUrl = fileStorageService.upload(file);
        FileInfoEntity fileInfoEntity = new FileInfoEntity();
        fileInfoEntity.setFileName(file.getFileName());
        fileInfoEntity.setFileType(file.getFileType());
        fileInfoEntity.setFileSize((long) file.getFileData().length);
        fileInfoEntity.setFilePathName(file.getFilePathName());
        fileInfoEntity.setFileLink(fileUrl);
        fileInfoEntity.setStoreType(fileStorageService.getStoreType());
        fileInfoRepository.save(fileInfoEntity);
        return fileInfoEntity.getId();
    }

    /**
     * 根据文件指纹Id获取文件对象信息集合
     *
     * @param fileIds 文件指纹
     * @return 文件对象信息集合
     */
    @Override
    public List<FileInfoRspDto> getFileInfoRspByFileIds(List<String> fileIds) {
        List<FileInfoEntity> fileInfoEntities = fileInfoRepository.listByIds(fileIds);
        if (CollUtil.isEmpty(fileInfoEntities)) {
            return Collections.emptyList();
        }
        return fileInfoEntities.stream().map(fileInfoMapStruct::toDto).collect(Collectors.toList());
    }

    /**
     * 网页文件上传
     *
     * @param file 文件上传请求实体
     * @return 上传文件响应文件指纹Id
     */
    @Override
    public String uploadPageFile(MultipartFile file, SourceFrom sourceFrom) {
        //文件上传MinIo
        FileInfoObj fileInfoObj = fileStorageService.upload(file);
        FileInfoEntity fileInfoEntity = new FileInfoEntity();
        fileInfoEntity.setSourceFrom(sourceFrom.getCode());
        fileInfoEntity.setFileName(file.getResource().getFilename());
        fileInfoEntity.setFileType(FileUtil.extName(fileInfoEntity.getFileName()));
        fileInfoEntity.setFileSize(file.getSize());
        fileInfoEntity.setFilePathName(fileInfoObj.getFilePathName());
        fileInfoEntity.setFileLink(fileInfoObj.getFileUrl());
        fileInfoEntity.setStoreType(fileStorageService.getStoreType());
        fileInfoRepository.save(fileInfoEntity);
        return fileInfoEntity.getId();
    }
}
