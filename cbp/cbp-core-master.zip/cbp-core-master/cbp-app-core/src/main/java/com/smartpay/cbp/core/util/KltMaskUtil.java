package com.smartpay.cbp.core.util;
import org.apache.commons.lang3.StringUtils;

/**
 * @Description:掩码工具
 * @Company:开联通支付服务有限公司
 * @Author:toni liu
 * @Date:2022/5/7 14:59
 */
public class KltMaskUtil {

    /**
     * 姓名脱敏
     * 一位时不脱敏，‘姓’脱敏
     *
     * @param name
     * @return
     */
    public static String nameMask(String name) {
        if (StringUtils.isNotBlank(name)) {
            char[] sArr = name.toCharArray();
            if (sArr.length == 2) {
                return "*" + sArr[1];
            } else if (sArr.length > 2) {
                sArr[0] = '*';
                return new String(sArr);
            }
        }
        return name;
    }

    /**
     * 手机号脱敏处理
     * 保留前3后4，中间星号显示
     *
     * @param phoneNo
     * @return
     */
    public static String phoneNoMask(String phoneNo) {
        if (StringUtils.isNotBlank(phoneNo)) {
            String s4 = phoneNo.replaceAll("(\\d{3})\\d*(\\d{4})", "$1****$2");
            return s4;
        }
        return phoneNo;
    }

    /**
     * 证件号脱敏处理
     * 保留前六后四, 适用于15位和18位身份证号
     *
     * @param idNo
     * @return
     */
    public static String idNoMask(String idNo) {
        if (StringUtils.isNotBlank(idNo)) {
            return StringUtils.left(idNo, 6).concat(StringUtils.removeStart(StringUtils.leftPad(StringUtils.right(idNo, 4), StringUtils.length(idNo), "*"), "******"));
        }
        return idNo;
    }


    public static String cardPassMask(String password) {
        if (StringUtils.isNotBlank(password)) {
            return StringUtils.left(password, 1).concat(StringUtils.removeStart(StringUtils.leftPad(StringUtils.right(password, 1), StringUtils.length(password), "*"), "******"));
        }
        return password;
    }

    /**
     * 银行卡号脱敏
     * 保留前六后四,其他位以星号显示
     *
     * @param bankCardNo
     * @return
     */
    public static String bankCardNoMask(String bankCardNo) {
        if (StringUtils.isNotBlank(bankCardNo)) {
            return replaceBetween(bankCardNo, 6, bankCardNo.length() - 4, "*");
        }
        return bankCardNo;
    }

    public static String emailMask(String email){
        if(StringUtils.isNotBlank(email)){
            //邮箱账号名只显示前两位
            String[] arr=email.split("@");
            String prefix=arr[0];
            String sufix=arr[1];
            if (email.indexOf("@") >= 3) {
                email=prefix.substring(0,3)+"***@"+sufix;
                return email;
            }else{
                email=prefix.substring(0,1)+"***@"+sufix;
                return email;
            }
        }
        return email;
    }

    /**
     * 将字符串开始位置到结束位置之间的字符用指定字符替换
     *
     * @param sourceStr   待处理字符串
     * @param begin       开始位置
     * @param end         结束位置
     * @param replacement 替换字符
     * @return
     */
    private static String replaceBetween(String sourceStr, int begin, int end, String replacement) {
        if (StringUtils.isBlank(sourceStr)) {
            return sourceStr;
        }
        if (null == replacement) {
            replacement = "*";
        }
        int replaceLength = end - begin;
        if (StringUtils.isNotBlank(sourceStr) && replaceLength > 0) {
            StringBuilder sb = new StringBuilder(sourceStr);
            sb.replace(begin, end, StringUtils.repeat(replacement, replaceLength));
            return sb.toString();
        } else {
            return sourceStr;
        }
    }

    /**
     * 身份证类型转换
     */
    public static String changeIdType(String idType){
        if("00".equals(idType)){
            idType = "01";
        }
        return idType;
    }

}
