package com.smartpay.cbp.core.vo;

import com.smartpay.cbp.common.core.annotation.Excel;
import com.smartpay.cbp.core.enums.RemitOrderStatus;
import com.smartpay.cbp.core.enums.RemitReqStatus;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.Objects;

/**
 * @Description: 提现请求vo
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/21 17:55
 * @Version: 1.0
 */
@Data
public class RemitReqVo {

    @ApiModelProperty("主键id")
    private String id;

    @Excel(name = "商户号")
    @ApiModelProperty("商户号")
    private String merchantNo;

    @Excel(name = "商户名称")
    @ApiModelProperty("商户名称")
    private String merchantName;

    @Excel(name = "提现批次号")
    @ApiModelProperty("批次号")
    private String batchNo;

    @Excel(name = "申请总条数")
    @ApiModelProperty("总条数")
    private Integer totalCount;

    @Excel(name = "校验通过笔数")
    @ApiModelProperty("校验成功数")
    private Integer totalSuccessCount;

    @Excel(name = "申请总金额")
    @ApiModelProperty("总金额")
    private Long totalAmount;

    @Excel(name = "校验通过总金额")
    @ApiModelProperty("校验成功金额")
    private Long totalSuccessAmount;

    @Excel(name = "状态")
    @ApiModelProperty("状态中文")
    private String statusName;

    @Excel(name = "创建时间",dateFormat = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("创建时间")
    private Date crtTime;

    @Excel(name = "更新时间",dateFormat = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("更新时间")
    private Date uptTime;

    @ApiModelProperty("状态")
    private String status;

    @ApiModelProperty("文件名")
    private String fileName;

    @ApiModelProperty("创建人")
    private String crtUserName;

    @ApiModelProperty("审核人")
    private String reviewUserName;

}
