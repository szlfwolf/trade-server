package com.smartpay.cbp.core.handler;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Maps;
import com.smartpay.cbp.common.core.constant.SecurityConstants;
import com.smartpay.cbp.common.core.domain.R;
import com.smartpay.cbp.common.core.domain.Result;
import com.smartpay.cbp.console.dto.MerchantChargeFeignDto;
import com.smartpay.cbp.console.feign.CommonApiService;
import com.smartpay.cbp.core.dto.MerchantUserRegCheckReqDto;
import com.smartpay.cbp.core.enums.AppCode;
import com.smartpay.cbp.core.feign.RemoteCoreApiService;
import com.smartpay.cbp.system.api.RemoteUserService;
import com.smartpay.cbp.system.api.domain.SysUser;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author guogangqiang
 * @version <b>1.0.0</b>
 * @date 2022/11/8 19:33
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class RemoteCallHandler {

    private final RemoteCoreApiService remoteCoreApiService;

    private final RemoteUserService remoteUserService;

    private final CommonApiService commonApiService;


    /**
     * 校验卖家是否在商户下备案
     *
     * @param merchantUserRegCheckReqDto
     * @return
     */
    public List<String> checkRegistedBatch(MerchantUserRegCheckReqDto merchantUserRegCheckReqDto) {
        log.info("【开始】调用远程校验卖家是否备案,参数:{}", JSON.toJSONString(merchantUserRegCheckReqDto));
        R<List<String>> response = remoteCoreApiService.checkRegistedBatch(merchantUserRegCheckReqDto, SecurityConstants.INNER);
        log.info("【结束】调用远程校验卖家是否备案完成：{}", JSON.toJSONString(response));
        if (R.isError(response)) {
            throw AppCode.B03000.toCodeException("【异常】远程调用校验卖家是否备案异常：%s,%s", response.getCode(), response.getMsg());
        }
        return response.getData();
    }


    /**
     * 获取用户信息
     *
     * @param userIds
     * @return
     */
    public Map<Long, SysUser> mapByUserIds(Set<Long> userIds) {
        log.info("【开始】远程获取用户信息,用户ids：{}", JSON.toJSONString(userIds));
        Result<Map<Long, SysUser>> result = remoteUserService.mapByUserIds(userIds, SecurityConstants.INNER);
        if (Result.isError(result)) {
            log.error("【异常】远程调用获取用户信息异常：{},{}", result.getCode(), result.getMsg());
            return Maps.newHashMap();
        }
        log.info("【结束】远程获取用户信息成功，结果：{}", JSON.toJSONString(result));
        return result.getData();
    }

    /**
     * 获取商户手续费配置
     *
     * @param merchantNo
     * @param productCode
     * @return
     */
    public MerchantChargeFeignDto getChargeInfo(String merchantNo, String productCode) {
        log.info("【开始】调用远程接口查询手续费账户，商户号：{}，产品编号：{}", merchantNo, productCode);
        R<MerchantChargeFeignDto> result = commonApiService.findChargeInfo(merchantNo, productCode, SecurityConstants.INNER);
        if (R.isError(result)) {
            log.error("【结束】远程查询手续费账户异常：{},{}", result.getCode(), result.getMsg());
            return null;
        }
        log.info("【结束】调用远程接口查询手续费账户结果：{}", JSON.toJSONString(result));
        return result.getData();
    }

}
