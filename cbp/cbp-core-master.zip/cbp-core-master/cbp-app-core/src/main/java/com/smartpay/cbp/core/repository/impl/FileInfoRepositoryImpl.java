package com.smartpay.cbp.core.repository.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.smartpay.cbp.core.entity.FileInfoEntity;
import com.smartpay.cbp.core.mapper.FileInfoMapper;
import com.smartpay.cbp.core.repository.FileInfoRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import java.io.Serializable;
import java.util.Optional;

/**
 * @author Carer
 * @desc
 * @date 2022/11/7 16:47
 */
@Repository
@Slf4j
@RequiredArgsConstructor
public class FileInfoRepositoryImpl extends ServiceImpl<FileInfoMapper, FileInfoEntity> implements FileInfoRepository {
    /**
     * 根据主键获取对象
     *
     * @param id 主键
     * @return 非空对象
     */
    @Override
    public Optional<FileInfoEntity> getNonByFileId(Serializable id) {
        return Optional.ofNullable(getById(id));
    }

    /**
     * 校验文件是否在系统中
     *
     * @param fileIds 文件主键
     */
    @Override
    public void checkExit(String... fileIds) {
        int queryCount = (int)count(Wrappers.<FileInfoEntity>lambdaQuery().in(FileInfoEntity::getId, fileIds));
        if(queryCount!=fileIds.length){
            throw new RuntimeException("影像文件不匹配！");
        }
    }
}
