package com.smartpay.cbp.core.dto;

import com.smartpay.cbp.core.annotation.ExcelField;
import com.smartpay.cbp.core.enums.ValidateResult;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

/**
 * @Description: 提现订单DTO
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/4 14:28
 * @Version: 1.0
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ApiModel("提现订单")
@Accessors(chain = true)
public class RemitOrderDto {

    @NotBlank(message = "商户号不能为空")
    @Size(max = 32)
    @ApiModelProperty("商户号")
    private String merchantNo;

    @NotBlank(message = "批次号不能为空")
    @Size(max = 32)
    @ApiModelProperty("批次号")
    private String batchNo;

    @NotBlank(message = "订单编号不能为空")
    @Size(max = 64)
    @ExcelField(name = "提现订单号")
    @ApiModelProperty("订单编号")
    private String orderNo;

    @NotBlank(message = "业务类型不能为空")
    @Size(max = 16)
    @ExcelField(name = "业务类型")
    @ApiModelProperty("业务类型")
    private String businessType;

    @Size(max = 11)
    @ExcelField(name = "银行预留手机号")
    @ApiModelProperty("银行预留手机号")
    private String mobilePhone;

    @NotBlank(message = "产品类型不能为空")
    @Size(max = 32)
    @ExcelField(name = "产品类型")
    @ApiModelProperty("产品编码")
    private String productCode;

    @NotBlank(message = "货币类型不能为空")
    @Size(max = 6)
    @ApiModelProperty("货币类型")
    private String currencyType;

    @NotBlank(message = "用途不能为空")
    @Size(max = 256)
    @ExcelField(name = "用途")
    @ApiModelProperty("用途")
    private String purpose;

    @NotNull(message = "付款金额不能为空")
    @Pattern(regexp = "^(([1-9]{1}\\d*)|(0{1}))(\\.\\d{1,2})?$", message = "金额数值不合法")
    @ExcelField(name = "金额(单位:元)")
    @ApiModelProperty("付款金额")
    private String amt;

    @NotNull(message = "卖家编码不能为空")
    @ExcelField(name = "卖家编码")
    @ApiModelProperty("卖家编码")
    private String platformUserNo;

    @Size(max = 20)
    @ExcelField(name = "联行号")
    @ApiModelProperty("联行号")
    private String cnapsNo;

    @NotBlank(message = "代发类型不能为空")
    @ExcelField(name = "代发类型")
    @ApiModelProperty("提现类型")
    private String remitType;

    @NotBlank(message = "到账类型不能为空")
    @ExcelField(name = "到账类型")
    @ApiModelProperty("到账类型")
    private String timeType;

    @NotBlank(message = "证件类型不能为空")
    @ExcelField(name = "证件类型")
    @ApiModelProperty("证件类型")
    private String accountIdType;

    @NotBlank(message = "证件号码不能为空")
    @Size(max = 64)
    @ExcelField(name = "证件号码")
    @ApiModelProperty("证件号码")
    private String accountIdNo;

    @Size(max = 16)
    @ExcelField(name = "省份")
    @ApiModelProperty("省份")
    private String province;

    @Size(max = 16)
    @ExcelField(name = "地区")
    @ApiModelProperty("城市")
    private String city;

    @Size(max = 32)
    @NotBlank(message = "银行名称不能为空")
    @ExcelField(name = "银行名称")
    @ApiModelProperty("银行名称")
    private String bankName;

    @Size(max = 256)
    @ExcelField(name = "支行名")
    @ApiModelProperty("收款支行名称")
    private String bankBranchName;

    @NotBlank(message = "账号不能为空")
    @Size(max = 32)
    @ExcelField(name = "账号")
    @ApiModelProperty("收款银行账号")
    private String bankAccountNo;

    @NotBlank(message = "户名不能为空")
    @Size(max = 32)
    @ExcelField(name = "户名")
    @ApiModelProperty("收款银行账户名")
    private String bankAccountName;

    @Size(max = 256)
    @ExcelField(name = "备注")
    @ApiModelProperty("备注")
    private String remark;

    @Size(max = 256)
    @ExcelField(name = "备注1")
    @ApiModelProperty("备注1")
    private String remark1;

    @Size(max = 256)
    @ExcelField(name = "备注2")
    @ApiModelProperty("备注2")
    private String remark2;

    @Size(max = 256)
    @ExcelField(name = "备注3")
    @ApiModelProperty("备注3")
    private String remark3;

    @Size(max = 256)
    @ExcelField(name = "备注4")
    @ApiModelProperty("备注4")
    private String remark4;

    @Size(max = 256)
    @ApiModelProperty("平台名称")
    private String platformName;

    @ExcelField(name = "校验结果")
    @ApiModelProperty(value = "校验错误信息", hidden = true)
    private StringBuilder validateErrMsg;

    @ApiModelProperty(value = "校验结果（成功/失败）", hidden = true)
    private ValidateResult validateResult;


}
