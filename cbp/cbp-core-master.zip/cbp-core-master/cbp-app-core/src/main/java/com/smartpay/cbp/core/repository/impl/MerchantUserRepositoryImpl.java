package com.smartpay.cbp.core.repository.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.smartpay.cbp.core.constant.RegisterStatus;
import com.smartpay.cbp.core.entity.MerchantUserEntity;
import com.smartpay.cbp.core.mapper.MerchantUserMapper;
import com.smartpay.cbp.core.repository.MerchantUserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @author Carer
 * @desc
 * @date 2022/11/8 11:31
 */
@Repository
@Slf4j
@RequiredArgsConstructor
public class MerchantUserRepositoryImpl extends ServiceImpl<MerchantUserMapper, MerchantUserEntity>
        implements MerchantUserRepository {
    /**
     * 查询同一渠道下是否存在相同的备案人
     *
     * @param name      明文姓名
     * @param certType  证件类型
     * @param certId    明文证件号
     * @param channelNo 渠道号
     * @return 备案用户信息合集
     */
    @Override
    public List<MerchantUserEntity> queryPersonsByInfo(String name, String certType, String certId, String channelNo) {
        return list(Wrappers.<MerchantUserEntity>lambdaQuery()
                .eq(MerchantUserEntity::getNameEnc,encData(name))
                .eq(MerchantUserEntity::getCertType,certType)
                .eq(MerchantUserEntity::getCertIdEnc,encData(certId))
                .eq(MerchantUserEntity::getChannelNo,channelNo));
    }

    /**
     * 根据商户号和外部用户编号查询备案人集合信息
     *
     * @param merchantNo     商户号
     * @param merchantUserNo 商户侧用户号
     * @return 备案人集合信息
     */
    @Override
    public List<MerchantUserEntity> queryPersonsByMerchantInfo(String merchantNo, String merchantUserNo) {
        return list(Wrappers.<MerchantUserEntity>lambdaQuery()
                .eq(MerchantUserEntity::getMerchantNo,merchantNo)
                .eq(MerchantUserEntity::getMerchantUserNo,merchantUserNo));
    }

    /**
     * 根据统一社会信用代码获取案人集合信息
     * @param licenseNo 统一社会信用代码
     * @param channelNo 渠道号
     * @return 备案人集合信息
     */
    @Override
    public List<MerchantUserEntity> queryCompanysByInfo(String licenseNo,String channelNo) {
        return list(Wrappers.<MerchantUserEntity>lambdaQuery()
                .eq(MerchantUserEntity::getLicenseNo,licenseNo)
                .eq(MerchantUserEntity::getChannelNo,channelNo));
    }

    /**
     * 根据系统用户号查询备案用户
     *
     * @param userNo 系统用户号
     * @return 备案用户信息
     */
    @Override
    public Optional<MerchantUserEntity> queryOneByUserNo(String userNo) {
        return Optional.ofNullable(getOne(Wrappers.<MerchantUserEntity>lambdaQuery()
                .eq(MerchantUserEntity::getUserNo,userNo)));
    }

    /**
     * 根据姓名等信息查询备案信息
     *
     * @param nameEnc   加密姓名
     * @param certType  证件类型
     * @param certIdEnc 证件号
     * @param channelNo 渠道号
     * @return 备案用户信息
     */
    @Override
    public List<MerchantUserEntity> queryPersonsByEncInfoUnSuc(String nameEnc, String certType, String certIdEnc, String channelNo) {
        return list(Wrappers.<MerchantUserEntity>lambdaQuery()
                .eq(MerchantUserEntity::getNameEnc,nameEnc)
                .eq(MerchantUserEntity::getCertType,certType)
                .eq(MerchantUserEntity::getCertIdEnc,certIdEnc)
                .eq(MerchantUserEntity::getChannelNo,channelNo)
                .ne(MerchantUserEntity::getStatus, RegisterStatus.REGISTER_SUCCESS.getCode()));
    }

    /**
     * 根据统一社会信用代码查询不成功备案用户
     *
     * @param licenseNo 统一社会信用代码
     * @param channelNo 渠道号
     * @return 备案用户信息
     */
    @Override
    public List<MerchantUserEntity> queryCompanysByInfoUnsuc(String licenseNo,String channelNo) {
        return list(Wrappers.<MerchantUserEntity>lambdaQuery()
                .eq(MerchantUserEntity::getLicenseNo,licenseNo)
                .eq(MerchantUserEntity::getChannelNo,channelNo)
                .ne(MerchantUserEntity::getStatus,RegisterStatus.REGISTER_SUCCESS.getCode())
        );
    }

    /**
     * 根据ReqNo查询备案用户
     *
     * @param reqNo 备案请求流水号
     * @return 备案用户
     */
    @Override
    public MerchantUserEntity queryByReqId(String reqNo) {
        return getOne(Wrappers.<MerchantUserEntity>lambdaQuery().eq(MerchantUserEntity::getRegReqId,reqNo));
    }

    /**
     * 查找对应状态的备案用户
     *
     * @param nameEnc   姓名加密
     * @param certType  证件类型
     * @param certIdEnc 证件号加密
     * @param channelNo 渠道号
     * @param status    状态
     * @return 备案用户集合
     */
    @Override
    public List<MerchantUserEntity> queryPersonsByEncInfoStatus(String nameEnc, String certType, String certIdEnc
            , String channelNo, RegisterStatus status) {
        return list(Wrappers.<MerchantUserEntity>lambdaQuery()
                .eq(MerchantUserEntity::getNameEnc,nameEnc)
                .eq(MerchantUserEntity::getCertType,certType)
                .eq(MerchantUserEntity::getCertIdEnc,certIdEnc)
                .eq(MerchantUserEntity::getChannelNo,channelNo)
                .eq(MerchantUserEntity::getStatus,status.getCode())
        );
    }

    /**
     * 查找对应状态的企业备案用户
     *
     * @param licenseNo 统一社会信用代码
     * @param channelNo 渠道号
     * @param status    状态
     * @return 备案用户集合
     */
    @Override
    public List<MerchantUserEntity> queryCompanysByInfoStatus(String licenseNo, String channelNo, RegisterStatus status) {
        return list(Wrappers.<MerchantUserEntity>lambdaQuery()
                .eq(MerchantUserEntity::getLicenseNo,licenseNo)
                .eq(MerchantUserEntity::getChannelNo,channelNo)
                .eq(MerchantUserEntity::getStatus,status)
        );
    }

    /**
     * 数据加密
     * @param dataStr 明文
     * @return 加密后
     */
    private String encData(String dataStr){
        return dataStr;
    }
}
