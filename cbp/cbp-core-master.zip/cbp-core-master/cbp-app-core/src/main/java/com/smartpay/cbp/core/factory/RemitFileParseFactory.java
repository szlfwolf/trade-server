package com.smartpay.cbp.core.factory;

import com.smartpay.cbp.core.enums.FileType;
import com.smartpay.cbp.core.interfaces.RemitFileParse;
import com.smartpay.cbp.core.interfaces.impl.RemitCsvParse;
import com.smartpay.cbp.core.interfaces.impl.RemitExcelParse;

/**
 * @Description: 提现文件解析工厂
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/14 17:30
 * @Version: 1.0
 */
public class RemitFileParseFactory {

    /**
     * 获取提现文件解析实例
     *
     * @param fileType 文件类型
     * @return 文件解析对象
     */
    public static RemitFileParse instance(FileType fileType) {
        return fileType == FileType.CSV ? new RemitCsvParse() : new RemitExcelParse();
    }

}
