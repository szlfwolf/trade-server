package com.smartpay.cbp.core.enums;

/**
 * @Description: 提现审核状态
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/9 13:36
 * @Version: 1.0
 */
public enum RemitReviewStatus {

    PASS("审核通过"),
    REFUSE("审核通过"),

    ;

    public final String desc;

    RemitReviewStatus(String desc) {
        this.desc = desc;
    }

}
