package com.smartpay.cbp.core.constants;

import cn.hutool.core.util.CharUtil;

/**
 * @author ：jmwang
 * @version ：V1.0
 * @description ：系统常量
 * @date ：2022/11/8 16:45
 */
public class Constants {

    /**
     * 填充符
     */
    public static final String FILL_ZERO = "0";
    public static final String FILL_EMPTY = " ";

    /**
     * CSV文件分隔符
     */
    public static final String CSV_SPLIT = CharUtil.toString((char) 0x0f);


    public static final String CORE_EXCHANGE = "CBP-CORE-EXCHANGE";
    public static final String REGISTER_QUEUE = "REGISTER-QUEUE";
    public static final String REGISTER_NOTIFY_OUTSIDE_QUEUE = "REGISTER_NOTIFY_OUTSIDE-QUEUE";
    public static final String NOTIFY_OUTSIDE_QUEUE = "NOTIFY-OUTSIDE_QUEUE";

    /**
     * 提现失败文件名称前缀
     */
    public static final String REMIT_FAIL_FILE_PRIFIX = "提现失败明细";
    public static final String REMIT_FAIL_FILE_NAME = "RemitFailFile";

    /**
     * 提现申请锁key
     */
    public static final String REMIT_APPLY_LOCK = "REMIT_APPLY_LOCK";

    public static final String ZERO = "0";

    public static final String HUNDRED = "100";

}
