package com.smartpay.cbp.core.enums;

import java.util.Arrays;
import java.util.Objects;

/**
 * @Description: 代发类型
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/4 15:41
 * @Version: 1.0
 */
public enum RemitType {

    INIT("默认"),
    P("对私"),
    C("对公"),

    ;

    public final String comment;


    RemitType(String comment) {
        this.comment = comment;
    }

    public String getComment() {
        return comment;
    }

    public static RemitType nameToEnum(String name) {
        return Arrays.stream(RemitType.values()).filter(remitType -> remitType.name().equalsIgnoreCase(name))
                .findFirst()
                .orElse(INIT);
    }

    public static RemitType ordinalToEnum(String ordinal) {
        return Arrays.stream(RemitType.values()).filter(remitType -> Objects.equals(remitType.ordinal(), Integer.parseInt(ordinal)))
                .findFirst()
                .orElse(INIT);
    }

}
