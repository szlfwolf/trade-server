package com.smartpay.cbp.core.rabbit;

import com.smartpay.cbp.core.constants.Constants;
import com.smartpay.cbp.core.entity.MerchantUserEntity;
import com.smartpay.cbp.core.repository.MerchantUserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.amqp.rabbit.annotation.*;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

/**
 * @author Carer
 * @desc  离岸通知队列
 * @date 2022/11/8 20:25
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class RegisterNotifyOutSideListen {

    private final RedissonClient redissonClient;

    private final MerchantUserRepository merchantUserRepository;

    /**
     * 监听 离岸通知 队列的处理器
     * @param message 消息
     */
    @RabbitListener(bindings = {@QueueBinding(value = @Queue(value = Constants.REGISTER_NOTIFY_OUTSIDE_QUEUE)
            ,exchange = @Exchange(Constants.CORE_EXCHANGE),key = Constants.REGISTER_NOTIFY_OUTSIDE_QUEUE )} )
    @RabbitHandler
    public void onMessage(Message<String> message) {
        log.info("离岸通知发送，渠道备案通知原数据key:{}",message.getPayload());
        RLock lock = redissonClient.getLock(message.getPayload());
        try {
            if(!lock.tryLock()){
                log.warn("离岸通知发送获取锁失败！");
                return;
            }
            MerchantUserEntity merchantUserEntity = merchantUserRepository.getById(message.getPayload());
            log.info("就当通知了把！{}",merchantUserEntity);
        }finally {
            lock.unlock();
        }
    }

}
