package com.smartpay.cbp.core.service.impl;

import com.alibaba.fastjson.JSON;
import com.smartpay.cbp.core.config.OrderDirectRabbitConfig;
import com.smartpay.cbp.core.dto.OrderApplyDto;
import com.smartpay.cbp.core.dto.OrderApplyMqDto;
import com.smartpay.cbp.core.dto.OrderApplyResponse;
import com.smartpay.cbp.core.entity.PaymentOrderSeq;
import com.smartpay.cbp.core.enums.OrderApplyStatus;
import com.smartpay.cbp.core.enums.SequenceType;
import com.smartpay.cbp.core.mapstruct.PaymentOrderReqStruct;
import com.smartpay.cbp.core.service.IPaymentOrderSeqService;
import com.smartpay.cbp.core.service.OrderApiService;
import com.smartpay.cbp.core.util.SequenceUtil;
import lombok.AllArgsConstructor;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

/**
 * @description ：订单申报API功能
 * @author ：jmwang
 * @version ：V1.0
 * @date ：2022/11/8 15:00
 */
@AllArgsConstructor
@Service
public class OrderApiServiceImpl implements OrderApiService {

    private final IPaymentOrderSeqService paymentOrderSeqService;
    private final PaymentOrderReqStruct paymentOrderReqStruct;
    private final RabbitTemplate rabbitTemplate;

    @Override
    public OrderApplyResponse apply(OrderApplyDto applyDto) {
        // 保存订单请求数据
        PaymentOrderSeq entity = new PaymentOrderSeq();
        // todo 雪花ID
        //entity.setId();
        entity.setBatchNo(SequenceUtil.genSerialNo(SequenceType.ORDER_APPLY));
        entity.setMerchantNo(applyDto.getMerchant().getMerchantNo());
        entity.setPayCur(applyDto.getCurrency());
        entity.setSourceSys(applyDto.getSourceSys());
        entity.setFileName(applyDto.getFile().getFullName());
        entity.setFileType(applyDto.getFileType());
        entity.setFileId(applyDto.getFile().getId());
        entity.setStatus(OrderApplyStatus.INIT.getCode());
        boolean success = paymentOrderSeqService.save(entity);
        if (!success) {
            // todo
        }

        // 异步处理订单文件
        OrderApplyMqDto mqDto = paymentOrderReqStruct.convertMq(entity);
        rabbitTemplate.convertAndSend(OrderDirectRabbitConfig.ORDER_EXCHANGE,
                OrderDirectRabbitConfig.ORDER_APPLY_QUEUE,
                JSON.toJSONString(mqDto));

        // todo
        return null;
    }
}
