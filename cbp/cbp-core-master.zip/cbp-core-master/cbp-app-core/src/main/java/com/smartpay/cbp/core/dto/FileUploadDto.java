package com.smartpay.cbp.core.dto;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.text.CharSequenceUtil;
import com.smartpay.cbp.common.core.utils.DateUtils;
import com.smartpay.cbp.common.core.utils.StringUtils;
import com.smartpay.cbp.common.core.utils.uuid.Seq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * @Description: 文件上传DTO
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/9 14:52
 * @Version: 1.0
 */
@Data
@Builder
public class FileUploadDto {

    @NotNull
    @ApiModelProperty("文件名称")
    private String fileName;

    private String filePathName;

    @NotNull
    @ApiModelProperty("文件类型")
    private String fileType;

    @NotNull
    @ApiModelProperty("文件数据")
    private byte[] fileData;

    @ApiModelProperty("文件备注")
    private String remark;

    public void setFileName(String fileName) {
        this.fileName = fileName;
        this.filePathName = StringUtils.format("{}/{}_{}.{}",DateUtils.datePath()
                , CharSequenceUtil.subBefore(fileName,".",false)
                , Seq.getId(Seq.uploadSeqType),FileUtil.extName(fileName));
    }
}
