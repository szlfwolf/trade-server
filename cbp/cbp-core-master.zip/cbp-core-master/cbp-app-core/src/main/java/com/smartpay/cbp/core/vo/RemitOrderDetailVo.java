package com.smartpay.cbp.core.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @Description: 提现订单详情
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/25 11:12
 * @Version: 1.0
 */
@Data
public class RemitOrderDetailVo {

    @ApiModelProperty("批次号")
    private String batchNo;

    @ApiModelProperty("订单编号")
    private String orderNo;

    @ApiModelProperty("卖家编号")
    private String platformUserNo;

    @ApiModelProperty("货币类型")
    private String currencyType;

    @ApiModelProperty("金额")
    private Long amt;

    @ApiModelProperty("手续费金额")
    private Long feeAmt;

    @ApiModelProperty("账户名称")
    private String bankAccountName;

    @ApiModelProperty("提现类型")
    private String remitType;

    @ApiModelProperty("提现类型中文")
    private String remitTypeName;

    @ApiModelProperty("账号")
    private String bankAccountNo;

    @ApiModelProperty("银行名称")
    private String bankName;

    @ApiModelProperty("支行名称")
    private String bankBranchName;

    @ApiModelProperty("联行号")
    private String cnapsNo;

    @ApiModelProperty("用途")
    private String purpose;

    @ApiModelProperty("手机号")
    private String mobilePhone;

    @ApiModelProperty("账户类型")
    private String accountIdType;

    @ApiModelProperty("账户编号")
    private String accountIdNo;

    @ApiModelProperty("业务类型")
    private String businessCode;

    @ApiModelProperty("平台名称")
    private String platformName;

    @ApiModelProperty("产品名称")
    private String productCode;

    @ApiModelProperty("到账类型")
    private String timeType;

    @ApiModelProperty("到账类型中文")
    private String timeTypeName;

    @ApiModelProperty("备注")
    private String remark;

    @ApiModelProperty("状态")
    private String status;

    @ApiModelProperty("错误信息")
    private String errorMsg;

    @ApiModelProperty("更新时间")
    private Date uptDate;

    @ApiModelProperty("创建时间")
    private Date crtDate;

}
