package com.smartpay.cbp.core.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.springframework.web.multipart.MultipartFile;

import java.io.Serializable;

/**
 * @author Carer
 * @desc    文件上传请求实体
 * @date 2022/11/7 16:51
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ToString(callSuper = true)
public class FileUploadReqDto extends BaseReqDto {
    private static final long serialVersionUID = 2375451729777797502L;

    private MultipartFile file;

}
