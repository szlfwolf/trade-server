package com.smartpay.cbp.core.service;

import com.smartpay.cbp.core.dto.*;

import java.util.List;

/**
 * @author Carer
 * @desc
 * @date 2022/11/18 16:35
 */
public interface MerchantUserService {

    /**
     * 校验外部用户编号是否备案成功
     * @param merchantUserRegCheckReqDto 外部用户编号
     * @return 未备案成功的外部用户编号
     */
    List<String> checkRegister(MerchantUserRegCheckReqDto merchantUserRegCheckReqDto);

    /**
     * 获取分页用户信息
     * @param merchantUserPageReqDto 分页查询入参
     * @return 响应内容
     */
    List<MerchantUserPageRspDto> pageList(MerchantUserPageReqDto merchantUserPageReqDto);

    /**
     * 根据主键查询商户用户信息
     * @param id    主键
     * @return  商户用户详情
     */
    MerchantUserDetailDto detailById(String id);

    /**
     * 审批
     * @param approveReqDto 审批入参
     * @return  审批结果
     */
    Boolean approve(ApproveReqDto approveReqDto);
}
