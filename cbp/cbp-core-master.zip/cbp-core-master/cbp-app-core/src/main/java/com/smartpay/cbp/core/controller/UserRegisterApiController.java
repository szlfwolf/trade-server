package com.smartpay.cbp.core.controller;

import com.smartpay.cbp.common.core.domain.R;
import com.smartpay.cbp.common.security.annotation.InnerAuth;
import com.smartpay.cbp.core.dto.CompanyRegisterDto;
import com.smartpay.cbp.core.dto.NotifyRegisterReqDto;
import com.smartpay.cbp.core.dto.PersonRegisterDto;
import com.smartpay.cbp.core.service.UserRegisterService;
import io.swagger.annotations.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Carer
 * @desc 用户备案Api控制器
 * @date 2022/11/8 10:43
 */
@Api(tags = "用户备案")
@RestController
@RequestMapping("/register")
@RequiredArgsConstructor
@Slf4j
public class UserRegisterApiController {

    private final UserRegisterService userRegisterService;

    /**
     * 个人开户
     * @param personRegisterDto 个人请求实体
     * @return 开户请求结果
     */
    @ApiOperation(value = "个人开户",response = R.class)
    @ApiResponses(value = {@ApiResponse(code = 200,message = "开户请求发送成功！")})
    @PostMapping("/person")
    public R<Boolean> personRegister(@ApiParam(value = "个人开户实体", required = true)
                                         @RequestBody @Validated PersonRegisterDto personRegisterDto){
        log.info("个人用户开户入参:{}",personRegisterDto);
        return R.ok(userRegisterService.personRegister(personRegisterDto));
    }

    /**
     * 企业开户
     * @param companyRegisterDto 企业请求实体
     * @return 开户请求结果
     */
    @ApiOperation("企业开户")
    @ApiResponses(value = {@ApiResponse(code = 200,message = "开户请求发送成功！")})
    @PostMapping("/company")
    public R<Boolean> companyRegister(@ApiParam(value = "企业开户实体", required = true)
                                          @RequestBody @Validated CompanyRegisterDto companyRegisterDto){
        log.info("企业用户开户入参:{}",companyRegisterDto);
        return R.ok(userRegisterService.companyRegister(companyRegisterDto));
    }


    /**
     * 回调通知
     * @param notifyRegisterReqDto 通知结果
     * @return 响应
     */
    @ApiOperation(value = "内部接口-核心备案回调通知(禁止swagger测试)",hidden = true)
    @InnerAuth
    @PostMapping("/notify")
    public R<Boolean> notifyRegisterResult(@RequestBody @Validated NotifyRegisterReqDto notifyRegisterReqDto){
        log.info("回调通知接收参数：{}",notifyRegisterReqDto);
        return R.ok(userRegisterService.notifyRegisterResult(notifyRegisterReqDto));
    }

}
