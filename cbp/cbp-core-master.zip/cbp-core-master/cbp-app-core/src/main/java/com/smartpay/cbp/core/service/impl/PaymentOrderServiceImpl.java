package com.smartpay.cbp.core.service.impl;

import cn.hutool.core.collection.CollUtil;
import com.smartpay.cbp.core.dto.PaymentOrderDto;
import com.smartpay.cbp.core.entity.PaymentOrder;
import com.smartpay.cbp.core.entity.PaymentOrderSeq;
import com.smartpay.cbp.core.mapper.PaymentOrderMapper;
import com.smartpay.cbp.core.mapstruct.PaymentOrderStruct;
import com.smartpay.cbp.core.service.IPaymentOrderService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author cbp-system
 * @since 2022-11-07
 */
@AllArgsConstructor
@Service
public class PaymentOrderServiceImpl extends ServiceImpl<PaymentOrderMapper, PaymentOrder> implements IPaymentOrderService {

    private final PaymentOrderStruct paymentOrderStruct;

    @Override
    public boolean saveBatch(PaymentOrderSeq orderSeq , List<PaymentOrderDto> orders) {
        if (CollUtil.isEmpty(orders)) {
            return true;
        }

        List<PaymentOrder> paymentOrders = orders.stream().map(order -> {
            PaymentOrder entity = paymentOrderStruct.convert(order);
            //todo 雪花
            //entity.setId();
            entity.setBatchNo(orderSeq.getBatchNo());
            return entity;
        }).collect(Collectors.toList());
        return saveBatch(paymentOrders);
    }
}
