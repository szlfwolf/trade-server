package com.smartpay.cbp.core.service.impl;

import cn.hutool.poi.excel.ExcelReader;
import cn.hutool.poi.excel.ExcelUtil;
import com.smartpay.cbp.core.annotation.ProviderHandler;
import com.smartpay.cbp.core.dto.PaymentOrderDto;
import com.smartpay.cbp.core.enums.ProviderType;
import com.smartpay.cbp.core.mapstruct.PaymentOrderStruct;
import com.smartpay.cbp.core.service.FileParseHandler;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author ：jmwang
 * @version ：V1.0
 * @description ：Excel文件解析
 * @date ：2022/11/8 15:40
 */
@ProviderHandler(provider = ProviderType.EXCEL)
@AllArgsConstructor
@Service
public class ExcelFileParseHandler implements FileParseHandler {

    private final PaymentOrderStruct paymentOrderStruct;

    @Override
    public List<PaymentOrderDto> parseOrder(InputStream is) {
        List<PaymentOrderDto> orders = new ArrayList<>();
        ExcelReader reader = ExcelUtil.getReader(is);
        List<List<Object>> rows = reader.read(1);
        rows.forEach(row -> {
            PaymentOrderDto dto = paymentOrderStruct.convert(row.stream().map(r -> r.toString()).collect(Collectors.toList()));
            orders.add(dto);
        });
        return orders;
    }
}
