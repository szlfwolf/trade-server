package com.smartpay.cbp.core.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.smartpay.cbp.core.constant.RegisterStatus;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDateTime;

/**
 * t_merchant_user
 * @author carer
 */
@TableName("t_merchant_user")
@EqualsAndHashCode(callSuper = false)
@Data
public class MerchantUserEntity extends Model<MerchantUserEntity> {

    private static final long serialVersionUID = -8710555189490513067L;

    /**
     * 主键
     */
    @TableId(type = IdType.ASSIGN_ID)
    private String id;

    /**
     * 系统商户号
     */
    @TableField(value = "m_no")
    private String merchantNo;

    /**
     * 系统用户号
     */
    private String userNo;

    /**
     * 备案渠道号
     */
    private String channelNo;

    /**
     * 渠道用户号
     */
    private String openUserNo;

    /**
     * 商户侧用户编号
     */
    private String merchantUserNo;

    /**
     * 卖家平台注册时间
     */
    private String regTime;

    /**
     * 备案请求号
     */
    private String regReqId;

    /**
     * 状态，${@link RegisterStatus}
     */
    private String status;

    public boolean isSuc(){
        return RegisterStatus.REGISTER_SUCCESS.getCode().equals(status);
    }

    public boolean isProcessing(){
        return RegisterStatus.REGISTER_ING.getCode().equals(status);
    }

    /**
     * 数据来源,${@link com.smartpay.cbp.core.constant.SourceFrom}
     */
    private String sourceFrom;

    /**
     * 用户类型,1-企业，2-个人
     */
    private String userType;

    /**
     * 国别
     */
    private String nationality;

    /**
     * 姓名、法人姓名-加密
     */
    private String nameMask;

    /**
     * 姓名、法人姓名-加密
     */
    private String nameEnc;

    /**
     * 手机号-加密
     */
    private String mobileNoMask;

    /**
     * 手机号-加密
     */
    private String mobileNoEnc;

    /**
     * 证件类型
     */
    private String certType;

    /**
     * 证件号-加密
     */
    private String certIdMask;

    /**
     * 证件号-加密
     */
    private String certIdEnc;

    /**
     * 证件有效期始
     */
    private String certExpBeginDate;

    /**
     * 证件有效期止
     */
    private String certExpEndDate;

    /**
     * 开户成功时间
     */
    private LocalDateTime registerTime;

    /**
     * 邮箱地址
     */
    private String email;

    /**
     * 联系地址
     */
    private String address;

    /**
     * 职业代码
     */
    private String professionCode;

    /**
     * 职业名称
     */
    private String professionName;

    /**
     * 开户银行
     */
    private String bankName;

    /**
     * 银行账号
     */
    private String bankAcct;

    /**
     * 统一社会信用代码
     */
    private String licenseNo;

    /**
     * 营业执照起始时间
     */
    private String licenseStartDate;

    /**
     * 营业执照结束时间
     */
    private String licenseEndDate;

    /**
     * 审批状态，${@link com.smartpay.cbp.core.constant.ApproveStatus}
     */
    private String approveStatus;

    /**
     * 审批人
     */
    private String approvePerson;

    /**
     * 企业简称
     */
    private String shortName;

    /**
     * 企业类型 1-个体工商户 2-企业
     */
    private String bizType;

    /**
     * 经营范围
     */
    private String bizScope;

    /**
     * 邮编
     */
    private String postCode;

    /**
     * 经营地址
     */
    private String opAddr;

    /**
     * 账户类型
     */
    private String acctType;

    /**
     * 账户名称
     */
    private String acctName;

    private String provinceCode;

    private String cityCode;

    private String areaCode;

    /**
     * 支行联行号
     */
    private String bankCode;

    /**
     * 支行名称
     */
    private String branchName;

    /**
     * 所属行业属性代码
     */
    private String industryCode;

    /**
     * 经济类型代码
     */
    private String attrCode;

    /**
     * 是否特殊经济区内企业
     */
    private String isTaxFree;

    /**
     * 特殊经济区内企业类型
     */
    private String taxFreeCode;

    /**
     * 外方投资者国别信息
     */
    private String invCountryCode;

    /**
     * 店铺网址
     */
    private String storeLink;

    /**
     * 备案备注
     */
    private String registerRemark;

    /**
     * 备注
     */
    private String remark;

    /**
     * 证件正面照文件Id
     */
    private String certFrontFileId;

    /**
     * 证件反面照文件Id
     */
    private String certBackFileId;

    /**
     * 营业执照文件Id
     */
    private String licenseFileId;

    /**
     * 逻辑删除字段，0-未删除(默认)，1-删除
     */
    @TableLogic(value = "0",delval = "1")
    private String delFlag;

    /**
     * 版本号字段
     */
    @Version
    private Integer version;

    /**
     * 创建时间
     */
    private LocalDateTime crtTime;

    /**
     * 创建人
     */
    private String crtBy;

    /**
     * 更新时间
     */
    private LocalDateTime updTime;

    /**
     * 更新人
     */
    private String updBy;

}