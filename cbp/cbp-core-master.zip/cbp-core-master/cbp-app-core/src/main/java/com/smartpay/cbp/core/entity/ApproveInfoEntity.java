package com.smartpay.cbp.core.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * t_approve_info
 * @author carer
 */
@ApiModel(value="审批记录")
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("t_approve_info")
public class ApproveInfoEntity extends Model<ApproveInfoEntity> {
    private static final long serialVersionUID = -926496386678028376L;
    /**
     * 主键
     */
    @ApiModelProperty(value="主键")
    @TableId(type = IdType.ASSIGN_ID)
    private String id;

    /**
     * 业务表Id
     */
    @ApiModelProperty(value="业务表Id")
    private String businessId;

    /**
     * 审批人
     */
    @ApiModelProperty(value="审批人")
    private String approveUser;

    /**
     * 审批动作,APPROVE-通过，REJECT-拒绝，ROLLBACK-退回
     */
    @ApiModelProperty(value="审批动作,APPROVE-通过，REJECT-拒绝，ROLLBACK-退回")
    private String approveAction;

    /**
     * 审批备注
     */
    @ApiModelProperty(value="审批备注")
    private String approveRemark;

    /**
     * 审批时间
     */
    @ApiModelProperty(value="审批时间")
    private LocalDateTime approveTime;

    /**
     * 备注
     */
    @ApiModelProperty(value="备注")
    private String remark;

    /**
     * 逻辑删除标识 0-未删除，1-删除
     */
    @ApiModelProperty(value="逻辑删除标识 0-未删除，1-删除")
    @TableLogic(value = "0",delval = "1")
    private String delFlag;

    /**
     * 创建人
     */
    @ApiModelProperty(value="创建人")
    private String crtBy;

    /**
     * 创建时间
     */
    @ApiModelProperty(value="创建时间")
    private LocalDateTime crtTime;

    /**
     * 更新人
     */
    @ApiModelProperty(value="更新人")
    private String uptBy;

    /**
     * 更新时间
     */
    @ApiModelProperty(value="更新时间")
    private LocalDateTime uptTime;

}