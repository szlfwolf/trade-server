package com.smartpay.cbp.core.enums;

/**
 * @Description: 校验结果
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/4 16:42
 * @Version: 1.0
 */
public enum ValidateResult {

    FAIL("校验失败"),
    SUCCESS("校验成功"),

    ;

    public final String comment;
    ValidateResult(String comment) {
        this.comment = comment;
    }

}
