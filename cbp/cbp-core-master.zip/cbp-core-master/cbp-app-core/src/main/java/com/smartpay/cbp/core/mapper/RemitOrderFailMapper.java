package com.smartpay.cbp.core.mapper;

import com.smartpay.cbp.core.entity.RemitOrderFail;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author admin
* @description 针对表【t_remit_order_fail(商户提现订单校验失败表)】的数据库操作Mapper
* @createDate 2022-11-09 11:21:39
* @Entity com.smartpay.cbp.core.entity.RemitOrderFail
*/
public interface RemitOrderFailMapper extends BaseMapper<RemitOrderFail> {

}




