package com.smartpay.cbp.core.dto;

import lombok.Data;

import java.io.InputStream;

/**
 * @author ：jmwang
 * @version ：V1.0
 * @description ：文件对象
 * @date ：2022/11/8 15:47
 */
@Data
public class FileInfoDto {

    /**
     * 文件ID
     */
    private String id;

    /**
     * 文件名
     */
    private String name;

    /**
     * 文件后缀/格式
     */
    private String suffix;

    /**
     * 文件名及后缀
     */
    private String fullName;

    /**
     * 文件流
     */
    private InputStream fileData;

}
