package com.smartpay.cbp.core.service.impl;

import com.smartpay.cbp.common.core.constant.SecurityConstants;
import com.smartpay.cbp.common.core.domain.R;
import com.smartpay.cbp.console.dto.ChannelInfoFeignDto;
import com.smartpay.cbp.console.dto.MerchantInfoForeignDto;
import com.smartpay.cbp.console.feign.CommonApiService;
import com.smartpay.cbp.console.feign.MerchantInfoApiService;
import com.smartpay.cbp.core.service.ConsoleRemoteApiService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * @author Carer
 * @desc  console模块远程调用接口
 * @date 2022/11/8 13:45
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class ConsoleRemoteApiServiceImpl implements ConsoleRemoteApiService {

    private final MerchantInfoApiService merchantInfoApiService;

    private final CommonApiService commonApiService;

    /**
     * 根据商户号获取商户信息
     * @param merchantNo 商户号
     * @return 商户信息
     */
    @Override
    public Optional<MerchantInfoForeignDto> getMerchantInfoByMerchantNo(String merchantNo){
        log.info("远程console获取商户信息入参:{}",merchantNo);
        R<MerchantInfoForeignDto> merchantDtoResult = merchantInfoApiService
                .queryMerchantForeign(merchantNo, SecurityConstants.INNER);
        log.info("远程console获取商户信息响应:{}",merchantDtoResult);
        if(Boolean.TRUE.equals(R.isError(merchantDtoResult))){
            log.error("远程console获取商户信息异常！");
            return Optional.empty();
        }
        return Optional.ofNullable(merchantDtoResult.getData());
    }

    /**
     * 获取可用渠道
     *
     * @return 渠道信息
     */
    @Override
    public Optional<ChannelInfoFeignDto> routeChannel() {
        R<ChannelInfoFeignDto> channelInfoR = commonApiService.getChannelInfo(SecurityConstants.INNER);
        log.info("路由渠道信息响应内容：{}",channelInfoR);
        if(Boolean.TRUE.equals(R.isError(channelInfoR))){
            log.error("远程console路由渠道信息异常！");
            return Optional.empty();
        }
        return Optional.ofNullable(channelInfoR.getData());
    }

    /**
     * 校验商户状态
     *
     * @param merchantNo 商户号
     */
    @Override
    public void checkMerchantStatus(String merchantNo) {
        Optional<MerchantInfoForeignDto> merchantInfoOpt = getMerchantInfoByMerchantNo(merchantNo);
        MerchantInfoForeignDto merchantInfo = merchantInfoOpt.orElseThrow(() -> new NullPointerException("商户信息为空！"));
        //校验商户状态
        if(!"1".equals(merchantInfo.getMerchantStatus())){
            throw new RuntimeException("商户当前不可用！");
        }
    }
}
