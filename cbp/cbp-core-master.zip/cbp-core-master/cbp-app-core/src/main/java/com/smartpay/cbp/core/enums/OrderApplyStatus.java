package com.smartpay.cbp.core.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author ：jmwang
 * @version ：V1.0
 * @description ：订单申报状态
 * @date ：2022/11/8 20:06
 */
@Getter
@AllArgsConstructor
public enum OrderApplyStatus {

    /**
     * 订单申报状态
     */
    INIT("init", "初始化/请求落库"),
    PROCESS("process", "处理中"),
    COMPLETE("complete", "处理完成"),
    //todo 后续流程
    ;

    private String code;
    private String comment;
}
