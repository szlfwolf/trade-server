package com.smartpay.cbp.core.mapper;

import com.smartpay.cbp.core.entity.PaymentOrderSeq;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 订单批次表 Mapper 接口
 * </p>
 *
 * @author cbp-system
 * @since 2022-11-07
 */
public interface PaymentOrderSeqMapper extends BaseMapper<PaymentOrderSeq> {

}
