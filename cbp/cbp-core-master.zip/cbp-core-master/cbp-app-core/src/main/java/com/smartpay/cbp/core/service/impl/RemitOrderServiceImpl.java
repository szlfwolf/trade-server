package com.smartpay.cbp.core.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.smartpay.cbp.core.dto.RemitOrderQueryDto;
import com.smartpay.cbp.core.dto.RemitResultDTO;
import com.smartpay.cbp.core.entity.RemitOrder;
import com.smartpay.cbp.core.enums.RemitOrderStatus;
import com.smartpay.cbp.core.mapper.RemitOrderMapper;
import com.smartpay.cbp.core.service.IRemitOrderService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * @author guogangqiang
 * @description 针对表【t_remit_order(商户下发明细表)】的数据库操作Service实现
 * @createDate 2022-11-03 20:18:17
 */
@Service
public class RemitOrderServiceImpl extends ServiceImpl<RemitOrderMapper, RemitOrder>
        implements IRemitOrderService {

    /**
     * 根据提现id查询提现明细
     *
     * @param remitReqId 提现请求id
     * @return 提现订单明细
     */
    @Override
    public List<RemitOrder> listByRemitReqId(@NotNull String remitReqId) {
        return lambdaQuery().eq(RemitOrder::getRemitReqId, remitReqId)
                .eq(RemitOrder::getDelFlag, false)
                .list();
    }

    /**
     * 根据提现请求id修改状态
     *
     * @param remitReqId
     * @param remitOrderStatus
     */
    @Override
    public void updateStatusByRemitReqId(@NotNull String remitReqId,
                                         @NotNull RemitOrderStatus remitOrderStatus,
                                         String uptUserId) {
        lambdaUpdate().eq(RemitOrder::getRemitReqId, remitReqId)
                .eq(RemitOrder::getDelFlag, false)
                .set(RemitOrder::getStatus, String.valueOf(remitOrderStatus.ordinal()))
                .set(RemitOrder::getUptBy, uptUserId)
                .update();
    }

    /**
     * 查询重复的提现订单号
     *
     * @param merchantNo
     * @param orderNos
     * @return
     */
    @Override
    public Set<String> existOrderNo(String merchantNo, Set<String> orderNos) {
        return this.baseMapper.existOrderNo(merchantNo, orderNos);
    }

    /**
     * 条件查询
     *
     * @param condition 条件筛选实体
     * @return
     */
    @Override
    public List<RemitOrder> list(RemitOrderQueryDto condition) {
        return lambdaQuery().eq(StringUtils.isNotBlank(condition.getBatchNo()), RemitOrder::getBatchNo, condition.getBatchNo())
                .eq(StringUtils.isNotBlank(condition.getOrderNo()), RemitOrder::getOrderNo, condition.getOrderNo())
                .eq(StringUtils.isNotBlank(condition.getBankAccountName()), RemitOrder::getBankAccountName, condition.getBankAccountName())
                .eq(StringUtils.isNotBlank(condition.getBankAccountNo()), RemitOrder::getBankAccountNo, condition.getBankAccountNo())
                .eq(StringUtils.isNotBlank(condition.getStatus()), RemitOrder::getStatus, condition.getStatus())
                .eq(StringUtils.isNotBlank(condition.getRemitType()), RemitOrder::getRemitType, condition.getRemitType())
                .ge(Objects.nonNull(condition.getCrtStartTime()), RemitOrder::getCrtTime, condition.getCrtStartTime())
                .le(Objects.nonNull(condition.getCrtEndTime()), RemitOrder::getCrtTime, condition.getCrtEndTime())
                .eq(RemitOrder::getMerchantNo, condition.getMerchantNo())
                .eq(RemitOrder::getDelFlag, false)
                .ne(RemitOrder::getStatus, String.valueOf(RemitOrderStatus.INIT.ordinal()))
                .orderByDesc(RemitOrder::getId)
                .list();
    }

    /**
     * 同步代付结果
     *
     * @param remitResultDTO 代付结果
     */
    @Override
    public void notifyResult(RemitResultDTO remitResultDTO) {
        lambdaUpdate().set(RemitOrder::getStatus, RemitOrderStatus.toEnum(remitResultDTO.getOrderStatus()).ordinal())
                .set(RemitOrder::getErrorMsg, remitResultDTO.getResponseMsg())
                .set(RemitOrder::getErrorCode, remitResultDTO.getResponseCode())
                .eq(RemitOrder::getId, remitResultDTO.getRemitOrderId())
                .update();
    }
}




