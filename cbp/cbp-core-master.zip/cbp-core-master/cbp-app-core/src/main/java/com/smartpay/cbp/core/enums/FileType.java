package com.smartpay.cbp.core.enums;

import java.util.Arrays;
import java.util.Objects;

/**
 * @Description: 通用文件类型
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/14 17:14
 * @Version: 1.0
 */
public enum FileType {

    XLS("xls", "excel"),
    XLSX("xlsx", "excel"),
    CSV("csv", "csv"),

    ;

    public String suffix;

    public String desc;

    FileType(String suffix, String desc) {
        this.suffix = suffix;
        this.desc = desc;
    }

    public static FileType suffixToFileType(String suffix) {
        return Arrays.stream(FileType.values()).filter(fileType -> fileType.suffix.equalsIgnoreCase(suffix))
                .findFirst()
                .orElseThrow(AppCode.B03006::toCodeException);
    }

}
