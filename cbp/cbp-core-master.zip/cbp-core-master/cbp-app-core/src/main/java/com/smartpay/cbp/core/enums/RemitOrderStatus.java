package com.smartpay.cbp.core.enums;

import java.util.Arrays;
import java.util.Objects;

/**
 * @Description: 提现订单状态
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/7 14:25
 * @Version: 1.0
 */
public enum RemitOrderStatus {

    INIT("初始化"),
    PROCESSING("处理中"),
    SUCCESS("处理成功"),
    FAIL("处理失败"),

    ;

    public final String comment;

    RemitOrderStatus(String comment) {
        this.comment = comment;
    }

    public static RemitOrderStatus toEnum(String orderStatus) {
        return Arrays.stream(RemitOrderStatus.values())
                .filter(remitOrderStatus -> Objects.equals(remitOrderStatus.name(), orderStatus))
                .findFirst()
                .orElse(PROCESSING);
    }


}
