package com.smartpay.cbp.core.annotation;

import java.lang.annotation.*;

/**
 * 内部认证注解
 * 
 * @author ruoyi
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface ExcelField
{
    String name() default "";
}