package com.smartpay.cbp.core.service.impl;

import com.smartpay.cbp.core.service.FileStorageService;
import io.minio.errors.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

/**
 * @author Carer
 * @desc
 * @date 2022/11/7 17:52
 */
public abstract class AbstractFileStorageServiceImpl implements FileStorageService {

    /**
     * 获取存储路径
     *
     * @return 存储路径
     */
    @Override
    public String getStorePath() {
        return "";
    }
}
