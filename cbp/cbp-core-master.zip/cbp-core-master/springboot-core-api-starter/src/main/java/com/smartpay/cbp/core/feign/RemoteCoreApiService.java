package com.smartpay.cbp.core.feign;

import com.smartpay.cbp.common.core.constant.SecurityConstants;
import com.smartpay.cbp.common.core.domain.R;
import com.smartpay.cbp.core.constant.ServiceNameConstants;
import com.smartpay.cbp.core.dto.FileInfoRspDto;
import com.smartpay.cbp.core.dto.MerchantUserRegCheckReqDto;
import com.smartpay.cbp.core.dto.NotifyRegisterReqDto;
import com.smartpay.cbp.core.dto.RemitResultDTO;
import com.smartpay.cbp.core.factory.RemoteCoreApiFallbackFactory;
import com.smartpay.cbp.core.response.RemitOrderResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 * @author Carer
 * @desc feign远程调用
 * @date 2022/10/27 18:51
 */
@FeignClient(contextId = "remoteCoreService", value = ServiceNameConstants.CORE_SERVICE
        , fallbackFactory = RemoteCoreApiFallbackFactory.class)
public interface RemoteCoreApiService {

    /**
     * 根据文件指纹Id获取文件url
     *
     * @param fileId 文件指纹
     * @param source 内部调用标识
     * @return 文件Url
     */
    @GetMapping("/file/{fileId}")
    R<String> getFileUrl(@PathVariable("fileId") String fileId
            , @RequestHeader(SecurityConstants.FROM_SOURCE) String source);

    /**
     * 根据文件指纹Id获取文件对象信息集合
     *
     * @param fileIds 文件指纹
     * @param source  内部调用标识
     * @return 文件对象信息集合
     */
    @GetMapping("/file/fileIds")
    R<List<FileInfoRspDto>> getFileInfos(List<String> fileIds
            , @RequestHeader(SecurityConstants.FROM_SOURCE) String source);

    /**
     * 回调通知
     *
     * @param notifyRegisterReqDto 通知结果
     * @param source               内部调用标识
     * @return 响应
     */
    @PostMapping("/register/notify")
    R<Boolean> notifyRegisterResult(@RequestBody @Validated NotifyRegisterReqDto notifyRegisterReqDto
            , @RequestHeader(SecurityConstants.FROM_SOURCE) String source);

    /**
     * 根据提现订单id查询提现订单
     *
     * @param remitOrderId 提现订单id
     * @return 提现订单 {@link RemitOrderResponse}
     */
    @GetMapping("/remit/api/{remitOrderId}")
    R<RemitOrderResponse> getRemitOrderById(@PathVariable("remitOrderId") String remitOrderId);

    /**
     * 校验传入商户下的外部用户编号是否已开户
     *
     * @param merchantUserRegCheckReqDto 传入参数
     * @param source                     内部调用标识
     * @return 未备案的外部用户编号
     */
    @PostMapping("/merchantUser/check/batch")
    R<List<String>> checkRegistedBatch(@RequestBody MerchantUserRegCheckReqDto merchantUserRegCheckReqDto
            , @RequestHeader(SecurityConstants.FROM_SOURCE) String source);

    /**
     * 通知提现结果
     *
     * @param remitResultDTO
     * @return
     */
    @PostMapping("/remit/api/notify")
    R<Void> notifyRemitResult(@Valid @RequestBody RemitResultDTO remitResultDTO);
}
