package com.smartpay.cbp.core.constant;

/**
 * @author Carer
 * @desc
 * @date 2022/10/27 18:56
 */
public interface ServiceNameConstants {

    String CORE_SERVICE = "cbp-app-core";
}
