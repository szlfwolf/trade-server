package com.smartpay.cbp.core.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author Carer
 * @desc
 * @date 2022/11/9 11:16
 */
@Getter
@AllArgsConstructor
public enum NotifyResults {

    //S-成功，F-失败，N-未知
    SUCCESS("S","成功"),
    FAIL("F","失败"),
    UN_KNOW("N","未知"),
    ;

    private final String code;
    private final String desc;
}
