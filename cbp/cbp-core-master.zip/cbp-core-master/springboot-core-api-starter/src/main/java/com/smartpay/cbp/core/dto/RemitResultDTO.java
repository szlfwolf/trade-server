package com.smartpay.cbp.core.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

/**
 * @Description: 提现结果状态DTO
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/11 15:19
 * @Version: 1.0
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RemitResultDTO {

    @NotBlank
    @ApiModelProperty("提现订单id")
    private String remitOrderId;

    @NotBlank
    @ApiModelProperty("订单处理状态")
    private String orderStatus;

    @ApiModelProperty("订单响应处理信息")
    private String responseMsg;

    @ApiModelProperty("订单响应码")
    private String responseCode;

}
