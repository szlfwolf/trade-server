package com.smartpay.cbp.core.dto;

import lombok.Data;

/**
 * @description ：订单申报API请求
 * @author ：jmwang
 * @version ：V1.0
 * @date ：2022/11/8 14:41
 */
@Data
public class OrderApplyRequest {

    private String requestId;

    private String merchantId;

    private String currency;

    private String fileId;

}
