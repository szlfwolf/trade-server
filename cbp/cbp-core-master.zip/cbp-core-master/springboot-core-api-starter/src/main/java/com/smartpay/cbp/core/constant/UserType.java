package com.smartpay.cbp.core.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author Carer
 * @desc
 * @date 2022/11/8 16:34
 */
@Getter
@AllArgsConstructor
public enum UserType {

    COMPANY("1","企业"),
    PERSON("2","个人"),
    ;

    private final String code;
    private final String desc;
}
