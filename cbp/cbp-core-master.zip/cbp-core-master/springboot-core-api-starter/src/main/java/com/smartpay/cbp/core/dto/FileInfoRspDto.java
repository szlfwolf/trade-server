package com.smartpay.cbp.core.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * @author Carer
 * @desc
 * @date 2022/11/7 17:57
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class FileInfoRspDto implements Serializable {
    private static final long serialVersionUID = 3955961479343175290L;

    /**
     * 文件类型
     */
    private String fileType;

    /**
     * 文件名
     */
    private String fileName;

    /**
     * 文件路径
     */
    private String filePath;

    /**
     * 文件链接
     */
    private String fileLink;

    /**
     * 文件大小
     */
    private Long fileSize;

    /**
     * 存储类型,0本地，1-sftp,2-对象存储
     */
    private String storeType;
}
