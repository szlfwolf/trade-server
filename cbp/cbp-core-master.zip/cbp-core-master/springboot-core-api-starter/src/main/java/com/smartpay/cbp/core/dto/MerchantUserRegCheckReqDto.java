package com.smartpay.cbp.core.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.util.Set;

/**
 * @author Carer
 * @desc  备案校验
 * @date 2022/11/18 15:51
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class MerchantUserRegCheckReqDto implements Serializable {

    private static final long serialVersionUID = -512077173490145792L;
    /**
     * 商户号
     */
    @NotBlank(message = "商户号不能为空")
    private String merchantNo;

    @NotEmpty(message = "外部用户编号不能为空")
    @Min(value = 1L)
    private Set<String> merchantUserNos;
}
