package com.smartpay.cbp.core.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author Carer
 * @desc
 * @date 2022/11/8 20:48
 */
@Getter
@AllArgsConstructor
public enum ApproveStatus {

    //0-默认通过，1-待审批，2-通过，3-拒绝
    DEFAULT("0","默认通过"),
    APPROVE_PENDING("1","待审批"),
    APPROVE("2","通过"),
    REJECT("3","拒绝"),
    ;
    private final String code;
    private final String desc;
}
