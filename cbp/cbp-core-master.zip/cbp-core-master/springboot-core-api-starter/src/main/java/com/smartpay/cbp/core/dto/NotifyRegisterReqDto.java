package com.smartpay.cbp.core.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author Carer
 * @desc  核心回调接收类
 * @date 2022/11/9 11:10
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class NotifyRegisterReqDto implements Serializable {
    private static final long serialVersionUID = 688129648008264813L;

    /**
     * 系统用户号
     */
    private String userNo;

    /**
     * 通知实际
     */
    private LocalDateTime notifyTime;

    /**
     * 回调结果  ${@link com.smartpay.cbp.core.constant.NotifyResults}
     */
    private String notifyResult;

    /**
     * 通知备注
     */
    private String remark;
}
