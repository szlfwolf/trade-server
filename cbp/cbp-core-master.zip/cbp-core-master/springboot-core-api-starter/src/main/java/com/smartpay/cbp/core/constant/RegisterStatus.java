package com.smartpay.cbp.core.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author Carer
 * @desc 备案状态
 * @date 2022/11/8 14:25
 */
@Getter
@AllArgsConstructor
public enum RegisterStatus {

    //状态，1-初始化，2-备案中，3-已备案，4-备案失败，5-备案失效
    INIT("1","初始化"),
    REGISTER_ING("2","备案中"),
    REGISTER_SUCCESS("3","已备案"),
    REGISTER_FAIL("4","备案失败"),
    REGISTER_TIMEOUT("5","备案失效"),
    ;

    private final String code;
    private final String desc;
}
