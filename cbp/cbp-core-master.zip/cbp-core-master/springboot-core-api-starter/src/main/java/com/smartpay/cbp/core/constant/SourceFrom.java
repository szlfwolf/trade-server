package com.smartpay.cbp.core.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author Carer
 * @desc 资源来源
 * @date 2022/11/9 11:32
 */
@Getter
@AllArgsConstructor
public enum SourceFrom {

    //1-在岸api,2-在岸商服，3离岸api,4-离岸商服
    INSIDE_API("1","在岸api"),
    INSIDE_CONSOLE("2","在岸商服"),
    OUTSIDE_API("3","离岸api"),
    OUTSIDE_CONSOLE("4","离岸商服"),
    ;

    private final String code;
    private final String desc;
}
