package com.smartpay.cbp.core.factory;

import com.smartpay.cbp.common.core.domain.R;
import com.smartpay.cbp.core.dto.FileInfoRspDto;
import com.smartpay.cbp.core.dto.MerchantUserRegCheckReqDto;
import com.smartpay.cbp.core.dto.NotifyRegisterReqDto;
import com.smartpay.cbp.core.dto.RemitResultDTO;
import com.smartpay.cbp.core.feign.RemoteCoreApiService;
import com.smartpay.cbp.core.response.RemitOrderResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.openfeign.FallbackFactory;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author Carer
 * @desc
 * @date 2022/10/27 19:00
 */
@Slf4j
@Component
public class RemoteCoreApiFallbackFactory implements FallbackFactory<RemoteCoreApiService> {

    @Override
    public RemoteCoreApiService create(Throwable throwable) {
        throwable.printStackTrace();
        return new RemoteCoreApiService() {

            @Override
            public R<String> getFileUrl(String fileId, String source) {
                log.error("根据文件指纹Id获取文件url-调用失败,入参：{}，异常：{}", fileId, throwable.getMessage());
                return R.fail();
            }

            @Override
            public R<List<FileInfoRspDto>> getFileInfos(List<String> fileIds, String source) {
                log.error("批量获取文件信息-调用失败,入参：{}，异常：{}", fileIds, throwable.getMessage());
                return R.fail();
            }

            @Override
            public R<Boolean> notifyRegisterResult(NotifyRegisterReqDto notifyRegisterReqDto, String source) {
                log.error("核心模块通知备案-调用失败,入参：{}，异常：{}", notifyRegisterReqDto, throwable.getMessage());
                return R.fail();
            }

            @Override
            public R<RemitOrderResponse> getRemitOrderById(String remitOrderId) {
                log.error("核心模块查询提现订单失败，入参：{}，异常：{}", remitOrderId, throwable.getMessage());
                return R.fail();
            }

            @Override
            public R<List<String>> checkRegistedBatch(MerchantUserRegCheckReqDto merchantUserRegCheckReqDto, String source) {
                log.error("校验传入商户下的外部用户编号是否已开户失败，入参：{}，异常：{}", merchantUserRegCheckReqDto, throwable.getMessage());
                return R.fail();
            }

            @Override
            public R<Void> notifyRemitResult(RemitResultDTO remitResultDTO) {
                return null;
            }

        };
    }
}
