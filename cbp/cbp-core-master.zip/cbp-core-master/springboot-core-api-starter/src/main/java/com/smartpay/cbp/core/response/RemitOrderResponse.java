package com.smartpay.cbp.core.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @Description: 提现订单VO
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/10 10:06
 * @Version: 1.0
 */
@Data
public class RemitOrderResponse {

    @ApiModelProperty("主键id")
    private String id;

    @ApiModelProperty("商户号")
    private String merchantNo;

    @ApiModelProperty("批次号")
    private String batchNo;

    @ApiModelProperty("汇款币别")
    private String currencyType;

    @ApiModelProperty("手续费金额")
    private Long feeAmt;

    @ApiModelProperty("手续费货币类型")
    private String feeCurrencyType;

    @ApiModelProperty("卖家编号")
    private String platformUserNo;

    @ApiModelProperty("订单编号")
    private String orderNo;

    @ApiModelProperty("产品编码")
    private String productCode;

    @ApiModelProperty("创建时间")
    private Date crtTime;

    @ApiModelProperty("收款方账号")
    private String bankAccountNo;

    @ApiModelProperty("收款方姓名")
    private String bankAccountName;

    @ApiModelProperty("提现类型")
    private String remitType;

    @ApiModelProperty("联行号")
    private String cnapsNo;

    @ApiModelProperty("银行名称")
    private String bankName;

    @ApiModelProperty("银行支行名称")
    private String bankBranchName;

    @ApiModelProperty("金额")
    private Long amt;

    @ApiModelProperty("用途")
    private String purpose;

}
