package com.smartpay.cbp.core.constant;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * @author Carer
 * @desc
 * @date 2022/11/7 17:40
 */
@Getter
@RequiredArgsConstructor
public enum StoreType {

    //本地
    LOCAL("0","本地"),
    SFTP("1","SFTP"),
    MIN_IO("2","minIo"),
    ;

    private final String code;
    private final String desc;
}
