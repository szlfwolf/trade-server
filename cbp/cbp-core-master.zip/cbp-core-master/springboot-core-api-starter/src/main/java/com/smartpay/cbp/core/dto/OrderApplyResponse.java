package com.smartpay.cbp.core.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @description ：订单申报API响应
 * @author ：jmwang
 * @version ：V1.0
 * @date ：2022/11/8 14:42
 */
@Data
public class OrderApplyResponse {

    @ApiModelProperty("请求流水号")
    private String requestId;

    @ApiModelProperty("批次号")
    private String batchNo;

    @ApiModelProperty("状态")
    private String status;

    @ApiModelProperty("总笔数")
    private Long totalCnt;

    @ApiModelProperty("总金额")
    private Long totalAmt;

    @ApiModelProperty("成功笔数")
    private Long successCnt;

    @ApiModelProperty("成功金额")
    private Long successAmt;

    @ApiModelProperty("失败笔数")
    private Long failCnt;

    @ApiModelProperty("失败金额")
    private Long failAmt;
}
