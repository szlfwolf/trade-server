package com.smartpay.cbp.auth.controller;

import javax.servlet.http.HttpServletRequest;

import com.smartpay.cbp.auth.form.LoginBody;
import com.smartpay.cbp.auth.form.RegisterBody;
import com.smartpay.cbp.auth.service.SysLoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.smartpay.cbp.common.core.domain.Result;
import com.smartpay.cbp.common.core.utils.JwtUtils;
import com.smartpay.cbp.common.core.utils.StringUtils;
import com.smartpay.cbp.common.security.auth.AuthUtil;
import com.smartpay.cbp.common.security.service.TokenService;
import com.smartpay.cbp.common.security.utils.SecurityUtils;
import com.smartpay.cbp.system.api.model.LoginUser;

/**
 * token 控制
 * 
 * @author ruoyi
 */
@RestController
public class TokenController
{
    @Autowired
    private TokenService tokenService;

    @Autowired
    private SysLoginService sysLoginService;

    @PostMapping("login")
    public Result<?> login(@RequestBody LoginBody form)
    {
        // 用户登录
        LoginUser userInfo = sysLoginService.login(form.getUsername(), form.getPassword());
        // 获取登录token
        return Result.ok(tokenService.createToken(userInfo));
    }

    @DeleteMapping("logout")
    public Result<?> logout(HttpServletRequest request)
    {
        String token = SecurityUtils.getToken(request);
        if (StringUtils.isNotEmpty(token))
        {
            String username = JwtUtils.getUserName(token);
            // 删除用户缓存记录
            AuthUtil.logoutByToken(token);
            // 记录用户退出日志
            sysLoginService.logout(username);
        }
        return Result.ok();
    }

    @PostMapping("refresh")
    public Result<?> refresh(HttpServletRequest request)
    {
        LoginUser loginUser = tokenService.getLoginUser(request);
        if (StringUtils.isNotNull(loginUser))
        {
            // 刷新令牌有效期
            tokenService.refreshToken(loginUser);
            return Result.ok();
        }
        return Result.ok();
    }

    @PostMapping("register")
    public Result<?> register(@RequestBody RegisterBody registerBody)
    {
        // 用户注册
        sysLoginService.register(registerBody.getUsername(), registerBody.getPassword());
        return Result.ok();
    }
}
