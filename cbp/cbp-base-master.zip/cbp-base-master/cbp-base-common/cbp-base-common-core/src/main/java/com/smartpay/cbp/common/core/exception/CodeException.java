package com.smartpay.cbp.common.core.exception;

import com.smartpay.cbp.common.core.enums.Code;
import com.smartpay.cbp.common.core.utils.ICode;

/**
 * 自定义异常:指定返回编码异常，禁止指定Code.A00000， Code.A00000 表示成功
 *
 */
public class CodeException extends RuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private ICode code;

    public CodeException(final CodeException e) {
        super(e.getMessage(), e);
        this.code = e.getCode();
        if (Code.A00000 == this.code) {
            this.code = Code.A00001;
        }
    }

    public CodeException(final ICode code, final String message) {
        super(message);
        this.code = code;
        if (Code.A00000 == this.code) {
            this.code = Code.A00001;
        }
    }

    public CodeException(final ICode code, final String message, final Throwable cause) {
        super(message, cause);
        this.code = code;
        if (Code.A00000 == this.code) {
            this.code = Code.A00001;
        }
    }

    public ICode getCode() {
        return code;
    }
}
