package com.smartpay.cbp.common.core.enums;


import com.smartpay.cbp.common.core.utils.ICode;

/**
 * 全局响应代码，异常响应代码: 限制区间在 A00000 - A00999
 * 定义 com.support.mvc.entity.base.Result#setCode(Code) 返回编码
 */
public enum Code implements ICode {
    /**
     * 错误响应码
     */
    A00000("成功"),
    A00001("失败"),
    /**
     * 取消 A00002 方便国际化
     */
//    A00002("自定义异常，将会以 exception 内容替换 message 内容，一般用于抛出带动态参数消息，直接在前端弹窗"),
    A00003("非用户操作错误，请联系系统管理员并提供错误代码"),
    A00004("页面数据已过期，请刷新之后再操作"),
    A00005("文件大小超过限制"),
    A00006("无操作权限"),
    A00008("分页查询，每页显示数据量超过最大值"),
    A00009("上传文件列表为空"),
    A00010("参数加解密失败"),
    A00011("验证码不正确"),
    A00012("文件解析异常"),
    A00013("提现文件数据不能为空"),



    ;
    /**
     * 枚举属性说明
     */
    public final String comment;

    Code(String comment) {
        this.comment = comment;
    }

    @Override
    public String getComment() {
        return this.comment;
    }
}
