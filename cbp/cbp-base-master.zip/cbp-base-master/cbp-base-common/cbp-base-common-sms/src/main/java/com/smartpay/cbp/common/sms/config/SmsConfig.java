package com.smartpay.cbp.common.sms.config;

import com.smartpay.cbp.common.sms.service.SmsService;
import com.smartpay.cbp.common.sms.service.impl.SmsKltChannelServiceImpl;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author Carer
 * @desc
 * @date 2022/11/25 10:21
 */
@Configuration
@EnableConfigurationProperties(SmsProperties.class)
public class SmsConfig {

    /**
     * 默认短信发送实现klt
     * @param smsProperties 短信相关配置
     * @return 发送实例
     */
    @Bean("kltChannelService")
    public SmsService kltChannelService(SmsProperties smsProperties){
        return new SmsKltChannelServiceImpl(smsProperties);
    }
}
