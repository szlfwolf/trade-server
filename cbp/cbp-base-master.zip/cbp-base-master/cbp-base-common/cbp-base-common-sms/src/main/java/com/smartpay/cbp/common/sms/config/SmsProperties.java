package com.smartpay.cbp.common.sms.config;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;

/**
 * @author Carer
 * @desc
 * @date 2022/11/25 10:24
 */
@RefreshScope
@ConfigurationProperties("sms")
@Data
@EqualsAndHashCode(callSuper = false)
public class SmsProperties {

    /**
     * 开联通短信请求地址
     */
    private String smsApiHost;

    /**
     * 短信过期时间，单位分
     */
    private Long smsTimeOut;
}
