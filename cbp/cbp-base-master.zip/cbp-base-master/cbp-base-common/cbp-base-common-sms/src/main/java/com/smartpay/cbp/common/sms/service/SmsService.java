package com.smartpay.cbp.common.sms.service;

/**
 * @author Carer
 * @desc
 * @date 2022/11/25 10:21
 */
public interface SmsService {

    /**
     * 发送短信内容
     * @param mobiles 手机号
     * @param content 短信内容
     */
    void sendSmsVerificationCode(String content,String... mobiles);
}
