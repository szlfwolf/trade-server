package com.smartpay.cbp.common.sms.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.http.HttpUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.smartpay.cbp.common.sms.config.SmsProperties;
import com.smartpay.cbp.common.sms.service.SmsService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * @author Carer
 * @desc
 * @date 2022/11/25 10:23
 */
@RequiredArgsConstructor
@Slf4j
public class SmsKltChannelServiceImpl implements SmsService {

    private final SmsProperties smsProperties;

    /**
     * 发送短信内容
     *
     * @param content 短信内容
     * @param mobiles 手机号
     */
    @Override
    public void sendSmsVerificationCode(String content, String... mobiles) {
        final String kltSmsApiHost = smsProperties.getSmsApiHost();
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("atAll",false);
        jsonObject.put("atAllEnum","NOT_AT_ALL");
        jsonObject.put("content",content);
        JSONArray jsonArray = new JSONArray();
        jsonArray.addAll(CollUtil.newArrayList(mobiles));
        jsonObject.put("phoneNumberList",jsonArray);
        jsonObject.put("title","");
        jsonObject.put("warningLevel","WARNING");
        jsonObject.put("warningTimeLimitEnum","ANY_TIME");
        JSONArray warningTypeEnumList = new JSONArray();
        warningTypeEnumList.add("TEXT");
        jsonObject.put("warningTypeEnumList",warningTypeEnumList);
        final String postRsp = HttpUtil.post(kltSmsApiHost, JSON.toJSONString(jsonObject));
        log.info("klt短信接口响应内容：{}",postRsp);
    }
}
