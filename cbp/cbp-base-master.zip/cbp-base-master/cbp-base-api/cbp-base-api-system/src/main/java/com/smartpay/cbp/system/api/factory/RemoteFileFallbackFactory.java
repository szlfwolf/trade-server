package com.smartpay.cbp.system.api.factory;

import com.smartpay.cbp.system.api.RemoteFileService;
import com.smartpay.cbp.system.api.domain.SysFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.openfeign.FallbackFactory;
import org.springframework.stereotype.Component;
import com.smartpay.cbp.common.core.domain.Result;
import com.smartpay.cbp.system.api.RemoteFileService;
import org.springframework.web.multipart.MultipartFile;

/**
 * 文件服务降级处理
 * 
 * @author ruoyi
 */
@Component
public class RemoteFileFallbackFactory implements FallbackFactory<RemoteFileService>
{
    private static final Logger log = LoggerFactory.getLogger(RemoteFileFallbackFactory.class);

    @Override
    public RemoteFileService create(Throwable throwable)
    {
        log.error("文件服务调用失败:{}", throwable.getMessage());
        return file -> Result.fail("上传文件失败:" + throwable.getMessage());
    }
}
