<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" size="small" v-show="showSearch" label-width="80px">
      <el-row :gutter="24">
        <!--<el-col :span="6">
          <el-form-item label="商户号" prop="merchantNo">
            <el-input
              v-model="queryParams.merchantNo"
              placeholder="请输入商户号"
              clearable
              style="width: 100%"
            />
          </el-form-item>
        </el-col>-->
        <el-col :span="6">
            <el-form-item label="商户名称" prop="merchantNo">
              <el-select
                clearable
                v-model="queryParams.merchantNo"
                placeholder="选择"
                style="width:100%"
                remote
                :remote-method="remoteMethod"
                @focus="onFocus"
                filterable
                :loading="xlloading"
                v-loadmore="loadmore"
              >
                <el-option
                  v-for="(item, index) in departmentList"
                  :key="index"
                  :label="item.merchantName+'('+item.merchantNo+')'"
                  :value="item.merchantNo"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        <el-col :span="6">
          <el-form-item label="账户类型" prop="accountType">
            <el-select style="width: 100%" v-model="queryParams.accountType" placeholder="账户类型" clearable>
              <el-option
                v-for="dict in dict.type.account_type"
                :key="dict.value"
                :label="dict.label"
                :value="dict.value"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="币种" prop="currency">
            <el-select style="width: 100%" v-model="queryParams.currency" placeholder="币种" clearable>
              <el-option
                v-for="dict in dict.type.currency_type"
                :key="dict.value"
                :label="dict.label"
                :value="dict.value"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="交易类型" prop="adjustType">
            <el-select style="width: 100%" v-model="queryParams.adjustType" placeholder="交易类型" clearable>
              <el-option
                v-for="dict in dict.type.adjust_type"
                :key="dict.value"
                :label="dict.label"
                :value="dict.value"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="状态" prop="status">
            <el-select style="width: 100%" v-model="queryParams.status" placeholder="状态" clearable>
              <el-option
                v-for="dict in dict.type.operation_status"
                :key="dict.value"
                :label="dict.label"
                :value="dict.value"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="创建时间">
            <el-date-picker
              style="width: 100%"
              v-model="dateRange"
              value-format="yyyy-MM-dd"
              type="daterange"
              range-separator="-"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
            ></el-date-picker>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="10" class="mb8">
        <el-col :span="1.5">
          <el-button v-hasPermi="['account:bookkeep:query']" type="primary" icon="el-icon-search" size="small" @click="handleQuery">查询</el-button>
        </el-col>
        <el-col :span="1.5">
          <el-button icon="el-icon-refresh" size="small" @click="resetQuery">重置</el-button>
        </el-col>
        <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
      </el-row>
    </el-form>
    <el-table v-loading="loading" :data="configList" @selection-change="handleSelectionChange">
      <el-table-column width="150px" fixed="left" label="商户号" align="center" prop="merchantNo" />
      <el-table-column width="150px" label="商户名称" align="center" prop="merchantName" :show-overflow-tooltip="true" />
      <el-table-column width="170px" label="账户号" align="center" prop="accountId" :show-overflow-tooltip="true" />
      <el-table-column width="180px" label="账户类型" align="center" prop="accountType" >
        <template slot-scope="scope">
          <dict-tag :options="dict.type.account_type" :value="scope.row.accountType"/>
        </template>
      </el-table-column>
      <el-table-column width="170px" label="交易流水号" align="center" prop="id" />
      <el-table-column width="100px" label="交易类型" align="center" prop="adjustType" >
        <template slot-scope="scope">
          <dict-tag :options="dict.type.adjust_type" :value="scope.row.adjustType"/>
        </template>
      </el-table-column>
      <el-table-column width="100px" label="币种" align="center" prop="currency">
        <template slot-scope="scope">
          <dict-tag :options="dict.type.currency_type" :value="scope.row.currency"/>
        </template>
      </el-table-column>
      <el-table-column width="150px" label="余额" align="center" prop="amount" :show-overflow-tooltip="true" >
        <template slot-scope="scope">
          <span>{{formDataMoney(scope.row.amount)}}</span>
        </template>
      </el-table-column>
      <el-table-column width="100px" label="修改人" align="center" prop="creatorName" :show-overflow-tooltip="true" />
      <el-table-column width="100px" label="审核人" align="center" prop="verifierName" :show-overflow-tooltip="true" />
      <el-table-column label="状态" align="center" prop="status" :show-overflow-tooltip="true" >
        <template slot-scope="scope">
          <dict-tag :options="dict.type.operation_status" :value="scope.row.status"/>
        </template>
      </el-table-column>
      <el-table-column width="150px" label="备注" align="center" prop="remark" :show-overflow-tooltip="true" />
      <el-table-column width="150px" label="审核意见" align="center" prop="auditOpinion" :show-overflow-tooltip="true" />
      <el-table-column width="150px" label="创建时间" align="center" prop="crtTime" :show-overflow-tooltip="true" />
      <el-table-column width="150px" label="更新时间" align="center" prop="uptTime" :show-overflow-tooltip="true" />
      <el-table-column label="操作" fixed="right" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            v-hasPermi="['account:bookkeep:examine']"
            @click="handleUpdate(scope.row)"
          >审核</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加或修改参数配置对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="900px" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="80px">
        <el-row :gutter="24">
          <el-col :span="12">
            <el-form-item label="商户号" prop="merchantNo">
              <p class="border-bottom">{{form.merchantNo}}</p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="商户名称" prop="merchantName">
              <p class="border-bottom">{{ form.merchantName }}</p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="余额" prop="amount">
              <p class="border-bottom">{{form.accountBalance}}</p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="账户类型" prop="accountType">
              <p class="border-bottom">
                <dict-tag :options="dict.type.account_type" :value="form.accountType"/>
              </p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="币种" prop="currency">
              <p class="border-bottom">
                <dict-tag :options="dict.type.currency_type" :value="form.currency"/>
              </p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="账户号" prop="accountId">
              <p class="border-bottom">{{form.accountId}}</p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="交易类型" prop="adjustType">
              <p class="border-bottom">
                <dict-tag :options="dict.type.adjust_type" :value="form.adjustType"/>
              </p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="变动金额" prop="amount">
              <p class="border-bottom">{{formDataMoney(form.amount)}}</p>
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="备注" prop="remark">
              <p class="border-bottom">{{form.remark}}</p>
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="审核意见" prop="auditOpinion">
              <el-input v-model="form.auditOpinion" type="textarea" placeholder="请输入内容" />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <el-dialog
        width="450px"
        title="授权验证"
        :close-on-click-modal="false" :close-on-press-escape="false"
        :visible.sync="innerVisible"
        append-to-body>
        <el-form :model="sendform" :rules="rules" ref="sendForm" size="small" label-width="120px">
          <el-row :gutter="24">
            <el-col :span="24">
              <el-form-item label="短信接收手机号:">
                <span>{{phone}}</span>
              </el-form-item>
            </el-col>
            <el-col :span="24">
                <el-form-item label="短信验证:" prop="verifyCode">
                  <div style="display: flex">
                   <el-input
                      v-model="sendform.verifyCode"
                      placeholder="请输入短信验证"
                      clearable
                      maxlength="6"
                      style="width: 200px;margin-right: 10px"
                    />
                    <el-button style="width: 90px"  :disabled="disBtn" type="primary" @click="sendCode">{{txtBtn}}</el-button>
                  </div>
                </el-form-item>
            </el-col>
          </el-row>
          <div style="text-align: center">
            <el-button type="primary" @click="toSure">确认</el-button>
          </div>
        </el-form>
      </el-dialog>
      <div slot="footer" class="dialog-footer">
        <el-button type="danger" @click="toExamine(false)">审核拒绝</el-button>
        <el-button type="primary" @click="toExamine(true)">审核通过</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { accountBookRequest, merInfo } from '@/api/merchant/infactor'
import { formDataMoney } from '@/utils'

export default {
  name: "Config",
  dicts: ['account_type', 'currency_type', 'operation_status', 'adjust_type' ],
  data() {
    return {
      sendform:{
        accountAdjustRecordId:'',
        auditIsPassed:'',
        auditOpinion:'',
        smsId:'',
        verifyCode:'',
      },
      phone:'',
      merSize:10,
      merNum:1,
      merTotal:1,
      departmentList:[],
      xlloading: false,
      // 遮罩层
      loading: true,
      // 内层dialog遮罩层
      innerVisible: false,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      disBtn: false,
      txtBtn: '发送短信',
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 参数表格数据
      configList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 日期范围
      dateRange: [],
      // 定时器
      trimer:null,
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        accountType: undefined,
        currency: undefined,
        merchantNo: undefined,
        status: undefined,
        adjustType: undefined
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        verifyCode: [
          { required: true, message: "不能为空", trigger: "change" }
        ]
      }
    };
  },
  created() {
    this.getList();
  },
  computed:{
    formDataMoney
  },
  methods: {
    toExamine(auditIsPassed){
      accountBookRequest.getPhone().then(res=>{
        this.phone = res.data
      })
      this.sendform = {
        accountAdjustRecordId:this.form.id,
        auditIsPassed:auditIsPassed,
        auditOpinion:this.form.auditOpinion,
        smsId:'',
        verifyCode:'',
      }
      if(!auditIsPassed){
        this.$confirm('是否继续操作?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          accountBookRequest.examine(this.sendform).then(response => {
            this.$modal.msgSuccess("操作成功");
            this.open = false;
            this.innerVisible = false;
            this.disBtn = false
            this.txtBtn ='发送短信'
            clearInterval(this.trimer)
            this.getList();
          });
        }).catch(() => {
        });
      } else {
        this.innerVisible = true
      }
    },
    // remoteMethod
    remoteMethod(query) {
      this.departmentList = []
      if (query !== '') {
        this.xlloading = true;
        this.merNum = 1
        this.getMerchantList(query);
      } else {
        this.getMerchantList();
      }
    },
    onFocus(){
      if (!this.queryParams.merchantNo) {
        this.xlloading = true;
        this.merNum = 1
        this.departmentList = []
        this.getMerchantList();
      }
    },
    getMerchantList(query){
      let params = {
        pageNum: this.merNum,
        pageSize: this.merSize,
      }
      if(Number(query)){
        params["merchantNo"] = query
      } else {
        params["merchantName"] = query
      }
      merInfo.getMerchantInfo(params).then(response => {
          this.departmentList = [...this.departmentList,...response.data]
          this.merTotal = Math.ceil(response.total / this.merSize)
        }
      ).catch(e=>{
        this.loading = false;
      }).finally(e=>{
        this.xlloading = false;
      });
    },
    //滑动触底的相关操作
    loadmore(){
      if(this.merNum<this.merTotal){
        this.merNum+=1
        this.getMerchantList()
      }
      console.log(this.merNum,this.merTotal);

      //数据页面更新，数据请求操作
    },
    /** 查询参数列表 */
    getList() {
      this.loading = true;
      accountBookRequest.list(this.addDateRange(this.queryParams, this.dateRange,'startTime','endTime')).then(response => {
          this.configList = response.data;
          this.total = response.total;
          this.loading = false;
        }
      ).catch((e)=>{
        this.loading = false
      });
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.resetForm("form");
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.dateRange = [];
      this.resetForm("queryForm");
      this.handleQuery();
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.reset();
      this.open = true;
      this.title = "添加参数";
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.configId)
      this.single = selection.length!=1
      this.multiple = !selection.length
    },
    /** 明细 */
    handleDetails(row) {
      this.$router.push("/meraccount/details")
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.open = true;
      this.reset();
      const recordId = row.id || ""
      accountBookRequest.getDetails({recordId}).then(response => {
        this.form = response.data;
        this.open = true;
        this.title = "审核";
      });
    },
    /** 发送按钮 */
    sendCode(){
      accountBookRequest.sendCode({
        "recordId": this.sendform.accountAdjustRecordId
      }).then(response => {
        if(response.code=='000000'){
          this.sendform.smsId = response.data.smsId;
          this.$message({type:'success',message:"发送成功"})
          let count = 60
          this.disBtn = true
          this.trimer = setInterval(()=>{
            this.txtBtn = count + 's'
            if(count<=0){
              this.disBtn = false
              this.txtBtn ='发送短信'
              clearInterval(this.trimer)
            }
            count--
          },1000)
        }

      });
    },
    /** 确认按钮 */
    toSure(){
      this.$refs["sendForm"].validate(valid => {
        if (valid) {
          if(!this.sendform.smsId){
            this.$message({type:'error',message:"请先发送验证码"})
            return false
          }
          accountBookRequest.examine(this.sendform).then(response => {
            this.$modal.msgSuccess("操作成功");
            this.open = false;
            this.innerVisible = false;
            this.disBtn = false
            this.txtBtn ='发送短信'
            clearInterval(this.trimer)
            this.getList();
          });
        } else {
          console.log(valid)
        }
      })
    },
    /** 拒绝按钮 */
    submitJect: function() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.configId != undefined) {
            updateConfig(this.form).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.getList();
            });
          } else {
            addConfig(this.form).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.getList();
            });
          }
        }
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const configIds = row.configId || this.ids;
      this.$modal.confirm('是否确认删除参数编号为"' + configIds + '"的数据项？').then(function() {
          return delConfig(configIds);
        }).then(() => {
          this.getList();
          this.$modal.msgSuccess("删除成功");
        }).catch(() => {});
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download('system/config/export', {
        ...this.queryParams
      }, `config_${new Date().getTime()}.xlsx`)
    },
    /** 刷新缓存按钮操作 */
    handleRefreshCache() {
      refreshCache().then(() => {
        this.$modal.msgSuccess("刷新成功");
      });
    }
  }
};
</script>
<style scoped>
.border-bottom{
  height: 36px;
}
</style>
