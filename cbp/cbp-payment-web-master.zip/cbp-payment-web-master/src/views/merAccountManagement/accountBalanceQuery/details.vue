<template>
  <div class="app-container">
    <el-form
      :model="queryParams"
      :rules="rules"
      ref="queryForm" size="small"
      :inline="true" v-show="showSearch" label-width="80px">
      <!--<el-form-item label="账户号" prop="accountId">
        <el-input
          v-model="queryParams.accountId"
          placeholder="请输入账户号"
          clearable
          style="width: 240px"

        />
      </el-form-item>-->
      <el-form-item label="交易时间" prop="dateRange">
        <el-date-picker
          v-model="queryParams.dateRange"
          value-format="yyyy-MM-dd"
          type="daterange"
          range-separator="-"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
        ></el-date-picker>
      </el-form-item>
      <el-form-item label="交易类型" prop="txnType">
        <el-select v-model="queryParams.txnType" placeholder="交易类型" clearable>
          <el-option
            v-for="dict in dict.type.txn_type"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="变更金额" prop="amount">
        <el-input
          v-model="queryParams.amount"
          placeholder="请输入变更金额"
          clearable
          style="width: 240px"

        />
      </el-form-item>
      <el-row :gutter="10" class="mb8">
        <el-col :span="1.5">
          <el-button v-hasPermi="['balance:details:query']" type="primary" icon="el-icon-search" size="small" @click="handleQuery">查询</el-button>
        </el-col>
        <el-col :span="1.5">
          <el-button icon="el-icon-refresh" size="small" @click="resetQuery">重置</el-button>
        </el-col>
        <el-col :span="1.5">
          <el-button v-hasPermi="['balance:details:download']" type="primary" icon="el-icon-refresh" size="small" @click="handleExport">导出</el-button>
        </el-col>
        <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
      </el-row>
    </el-form>
    <el-table v-loading="loading" :data="configList" @selection-change="handleSelectionChange">
      <el-table-column width="150px" label="商户号" align="center" prop="merchantNo" />
      <el-table-column label="商户名称" align="center" prop="merchantName" :show-overflow-tooltip="true" />
      <el-table-column width="170px" label="账户号" align="center" prop="accountId" :show-overflow-tooltip="true" />
      <el-table-column width="150px" label="账户类型" align="center" prop="accountType" >
        <template slot-scope="scope">
          <dict-tag :options="dict.type.account_type" :value="scope.row.accountType"/>
        </template>
      </el-table-column>
      <el-table-column width="170px" label="交易流水号" align="center" prop="txnId" />
      <el-table-column label="交易类型" align="center" prop="txnCode" >
        <template slot-scope="scope">
          <dict-tag :options="dict.type.txn_type" :value="scope.row.txnCode"/>
        </template>
      </el-table-column>
      <el-table-column label="币种" align="center" prop="currency">
        <template slot-scope="scope">
          <dict-tag :options="dict.type.currency_type" :value="scope.row.currency"/>
        </template>
      </el-table-column>
      <el-table-column width="150px" label="变更前余额" align="center" prop="beforeBalance" :show-overflow-tooltip="true" >
        <template slot-scope="scope">
          <span>{{formDataMoney(scope.row.beforeBalance)}}</span>
        </template>
      </el-table-column>
      <el-table-column label="变更金额" align="center" prop="amount" :show-overflow-tooltip="true" >
        <template slot-scope="scope">
          <span>{{formDataMoney(scope.row.amount)}}</span>
        </template>
      </el-table-column>
      <el-table-column width="150px" label="变更后余额" align="center" prop="afterBalance" :show-overflow-tooltip="true" >
        <template slot-scope="scope">
          <span>{{formDataMoney(scope.row.afterBalance)}}</span>
        </template>
      </el-table-column>
      <el-table-column width="150px" label="商户提现订单号" align="center" prop="agentPayNo" :show-overflow-tooltip="true" />
      <el-table-column width="150px" label="交易时间" align="center" prop="txnTime" :show-overflow-tooltip="true" />
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加或修改参数配置对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="500px" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="参数名称" prop="configName">
          <el-input v-model="form.configName" placeholder="请输入参数名称" />
        </el-form-item>
        <el-form-item label="参数键名" prop="configKey">
          <el-input v-model="form.configKey" placeholder="请输入参数键名" />
        </el-form-item>
        <el-form-item label="参数键值" prop="configValue">
          <el-input v-model="form.configValue" placeholder="请输入参数键值" />
        </el-form-item>
        <el-form-item label="系统内置" prop="configType">
          <el-radio-group v-model="form.configType">
            <el-radio
              v-for="dict in dict.type.sys_yes_no"
              :key="dict.value"
              :label="dict.value"
            >{{dict.label}}</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="备注" prop="remark">
          <el-input v-model="form.remark" type="textarea" placeholder="请输入内容" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { balanceDetailRequest, InfoExportApi, serviceBalanceDetailRequest } from '@/api/merchant/infactor'
import dayjs from 'dayjs'
import {regMoney} from '@/utils/validate'
import { formDataMoney } from '@/utils'

export default {
  name: "details",
  dicts: ['currency_type','txn_type','account_type'],
  data() {
    const dateRangeValidator =  (rule, value, callback) => {
      console.log(value)
      if(value){
        if(dayjs(value[1]).diff(dayjs(value[0]), 'months')>=3){
          callback(new Error('不能超过三个月'));
        }
      }
      callback()
    }
    return {
      // 遮罩层
      loading: false,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 参数表格数据
      configList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 日期范围
      dateRange: [],
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        amount: undefined,
        accountId: this.$route.query.accountId,
        txnType: undefined,
        dateRange: [dayjs().subtract(7, 'day').format("YYYY-MM-DD"),dayjs().format("YYYY-MM-DD")],
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        amount: [
          regMoney
        ],
        dateRange: [
          { type:'array', required: true, message: "不能为空", trigger: "change" },
          { validator: dateRangeValidator, trigger: 'change' }
        ],
        accountId: [
          { required: true, message: "不能为空", trigger: "change" }
        ]
      }
    };
  },
  mounted() {
    this.getList();
  },
  computed:{
    formDataMoney
  },
  methods: {
    /** 查询参数列表 */
    getList() {
      this.$refs.queryForm.validate(valid=>{
        if (valid) {
          this.loading = true;
          let json = JSON.parse(JSON.stringify(this.queryParams))
          let dateRange  = json.dateRange
          delete json['dateRange']
          let params = this.addDateRange(json, this.queryParams.dateRange,"startTime","endTime")
          if(params.amount){
            params.amount = Number(params.amount) * 100
          }
          balanceDetailRequest.list(params).then(response => {
              this.configList = response.data;
              this.total = Number(response.total);
              this.loading = false;
            }
          ).catch((e)=>{
            this.loading = false
          });
        }
      })
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        configId: undefined,
        configName: undefined,
        configKey: undefined,
        configValue: undefined,
        configType: "Y",
        remark: undefined
      };
      this.resetForm("form");
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm");
      this.handleQuery();
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.reset();
      this.open = true;
      this.title = "添加参数";
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.configId)
      this.single = selection.length!=1
      this.multiple = !selection.length
    },
    /** 明细 */
    handleDetails(row) {

    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.reset();
      this.open = true;
      const configId = row.configId || this.ids
      getConfig(configId).then(response => {
        this.form = response.data;
        this.open = true;
        this.title = "修改参数";
      });
    },
    /** 提交按钮 */
    submitForm: function() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.configId != undefined) {
            updateConfig(this.form).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.getList();
            });
          } else {
            addConfig(this.form).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.getList();
            });
          }
        }
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const configIds = row.configId || this.ids;
      this.$modal.confirm('是否确认删除参数编号为"' + configIds + '"的数据项？').then(function() {
          return delConfig(configIds);
        }).then(() => {
          this.getList();
          this.$modal.msgSuccess("删除成功");
        }).catch(() => {});
    },
    /** 导出按钮操作 */
    handleExport() {
      let json = JSON.parse(JSON.stringify(this.queryParams))
      let dateRange  = json.dateRange
      delete json['dateRange']
      let params = this.addDateRange(json, this.queryParams.dateRange,"startTime","endTime")
      if(params.amount){
        params.amount = Number(params.amount) * 100
      }
      this.download(InfoExportApi, {
        ...params
      }, `账户变动明细_${new Date().getTime()}.xlsx`)
    },
    /** 刷新缓存按钮操作 */
    handleRefreshCache() {
      refreshCache().then(() => {
        this.$modal.msgSuccess("刷新成功");
      });
    }
  }
};
</script>
