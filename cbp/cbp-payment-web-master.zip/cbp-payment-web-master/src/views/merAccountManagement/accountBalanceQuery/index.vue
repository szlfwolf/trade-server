<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="80px">
      <!--<el-form-item label="商户号" prop="merchantNo">
        <el-input
          v-model="queryParams.merchantNo"
          placeholder="请输入商户号"
          clearable
          style="width: 240px"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>-->
        <el-form-item label="商户名称" prop="merchantNo">
          <el-select
            clearable
            v-model="queryParams.merchantNo"
            placeholder="选择"
            style="width:100%"
            remote
            :remote-method="remoteMethod"
            @focus="onFocus"
            filterable
            :loading="xlloading"
            v-loadmore="loadmore"
          >
            <el-option
              v-for="(item, index) in departmentList"
              :key="index"
              :label="item.merchantName+'('+item.merchantNo+')'"
              :value="item.merchantNo"
            ></el-option>
          </el-select>
       <!-- <el-input
          v-model="queryParams.merchantName"
          placeholder="请输入商户名称"
          clearable
          style="width: 240px"
          @keyup.enter.native="handleQuery"
        />-->
      </el-form-item>
      <el-form-item label="账户类型" prop="accountType">
        <el-select v-model="queryParams.accountType" placeholder="账户类型" clearable>
          <el-option
            v-for="dict in dict.type.account_type"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="币种" prop="currency">
        <el-select v-model="queryParams.currency" placeholder="币种" clearable>
          <el-option
            v-for="dict in dict.type.currency_type"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-row :gutter="10" class="mb8">
        <el-col :span="1.5">
          <el-button v-hasPermi="['account:balance:query']" type="primary" icon="el-icon-search" size="small" @click="handleQuery">查询</el-button>
        </el-col>
        <el-col :span="1.5">
          <el-button icon="el-icon-refresh" size="small" @click="resetQuery">重置</el-button>
        </el-col>
        <el-col :span="1.5">
          <el-button v-hasPermi="['account:balance:export']" type="primary" icon="el-icon-download" size="small" @click="handleExport">导出</el-button>
        </el-col>
        <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
      </el-row>
    </el-form>
    <el-table v-loading="loading" :data="configList" @selection-change="handleSelectionChange">
      <el-table-column label="商户号" align="center" prop="merchantNo" />
      <el-table-column label="商户名称" align="center" prop="merchantName" :show-overflow-tooltip="true" />
      <el-table-column width="170px" label="账户号" align="center" prop="accountId" :show-overflow-tooltip="true" />
      <el-table-column label="账户类型" align="center" prop="accountType" :show-overflow-tooltip="true">
        <template slot-scope="scope">
          <dict-tag :options="dict.type.account_type" :value="scope.row.accountType"/>
        </template>
      </el-table-column>
      <el-table-column label="币种" align="center" prop="currency">
        <template slot-scope="scope">
          <dict-tag :options="dict.type.currency_type" :value="scope.row.currency"/>
        </template>
      </el-table-column>
      <el-table-column label="余额" align="center" prop="balance" :show-overflow-tooltip="true" >
        <template slot-scope="scope">
          <span>{{formDataMoney(scope.row.balance)}}</span>
        </template>
      </el-table-column>
      <el-table-column fixed="right" label="操作" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            @click="handleDetails(scope.row)"
          >变动明细</el-button>
          <el-button
            size="mini"
            type="text"
            @click="handleUpdate(scope.row)"
          >修改</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加或修改参数配置对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="900px" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="80px">
        <el-row :gutter="24">
          <el-col :span="12">
            <el-form-item label="商户号" prop="merchantNo">
              <p class="border-bottom">{{form.merchantNo}}</p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="商户名称" prop="merchantName">
              <p :title="form.merchantName" class="border-bottom">{{form.merchantName}}</p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="余额" prop="balance">
              <p class="border-bottom">{{form.balance}}</p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="账户类型" prop="accountType">
              <p class="border-bottom">
                <dict-tag :options="dict.type.account_type" :value="form.accountType"/>
              </p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="币种" prop="currency">
              <p class="border-bottom">
                <dict-tag :options="dict.type.currency_type" :value="form.currency"/>
              </p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="账户号" prop="accountId">
              <p class="border-bottom">{{form.accountId}}</p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="交易类型" prop="adjustType">
              <el-select style="width: 100%" v-model="form.adjustType" placeholder="状态" clearable>
                <el-option
                  v-for="dict in dict.type.adjust_type"
                  :key="dict.value"
                  :label="dict.label"
                  :value="dict.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="变动金额" prop="amount">
              <el-input v-model="form.amount" placeholder="请输入内容" />
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="备注" prop="remark">
              <el-input v-model="form.remark" type="textarea" placeholder="请输入内容" />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { merBalanceRequest, balanceExportApi, merInfo } from '@/api/merchant/infactor'
import { regMoney } from '@/utils/validate'
import { formDataMoney } from '@/utils'
export default {
  name: "Accountbalancequery",
  dicts: ['currency_type','account_type','merchant_status','adjust_type'],
  data() {
    return {
      merSize:10,
      merNum:1,
      merTotal:1,
      departmentList:[],
      // 遮罩层
      xlloading: false,
      loading: false,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 参数表格数据
      configList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 日期范围
      dateRange: [],
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        merchantNo: undefined,
        currency: undefined,
        accountType: undefined
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        adjustType: [
          { required: true, message: "不能为空", trigger: "change" }
        ],
        amount: [
          { required: true, message: "不能为空", trigger: "change" },
          regMoney
        ],
        remark: [
          { required: true, message: "不能为空", trigger: "change" }
        ]
      }
    };
  },
  computed:{
    formDataMoney
  },
  created() {
    this.getList();
  },
  methods: {
    // remoteMethod
    remoteMethod(query) {
      this.departmentList = []
      if (query !== '') {
        this.xlloading = true;
        this.merNum = 1
        this.getMerchantList(query);
      } else {
        this.getMerchantList();
      }
    },
    onFocus(){
      if (!this.queryParams.merchantNo) {
        this.xlloading = true;
        this.merNum = 1
        this.departmentList = []
        this.getMerchantList();
      }
    },
    getMerchantList(query){
      let params = {
        pageNum: this.merNum,
        pageSize: this.merSize,
      }
      if(Number(query)){
        params["merchantNo"] = query
      } else {
        params["merchantName"] = query
      }
      merInfo.getMerchantInfo(params).then(response => {
          this.departmentList = [...this.departmentList,...response.data]
          this.merTotal = Math.ceil(response.total / this.merSize)
        }
      ).catch(e=>{
        this.loading = false;
      }).finally(e=>{
        this.xlloading = false;
      });
    },
    //滑动触底的相关操作
    loadmore(){
      if(this.merNum<this.merTotal){
        this.merNum+=1
        this.getMerchantList()
      }
      console.log(this.merNum,this.merTotal);

      //数据页面更新，数据请求操作
    },
    selectChannel(){
      console.log('我滑动加载了');
      //数据页面更新，数据请求操作
    },
    /** 查询参数列表 */
    getList() {
      this.loading = true;
      merBalanceRequest.list(this.addDateRange(this.queryParams, this.dateRange)).then(response => {
          this.configList = response.data;
          this.total = Number(response.total);
          this.loading = false;
        }
      ).catch((e)=>{
        this.loading = false
      });
    },
    // 取消按钮
    cancel() {
      this.open = false;
      // this.reset();
    },
    // 表单重置
    reset() {
      this.resetForm("form");
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.dateRange = [];
      this.resetForm("queryForm");
      this.handleQuery();
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.reset();
      this.open = true;
      this.title = "添加参数";
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.configId)
      this.single = selection.length!=1
      this.multiple = !selection.length
    },
    /** 明细 */
    handleDetails(row) {
      this.$router.push("/meraccount/details?accountId="+row.accountId)
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.open = true;
      this.$nextTick(()=>{
        this.form = {...row,remark:null,adjustType:null,amount:null}
        setTimeout(()=>{
          this.$refs["form"].clearValidate()
        },0)
      })
    },
    /** 提交按钮 */
    submitForm: function() {
      this.$refs["form"].validate(valid => {
          if(valid){
            merBalanceRequest.update({
              accountId: this.form.accountId,
              adjustType: this.form.adjustType,
              amount: Number(this.form.amount) * 100,
              remark: this.form.remark,
            }).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.getList();
            });
          }
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const configIds = row.configId || this.ids;
      this.$modal.confirm('是否确认删除参数编号为"' + configIds + '"的数据项？').then(function() {
          return delConfig(configIds);
        }).then(() => {
          this.getList();
          this.$modal.msgSuccess("删除成功");
        }).catch(() => {});
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download(balanceExportApi, {
        ...this.queryParams
      }, `账户余额信息_${new Date().getTime()}.xlsx`)
    },
    /** 刷新缓存按钮操作 */
    handleRefreshCache() {
      refreshCache().then(() => {
        this.$modal.msgSuccess("刷新成功");
      });
    }
  }
};
</script>
<style scoped>
.border-bottom{
  height: 36px;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
</style>
