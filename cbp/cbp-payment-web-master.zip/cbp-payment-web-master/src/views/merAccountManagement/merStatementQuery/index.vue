<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" size="small" v-show="showSearch" label-width="80px">
      <el-row :gutter="24">
        <el-col :span="6">
          <el-form-item label="商户名称" prop="merchantNo">
            <el-select
              clearable
              v-model="queryParams.merchantNo"
              placeholder="选择"
              style="width:100%"
              remote
              :remote-method="remoteMethod"
              @focus="onFocus"
              filterable
              :loading="xlloading"
              v-loadmore="loadmore"
            >
              <el-option
                v-for="(item, index) in departmentList"
                :key="index"
                :label="item.merchantName+'('+item.merchantNo+')'"
                :value="item.merchantNo"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="账户类型" prop="accountType">
            <el-select style="width: 100%" v-model="queryParams.accountType" placeholder="账户类型" clearable>
              <el-option
                v-for="dict in dict.type.account_type"
                :key="dict.value"
                :label="dict.label"
                :value="dict.value"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="币种" prop="currency">
            <el-select style="width: 100%" v-model="queryParams.currency" placeholder="币种" clearable>
              <el-option
                v-for="dict in dict.type.currency_type"
                :key="dict.value"
                :label="dict.label"
                :value="dict.value"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="交易时间">
            <el-date-picker
              style="width: 100%"
              v-model="dateRange"
              value-format="yyyy-MM-dd"
              type="daterange"
              range-separator="-"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
            ></el-date-picker>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="10" class="mb8">
        <el-col :span="1.5">
          <el-button v-hasPermi="['mer:statement:query']" type="primary" icon="el-icon-search" size="small" @click="handleQuery">查询</el-button>
        </el-col>
        <el-col :span="1.5">
          <el-button icon="el-icon-refresh" size="small" @click="resetQuery">重置</el-button>
        </el-col>
        <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
      </el-row>
    </el-form>
    <el-table v-loading="loading" :data="configList" @selection-change="handleSelectionChange">
      <el-table-column fixed="left" label="商户号" align="center" prop="merchantNo" />
      <el-table-column label="商户名称" align="center" prop="merchantName" :show-overflow-tooltip="true" />
      <el-table-column label="账户号" align="center" prop="accountId" :show-overflow-tooltip="true" />
      <el-table-column label="账户类型" align="center" prop="accountType" >
        <template slot-scope="scope">
          <dict-tag :options="dict.type.account_type" :value="scope.row.accountType"/>
        </template>
      </el-table-column>
      <el-table-column label="币种" align="center" prop="currency">
        <template slot-scope="scope">
          <dict-tag :options="dict.type.currency_type" :value="scope.row.currency"/>
        </template>
      </el-table-column>
      <el-table-column label="交易开始时间" align="center" prop="startTime" :show-overflow-tooltip="true" />
      <el-table-column label="交易结束时间" align="center" prop="endTime" :show-overflow-tooltip="true" />
      <el-table-column label="操作" fixed="right" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            @click="handleDownload(scope.row)"
            v-hasPermi="['mer:statement:download']"
          >下载</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加或修改参数配置对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="900px" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="80px">
        <el-row :gutter="24">
          <el-col :span="12">
            <el-form-item label="商户号" prop="configName">
              <p style="border-bottom: 1px solid #eee">1243</p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="商户名称" prop="configKey">
              <p style="border-bottom: 1px solid #eee">1243</p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="余额" prop="configKey">
              <p style="border-bottom: 1px solid #eee">1243</p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="账户类型" prop="configKey">
              <p style="border-bottom: 1px solid #eee">1243</p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="币种" prop="configKey">
              <p style="border-bottom: 1px solid #eee">1243</p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="账户号" prop="configKey">
              <p style="border-bottom: 1px solid #eee">1243</p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="交易类型" prop="configType">
              <p style="border-bottom: 1px solid #eee">1243</p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="变动金额" prop="remark">
              <p style="border-bottom: 1px solid #eee">1243</p>
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="备注" prop="remark">
              <p style="border-bottom: 1px solid #eee">1243</p>
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="审核意见" prop="remark">
              <el-input v-model="form.remark" type="textarea" placeholder="请输入内容" />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <el-dialog
        width="30%"
        title="授权验证"
        :visible.sync="innerVisible"
        append-to-body>
        <el-form :model="queryParams" ref="sendForm" size="small" label-width="120px">
          <el-row :gutter="24">
            <el-col :span="24">
              <el-form-item label="短信接收手机号:" prop="configName">
                <span>13916263154</span>
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item label="短信验证:" prop="configName">
                <el-input
                  v-model="queryParams.configName"
                  placeholder="请输入短信验证"
                  clearable
                  style="width: 200px;margin-right: 10px"
                  @keyup.enter.native="sendCode"
                />
                <el-button type="primary" @click="toSure">发送短信</el-button>
              </el-form-item>
            </el-col>
          </el-row>
          <div style="text-align: center">
            <el-button type="primary" @click="toSure">确认</el-button>
          </div>
        </el-form>
      </el-dialog>
      <div slot="footer" class="dialog-footer">
        <el-button type="danger" @click="submitJect">审核拒绝</el-button>
        <el-button type="primary" @click="innerVisible = true">审核通过</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { merstatementRequest, exportApi, merInfo } from '@/api/merchant/infactor'

export default {
  name: "Merstatementquery",
  dicts: ['currency_type','account_type'],
  data() {
    return {
      departmentList:[],
      merSize:10,
      merNum:1,
      merTotal:1,
      // 遮罩层
      loading: true,
      xlloading: true,
      // 内层dialog遮罩层
      innerVisible: false,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 参数表格数据
      configList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 日期范围
      dateRange: [],
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        configName: undefined,
        configKey: undefined,
        configType: undefined
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        configName: [
          { required: true, message: "参数名称不能为空", trigger: "blur" }
        ],
        configKey: [
          { required: true, message: "参数键名不能为空", trigger: "blur" }
        ],
        configValue: [
          { required: true, message: "参数键值不能为空", trigger: "blur" }
        ]
      }
    };
  },
  created() {
    this.getList();
  },
  methods: {
    // remoteMethod
    remoteMethod(query) {
      this.departmentList = []
      if (query !== '') {
        this.xlloading = true;
        this.merNum = 1
        this.getMerchantList(query);
      } else {
        this.getMerchantList();
      }
    },
    onFocus(){
      if (!this.queryParams.merchantNo) {
        this.xlloading = true;
        this.merNum = 1
        this.departmentList = []
        this.getMerchantList();
      }
    },
    getMerchantList(query){
      let params = {
        pageNum: this.merNum,
        pageSize: this.merSize,
      }
      if(Number(query)){
        params["merchantNo"] = query
      } else {
        params["merchantName"] = query
      }
      merInfo.getMerchantInfo(params).then(response => {
          this.departmentList = [...this.departmentList,...response.data]
          this.merTotal = Math.ceil(response.total / this.merSize)
        }
      ).catch(e=>{
      }).finally(e=>{
        this.xlloading = false;
      });
    },
    //滑动触底的相关操作
    loadmore(){
      if(this.merNum<this.merTotal){
        this.merNum+=1
        this.getMerchantList()
      }
      //数据页面更新，数据请求操作
    },
    selectChannel(){
      console.log('我滑动加载了');
      //数据页面更新，数据请求操作
    },
    /** 查询参数列表 */
    getList() {
      this.loading = true;
      merstatementRequest.list(this.addDateRange(this.queryParams, this.dateRange,'startTime','endTime')).then(response => {
          this.configList = response.data;
          this.total = Number(response.total);
          this.loading = false;
        }
      ).catch((e)=>{
        this.loading = false
      });
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        configId: undefined,
        configName: undefined,
        configKey: undefined,
        configValue: undefined,
        configType: "Y",
        remark: undefined
      };
      this.resetForm("form");
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.dateRange = [];
      this.resetForm("queryForm");
      this.handleQuery();
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.reset();
      this.open = true;
      this.title = "添加参数";
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.configId)
      this.single = selection.length!=1
      this.multiple = !selection.length
    },
    /** 明细 */
    handleDetails(row) {
      this.$router.push("/meraccount/details")
    },
    /** 修下载按钮操作 */
    handleDownload(row) {
      this.download(exportApi, {
        accountId:row.accountId,
        endTime:row.endTime,
        startTime:row.startTime,
      }, `对账单_${new Date().getTime()}.xlsx`)
    },
    /** 发送按钮 */
    sendCode(){

    },
    /** 确认按钮 */
    toSure(){

    },
    /** 拒绝按钮 */
    submitJect: function() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.configId != undefined) {
            updateConfig(this.form).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.getList();
            });
          } else {
            addConfig(this.form).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.getList();
            });
          }
        }
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const configIds = row.configId || this.ids;
      this.$modal.confirm('是否确认删除参数编号为"' + configIds + '"的数据项？').then(function() {
          return delConfig(configIds);
        }).then(() => {
          this.getList();
          this.$modal.msgSuccess("删除成功");
        }).catch(() => {});
    },
    /** 刷新缓存按钮操作 */
    handleRefreshCache() {
      refreshCache().then(() => {
        this.$modal.msgSuccess("刷新成功");
      });
    }
  }
};
</script>
