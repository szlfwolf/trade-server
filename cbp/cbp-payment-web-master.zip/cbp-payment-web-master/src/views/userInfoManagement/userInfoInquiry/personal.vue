<template>
  <!-- 添加或修改参数配置对话框 -->
  <el-dialog :title="title" :visible.sync="open" width="1000px" append-to-body
             :close-on-press-escape="false"
             :close-on-click-modal="false"
             :fullscreen="isFullscreen"
  >
    <template slot="title">
      <div class="dialog-bar">
        <span>{{title}}</span>
        <el-tooltip content="全屏 / 窗口" effect="dark" placement="bottom">
          <svg-icon @click="onScale" class="icon-full" :icon-class="isFullscreen?'exit-fullscreen':'fullscreen'" />
        </el-tooltip>
      </div>
    </template>
    <el-form ref="form" :model="form" :rules="rules" label-width="100px" class="form" disabled>
      <el-row :gutter="24">
        <el-col :span="isFullscreen ? 8 : 12">
          <el-form-item label="商户号" prop="merchantNo">
            <el-input :title="form.merchantNo" v-model="form.merchantNo" placeholder="请输入商户号" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 12">
          <el-form-item label="商户名称" prop="merchantName">
            <el-input :title="form.merchantName" v-model="form.merchantName" placeholder="请输入商户名称" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 12">
          <el-form-item label-width="100px" label="通道用户编号" prop="openUserNo">
            <el-input :title="form.openUserNo" v-model="form.openUserNo" placeholder="请输入通道用户编号" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 12">
          <el-form-item label-width="100px" label="卖家编号" prop="merchantUserNo">
            <el-input :title="form.merchantUserNo" v-model="form.merchantUserNo" placeholder="请输入卖家编号" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 12">
          <el-form-item label-width="100px" label="用户编号" prop="userNo">
            <el-input :title="form.userNo" v-model="form.userNo" placeholder="请输入用户编号" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 12">
          <el-form-item label-width="100px" label="用户名称" prop="nameMask">
            <el-input :title="form.nameMask" v-model="form.nameMask" placeholder="请输入用户名称" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 12">
          <el-form-item label-width="100px" label="用户类型" prop="userType">
            <el-select style="width: 100%" v-model="form.userType" placeholder="用户类型" clearable>
              <el-option
                v-for="dict in dict.type.user_type"
                :key="dict.value"
                :label="dict.label"
                :value="dict.value"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 12">
          <el-form-item label-width="100px" label="证件号码" prop="certIdMask">
            <el-input :title="form.certIdMask" v-model="form.certIdMask" placeholder="请输入证件号码" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 12">
          <el-form-item label-width="100px" label="创建时间" prop="crtTime">
            <el-input v-model="form.crtTime" placeholder="请输入创建时间" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 12">
          <el-form-item label-width="100px" label="更新时间" prop="updTime">
            <el-input v-model="form.updTime" placeholder="请输入更新时间" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 12">
          <el-form-item label-width="100px" label="平台注册时间" prop="regTime">
            <el-input v-model="form.regTime" placeholder="请输入平台注册时间" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 12">
          <el-form-item label-width="100px" label="备案状态" prop="status">
            <el-select style="width: 100%" v-model="form.status" placeholder="用户类型" clearable>
              <el-option
                v-for="dict in dict.type.register_status2"
                :key="dict.value"
                :label="dict.label"
                :value="dict.value"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 12">
          <el-form-item label-width="100px" label="证件有效期起" prop="certExpBeginDate">
            <el-input v-model="form.certExpBeginDate" placeholder="请输入证件有效期起" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 12">
          <el-form-item label-width="100px" label="证件有效期止" prop="certExpEndDate">
            <el-input v-model="form.certExpEndDate" placeholder="请输入证件有效期止" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 12">
          <el-form-item label-width="100px" label="地址" prop="address">
            <el-input :title="form.address" v-model="form.address" placeholder="请输入地址" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 12">
          <el-form-item label-width="100px" label="国籍" prop="nationality">
            <el-select style="width: 100%" v-model="form.nationality" placeholder="用户类型" clearable>
              <el-option
                v-for="dict in dict.type.source_country"
                :key="dict.value"
                :label="dict.label + '('+dict.value+')' "
                :value="dict.value"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 12">
          <el-form-item label-width="100px" label="职业" prop="professionCode">
            <el-input v-model="form.professionCode" placeholder="请输入职业" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 12">
          <el-form-item label-width="100px" label="邮箱" prop="email">
            <el-input :title="form.email" v-model="form.email" placeholder="请输入邮箱" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 12">
          <el-form-item label-width="100px" label="开户银行" prop="bankName">
            <el-input :title="form.bankName" v-model="form.bankName" placeholder="请输入开户银行" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 12">
          <el-form-item label-width="100px" label="银行卡号" prop="bankAcct">
            <el-input v-model="form.bankAcct" placeholder="请输入银行卡号" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 12">
          <el-form-item label-width="100px" label="店铺链接" prop="storeLink">
            <el-input :title="form.storeLink" v-model="form.storeLink" placeholder="请输入店铺链接" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 12">
          <el-form-item label-width="100px" label="手机号" prop="mobileNoMask">
            <el-input v-model="form.mobileNoMask" placeholder="请输入手机号" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 12">
          <el-form-item label-width="130px" label="身份证影印件正面" prop="certFrontFileId">
            <p @click="toViewPhoto(form.certFrontFileId)" title="点击预览" style="color: #1482f0;cursor:pointer;">{{form.certFrontFileId}}</p>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 12">
          <el-form-item label-width="130px" label="身份证影印件反面" prop="certBackFileId">
            <p @click="toViewPhoto(form.certBackFileId)" title="点击预览" style="color: #1482f0;cursor:pointer;">{{form.certBackFileId}}</p>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
      <div slot="footer" class="dialog-footer">
<!--        <el-button type="primary" @click="submitForm">确 定</el-button>-->
        <el-button @click="cancel">取 消</el-button>
      </div>
    <el-dialog
      width="70%"
      title="预览"
      style="text-align: center"
      :visible.sync="innerVisible"
      append-to-body>
      <el-image title="右击另存为...." :src="imgUrl" lazy></el-image>
    </el-dialog>
  </el-dialog>
</template>

<script>
import { userInfoRequest, merInfo, userExport, downPhoto } from '@/api/merchant/infactor'
import { mixinsAction } from '@/utils/actionMinxis'
export default {
  mixins:[mixinsAction],
  dicts:["operation_status","merchant_status","user_type","source_country","register_status2"],
  data(){
    return{
      imgUrl:'',
      // dialog全屏
      innerVisible:false,
      isFullscreen:false,
      // tabs的显示id
      activeName: 'first',
      // 弹出层标题
      title: "添加",
      // 是否显示弹出层
      open: false,
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        memberNo: [
          { required: true, message: "参数名称不能为空", trigger: "blur" }
        ]
      },
      // 表格集合
      tableData:[],
      // 表格集合
      headerStyle:{
        color:"#123456"
      },
    }
  },
  methods:{
    onScale(){
      this.isFullscreen = !this.isFullscreen
    },
    handleSelectionChange(val){
      this.clearTree = val.map(item=>{
        return item.id
      })
      console.log(this.clearTree)
    },
    add(){
      this.open = true;
      this.title = "添加";
      this.reset();
    },
    /** 审核按钮操作 */
    examine(row) {
      this.open = true;
      this.title = "审核";
      // const configId = row.configId || this.ids
      getConfig().then(response => {
        this.form = response.data;
      });
    },
    /** 查看按钮操作 */
    checkData(row) {
      this.open = true;
      this.title = "查看";
      // const configId = row.configId || this.ids
      userInfoRequest.getDetails(row.id).then(response => {
        this.form = response.data;
      });
    },
    /** 修改按钮操作 */
    update(row) {
      this.open = true;
      this.title = "修改";
      // const configId = row.configId || this.ids
      userInfoRequest.getDetails(row.id).then(response => {
        this.form = response.data;
      });
    },
    /** 提交按钮 */
    submitForm: function() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.configId != undefined) {
            updateConfig(this.form).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.getList();
            });
          } else {
            addConfig(this.form).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.getList();
            });
          }
        }
      });
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        configId: undefined,
        memberNo: undefined,
        configKey: undefined,
        configValue: undefined,
        status: "",
        remark: undefined
      };
      this.resetForm("form");
    },
  }
}
</script>

<style>
  .title{
    font-size: 15px;
    color: #1890ff;
  }
  .el-table tr .heade-cell{
    color: #333;
    background-color:#eff3f8;
  }
</style>
<style scoped lang="scss">
.dialog-bar{
  position: relative;
  .icon-full{
    position: absolute;
    right: 30px;
    font-size: 12px;
    top: 2px;
    cursor: pointer;
  }
}
.form{
  overflow-x: hidden;
  overflow-y: scroll;
}
.form::-webkit-scrollbar{
  display: none;
}
.upload-demo{
  display: flex;
  align-items: center;
  justify-content: flex-start;
}
.date-select{
  /*display: flex;*/
  align-items: center;
  justify-content: flex-start;
}
</style>
