<template>
  <div class="app-container">
    <el-form
      :model="queryParams"
      ref="queryForm"
      size="small"
      :inline="true"
      v-show="showSearch"
      label-width="88px">
      <!--<el-form-item label="商户号" prop="merchantNo">
        <el-input
          v-model="queryParams.memberNo"
          placeholder="请输入商户号"
          clearable
          style="width: 240px"
        />
      </el-form-item>-->
      <el-form-item label="商户名称" prop="merchantNo">
        <el-select
          clearable
          v-model="queryParams.merchantNo"
          placeholder="选择"
          style="width: 210px"
          remote
          :remote-method="remoteMethod"
          @focus="onFocus"
          filterable
          :loading="xlloading"
          v-loadmore="loadmore"
        >
          <el-option
            v-for="(item, index) in departmentList"
            :key="item.merchantNo"
            :label="item.merchantName +'('+ item.merchantNo+')'"
            :value="item.merchantNo"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="产品类型" prop="productType">
        <el-select filterable style="width: 210px" v-model="queryParams.productType" placeholder="产品类型" clearable>
          <el-option
            v-for="dict in productCodes"
            :key="dict.productCode"
            :label="dict.productName+'('+dict.productCode+')'"
            :value="dict.productCode"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="商户批次号" prop="batchNo">
        <el-input
          v-model="queryParams.batchNo"
          placeholder="请输入商户批次号"
          clearable
          style="width: 210px"
        />
      </el-form-item>
      <el-form-item label="汇款批次号" prop="remitBatchNo">
        <el-input
          v-model="queryParams.remitBatchNo"
          placeholder="请输入汇款批次号"
          clearable
          style="width: 210px"
        />
      </el-form-item>
      <el-form-item label="明细流水号" prop="serialNo">
        <el-input
          v-model="queryParams.serialNo"
          placeholder="请输入明细流水号"
          clearable
          style="width: 210px"
        />
      </el-form-item>
      <el-form-item label="订单编号" prop="orderNo">
        <el-input
          v-model="queryParams.orderNo"
          placeholder="请输入订单编号"
          clearable
          style="width: 210px"
        />
      </el-form-item>
      <el-form-item label="核查状态" prop="verifyStatus">
        <el-select style="width: 210px" v-model="queryParams.verifyStatus" placeholder="核查状态" clearable>
          <el-option
            v-for="dict in dict.type.order_verify_status"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="创建时间">
        <el-date-picker
          v-model="dateRange"
          style="width: 210px"
          value-format="yyyy-MM-dd"
          type="daterange"
          range-separator="-"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
        ></el-date-picker>
      </el-form-item>
      <el-row :gutter="10" class="mb8">
        <el-col :span="1.5">
        </el-col>
        <el-form-item>
          <el-button v-hasPermi="['order:details:query']" type="primary" icon="el-icon-search" @click="handleQuery">查询</el-button>
          <el-button icon="el-icon-refresh" @click="resetQuery">重置</el-button>
          <el-button v-hasPermi="['order:details:export']" type="primary" icon="el-icon-download" @click="handleExport">导出</el-button>
        </el-form-item>
        <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
      </el-row>
    </el-form>
    <el-table v-loading="loading" :data="configList" @selection-change="handleSelectionChange">
      <el-table-column width="150px" label="商户号" fixed="left"  align="center" prop="merchantNo"  />
      <el-table-column width="150px" label="商户名称" align="center" prop="merchantName" :show-overflow-tooltip="true"/>
      <el-table-column width="150px" label="商户批次号" align="center" prop="batchNo" :show-overflow-tooltip="true"/>
      <el-table-column width="150px" label="明细流水号" align="center" prop="serialNo"  :show-overflow-tooltip="true"/>
      <el-table-column width="150px" label="订单编号" align="center" prop="orderNo"  :show-overflow-tooltip="true"/>
      <el-table-column width="180px" label="卖家编号" align="center" prop="userNo"  :show-overflow-tooltip="true"/>
      <el-table-column width="150px" label="付款币种" align="center" prop="payCur"  >
        <template slot-scope="scope">
          <dict-tag :options="dict.type.merch_currency_type" :value="scope.row.payCur"/>
        </template>
      </el-table-column>
      <el-table-column width="150px" label="付款金额" align="center" prop="payAmt"  >
        <template slot-scope="scope">
         <span>{{formDataMoney(scope.row.payAmt)}}</span>
        </template>
      </el-table-column>
      <el-table-column width="120px" label="产品类型" align="center" prop="productType"  />
      <el-table-column width="120px" label="汇款批次号" align="center" prop="remitBatchNo"  />
      <el-table-column width="120px" label="状态" align="center" prop="reviewStatus"  >
        <template slot-scope="scope">
          <dict-tag :options="dict.type.mer_order_status" :value="scope.row.reviewStatus"/>
        </template>
      </el-table-column>
      <el-table-column width="120px" label="审核详情" align="center" prop="results"  :show-overflow-tooltip="true"/>
      <el-table-column width="120px" label="审核人" align="center" prop="checkPerson"  />
      <el-table-column width="120px" label="核查状态" align="center" prop="verifyStatus" >
        <template slot-scope="scope">
          <dict-tag :options="dict.type.order_verify_status" :value="scope.row.verifyStatus"/>
        </template>
      </el-table-column>
      <el-table-column width="120px" label="核查详情" align="center" prop="checkDetails"  :show-overflow-tooltip="true"/>
      <el-table-column width="120px" label="核查人" align="center" prop="examinePerson"  />
      <el-table-column width="120px" label="银行申报详情" align="center" prop="bankDeclaration"  :show-overflow-tooltip="true"/>
      <el-table-column width="150px" label="创建时间" align="center" prop="crtTime"  />
      <el-table-column width="150px" label="更新时间" align="center" prop="uptTime"  />
      <el-table-column width="160px" label="操作" fixed="right" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            v-hasPermi="['order:details:view']"
            @click="handleView(scope.row)"
          >详情</el-button>
          <el-button
            size="mini"
            type="text"
            v-if="scope.row.productType==1007"
            v-hasPermi="['order:details:examine']"
            @click="handleExamine(scope.row)"
          >审核</el-button>
          <el-button
            size="mini"
            type="text"
            @click="handleAgain(scope.row)"
            v-if="scope.row.productType==1003"
            v-hasPermi="['order:details:check']"
          >核查</el-button>
          <el-button
            size="mini"
            type="text"
            @click="handleUpdate(scope.row)"
            v-if="scope.row.productType==1003"
            v-hasPermi="['order:details:again']"
          >材料补充</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />
    <dialogView ref="dialog"></dialogView>
  </div>
</template>

<script>
import { orderDetailsRequest, product, manageOrderDtailExportApi } from '@/api/merchant/infactor'
import dialogView from "./dialogView";
import { myMixins } from '@/utils/minxis'
import { formDataMoney } from '@/utils'
export default {
  dicts:['order_verify_status','mer_order_status','merch_currency_type'],
  name: "Config",
  mixins:[myMixins],
  components:{
    dialogView
  },
  data() {
    return {
      productCodes: [],
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 参数表格数据
      configList: [],
      // 日期范围
      dateRange: [],
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        memberNo: undefined,
        configKey: undefined,
        status: undefined
      },
      // 表单校验
      rules: {
        memberNo: [
          { required: true, message: "参数名称不能为空", trigger: "blur" }
        ],
        configKey: [
          { required: true, message: "参数键名不能为空", trigger: "blur" }
        ],
        configValue: [
          { required: true, message: "参数键值不能为空", trigger: "blur" }
        ]
      }
    };
  },
  created() {
    this.getList();
    this.getProductCodes() //
  },
  computed:{
    formDataMoney
  },
  methods: {
    /*获取二级产品枚举*/
    getProductCodes(val){
      product.getParentCodesAction({type:"2"}).then(response => {
        this.productCodes = response.data;
      })
      /* product.getProductCodesAction({parentProductCode:val}).then(response => {
         this.productCodes = response.data;
       })*/
    },
    /** 查询商户信息列表 */
    getList() {
      this.loading = true;
      orderDetailsRequest.list(this.addDateRange(this.queryParams, this.dateRange,'crtTimeBegin','crtTimeEnd')).then(response => {
          this.configList = response.data;
          this.total = Number(response.total);
          this.loading = false;
        }
      ).catch(e=>{
        this.loading = false;
      });
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.queryParams.pageSize = 10;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.dateRange = [];
      this.resetForm("queryForm");
      this.handleQuery();
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.$refs.dialog.add()
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.configId)
      this.single = selection.length!=1
      this.multiple = !selection.length
    },
    /** 审核按钮操作 */
    handleExamine(row) {
      // const configId = row.configId || this.ids
      this.$refs.dialog.examine(row)
    },
    /** 审核按钮操作 */
    handleAgain(row) {
      // const configId = row.configId || this.ids
      this.$refs.dialog.again(row)
    },
    /** 恢补充按钮操作 */
    handleUpdate(row) {
      // const configId = row.configId || this.ids
      this.$refs.dialog.update(row)
    },
    /** 查看按钮操作 */
    handleView(row) {
      // const configId = row.configId || this.ids
      this.$refs.dialog.checkData(row)
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download(manageOrderDtailExportApi, {
        ...this.queryParams
      }, `订单明细信息_${new Date().getTime()}.xlsx`)
    },
  }
};
</script>
