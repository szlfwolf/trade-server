<template>
  <!-- 添加或修改参数配置对话框 -->
  <el-dialog :title="title" :visible.sync="open" width="600px" append-to-body
             :close-on-press-escape="false"
             :close-on-click-modal="false"
             :fullscreen="isFullscreen"
  >
    <template slot="title">
      <div class="dialog-bar">
        <span>{{title}}</span>
        <el-tooltip content="全屏 / 窗口" effect="dark" placement="bottom">
          <svg-icon @click="onScale" class="icon-full" :icon-class="isFullscreen?'exit-fullscreen':'fullscreen'" />
        </el-tooltip>
      </div>
    </template>
    <el-form ref="form" :model="form" :rules="rules" label-width="80px" class="form" :disabled="Dis">
      <el-row :gutter="24">
        <el-col :span="isFullscreen ? 8 : 24">
          <el-form-item label-width="110px" label="通道编号" prop="channelCode">
            <el-input :disabled="type=='edit'" v-model="form.channelCode" placeholder="请输入通道编号" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 24">
          <el-form-item label-width="110px" label="通道名称" prop="channelName">
            <el-input :disabled="type=='edit'" v-model="form.channelName" placeholder="请输入通道名称" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 24">
          <el-form-item label-width="110px" label="一级产品名称" prop="parentProductCode">
            <el-select :disabled="type=='edit'" style="width: 100%" v-model="form.parentProductCode" @change="onChange" placeholder="一级产品名称" clearable>
              <el-option
                v-for="dict in dict.type.parent_product_code"
                :key="dict.value"
                :label="dict.label"
                :value="dict.value"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 24" v-if="type!='add'">
          <el-form-item label-width="110px" label="状态" prop="channelStatus">
            <el-select style="width: 440px" v-model="form.channelStatus" placeholder="状态" clearable>
              <el-option
                v-for="dict in dict.type.pro_common_status"
                :key="dict.value"
                :label="dict.label"
                :value="dict.value"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 24">
          <p style="margin-bottom:10px;">
            <span style="font-weight:600">二级产品名称（可多选）：</span>
            <el-checkbox :indeterminate="isIndeterminate" v-model="checkAll" @change="handleCheckAllChange">全选</el-checkbox>
          </p>
          <el-form-item label-width="0px" prop="channelConfigProductVoList">
            <el-checkbox-group v-model="form.channelConfigProductVoList" @change="handleCheckedCitiesChange">
              <el-row :gutter="24">
                <el-col style="height: 30px;" :span="6" v-for="city in cities" :key="city.productCode"  >
                  <el-checkbox style="width:100%;overflow:hidden" :label="city.productCode" >
                    <p :title="city.productName">{{city.productName}}</p>
                  </el-checkbox>
                </el-col>
              </el-row>
            </el-checkbox-group>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button v-if="type!='view'" type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
  </el-dialog>
</template>

<script>
import {channel, product} from "@/api/merchant/infactor";
export default {
  dicts: ['pro_common_status','parent_product_code'],
  data(){
    return{
      checkAll: false,
      parentProductCodes: [],
      channelProductQryDtoList: [],
      cities: [],
      isIndeterminate: true,
      cityOptions: [],
      // dialog全屏
      isFullscreen:false,
      Dis:false,
      // tabs的显示id
      activeName: 'first',
      type: 'add',
      // 弹出层标题
      title: "添加",
      // 是否显示弹出层
      open: false,
      // 表单参数
      form: {
        channelConfigProductVoList:[],
        channelCode:null,
        channelStatus:null,
        channelName:null,
        parentProductCode:null,
      },
      // 表单校验
      rules: {
        channelCode: [
          { required: true, message: "通道编号不能为空", trigger: "change" },
        ],
        channelName: [
          { required: true, message: "通道名称不能为空", trigger: "change" },
        ],
        parentProductCode: [
          { required: true, message: "一级产品名称不能为空", trigger: "change" },
        ],
        channelConfigProductVoList: [
          { type: 'array', required: true, message: "请至少选择一个二级产品", trigger: "change" },
        ],
      },
      // 表格集合
      tableData:[],
      // 表格集合
      headerStyle:{
        color:"#123456"
      },
      multipleSelection:[],
      clearTree:[]
    }
  },
  created() {
    this.getParentCodes();
  },
  methods:{
    /*获取一级产品枚举*/
    getParentCodes(){
      product.getParentCodesAction({type:"1"}).then(response => {
        this.parentProductCodes = response.data;
      })
    },
    /*获取二级产品枚举*/
    getProductCodes(val){
      try {
        product.getProductCodesAction({parentProductCode:val,productStatus:'1'}).then(response => {
          this.cities = JSON.parse(JSON.stringify(response.data));
          this.cityOptions = JSON.parse(JSON.stringify(response.data));
        })
      }catch (e){
        console.log(e)
      }
    },
    onChange(val){
      this.getProductCodes(val)
    },
    //全选
    handleCheckAllChange(val) {
      this.form.channelConfigProductVoList = val ? this.cityOptions.map(val=>{return val.productCode}) : [];
      this.isIndeterminate = false;
    },
    handleCheckedCitiesChange(value) {
      try {
        let checkedCount = value.length;
        this.checkAll = checkedCount === this.cities.length;
        this.isIndeterminate = checkedCount > 0 && checkedCount < this.cities.length;
      }catch (e){
        console.log(e)
      }
      console.log(this.form.channelConfigProductVoList)
    },
    onScale(){
      this.isFullscreen = !this.isFullscreen
    },
    handleSelectionChange(val){
      this.clearTree = val.map(item=>{
        return item.id
      })
      console.log(this.clearTree)
    },
    add(){
      this.open = true;
      this.Dis = false;
      this.title = "添加";
      this.type = "add";
      this.reset();
      this.form = {
        channelConfigProductVoList:[],
        channelCode:null,
        channelStatus:null,
        channelName:null,
        parentProductCode:null,
      }
    },
    /** 审核按钮操作 */
    examine(row) {
      this.open = true;
      this.title = "审核";
    },
    /** 查看按钮操作 */
    checkData(row) {
      this.open = true;
      this.Dis = true;
      this.type = "view";
      this.title = "查看";
      this.reset()
      this.getProductCodes(row.parentProductCode)
      this.$nextTick(()=>{
        this.form = {
          channelCode:row.channelCode,
          channelName:row.channelName,
          channelStatus:row.channelStatus,
          id:row.id,
          parentProductCode:row.parentProductCode,
        }
        this.form.channelConfigProductVoList = row.channelProductQryDtoList.map(val=>{
          return val.productCode
        })
      })
    },
    /** 修改按钮操作 */
    async update(row) {
      this.open = true;
      this.Dis = false;
      this.type = "edit";
      this.title = "修改";
      await this.reset()
      await this.getParentCodes()
      await this.getProductCodes(row.parentProductCode)
      this.$nextTick(()=>{
        this.form = {
          channelCode:row.channelCode,
          channelName:row.channelName,
          channelStatus:row.channelStatus,
          id:row.id,
          parentProductCode:row.parentProductCode,
          channelConfigProductVoList:[]
        }
        this.channelProductQryDtoList = row.channelProductQryDtoList
        this.form.channelConfigProductVoList = row.channelProductQryDtoList.map(val=>{
          return val.productCode
        })
        console.log(row,this.form)
      })
    },
    /** 提交按钮 */
    submitForm: function() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          let channelConfigProductVoList = []
          this.form.channelConfigProductVoList.forEach(val=>{
            if(!this.form.id){
              channelConfigProductVoList.push({
                productCode: val
              })
            }else{
              console.log(this.channelProductQryDtoList)
              let arr = this.channelProductQryDtoList.filter(item=>item.productCode == val)
              if(arr[0]){
                channelConfigProductVoList.push({
                  productCode: val,
                  id:arr[0].id
                })
              } else {
                channelConfigProductVoList.push({
                  productCode: val
                })
              }
            }
          })
          if (this.form.id != undefined) {
            channel.updateChannel({...this.form, channelConfigProductVoList}).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.$parent.getList();
            });
          } else {
            channel.addChannel({...this.form, channelConfigProductVoList}).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.$parent.getList();
            });
          }
        }
      });
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.cities = []
      this.resetForm("form");
    },
  }
}
</script>

<style>
  .title{
    font-size: 15px;
    color: #1890ff;
  }
  .el-table tr .heade-cell{
    color: #333;
    background-color:#eff3f8;
  }
</style>
<style scoped lang="scss">
.dialog-bar{
  position: relative;
  .icon-full{
    position: absolute;
    right: 30px;
    font-size: 12px;
    top: 2px;
    cursor: pointer;
  }
}
.form{
  overflow-x: hidden;
  overflow-y: scroll;
}
.form::-webkit-scrollbar{
  display: none;
}
.upload-demo{
  display: flex;
  align-items: center;
  justify-content: flex-start;
}
.date-select{
  /*display: flex;*/
  align-items: center;
  justify-content: flex-start;
}
</style>
