<template>
  <!-- 添加或修改参数配置对话框 -->
  <el-dialog :title="title" :visible.sync="open" width="600px" append-to-body
             :close-on-press-escape="false"
             :close-on-click-modal="false"
             :fullscreen="isFullscreen"
  >
    <template slot="title">
      <div class="dialog-bar">
        <span>{{title}}</span>
        <el-tooltip content="全屏 / 窗口" effect="dark" placement="bottom">
          <svg-icon @click="onScale" class="icon-full" :icon-class="isFullscreen?'exit-fullscreen':'fullscreen'" />
        </el-tooltip>
      </div>
    </template>
    <el-form ref="form" :model="form" :rules="rules" label-width="80px" class="form" :disabled="formDis">
      <el-row :gutter="24">
        <el-col :span="isFullscreen ? 8 : 24">
          <el-form-item label-width="110px" label="一级产品名称" prop="parentProductCode">
            <el-select style="width: 440px" :disabled="type=='update'" v-model="form.parentProductName" @change="onChange" placeholder="一级产品名称" clearable>
              <el-option
                v-for="dict in dict.type.parent_product_code"
                :key="dict.value"
                :label="dict.label"
                :value="dict"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 24">
          <el-form-item label-width="110px" label="一级产品编号" prop="parentProductCode">
            <el-input style="width: 440px" disabled v-model="form.parentProductCode" placeholder="请输入一级产品编号" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 24">
          <el-form-item label-width="110px" label="二级产品名称" prop="productName">
            <el-input style="width: 440px" v-model="form.productName" placeholder="请输入二级产品名称" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 24">
          <el-form-item label-width="110px" label="二级产品编号" prop="productCode">
            <el-input style="width: 440px" :disabled="type=='update'"  maxlength="4" v-model="form.productCode" placeholder="请输入二级产品编号" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 24" v-if="type!='add'">
          <el-form-item label-width="110px" label="状态" prop="productStatus">
            <el-select style="width: 440px" v-model="form.productStatus" placeholder="状态" clearable>
              <el-option
                v-for="dict in dict.type.pro_common_status"
                :key="dict.value"
                :label="dict.label"
                :value="dict.value"
              />
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="24">
        <el-col :span="24">
          <span class="title">业务类型</span>
        </el-col>
        <el-divider></el-divider>
        <el-col :span="24" style="margin-bottom: 10px">
          <el-button size="small" type="primary" plain icon="el-icon-plus" @click="toAdd('tableData')">增加</el-button>
          <el-tooltip class="item" effect="light" content="至少选择一条记录" placement="right">
            <el-button size="small" type="danger" icon="el-icon-minus" @click="toDelete('tableData')" plain>删除</el-button>
          </el-tooltip>
        </el-col>
        <el-col :span="24" :border="false">
          <el-table
            :data="tableData"
            height="280px"
            :header-row-style="headerStyle"
            row-key="sort"
            header-cell-class-name="header-cell"
            @selection-change="handleSelectionChange"
            style="width: 100%">
            <el-table-column
              type="selection"
              width="55"/>
            <el-table-column
              label="序号"
              prop="sort"
              width="100"
            />
            <el-table-column
              label="交易编码"
              width="150"
              prop="tradeCode"
            >
              <template slot-scope="scope">
                <el-select style="width: 100%" @change="onChangeCode($event,scope)" v-model="scope.row.tradeCode" placeholder="交易编码" clearable>
                  <el-option
                    v-for="dict in dict.type.trad_code"
                    :key="dict.value"
                    :label="dict.value"
                    :value="dict"
                  />
                </el-select>
              </template>
            </el-table-column>
            <el-table-column
              label="交易附言"
              prop="tradeRemark"
            >
              <template slot-scope="scope">
                <el-input type="textarea"
                          disabled
                          :autosize="{ minRows: 2, maxRows: 2 }"
                          v-model="scope.row.tradeRemark"/>
              </template>
            </el-table-column>
          </el-table>
        </el-col>
      </el-row>
    </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button v-if="type!='view'" type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
  </el-dialog>
</template>

<script>
import { product } from "@/api/merchant/infactor";
import {regProductCode} from '@/utils/validate'
export default {
  dicts: ['pro_common_status','trad_code','parent_product_code','parent_product_code'],
  data(){
    return{
      //可确定
      type:'view',
      // 一级  二级产品
      parentProductCodes: [],
      // form disbale
      formDis:false,
      // dialog全屏
      isFullscreen:false,
      // tabs的显示id
      activeName: 'first',
      // 弹出层标题
      title: "添加",
      // 是否显示弹出层
      open: false,
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        parentProductCode: [
          { required: true, message: "一级产品编号不能为空", trigger: "change" }
        ],
        parentProductName: [
          { required: true, message: "一级产品名称不能为空", trigger: "change" }
        ],
        productCode: [
          { required: true, message: "二级产品编号不能为空", trigger: "change" },
          regProductCode
        ],
        productName: [
          { required: true, message: "二级产品名称不能为空", trigger: "change" }
        ],
      },
      // 表格集合
      tableData:[],
      // 表格集合
      headerStyle:{
        color:"#123456"
      },
      multipleSelection:[],
      clearTree:[]
    }
  },
  created() {
    this.getParentCodes()
  },
  methods:{
    /*获取一级产品枚举*/
    getParentCodes(){
      product.getParentCodesAction({type:1}).then(response => {
        this.parentProductCodes = response.data;
      })
    },
    /*切换一级*/
    onChange(val){
      this.form.parentProductCode = val.value
      this.form.parentProductName = val.label
    },
    /*切换一级*/
    onChangeCode(val,row){
      this.tableData[row.$index].tradeCode = val.value
      this.tableData[row.$index].tradeRemark =  val.label
      // this.form.parentProductCode = val.value
    },
    onScale(){
      this.isFullscreen = !this.isFullscreen
    },
    // 增加记录
    toAdd(tableName){
      if(tableName == 'tableData'){
        this[tableName].push({
          sort:this[tableName].length+1,
          tradeCode:"",
          tradeRemark:"",
        })
      }
    },
    // 删除记录
    toDelete(tableName){
      if(this.clearTree.length==0){
        this.$message({
          message: '至少选择一条记录',
          type: 'warning'
        });
        return false
      }
      var arr = this[tableName].filter(item=>!this.clearTree.some(val=>item.sort == val))
      this[tableName] = arr.map((val,index)=>{
        return {
          ...val,
          sort: index + 1
        }
      })
    },
    handleSelectionChange(val){
      this.clearTree = val.map(item=>{
        return item.sort
      })
      console.log(this.clearTree)
    },
    add(){
      this.open = true;
      this.type = 'add';
      this.title = "添加";
      this.formDis = false;
      this.reset();
    },
    /** 查看按钮操作 */
    checkData(json) {
      let row = JSON.parse(JSON.stringify(json))
      this.open = true;
      this.type = 'view';
      this.formDis = true;
      this.title = "查看";
      this.reset();
      this.$nextTick(()=>{
        this.form = {
          id:row.id,
          parentProductCode:row.parentProductCode,
          parentProductName:row.parentProductName,
          productCode:row.productCode,
          productName:row.productName,
          productStatus:row.productStatus,
        };
        this.tableData = row.productBusinessQryDto.map((val,index)=>{
          return {
            ...val,
            sort:index+1
          }
        }) || []
      })
    },
    /** 修改按钮操作 */
    update(json) {
      let row = JSON.parse(JSON.stringify(json))
      this.type = 'update';
      this.open = true;
      this.formDis = false;
      this.title = "修改";
      this.reset();
      this.$nextTick(()=>{
        this.form = {
          id:row.id,
          parentProductCode:row.parentProductCode,
          parentProductName:row.parentProductName,
          productCode:row.productCode,
          productName:row.productName,
          productStatus:row.productStatus,
        };
        this.tableData = row.productBusinessQryDto.map((val,index)=>{
          return {
            ...val,
            sort:index+1
          }
        }) || []
      })
    },
    /** 提交按钮 */
    submitForm: function() {
      console.log(this.form)
      if(this.tableData.length==0){
        // this.$message({type:"error",message:"请增加业务类型"})
        // return false
      }
      let arr = JSON.parse(JSON.stringify(this.tableData))
      arr.forEach(val=>{
        delete val['sort']
      })
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.id != undefined) {
            product.updatePro({...this.form,productBusinessVoList: arr}).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.$parent.getList();
            });
          } else {
            product.addPro({...this.form,productBusinessVoList: arr}).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.$parent.getList();
            });
          }
        }
      });
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        parentProductCode:'',
        parentProductName:'',
        productCode:'',
        productName:'',
        productStatus:'',
      }
      this.tableData = []
      this.resetForm("form");
    },
  }
}
</script>

<style>
  .title{
    font-size: 15px;
    color: #1890ff;
  }
  .el-table tr .heade-cell{
    color: #333;
    background-color:#eff3f8;
  }
</style>
<style scoped lang="scss">
.dialog-bar{
  position: relative;
  .icon-full{
    position: absolute;
    right: 30px;
    font-size: 12px;
    top: 2px;
    cursor: pointer;
  }
}
.form{
  overflow-x: hidden;
  overflow-y: scroll;
}
.form::-webkit-scrollbar{
  display: none;
}
.upload-demo{
  display: flex;
  align-items: center;
  justify-content: flex-start;
}
.date-select{
  /*display: flex;*/
  align-items: center;
  justify-content: flex-start;
}
</style>
