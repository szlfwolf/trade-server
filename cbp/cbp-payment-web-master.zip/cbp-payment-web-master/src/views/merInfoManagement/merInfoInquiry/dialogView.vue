<template>
  <!-- 添加或修改参数配置对话框 -->
  <el-dialog :title="title" :visible.sync="open" width="1100px" append-to-body
             :close-on-press-escape="false"
             :close-on-click-modal="false"
             :fullscreen="isFullscreen"
  >

    <template slot="title">
      <div class="dialog-bar">
        <span>{{title}}</span>
        <el-tooltip content="全屏 / 窗口" effect="dark" placement="bottom">
          <svg-icon @click="onScale" class="icon-full" :icon-class="isFullscreen?'exit-fullscreen':'fullscreen'" />
        </el-tooltip>
      </div>
    </template>
    <el-form ref="form" :model="form" :rules="rules" label-width="110px" class="form" :disabled="formDis">
      <el-tabs v-model="activeName" type="card">
        <el-tab-pane label="企业信息" name="first">
          <el-row :gutter="24">
<!--            <el-col :span="24">-->
<!--              <span class="title">企业信息</span>-->
<!--            </el-col>-->
<!--            <el-divider></el-divider>-->
            <el-col :span="isFullscreen ? 8 : 12" v-if="type!='add'">
              <el-form-item label="商户号" prop="merchantNo">
                <el-input disabled v-model="form.merchantNo" placeholder="请输入商户号" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item label="商户名称" prop="merchantName">
                <el-input v-model="form.merchantName" placeholder="请输入商户名称" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item label="营业地址" prop="businessAddress">
                <el-input v-model="form.businessAddress" placeholder="请输入营业地址" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item label="注册地址" prop="registerAddress">
                <el-input v-model="form.registerAddress" placeholder="请输入注册地址" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item label-width="110px" label="注册资本币种" prop="registerCapitalCurrency">
                <el-select style="width: 100%" filterable  v-model="form.registerCapitalCurrency" placeholder="注册资本币种" clearable>
                  <el-option
                    v-for="dict in dict.type.merch_currency_type"
                    :key="dict.value"
                    :label="dict.label"
                    :value="dict.value"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item label="注册资本" prop="registerCapital">
                <el-input v-model="form.registerCapital" placeholder="请输入注册资本" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item label="国家地区" prop="sourceCountry">
                <el-select filterable style="width: 100%" v-model="form.sourceCountry" placeholder="国家地区" clearable>
                  <el-option
                    v-for="dict in dict.type.source_country"
                    :key="dict.value"
                    :label="dict.label"
                    :value="dict.value"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item label="办公电话" prop="officePhone">
                <el-input v-model="form.officePhone" placeholder="请输入办公电话" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item label="还原模式" prop="recovertMode">
                <el-select style="width: 100%" v-model="form.recovertMode" placeholder="还原模式" clearable>
                  <el-option
                    v-for="dict in dict.type.recovert_mode"
                    :key="dict.value"
                    :label="dict.label"
                    :value="dict.value"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item label="通道名称" prop="channelNo">
               <!-- <el-select style="width:100%" v-model="form.channelNo" placeholder="请选择" clearable>
                  <el-option
                    v-for="dict in channelMenu"
                    :key="dict.channelCode"
                    :label="dict.channelName"
                    :value="dict.channelCode"
                  />
                </el-select>-->
                <el-select
                  clearable
                  v-model="form.channelNo"
                  placeholder="选择"
                  style="width: 100%"
                  remote
                  :remote-method="remoteMethod2"
                  @change="selectChannel"
                  @focus="onFocus"
                  filterable
                  :loading="xlloading"
                  v-loadmore="loadmore"
                >
                  <el-option
                    v-for="(item, index) in departmentList"
                    :key="index"
                    :label="item.channelName"
                    :value="item.channelCode"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item label-width="110px" label="到账通知地址" prop="notifyAddress">
                <el-input v-model="form.notifyAddress" placeholder="请输入到账通知地址" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item label="风险等级" prop="riskGrade">
                <el-select style="width: 100%" v-model="form.riskGrade" placeholder="风险等级" clearable>
                  <el-option
                    v-for="dict in dict.type.risk_grade"
                    :key="dict.value"
                    :label="dict.label"
                    :value="dict.value"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12" v-if="type!='add'">
              <el-form-item label="状态" prop="merchantStatus">
                <el-select style="width: 100%" v-model="form.merchantStatus" placeholder="状态" clearable>
                  <el-option
                    v-for="dict in dict.type.merchant_status"
                    :key="dict.value"
                    :label="dict.label"
                    :value="dict.value"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item label="经营范围" prop="businessScope">
                <el-input
                  v-model="form.businessScope"
                  type="textarea"
                  :rows="2"
                  autosize
                  placeholder="请输入经营范围" />
              </el-form-item>
            </el-col>
            <!--<el-col :span="isFullscreen ? 8 : 12">
              <el-form-item label="公司注册登记号" prop="businessScope">
                <el-input
                  v-model="form.businessScope"
                  type="textarea"
                  :rows="2"
                  autosize
                  placeholder="请输入公司注册登记号" />
              </el-form-item>
            </el-col>-->
          </el-row >
        </el-tab-pane>
        <el-tab-pane label="合法经营材料信息" name="second">
          <el-row :gutter="24">
            <el-col :span="24" style="margin-bottom: 10px">
              <el-button size="small" type="primary" plain icon="el-icon-plus" @click="toAdd('merchantInfoManageVo')">增加</el-button>
              <el-button size="small" type="danger" icon="el-icon-minus" @click="toDelete('merchantInfoManageVo')" plain>删除</el-button>
            </el-col>
            <el-col :span="24">
              <el-table
                :data="form.merchantInfoManageVo"
                row-key="sort"
                :header-row-style="headerStyle"
                header-cell-class-name="heade-cell"
                @selection-change="handleSelectionChange"
                style="width: 100%">
                <el-table-column
                  type="selection"
                  width="55">
                </el-table-column>
                <el-table-column
                  label="序号"
                  prop="sort"
                  width="55"
                >
                </el-table-column>
                <el-table-column
                  label="证件名称"
                  prop="name"
                  width="200"
                >
                  <template slot-scope="scope">
                    <el-form-item
                      label-width="0px"
                      :prop="'merchantInfoManageVo.' + scope.$index + '.certificateName'"
                      :rules="rules.certificateName"
                      style="margin-bottom: 0px"
                    >
                      <el-input v-model="scope.row.certificateName"/>
                    </el-form-item>
                  </template>
                </el-table-column>
                <el-table-column
                  :show-overflow-tooltip="true"
                  label="证件影印件">
                  <template slot-scope="scope">
                    <el-form-item
                      label-width="0px"
                      :prop="'merchantInfoManageVo.' + scope.$index + '.certificatePhotoName'"
                      :rules="rules.certificatePhoto"
                      style="margin-bottom: 0px"
                    >
                      <el-upload
                        v-if="type!='view'  && type!='examine'"
                        class="upload-demo"
                        ref="upload1"
                        :on-error="oError"
                        :before-upload="beforeUpload"
                        :on-success="(response, file, fileList) => {onSuccess(response, file, fileList, scope.$index,'merchantInfoManageVo')}"
                        :action="uploadApi"
                        :headers="headers"
                        :limit="1"
                        :show-file-list="false">
                        <el-input
                          :title="scope.row.certificatePhotoName"
                          slot="trigger" style="width: 100%" readonly v-model="scope.row.certificatePhotoName"
                                  placeholder="选取文件"
                        ></el-input>
                      </el-upload>
                      <p
                        v-else
                        title="查看附件"
                        @click="toViewPhoto(scope.row.certificatePhoto,scope.row.certificatePhotoName)"
                        style="width: 100%;color: blue;cursor: pointer"
                      >{{scope.row.certificatePhotoName}}</p>
                    </el-form-item>
                  </template>
                </el-table-column>
                <el-table-column
                  width="300"
                  label="证件有效期">
                  <template slot-scope="scope">
                    <el-form-item
                      label-width="0px"
                      :prop="'merchantInfoManageVo.' + scope.$index + '.certificateValidity'"
                      :rules="rules.certificateValidity"
                      style="margin-bottom: 0px"
                    >
                      <div class="date-select">
                        <el-date-picker
                          style="width:150px"
                          v-model="scope.row.certificateValidity"
                          type="date"
                          :disabled="scope.row.certificateValidity == '长期'"
                          placeholder="选择日期">
                        </el-date-picker>
                        <el-checkbox
                          @change="changeBox($event,scope.$index,'merchantInfoManageVo')"
                          style="margin-left:10px" :checked="scope.row.certificateValidity == '长期'">长期</el-checkbox>
                      </div>
                    </el-form-item>
                  </template>
                </el-table-column>
              </el-table>
            </el-col>
          </el-row>
        </el-tab-pane>
        <el-tab-pane label="企业法人信息" name="third">
          <el-row :gutter="24" >
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item
                label-width="100px"
                label="姓名"
                :rules="rules.legalName"
                :prop="'merchantInfoLegalVo.legalName'"
                >
                <el-input v-model="form.merchantInfoLegalVo.legalName" placeholder="请输入姓名" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item
                :rules="rules.certificateType"
                :prop="'merchantInfoLegalVo.certificateType'"
                label-width="100px" label="证件类型" >
                <el-select style="width: 100%" v-model="form.merchantInfoLegalVo.certificateType" placeholder="证件类型" clearable>
                  <el-option
                    v-for="dict in dict.type.certificate_type2"
                    :key="dict.value"
                    :label="dict.label"
                    :value="dict.value"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item
                :rules="rules.certificateNo"
                :prop="'merchantInfoLegalVo.certificateNo'"
                label-width="100px" label="证件号">
                <el-input v-model="form.merchantInfoLegalVo.certificateNo" placeholder="请输入证件号" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item
                :rules="rules.certificateValidity"
                :prop="'merchantInfoLegalVo.certificateValidity'"
                label-width="100px" label="证件有效期">
                <div class="date-select">
                  <el-date-picker
                    style="width:250px"
                    v-model="form.merchantInfoLegalVo.certificateValidity"
                    type="date"
                    :disabled="form.merchantInfoLegalVo.certificateValidity == '长期'"
                    placeholder="选择日期">
                  </el-date-picker>
                  <el-checkbox
                    @change="changeBox($event,'NAN','merchantInfoLegalVo')"
                   style="margin-left:10px" :checked="form.merchantInfoLegalVo.certificateValidity== '长期'">长期</el-checkbox>
                </div>
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item
                :rules="rules.certificatePhoto"
                :prop="'merchantInfoLegalVo.certificatePhoto'"
                label-width="100px" label="证件影印件" style="margin-bottom: 0px">
                <el-upload
                  class="upload-demo"
                  ref="upload2"
                  v-if="type!='view' && type!='examine'"
                  style="width: 100%"
                  :on-error="oError"
                  :before-upload="beforeUpload"
                  :on-success="(response, file, fileList) => {onSuccess(response, file, fileList, 'NAN','merchantInfoLegalVo')}"
                  :action="uploadApi"
                  :headers="headers"
                  :limit="1"
                  :show-file-list="false">
                  <el-input :title="form.merchantInfoLegalVo.certificatePhotoName" slot="trigger" style="width: 100%" readonly
                            v-model="form.merchantInfoLegalVo.certificatePhotoName"
                            placeholder="选取文件"
                  ></el-input>
                </el-upload>
                <p
                  v-else
                  title="查看附件"
                  @click="toViewPhoto(form.merchantInfoLegalVo.certificatePhoto,form.merchantInfoLegalVo.certificatePhotoName)"
                  style="width: 100%;color: blue;cursor: pointer"
                >{{form.merchantInfoLegalVo.certificatePhotoName}}</p>
              </el-form-item>
            </el-col>
          </el-row >
        </el-tab-pane>
        <el-tab-pane label="收益人信息" name="fourth">
          <el-row :gutter="24">
            <el-col :span="24" style="margin-bottom: 10px">
              <el-button size="small" type="primary" plain icon="el-icon-plus" @click="toAdd('merchantInfoBeneficiaryVo')">增加</el-button>
              <el-button size="small" type="danger" icon="el-icon-minus" @click="toDelete('merchantInfoBeneficiaryVo')" plain>删除</el-button>
            </el-col>
            <el-col :span="24">
              <el-table
                :data="form.merchantInfoBeneficiaryVo"
                row-key="sort"
                height="50vh"
                :header-row-style="headerStyle"
                header-cell-class-name="heade-cell"
                @selection-change="handleSelectionChange"
                style="width: 100%">
                <el-table-column
                  type="selection"
                  fixed="left"
                  width="45">
                </el-table-column>
                <el-table-column
                  label="序号"
                  fixed="left"
                  prop="sort"
                  width="55"
                >
                </el-table-column>
                <el-table-column
                  label="姓名"
                  prop="name"
                  width="100"
                >
                  <template slot-scope="scope">
                    <el-form-item
                      style="margin-bottom:0px"
                      :rules="rules.beneficiaryName"
                      :prop="'merchantInfoBeneficiaryVo.'+scope.$index+'.beneficiaryName'"
                      label-width="0px">
                      <el-input v-model="scope.row.beneficiaryName"/>
                    </el-form-item>
                  </template>
                </el-table-column>
                <el-table-column
                  :show-overflow-tooltip="true"
                  width="185"
                  label="证件影印件">
                  <template slot-scope="scope">
                    <el-form-item
                      :rules="rules.certificatePhoto"
                      :prop="'merchantInfoBeneficiaryVo.'+scope.$index+'.certificatePhoto'"
                      style="overflow:hidden;margin-bottom: 0px"
                      label-width="0px" label="">
                      <el-upload
                        class="upload-demo"
                        ref="upload3"
                        v-if="type!='view' && type!='examine'"
                        :on-error="oError"
                        :before-upload="beforeUpload"
                        :on-success="(response, file, fileList) => {onSuccess(response, file, fileList, scope.$index,'merchantInfoBeneficiaryVo')}"
                        :action="uploadApi"
                        :headers="headers"
                        :limit="1"
                        :show-file-list="false">
                        <el-input :title="scope.row.certificatePhotoName" slot="trigger" style="width: 100%" readonly
                                  v-model="scope.row.certificatePhotoName"
                                  placeholder="选取文件"
                        ></el-input>
                      </el-upload>
                      <p
                        v-else
                        title="查看附件"
                        @click="toViewPhoto(scope.row.certificatePhoto,scope.row.certificatePhotoName)"
                        style="width: 100%;color: blue;cursor: pointer"
                      >{{scope.row.certificatePhotoName}}</p>
                    </el-form-item>
                  </template>
                </el-table-column>
                <el-table-column
                  label="证件影有效期"
                  width="160px"
                >
                  <template slot-scope="scope">
                    <el-form-item
                      style="margin-bottom: 0px"
                      :rules="rules.certificateValidity"
                      :prop="'merchantInfoBeneficiaryVo.'+scope.$index+'.certificateValidity'"
                      label-width="0px" label="" >
                      <div class="date-select">
                        <el-date-picker
                          style="width: 100%"
                          v-model="scope.row.certificateValidity"
                          type="date"
                          :disabled="scope.row.certificateValidity == '长期'"
                          placeholder="选择日期">
                        </el-date-picker>
                        <el-checkbox
                          @change="changeBox($event,scope.$index,'merchantInfoBeneficiaryVo')"
                          style="margin-left:10px" :checked="scope.row.certificateValidity== '长期'">长期</el-checkbox>
                      </div>
                    </el-form-item>
                  </template>
                </el-table-column>
                <el-table-column
                  label="证件类型"
                  prop="name"
                  width="100"
                >
                  <template slot-scope="scope">
                    <el-form-item
                      style="margin-bottom:0px"
                      :rules="rules.certificateType"
                      :prop="'merchantInfoBeneficiaryVo.'+scope.$index+'.certificateType'"
                      label-width="0px">
                      <el-select style="width: 100%" v-model="scope.row.certificateType" placeholder="证件类型" clearable>
                        <el-option
                          v-for="dict in dict.type.certificate_type2"
                          :key="dict.value"
                          :label="dict.label"
                          :value="dict.value"
                        />
                      </el-select>
                    </el-form-item>
                  </template>
                </el-table-column>
                <el-table-column
                  label="证件号"
                  prop="name"
                  width="180"
                >
                  <template slot-scope="scope">
                    <el-form-item
                      style="margin-bottom:0px"
                      :rules="rules.certificateNo"
                      :prop="'merchantInfoBeneficiaryVo.'+scope.$index+'.certificateNo'"
                      label-width="0px">
                      <el-input v-model="scope.row.certificateNo"/>
                    </el-form-item>
                  </template>
                </el-table-column>

                <el-table-column
                  label="股份占比（%）"
                  prop="name"
                  width="110"
                >
                  <template slot-scope="scope">
                    <el-form-item
                      style="margin-bottom:0px"
                      :rules="rules.shareProportion"
                      :prop="'merchantInfoBeneficiaryVo.'+scope.$index+'.shareProportion'"
                      label-width="0px">
                      <el-input v-model="scope.row.shareProportion"/>
                    </el-form-item>
                  </template>
                </el-table-column>
                <el-table-column
                  label="联系地址"
                  prop="name"
                  width="200"
                >
                  <template slot-scope="scope">
                    <el-form-item
                      style="margin-bottom:0px"
                      :rules="rules.contactsAddress"
                      :prop="'merchantInfoBeneficiaryVo.'+scope.$index+'.contactsAddress'"
                      label-width="0px">
                      <el-input type="textarea" autosize v-model="scope.row.contactsAddress"/>
                    </el-form-item>
                  </template>
                </el-table-column>
              </el-table>
            </el-col>
          </el-row>
        </el-tab-pane>
        <el-tab-pane label="联系人信息" name="fifth">
          <el-row :gutter="24">
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item
                :rules="rules.contactsName"
                :prop="'merchantInfoContactsVo.contactsName'"
                label="姓名">
                <el-input v-model="form.merchantInfoContactsVo.contactsName" placeholder="请输入姓名" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item
                :rules="rules.certificateType"
                :prop="'merchantInfoContactsVo.certificateType'"
                label="证件类型">
                <el-select style="width: 100%" v-model="form.merchantInfoContactsVo.certificateType" placeholder="证件类型" clearable>
                  <el-option
                    v-for="dict in dict.type.certificate_type2"
                    :key="dict.value"
                    :label="dict.label"
                    :value="dict.value"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item
                :rules="rules.certificateNo"
                :prop="'merchantInfoContactsVo.certificateNo'"
                label="证件号">
                <el-input v-model="form.merchantInfoContactsVo.certificateNo" placeholder="请输入证件号" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item
                :rules="rules.certificatePhoto"
                style="overflow:hidden;"
                :prop="'merchantInfoContactsVo.certificatePhoto'"
                label="证件影印件" label-width="110px">
                <el-upload
                  class="avatar-uploader"
                  ref="upload4"
                  v-if="type!='view' && type!='examine'"
                  :on-error="oError"
                  :before-upload="beforeUpload"
                  :on-success="(response, file, fileList) => {onSuccess(response, file, fileList, 'NAN','merchantInfoContactsVo')}"
                  :action="uploadApi"
                  :headers="headers"
                  :limit="1"
                  :show-file-list="false">
                  <el-input
                    :title="form.merchantInfoContactsVo.certificatePhotoName"
                    slot="trigger" style="width: 100%" readonly v-model="form.merchantInfoContactsVo.certificatePhotoName"
                            placeholder="选取文件"
                  ></el-input>
                </el-upload>
                <p
                  v-else
                  title="查看附件"
                  @click="toViewPhoto(form.merchantInfoContactsVo.certificatePhoto,form.merchantInfoContactsVo.certificatePhotoName)"
                  style="width: 100%;color: blue;cursor: pointer"
                >
                  {{form.merchantInfoContactsVo.certificatePhotoName}}
                </p>
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item
                :rules="rules.contactsDuty"
                :prop="'merchantInfoContactsVo.contactsDuty'"
                label="职务">
                <el-input v-model="form.merchantInfoContactsVo.contactsDuty" placeholder="请输入职务" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item
                :rules="rules.phoneNumber"
                :prop="'merchantInfoContactsVo.phoneNumber'"
                label="电话">
                <el-input v-model="form.merchantInfoContactsVo.phoneNumber" placeholder="请输入电话" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item
                :rules="rules.email"
                :prop="'merchantInfoContactsVo.email'"
                label="邮件">
                <el-input v-model="form.merchantInfoContactsVo.email" placeholder="请输入邮件" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item
                :rules="rules.facsimile"
                :prop="'merchantInfoContactsVo.facsimile'"
                label="传真">
                <el-input v-model="form.merchantInfoContactsVo.facsimile" placeholder="请输入传真" />
              </el-form-item>
            </el-col>
          </el-row >
        </el-tab-pane>
      </el-tabs>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button v-if="type=='examine'" type="danger" @click="onReject">审核拒绝</el-button>
      <el-button v-if="type=='examine'" type="primary" @click="onPass">审核通过</el-button>
      <el-button type="primary" v-if="type!='view' && type!='examine'" @click="submitForm">确 定</el-button>
      <el-button @click="cancel">取 消</el-button>
    </div>
    <el-dialog
      width="40%"
      title="预览"
      style="text-align: center"
      :visible.sync="innerVisible"
      append-to-body>
      <el-image @error="onError" :src="imgUrl" lazy></el-image>
    </el-dialog>
  </el-dialog>
</template>

<script>
import { merInfo, uploadApi, channel, headers, downPhoto } from '@/api/merchant/infactor'
import {downloadPhoto} from '@/utils/request'
import {idReg, regPhone, rateReg, regMoney} from '@/utils/validate'
import dayjs from 'dayjs'
import { Loading } from 'element-ui'
import { mixinsAction } from '@/utils/actionMinxis'
export default {
  dicts:["merch_currency_type","source_country",'certificate_type2','risk_grade','recovert_mode','merchant_status'],
  mixins:[mixinsAction],
  data(){
    return{
      downloadLoadingInstance:null,
      merSize:10,
      merNum:1,
      merTotal:1,
      uploadApi:uploadApi,
      headers:headers,
      channelMenu:[],
      departmentList:[],
      // dialog全屏
      isFullscreen:false,
      xlloading:false,
      formDis:false,
      innerVisible:false,
      // tabs的显示id
      activeName: 'first',
      // 弹出层标题
      title: "添加",
      // 是否显示弹出层
      open: false,
      // 表单参数
      form: {
        // 合法经营
        merchantInfoManageVo:[
          {
            sort:1,
            certificateValidity: '',
            certificateName: '',
            certificatePhotoName: '',
            certificatePhoto:""
          }
        ],
        //法人
        merchantInfoLegalVo:{
          certificateNo:"",
          certificatePhoto:"",
          certificatePhotoName:"",
          certificateType:"",
          certificateValidity:"",
          legalName:"",
        },
        // 收益人
        merchantInfoBeneficiaryVo:[
          {
            sort:1,
            beneficiaryName: '',
            certificateNo: '',
            certificatePhoto:"",
            certificatePhotoName:"",
            certificateType: '',
            contactsAddress: '',
            shareProportion: '',
            certificateValidity: '',
          }
        ],
        // 联系人
        merchantInfoContactsVo:{
          email:"",
          facsimile:"",
          certificateNo:"",
          certificateType:"",
          contactsDuty:"",
          contactsName: '',
          certificatePhoto:"",
          certificatePhotoName:"",
          phoneNumber:""
        },

      },
      type:'add',
      // 表单校验
      rules: {
        channelNo: [
          { required: true, message: "不能为空", trigger: "change" }
        ],
        contactsName: [
          { required: true, message: "不能为空", trigger: "change" }
        ],
        merchantNo: [
          { required: true, message: "不能为空", trigger: "change" }
        ],
        merchantName: [
          { required: true, message: "不能为空", trigger: "change" }
        ],
        businessAddress: [
          { required: true, message: "不能为空", trigger: "change" }
        ],
        registerAddress: [
          { required: true, message: "不能为空", trigger: "change" }
        ],
        sourceCountry: [
          { required: true, message: "不能为空", trigger: "change" }
        ],
        recovertMode: [
          { required: true, message: "不能为空", trigger: "change" }
        ],
        riskGrade: [
          { required: true, message: "不能为空", trigger: "change" }
        ],
        businessScope: [
          { required: true, message: "不能为空", trigger: "change" }
        ],
        certificateName: [
          { required: true, message: "不能为空", trigger: "change" }
        ],
        certificatePhoto: [
          { required: true, message: "不能为空", trigger: "change" }
        ],
        legalName: [
          { required: true, message: "不能为空", trigger: "change" }
        ],
        certificateNo: [
          { required: true, message: "不能为空", trigger: "change" },
          idReg
        ],
        certificateType: [
          { required: true, message: "不能为空", trigger: "change" }
        ],
        certificateValidity: [
          { required: true, message: "不能为空", trigger: "change" }
        ],
        contactsAddress: [
          { required: true, message: "不能为空", trigger: "change" }
        ],
        shareProportion: [
          { required: true, message: "不能为空", trigger: "change" },
          rateReg
        ],
        beneficiaryName: [
          { required: true, message: "不能为空", trigger: "change" }
        ],
        registerCapital: [
          { required: false, message: "不能为空", trigger: "change" },
          regMoney
        ],
      },
      // 表格集合
      headerStyle:{
        color:"#123456"
      },
      multipleSelection:[],
      clearTree:[],
      imgUrl:""
    }
  },
  watch:{
    "form":{
      handler(n,o){
        // console.log(this.form)
      },
      deep:true
    }
  },
  created() {
  },
  methods:{
    // remoteMethod
    remoteMethod2(query) {
      this.departmentList = []
      if (query !== '') {
        this.xlloading = true;
        this.merNum = 1
        this.getMerchantList2(query);
      } else {
        this.getMerchantList2();
      }
    },
    onFocus(){
      if (!this.form.channelNo) {
        this.xlloading = true;
        this.merNum = 1
        this.departmentList = []
        this.getMerchantList2();
      }
    },
    getMerchantList2(query){
      let params = {
        pageNum: this.merNum,
        pageSize: this.merSize,
        channelStatus:'1'
      }
      channel.getChannelMenu(params).then(res=>{
        this.departmentList = [...this.departmentList,...res.data]
        this.merTotal = Math.ceil(res.total / this.merSize)
      }).catch(e=>{
      }).finally(e=>{
        this.xlloading = false;
      });
    },
    //滑动触底的相关操作
    loadmore(){
      if(this.merNum<this.merTotal){
        this.merNum+=1
        this.getMerchantList2()
      }
      console.log(this.merNum,this.merTotal);

      //数据页面更新，数据请求操作
    },
    selectChannel(){
      console.log('我滑动加载了');
      //数据页面更新，数据请求操作
    },
    onError(e){
      let url = this.imgUrl
      window.open(url)
      this.imgUrl = ""
    },
    // 长期
    changeBox(val,index,name){
      if(val){
        if(index=="NAN"){
          this.form[name].certificateValidity = '长期'
        } else {
          this.form[name][index].certificateValidity = '长期'
        }
      } else {
        if(index=="NAN"){
          this.form[name].certificateValidity = ''
        }else {
          this.form[name][index].certificateValidity = ''
        }
      }
      console.log(val)
    },
    beforeUpload(file, fileList){
      this.downloadLoadingInstance = Loading.service({ text: "正在上传数据，请稍候", spinner: "el-icon-loading", background: "rgba(0, 0, 0, 0.7)", })
    },
    oError(error, file, fileList, index, name, refName){
      console.log(error)
      this.downloadLoadingInstance.close()
      this.$message.error("文件上传失败")
    },
    onSuccess(response, file, fileList, index, name, refName){
      this.downloadLoadingInstance.close()
      if(index!='NAN'){
        this.form[name][index].certificatePhoto = response.data
        this.form[name][index].certificatePhotoName = fileList[0].name
      } else {
        this.form[name].certificatePhoto = response.data
        this.form[name].certificatePhotoName= fileList[0].name
      }
      this.$refs['upload1'].clearFiles()
      this.$refs['upload2'].clearFiles()
      this.$refs['upload3'].clearFiles()
      this.$refs['upload4'].clearFiles()
      console.log(this.$refs['upload'])
    },
    // 文件
    onChange(file, fileList,index,name,refName){

    },
    onScale(){
      this.isFullscreen = !this.isFullscreen
    },
    // 增加记录
    toAdd(tableName){
      if(tableName == 'merchantInfoManageVo'){
        this.form[tableName].push({
          sort:this.form[tableName].length+1,
          certificateValidity: '',
          certificatePhotoName: '',
          certificateName: '',
          certificatePhoto:""
        })
      }
      if(tableName == 'merchantInfoBeneficiaryVo'){
        this.form[tableName].push({
          sort:this.form[tableName].length+1,
          beneficiaryName: '',
          certificateNo: '',
          certificatePhoto:"",
          certificatePhotoName:"",
          certificateType: '',
          contactsAddress: '',
          shareProportion: '',
          certificateValidity: '',
        })
      }
    },
    // 删除记录
    toDelete(tableName){
      if(this.clearTree.length==0){
        this.$message({
          message: '至少选择一条记录才可删除',
          type: 'warning'
        });
        return false
      }
      if(this.form[tableName].length==1){
        this.$message({
          message: '不可删除，至少填写一条记录',
          type: 'error'
        });
        return false
      }
      var arr = this.form[tableName].filter(item=>!this.clearTree.some(val=>item.sort == val))
      this.form[tableName] = arr.map((val,index)=>{
        return {
          ...val,
          sort: index+1
        }
      })
    },
    handleSelectionChange(val){
      this.clearTree = val.map(item=>{
        return item.sort
      })
      console.log(this.clearTree)
    },
    add(){
      this.open = true;
      this.activeName = 'first'
      this.formDis = false;
      this.title = "添加";
      this.type = "add";
      this.reset();
      this.$nextTick(()=>{
        // 合法经营
        this.form.merchantInfoManageVo = [
          {
            sort:1,
            certificatePhotoName: '',
            certificateValidity: '',
            certificateName: '',
            certificatePhoto:""
          }
        ],
        //法人
        this.form.merchantInfoLegalVo = {
          certificateNo:"",
          certificatePhoto:"",
          certificateType:"",
          certificatePhotoName: '',
          certificateValidity:"",
          legalName:"",
        },
        // 收益人
        this.form.merchantInfoBeneficiaryVo = [
          {
            sort:1,
            beneficiaryName: '',
            certificateNo: '',
            certificatePhoto:"",
            certificatePhotoName: '',
            certificateType: '',
            contactsAddress: '',
            shareProportion: '',
            certificateValidity: '',
          }
        ],
        // 联系人
        this.form.merchantInfoContactsVo = {
            email:"",
            facsimile:"",
            certificateNo:"",
            certificateType:"",
            contactsDuty:"",
            contactsName: '',
            certificatePhotoName: '',
            certificatePhoto:"",
            phoneNumber:""
          }
        // this.$set(this.form,'riskGrade',null)
        this.$set(this.form,'registerCapitalCurrency',"CNY")
        this.$set(this.form,'sourceCountry',"CHN")
        delete this.form['merchantInfoId']
        delete this.form['operationStatus']
        delete this.form['uptBy']
        delete this.form['uptTime']
        delete this.form['verifierUser']
      })
    },
    /** 查看按钮操作 */
    check(row) {
      this.open = true;
      this.formDis = true;
      this.type = "view";
      this.reset();
      this.activeName = 'first'
      this.$nextTick(()=>{
        this.form = {
          ...row,
          merchantInfoBeneficiaryVo: row.merchantInfoBeneficiaryDto,
          merchantInfoContactsVo: row.merchantInfoContactsDto,
          merchantInfoLegalVo: row.merchantInfoLegalDto,
          merchantInfoManageVo: row.merchantInfoManageDto,
        }
        delete this.form['merchantInfoBeneficiaryDto']
        delete this.form['merchantInfoContactsDto']
        delete this.form['merchantInfoLegalDto']
        delete this.form['merchantInfoManageDto']
      })
    },
    /** 查看按钮操作 */
    examine(row) {
      this.open = true;
      this.formDis = true;
      this.type = "examine";
      this.reset();
      this.$nextTick(()=>{
        this.activeName = 'first'
        this.form = {
          ...row,
          merchantInfoBeneficiaryVo: row.merchantInfoBeneficiaryDto,
          merchantInfoContactsVo: row.merchantInfoContactsDto,
          merchantInfoLegalVo: row.merchantInfoLegalDto,
          merchantInfoManageVo: row.merchantInfoManageDto,
        }
        delete this.form['merchantInfoBeneficiaryDto']
        delete this.form['merchantInfoContactsDto']
        delete this.form['merchantInfoLegalDto']
        delete this.form['merchantInfoManageDto']
      })
    },
    /** 修改按钮操作 */
    update(row) {
      this.open = true;
      this.formDis = false;
      this.type = "edit";
      this.activeName = 'first'
      this.reset();
      this.form = {
        ...row,
        merchantInfoBeneficiaryVo: row.merchantInfoBeneficiaryDto,
        merchantInfoContactsVo: row.merchantInfoContactsDto,
        merchantInfoLegalVo: row.merchantInfoLegalDto,
        merchantInfoManageVo: row.merchantInfoManageDto,
      }
      delete this.form['merchantInfoBeneficiaryDto']
      delete this.form['merchantInfoContactsDto']
      delete this.form['merchantInfoLegalDto']
      delete this.form['merchantInfoManageDto']
    },
    // 拒绝
    onReject(){
      this.$confirm('是否继续此操作?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'error'
      }).then(() => {
        merInfo.examineMerInfo({
          merchantInfoId:this.form.merchantInfoId,
          merchantNo:this.form.merchantNo,
          merchantStatus:this.form.merchantStatus,
          operationStatus: '2',
        }).then(res=>{
          this.$modal.msgSuccess("审核拒绝成功");
          this.open = false;
          this.$parent.getList();
        })
      }).catch(() => {

      });
    },
    // 审核
    onPass(){
      this.$confirm('是否继续此操作?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'success'
      }).then(() => {
        merInfo.examineMerInfo({
          merchantInfoId:this.form.merchantInfoId,
          merchantNo:this.form.merchantNo,
          merchantStatus:this.form.merchantStatus,
          operationStatus: '3',
        }).then(res=>{
          this.$modal.msgSuccess("审核通过成功");
          this.open = false;
          this.$parent.getList();
        })
      }).catch(() => {

      });
    },
    /** 提交按钮 */
    submitForm: function() {
      console.log(this.form)
      this.$refs["form"].validate(valid => {
        if (valid) {
          let params = JSON.parse(JSON.stringify(this.form))
          params.merchantInfoManageVo.forEach(val=>{
            if(val.certificateValidity == '长期'){
            } else {
              val.certificateValidity = dayjs(val.certificateValidity).format("YYYY-MM-DD")
            }
          })
          params.merchantInfoBeneficiaryVo.forEach(val=>{
            if(val.certificateValidity == '长期'){
            } else {
              val.certificateValidity = dayjs(val.certificateValidity).format("YYYY-MM-DD")
            }
          })
          if(params.merchantInfoLegalVo.certificateValidity != '长期'){
            params.merchantInfoLegalVo.certificateValidity = dayjs(params.merchantInfoLegalVo.certificateValidity).format("YYYY-MM-DD")
          }
          if(params.merchantInfoContactsVo.certificateValidity != '长期'){
            params.merchantInfoContactsVo.certificateValidity = dayjs(params.merchantInfoContactsVo.certificateValidity).format("YYYY-MM-DD")
          }
          if (this.form.merchantInfoId != undefined) {
            merInfo.updateMerInfo(params).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.$parent.getList();
            });
          } else {
            merInfo.addMerInfo(params).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.$parent.getList();
            });
          }
        } else {
          this.$message({type:'error',message:'请检查各项已填写完整'})
        }
      });
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.resetForm("form");
    },
  }
}
</script>

<style>
  .title{
    font-size: 15px;
    color: #1890ff;
  }
  .el-table tr .heade-cell{
    color: #333;
    background-color:#eff3f8;
  }
  .el-upload{
    width: 100%;
  }
</style>
<style scoped lang="scss">
.dialog-bar{
  position: relative;
  .icon-full{
    position: absolute;
    right: 30px;
    font-size: 12px;
    top: 2px;
    cursor: pointer;
  }
}
.form{
  height: 60vh;
  overflow-x: hidden;
  overflow-y: scroll;
}
.form::-webkit-scrollbar{
  display: none;
}
.upload-demo{
  display: flex;
  align-items: center;
  justify-content: flex-start;
}
.date-select{
  /*display: flex;*/
  align-items: center;
  justify-content: flex-start;
}
</style>
