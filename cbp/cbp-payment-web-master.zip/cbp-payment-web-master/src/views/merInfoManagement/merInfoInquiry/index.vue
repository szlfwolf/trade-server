<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="68px">
      <!--<el-form-item label="商户号" prop="merchantNo">
        <el-input v-model="queryParams.merchantNo" placeholder="请输入商户号" />
      </el-form-item>-->
      <el-form-item label="商户名称" prop="merchantNo">
        <el-select
          clearable
          v-model="queryParams.merchantNo"
          placeholder="选择"
          style="width: 210px"
          remote
          :remote-method="remoteMethod"
          @change="selectChannel"
          @focus="onFocus"
          filterable
          :loading="xlloading"
          v-loadmore="loadmore"
        >
          <el-option
            v-for="(item, index) in departmentList"
            :key="index"
            :label="item.merchantName +'('+ item.merchantNo+')'"
            :value="item.merchantNo"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="创建时间">
        <el-date-picker
          v-model="dateRange"
          style="width: 210px"
          value-format="yyyy-MM-dd"
          type="daterange"
          range-separator="-"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
        ></el-date-picker>
      </el-form-item>
      <el-form-item label="状态" prop="merchantStatus">
        <el-select style="width: 210px" v-model="queryParams.merchantStatus" placeholder="状态" clearable>
          <el-option
            v-for="dict in dict.type.merchant_status"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="审核状态" prop="operationStatus">
        <el-select style="width: 210px" v-model="queryParams.operationStatus" placeholder="审核状态" clearable>
          <el-option
            v-for="dict in dict.type.operation_status"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button v-hasPermi="['mer:Info:query']" type="primary" icon="el-icon-search" size="mini" @click="handleQuery">查询</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="el-icon-plus"
          size="mini"
          @click="handleAdd"
          v-hasPermi="['mer:Info:add']"
        >添加</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="el-icon-download"
          size="mini"
          @click="handleExport"
          v-hasPermi="['mer:Info:export']"
        >导出</el-button>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="configList" @selection-change="handleSelectionChange">
<!--      <el-table-column type="selection" width="55" align="center" />-->
      <el-table-column min-width="120px" label="商户号" fixed="left" align="center" prop="merchantNo" />
      <el-table-column label="商户名称" align="center" prop="merchantName" :show-overflow-tooltip="true"/>
      <el-table-column label="状态" align="center" prop="merchantStatus">
        <template slot-scope="scope">
          <dict-tag :options="dict.type.merchant_status" :value="scope.row.merchantStatus"/>
        </template>
      </el-table-column>
      <el-table-column label="审核状态" align="center" prop="operationStatus">
        <template slot-scope="scope">
          <dict-tag :options="dict.type.operation_status" :value="scope.row.operationStatus"/>
        </template>
      </el-table-column>
      <el-table-column min-width="150px" label="创建时间" align="center" prop="crtTime" />
      <el-table-column min-width="150px" label="更新时间" align="center" prop="uptTime" />
      <el-table-column label="审核人" align="center" prop="verifierUser"  />
      <el-table-column label="修改人" align="center" prop="uptBy" />
      <el-table-column min-width="150px" fixed="right" label="操作" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            @click="handleView(scope.row)"
            v-hasPermi="['mer:Info:view']"
          >详情</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row)"
            v-hasPermi="['mer:Info:edit']"
          >修改</el-button>
          <el-button
            size="mini"
            type="text"
            @click="handleExamine(scope.row)"
            v-hasPermi="['mer:Info:examine']"
          >审核</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />
    <dialogView ref="dialog"></dialogView>
  </div>
</template>

<script>
import { merInfo, merchantExApi } from "@/api/merchant/infactor";
import dialogView from "./dialogView";
export default {
  name: "Config",
  components:{
    dialogView
  },
  dicts:["operation_status","merchant_status"],
  data() {
    return {
      departmentList:[],
      xlloading: false,
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 参数表格数据
      configList: [],
      // 日期范围
      dateRange: [],
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        operationStatus: undefined,
        merchantStatus: undefined,
        merchantNo: undefined,
        merchantName: undefined
      },
      // 表单校验
      rules: {
        memberNo: [
          { required: true, message: "参数名称不能为空", trigger: "blur" }
        ],
        configKey: [
          { required: true, message: "参数键名不能为空", trigger: "blur" }
        ],
        configValue: [
          { required: true, message: "参数键值不能为空", trigger: "blur" }
        ]
      },
      merSize:10,
      merNum:1,
      merTotal:1,
    };
  },
  created() {
    this.getList();
    this.getMerchantList();
  },
  methods: {
    // remoteMethod
    remoteMethod(query) {
      this.departmentList = []
      if (query !== '') {
        this.xlloading = true;
        this.merNum = 1
        this.getMerchantList(query);
      } else {
        this.getMerchantList();
      }
    },
    onFocus(){
      if (!this.queryParams.merchantNo) {
        this.xlloading = true;
        this.merNum = 1
        this.departmentList = []
        this.getMerchantList();
      }
    },
    getMerchantList(query){
      let params = {
        pageNum: this.merNum,
        pageSize: this.merSize,
      }
      if(Number(query)){
        params["merchantNo"] = query
      } else {
        params["merchantName"] = query
      }
      merInfo.getMerchantInfo(params).then(response => {
          this.departmentList = [...this.departmentList,...response.data]
          this.merTotal = Math.ceil(response.total / this.merSize)
        }
      ).catch(e=>{
        this.loading = false;
      }).finally(e=>{
        this.xlloading = false;
      });
    },
    //
    loadmore(){
      console.log("滑动触底的相关操作",this.merNum,this.merTotal);

      if(this.merNum<this.merTotal){
        this.merNum+=1
        this.getMerchantList()
      }

      //数据页面更新，数据请求操作
    },
    selectChannel(){
      console.log('我滑动加载了');
      //数据页面更新，数据请求操作
    },
    /** 查询商户信息列表 */
    getList() {
      this.loading = true;
      let params = JSON.parse(JSON.stringify(this.addDateRange(this.queryParams, this.dateRange,'crtTimeBegin','crtTimeEnd')))
      if(params.merchantStatus == 'all'){
        params.merchantStatus = ""
      }
      merInfo.listMerInfo(params).then(response => {
          this.configList = response.data;
          this.total = response.total;
          this.loading = false;
        }
      ).catch(e=>{
        this.loading = false;
      });
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.dateRange = [];
      this.resetForm("queryForm");
      this.handleQuery();
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.$refs.dialog.add()
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.configId)
      this.single = selection.length!=1
      this.multiple = !selection.length
    },
    /** 详情按钮操作 */
    handleView(row) {
      merInfo.getMerInfo({
        merchantNo:row.merchantNo
      }).then(res=>{
        this.$refs.dialog.check(res.data)
      })
    },
    /** 详情按钮操作 */
    handleExamine(row) {
      merInfo.getMerInfo({
        merchantNo:row.merchantNo
      }).then(res=>{
        this.$refs.dialog.examine(res.data)
      })
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      merInfo.getMerInfo({
        merchantNo:row.merchantNo
      }).then(res=>{
        this.$refs.dialog.update(res.data)
      })
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const configIds = row.configId || this.ids;
      this.$modal.confirm('是否确认删除参数编号为"' + configIds + '"的数据项？').then(function() {
          return delConfig(configIds);
        }).then(() => {
          this.getList();
          this.$modal.msgSuccess("删除成功");
        }).catch(() => {});
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download(merchantExApi, {
        ...this.queryParams
      }, `商户信息查询_${new Date().getTime()}.xlsx`)
    },
    /** 刷新缓存按钮操作 */
    handleRefreshCache() {
      refreshCache().then(() => {
        this.$modal.msgSuccess("刷新成功");
      });
    }
  }
};
</script>
