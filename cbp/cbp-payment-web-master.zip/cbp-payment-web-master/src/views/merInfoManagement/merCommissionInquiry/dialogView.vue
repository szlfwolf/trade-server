<template>
  <!-- 添加或修改参数配置对话框 -->
  <div>
    <el-dialog :title="title" :visible.sync="open" width="700px" append-to-body
               :close-on-press-escape="false"
               :close-on-click-modal="false"
               :fullscreen="isFullscreen"
    >
      <template slot="title">
        <div class="dialog-bar">
          <span>{{title}}</span>
          <el-tooltip content="全屏 / 窗口" effect="dark" placement="bottom">
            <svg-icon @click="onScale" class="icon-full" :icon-class="isFullscreen?'exit-fullscreen':'fullscreen'" />
          </el-tooltip>
        </div>
      </template>
      <el-form ref="form" :model="form" :rules="rules" label-width="110px" class="form" :disabled="formDis">
        <el-row :gutter="24">
          <el-col :span="isFullscreen ? 8 : 12">
            <el-form-item label="商户名称" prop="merchantNo">
              <el-select
                clearable
                v-model="form.merchantNo"
                placeholder="选择"
                style="width: 100%"
                remote
                :disabled="formDis || type=='edit'"
                :remote-method="remoteMethod"
                @change="onChange"
                @focus="onFocus"
                filterable
                :loading="xlloading"
                v-loadmore="loadmore"
              >
                <el-option
                  v-for="(item, index) in departmentList"
                  :key="index"
                  :label="item.merchantName"
                  :value="item.merchantNo"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="isFullscreen ? 8 : 12">
            <el-form-item label="商户号" prop="merchantNo">
              <el-input disabled v-model="form.merchantNo" placeholder="请输入商户号" />
            </el-form-item>
          </el-col>
          <el-col :span="isFullscreen ? 8 : 12">
            <el-form-item label="一级产品名称" label-width="110px" prop="parentProductCode">
              <el-select :disabled="formDis || type=='edit'" style="width: 100%" v-model="form.parentProductCode" @change="onChangeCode" placeholder="一级产品名称" clearable>
                <el-option
                  v-for="dict in dict.type.parent_product_code"
                  :key="dict.value"
                  :label="dict.label"
                  :value="dict.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="isFullscreen ? 8 : 12">
            <el-form-item label="二级产品名称" label-width="110px" prop="productCode">
              <el-select :disabled="formDis || type=='edit'" style="width: 100%" v-model="form.productCode" placeholder="二级产品名称" clearable>
                <el-option
                  v-for="dict in productCodes"
                  :key="dict.productCode"
                  :label="dict.productName"
                  :value="dict.productCode"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="isFullscreen ? 8 : 24">
            <el-form-item label-width="110px" label="合同有效期" prop="dateRange">
              <el-date-picker
                v-model="form.dateRange"
                style="width: 100%"
                value-format="yyyy-MM-dd"
                type="daterange"
                range-separator="-"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
              ></el-date-picker>
            </el-form-item>
          </el-col>
          <!--<el-col :span="isFullscreen ? 8 : 12">
            <el-form-item label-width="100px" label="合同结束时间" prop="contractEndTime">
              <el-input v-model="form.contractEndTime" placeholder="请输入合同结束时间" />
            </el-form-item>
          </el-col>-->
          <el-col :span="isFullscreen ? 8 : 12">
            <el-form-item label="交割方式" prop="deliveryPattern">
              <el-select :disabled="formDis" @change="changePattern" style="width: 100%" v-model="form.deliveryPattern" placeholder="交割方式" clearable>
                <el-option
                  v-for="dict in dict.type.delivery_pattern"
                  :key="dict.value"
                  :label="dict.label"
                  :value="dict.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="isFullscreen ? 8 : 12">
            <el-form-item label="扣费方式" prop="deductionPattern">
              <el-select disabled style="width: 100%" v-model="form.deductionPattern" placeholder="扣费方式" clearable>
                <el-option
                  v-for="dict in dict.type.deduction_pattern_type"
                  :key="dict.value"
                  :label="dict.label"
                  :value="dict.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="isFullscreen ? 8 : 12">
            <el-form-item label="计算方法" prop="calculatePattern">
              <el-select :disabled="formDis" @change="changeCalculate" style="width: 100%" v-model="form.calculatePattern" placeholder="计算方法" clearable>
                <el-option
                  v-for="dict in dict.type.calculate_pattern"
                  :key="dict.value"
                  :label="dict.label"
                  :value="dict.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="isFullscreen ? 8 : 12" v-if="type=='view' && this.title!='审核'">
            <el-form-item label="审核状态" prop="operationStatus">
              <el-select :disabled="formDis || type=='edit'" @change="changeCalculate" style="width: 100%" v-model="form.operationStatus" placeholder="审核状态" clearable>
                <el-option
                  v-for="dict in dict.type.operation_status"
                  :key="dict.value"
                  :label="dict.label"
                  :value="dict.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="24">
          <el-col :span="24">
            <span class="title">手续费参数</span>
          </el-col>
          <el-divider></el-divider>
          <el-col :span="24" border v-if="form.calculatePattern==2">
            <el-row :gutter="24" style="display: flex;align-items: center;border-top: 1px solid #DCDFE6;background-color: #f8f8f9">
              <el-col :span="8" style="text-align: center">参数名称</el-col>
              <el-col :span="8"
                      style="text-align: center;border-left: 1px solid #DCDFE6;border-right: 1px solid #DCDFE6;padding: 10px">参数值</el-col>
              <el-col :span="8" style="text-align: center">备注</el-col>
            </el-row>
            <el-row :gutter="24" style="display: flex;align-items: center;border-top: 1px solid #DCDFE6">
              <el-col :span="8" style="text-align: center">手续费币别</el-col>
              <el-col :span="8" style="border-left: 1px solid #DCDFE6;border-right: 1px solid #DCDFE6;padding: 10px">
                <el-form-item style="margin-bottom: 0px" label-width="0" label="" prop="chargeCurrency">
                  <el-select :disabled="formDis" style="width: 100%" v-model="form.chargeCurrency" placeholder="手续费币别" clearable>
                    <el-option
                      v-for="dict in dict.type.merch_currency_type"
                      :key="dict.value"
                      :label="dict.label+'('+dict.value+')'"
                      :value="dict.value"
                    />
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="8">默认填写：CNY</el-col>
            </el-row>
            <el-row :gutter="24" style="display: flex;align-items: center;border-top: 1px solid #DCDFE6;border-bottom: 1px solid #DCDFE6">
              <el-col :span="8" style="text-align: center">固定金额</el-col>
              <el-col :span="8" style="border-left: 1px solid #DCDFE6;border-right: 1px solid #DCDFE6;padding: 10px">
                <el-form-item style="margin-bottom: 0px" label-width="0" label="" prop="fixedAmount">
                  <el-input :disabled="formDis" v-model="form.fixedAmount" placeholder="固定金额" />
                </el-form-item>
              </el-col>
              <el-col :span="8">以分为单位,填写整数（1-10000）</el-col>
            </el-row>
          </el-col>

          <el-col :span="24" border v-else>
            <el-row :gutter="24" style="display: flex;align-items: center;border-top: 1px solid #DCDFE6;background-color: #f8f8f9">
              <el-col :span="8" style="text-align: center">参数名称</el-col>
              <el-col :span="8"
                      style="text-align: center;border-left: 1px solid #DCDFE6;border-right: 1px solid #DCDFE6;padding: 10px">参数值</el-col>
              <el-col :span="8" style="text-align: center">备注</el-col>
            </el-row>
            <el-row :gutter="24" style="display: flex;align-items: center;border-top: 1px solid #DCDFE6">
              <el-col :span="8" style="text-align: center">手续费币别</el-col>
              <el-col :span="8" style="border-left: 1px solid #DCDFE6;border-right: 1px solid #DCDFE6;padding: 10px">
                <el-form-item style="margin-bottom: 0px" label-width="0" label="" prop="chargeCurrency">
                  <el-select :disabled="formDis" style="width: 100%" filterable v-model="form.chargeCurrency" placeholder="手续费币别" clearable>
                    <el-option
                      v-for="dict in dict.type.merch_currency_type"
                      :key="dict.value"
                      :label="dict.label+'('+dict.value+')'"
                      :value="dict.value"
                    />
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="8">默认填写：CNY</el-col>
            </el-row>
            <el-row :gutter="24" style="display: flex;align-items: center;border-top: 1px solid #DCDFE6">
              <el-col :span="8" style="text-align: center">手续费比例</el-col>
              <el-col :span="8" style="border-left: 1px solid #DCDFE6;border-right: 1px solid #DCDFE6;padding: 10px">
                <el-form-item style="margin-bottom: 0px" label-width="0" label="" prop="ratePerTxn">
                  <el-input :disabled="formDis" v-model="form.ratePerTxn" placeholder="手续费比例" />
                </el-form-item>
              </el-col>
              <el-col :span="8">填写整数（1-10000）</el-col>
            </el-row>
            <el-row :gutter="24" style="display: flex;align-items: center;border-top: 1px solid #DCDFE6">
              <el-col :span="8" style="text-align: center">封顶</el-col>
              <el-col :span="8" style="border-left: 1px solid #DCDFE6;border-right: 1px solid #DCDFE6;padding: 10px">
                <el-form-item style="margin-bottom: 0px" label-width="0" label="" prop="feeMax">
                  <el-input :disabled="formDis" v-model="form.feeMax" placeholder="封顶" />
                </el-form-item>
              </el-col>
              <el-col :span="8">以分为单位,填写整数</el-col>
            </el-row>
            <el-row :gutter="24" style="display: flex;align-items: center;border-top: 1px solid #DCDFE6;border-bottom: 1px solid #DCDFE6">
              <el-col :span="8" style="text-align: center">最低</el-col>
              <el-col :span="8" style="border-left: 1px solid #DCDFE6;border-right: 1px solid #DCDFE6;padding: 10px">
                <el-form-item style="margin-bottom: 0px" label-width="0" label="" prop="feeMin">
                  <el-input :disabled="formDis" v-model="form.feeMin" placeholder="最低" />
                </el-form-item>
              </el-col>
              <el-col :span="8">以分为单位,填写整数</el-col>
            </el-row>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button v-if="type=='examine'" type="danger" @click="onReject">审核拒绝</el-button>
        <el-button v-if="type=='examine'"  type="primary" @click="onPass">审核通过</el-button>
        <el-button type="primary" v-if="type!='view' && type!='examine'" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { Fee, merInfo, product } from '@/api/merchant/infactor'
import dayjs from 'dayjs'
export default {
  dicts:[
    "parent_product_code",
    "deduction_pattern_type",
    "delivery_pattern",
    "operation_status",
    "calculate_pattern",
    "merchant_status","merch_currency_type","source_country",
    "certificate_type","account_mer_type"],
  data(){
    return{
      merSize:10,
      merNum:1,
      merTotal:1,
      // 一级  二级产品
      parentProductCodes: [],
      productCodes: [],
      type:'add',
      departmentList: [],
      formDis: false,
      xlloading: false,
      // dialog全屏
      isFullscreen:false,
      // tabs的显示id
      activeName: 'first',
      // 弹出层标题
      title: "添加",
      // 是否显示弹出层
      open: false,
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        dateRange: [
          { type:'array', required: true, message: "不能为空", trigger: "change" }
        ],
        productCode: [
          { required: true, message: "不能为空", trigger: "change" }
        ],
        parentProductCode: [
          { required: true, message: "不能为空", trigger: "change" }
        ],
        merchantNo: [
          { required: true, message: "不能为空", trigger: "change" }
        ],
        deliveryPattern: [
          { required: true, message: "不能为空", trigger: "change" }
        ],
        deductionPattern: [
          { required: true, message: "不能为空", trigger: "change" }
        ],
        calculatePattern: [
          { required: true, message: "不能为空", trigger: "change" }
        ],
        chargeCurrency: [
          { required: true, message: "不能为空", trigger: "change" }
        ],
        feeMax: [
          { required: true, message: "不能为空", trigger: "change" }
        ],
        feeMin: [
          { required: true, message: "不能为空", trigger: "change" }
        ],
        ratePerTxn: [
          { required: true, message: "不能为空", trigger: "change" }
        ],
        fixedAmount: [
          { required: true, message: "不能为空", trigger: "change" }
        ],
      },
      // 表格集合
      tableData:[
        {
          name: '手续费币别',
          num: '',
          remark: '默认填写：CNY',
        },
        {
          name: '手续费比例',
          num: '',
          remark: '填写整数（1-10000）',
        },
        {
          name: '封顶',
          num: '',
          remark: '以分为单位',
        },
        {
          name: '最低',
          num: '',
          remark: '以分为单位',
        },
      ],
      // 表格集合
      headerStyle:{
        color:"#123456"
      },
    }
  },
  created() {
    this.getParentCodes() //
  },
  methods:{
    // 拒绝
    onReject(){
      this.$confirm('是否继续此操作?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'error'
      }).then(() => {
        Fee.examineFee({
          id:this.form.id,
          merchantNo:this.form.merchantNo,
          productCode:this.form.productCode,
          status:this.form.status,
          operationStatus: '2',
        }).then(res=>{
          this.$modal.msgSuccess("审核拒绝成功");
          this.open = false;
          this.$parent.getList();
        })
      }).catch(() => {

      });
    },
    // 审核
    onPass(){
      this.$confirm('是否继续此操作?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'success'
      }).then(() => {
        Fee.examineFee({
          id:this.form.id,
          merchantNo:this.form.merchantNo,
          productCode:this.form.productCode,
          deliveryPattern:this.form.deliveryPattern,
          chargeCurrency:this.form.chargeCurrency,
          status:this.form.status,
          operationStatus: '3',
        }).then(res=>{
          this.$modal.msgSuccess("审核通过成功");
          this.open = false;
          this.$parent.getList();
        })
      }).catch(() => {

      });
    },
    changeCalculate(val){
      if(val==2){
        this.$set(this.form,'feeMax',"")
        this.$set(this.form,'feeMin',"")
        this.$set(this.form,'ratePerTxn',"")
      } else {
        this.$set(this.form,'fixedAmount',"")
      }
    },
    /*获取一级产品枚举*/
    getParentCodes(){
      product.getParentCodesAction({type:"1"}).then(response => {
        this.parentProductCodes = response.data;
      })
    },
    /*切换一级*/
    onChangeCode(val){
      this.getProductCodes(val)
    },
    /*获取二级产品枚举*/
    getProductCodes(val){
      product.getProductCodesAction({parentProductCode:val,productStatus:'1'}).then(response => {
        this.productCodes = response.data;
      })
    },
    // remoteMethod
    remoteMethod(query) {
      this.departmentList = []
      if (query !== '') {
        this.xlloading = true;
        this.merNum = 1
        this.getMerchantList(query);
      } else {
        this.getMerchantList();
      }
    },
    onFocus(){
      if (!this.form.merchantNo) {
        this.xlloading = true;
        this.merNum = 1
        this.departmentList = []
        this.getMerchantList();
      }
    },
    onChange(val){
      if (!this.form.merchantNo) {
        this.xlloading = true;
        this.merNum = 1
        this.departmentList = []
        this.getMerchantList();
      }
    },
    getMerchantList(query){
      let params = {
        pageNum: this.merNum,
        pageSize: this.merSize,
        merchantStatus:"1"
      }
      if(Number(query)){
        params["merchantNo"] = query
      } else {
        params["merchantName"] = query
      }
      merInfo.getMerchantInfo(params).then(response => {
          this.departmentList = [...this.departmentList,...response.data]
          this.merTotal = Math.ceil(response.total / this.merSize)
        }
      ).catch(e=>{
        this.loading = false;
      }).finally(e=>{
        this.xlloading = false;
      });
    },
    //滑动触底的相关操作
    loadmore(){
      if(this.merNum<this.merTotal){
        this.merNum+=1
        this.getMerchantList()
      }
      console.log(this.merNum,this.merTotal);

      //数据页面更新，数据请求操作
    },
    onScale(){
      this.isFullscreen = !this.isFullscreen
    },
    changePattern(val){
      if((val==1 || val==2)){
        this.form.deductionPattern = "1"
      }
      if((val==3)){
        this.form.deductionPattern = "2"
      }
    },
    handleSelectionChange(val){
      this.clearTree = val.map(item=>{
        return item.id
      })
      console.log(this.clearTree)
    },
    add(){
      this.open = true;
      this.formDis = false;
      this.title = "添加";
      this.type = "add";
      this.reset()
      this.form={}
      this.$set(this.form,'chargeCurrency',"CNY")
    },
    /** 审核按钮操作 */
    examine(row) {
      this.open = true;
      this.formDis = true;
      this.title = "审核";
      this.type = "examine";
      this.reset()
      this.$nextTick(()=>{
        this.form = JSON.parse(JSON.stringify(row))
        this.form.dateRange = [this.form.contractBeginTime,this.form.contractEndTime]
        if(row.merchantNo) this.getMerchantList(row.merchantNo)
        this.getProductCodes(this.form.parentProductCode)
      })
    },
    /** 查看按钮操作 */
    checkData(row) {
      this.open = true;
      this.formDis = true;
      this.title = "查看";
      this.type = "view";
      this.reset()
      this.$nextTick(()=>{
        this.form = JSON.parse(JSON.stringify(row))
        this.form.dateRange = [this.form.contractBeginTime,this.form.contractEndTime]
        this.getProductCodes(this.form.parentProductCode)
        if(row.merchantNo) this.getMerchantList(row.merchantNo)
      })
    },
    /** 修改按钮操作 */
    update(row) {
      this.open = true;
      this.formDis = false;
      this.title = "修改";
      this.type = "edit";
      this.reset()
      this.$nextTick(()=>{
        this.form = JSON.parse(JSON.stringify(row))
        this.$set(this.form,'dateRange',[dayjs(this.form.contractBeginTime).format("YYYY-MM-DD"),
          dayjs(this.form.contractEndTime).format("YYYY-MM-DD")])
        this.getProductCodes(this.form.parentProductCode)
        if(row.merchantNo) this.getMerchantList(row.merchantNo)
      })
    },
    /** 提交按钮 */
    submitForm: function() {
      console.log(this.form)
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.id != undefined) {
            Fee.updateFee(
              {
                ...this.form,
                contractBeginTime: dayjs(this.form.dateRange[0]).format("YYYY-MM-DD"),
                contractEndTime: dayjs(this.form.dateRange[1]).format("YYYY-MM-DD"),
              }
            ).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.$parent.getList();
            });
          } else {
            Fee.addFee(
              {
                ...this.form, contractBeginTime: this.form.dateRange[0], contractEndTime: this.form.dateRange[1]
              }
            ).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.$parent.getList();
            });
          }
        }
      });
    },
    // 取消按钮
    cancel() {
      this.open = false;
      // this.reset();
    },
    // 表单重置
    reset() {
      this.resetForm("form");
    },
  }
}
</script>

<style>
  .title{
    font-size: 15px;
    color: #1890ff;
  }
  .el-table tr .heade-cell{
    color: #333;
    background-color:#eff3f8;
  }
</style>
<style scoped lang="scss">
.dialog-bar{
  position: relative;
  .icon-full{
    position: absolute;
    right: 30px;
    font-size: 12px;
    top: 2px;
    cursor: pointer;
  }
}
.form{
  overflow-x: hidden;
  overflow-y: scroll;
}
.form::-webkit-scrollbar{
  display: none;
}
.upload-demo{
  display: flex;
  align-items: center;
  justify-content: flex-start;
}
.date-select{
  /*display: flex;*/
  align-items: center;
  justify-content: flex-start;
}
</style>
