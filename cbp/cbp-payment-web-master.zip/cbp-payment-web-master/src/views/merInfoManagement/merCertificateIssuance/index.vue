<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="68px">
      <el-form-item label="商户名称" prop="merchantNo">
        <el-select
          clearable
          v-model="queryParams.merchantNo"
          placeholder="选择"
          style="width: 240px"
          remote
          :remote-method="remoteMethod"
          @focus="onFocus"
          filterable
          :loading="xlloading"
          v-loadmore="loadmore"
        >
          <el-option
            v-for="(item, index) in departmentList"
            :key="item.merchantNo"
            :label="item.merchantName +'('+ item.merchantNo+')'"
            :value="item.merchantNo"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="状态" prop="secretStatus">
        <el-select v-model="queryParams.secretStatus" placeholder="状态" clearable>
          <el-option
            v-for="dict in dict.type.secret_status"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="创建时间">
        <el-date-picker
          v-model="dateRange"
          style="width: 240px"
          value-format="yyyy-MM-dd"
          type="daterange"
          range-separator="-"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
        ></el-date-picker>
      </el-form-item>
      <el-form-item>
        <el-button v-hasPermi="['certificate:info:query']" type="primary" icon="el-icon-search" size="mini" @click="handleQuery">查询</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="el-icon-plus"
          size="mini"
          @click="handleAdd"
          v-hasPermi="['certificate:info:add']"
        >商户证书签发</el-button>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="configList" @selection-change="handleSelectionChange">
      <el-table-column width="150px" label="商户号" fixed="left"  align="center" prop="merchantNo"  />
      <el-table-column width="150px" label="商户名称" align="center" prop="merchantName" :show-overflow-tooltip="true"/>
      <el-table-column label="状态" align="center" prop="secretStatus" >
        <template slot-scope="scope">
          <dict-tag :options="dict.type.secret_status" :value="scope.row.secretStatus"/>
        </template>
      </el-table-column>
      <el-table-column width="160px" label="签发邮箱" align="center" prop="email"  />
      <el-table-column width="150px" label="手机号" align="center" prop="phoneNumber"  />
      <el-table-column width="150px" label="证书有效期" align="center" prop="certificateValidTime"  />
      <el-table-column width="150px" label="创建时间" align="center" prop="crtTime"  />
      <el-table-column width="150px" label="更新时间" align="center" prop="uptTime"  />
      <el-table-column width="120px" label="操作人" align="center" prop="uptBy"  />
      <el-table-column label="操作" fixed="right" width="150px" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-popconfirm
            title="是否继续补发操作？"
            v-hasPermi="['certificate:info:retry']"
            @confirm="handleExamine(scope.row)"
          >
            <el-button
              slot="reference"
              size="mini"
              type="text"
            >补发</el-button>
          </el-popconfirm>

          <el-popconfirm
            title="是否继续注销操作？"
            v-hasPermi="['certificate:info:cancel']"
            @confirm="handleStop(scope.row)"
          >
            <el-button
              slot="reference"
              size="mini"
              type="text"
            >注销</el-button>
          </el-popconfirm>
          <el-button
            size="mini"
            type="text"
            v-hasPermi="['certificate:info:uplaod']"
            @click="handleResumee(scope.row)"
          >公钥上传</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />
    <dialogView ref="dialog"></dialogView>
    <uploadView ref="uploadView"></uploadView>
  </div>
</template>

<script>
import { certRequest } from "@/api/merchant/infactor";
import { myMixins } from '@/utils/minxis'
import dialogView from "./dialogView";
import uploadView from "./uploadView";
export default {
  name: "Config",
  mixins: [myMixins],
  dicts:["secret_status"],
  components:{
    dialogView,
    uploadView
  },
  data() {
    return {
      merSize:10,
      merNum:1,
      merTotal:1,
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 参数表格数据
      configList: [],
      // 日期范围
      dateRange: [],
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        memberNo: undefined,
        configKey: undefined,
        status: undefined
      },
      // 表单校验
      rules: {
        memberNo: [
          { required: true, message: "不能为空", trigger: "blur" }
        ]
      }
    };
  },
  created() {
    this.getList();
  },
  methods: {
    /** 查询商户信息列表 */
    getList() {
      this.loading = true;
      certRequest.listCert(this.addDateRange(this.queryParams, this.dateRange,'crtTimeBegin','crtTimeEnd')).then(response => {
          this.configList = response.data;
          this.total = Number(response.total);
          this.loading = false;
        }
      ).catch(e=>{
        this.loading = false;
      });
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.dateRange = [];
      this.resetForm("queryForm");
      this.handleQuery();
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.$refs.dialog.add()
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.configId)
      this.single = selection.length!=1
      this.multiple = !selection.length
    },
    /** 补发按钮操作 */
    handleExamine(row) {
      // const configId = row.configId || this.ids
      certRequest.resumee({id:row.id}).then(response => {
        this.$modal.msgSuccess("补发成功");
        this.getList()
      }
      ).catch(e=>{
        this.loading = false;
      });
    },
    /** 注销按钮操作 */
    handleStop(row) {
      certRequest.stop({id:row.id}).then(response => {
          this.$modal.msgSuccess("注销成功");
          this.getList()
        }
      ).catch(e=>{
        this.loading = false;
      });
    },
    /** 公钥上传 */
    handleResumee(row) {
      this.$refs.uploadView.add(row)
      // const configId = row.configId || this.ids
    },
    /** 查看按钮操作 */
    handleView(row) {
      // const configId = row.configId || this.ids
      this.$refs.dialog.checkData()
    },
  }
};
</script>
