<template>
  <!-- 添加或修改参数配置对话框 -->
  <el-dialog :title="title" :visible.sync="open" width="500px" append-to-body
             :close-on-press-escape="false"
             :close-on-click-modal="false"
             :fullscreen="isFullscreen"
  >
    <template slot="title">
      <div class="dialog-bar">
        <span>{{title}}</span>
        <el-tooltip content="全屏 / 窗口" effect="dark" placement="bottom">
          <svg-icon @click="onScale" class="icon-full" :icon-class="isFullscreen?'exit-fullscreen':'fullscreen'" />
        </el-tooltip>
      </div>
    </template>
    <el-form ref="form" :model="form" :rules="rules" label-width="80px" class="form">
      <el-row :gutter="24">
        <el-col :span="isFullscreen ? 8 : 24">
          <el-form-item label-width="100px" label="商户名称" prop="merchantName">
              <el-select
                clearable
                v-model="form.merchantName"
                placeholder="选择"
                style="width: 100%"
                remote
                :remote-method="remoteMethod"
                @focus="onFocus"
                @change="onChange"
                filterable
                :loading="xlloading"
                v-loadmore="loadmore"
              >
                <el-option
                  v-for="(item, index) in departmentList"
                  :key="item.merchantNo+item.merchantName"
                  :label="item.merchantName"
                  :value="item"
                ></el-option>
              </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 24">
          <el-form-item label-width="100px" label="商户号" prop="merchantNo">
            <el-input disabled v-model="form.merchantNo" placeholder="请输入商户号" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 24">
          <el-form-item label-width="100px" label="签发邮箱" prop="email">
            <el-input v-model="form.email" placeholder="请输入签发邮箱" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 24">
          <el-form-item label-width="100px" label="手机号" prop="phoneNumber">
            <el-input maxlength="11" v-model="form.phoneNumber" placeholder="请输入手机号" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 24">
          <el-form-item label-width="100px" label="证书有效期">
            <el-input disabled v-model="configKey" placeholder="请输入证书有效期" />
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
  </el-dialog>
</template>

<script>
import { certRequest, merInfo } from '@/api/merchant/infactor'
import { regPhone, regEmail } from "@/utils/validate"
import { myMixins } from '@/utils/minxis'
import dayjs from 'dayjs'
export default {
  mixins: [myMixins],
  data(){
    return{
      configKey: dayjs().add(1, 'year').format("YYYY-MM-DD"),
      // dialog全屏
      isFullscreen:false,
      // tabs的显示id
      activeName: 'first',
      // 弹出层标题
      title: "添加",
      // 是否显示弹出层
      open: false,
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        merchantName: [
          { required: true, message: "不能为空", trigger: "change" }
        ],
        merchantNo: [
          { required: true, message: "不能为空", trigger: "change" }
        ],
        email: [
          { required: true, message: "不能为空", trigger: "change" },
          regEmail
        ],
        phoneNumber: [
          { required: true, message: "不能为空", trigger: "change" },
          regPhone
        ],
      },
      // 表格集合
      tableData:[
        {
          id:1,
          date: '2016-05-02',
          checked:false,
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
          fileList:[]
        },
        {
          id:12,
          date: '2016-05-02',
          checked:false,
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
          fileList:[]
        },
        {
          id:3,
          date: '2016-05-02',
          checked:false,
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
          fileList:[]
        },
        {
          id:5,
          date: '2016-05-02',
          checked:false,
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
          fileList:[]
        }
      ],
      // 表格集合
      headerStyle:{
        color:"#123456"
      },
    }
  },
  methods:{
    getMerchantList(query){
      let params = {
        pageNum: this.merNum,
        pageSize: this.merSize,
        merchantStatus:"1"
      }
      if(Number(query)){
        params["merchantNo"] = query
      } else {
        params["merchantName"] = query
      }
      merInfo.getMerchantInfo(params).then(response => {
          this.departmentList = JSON.parse(JSON.stringify([...this.departmentList,...response.data]))
          this.merTotal = Math.ceil(response.total / this.merSize)
        }
      ).catch(e=>{
        this.loading = false;
      }).finally(e=>{
        this.xlloading = false;
      });
    },
    onChange(val){
      this.form.merchantName = val.merchantName
      this.form.merchantNo = val.merchantNo
    },
    onScale(){
      this.isFullscreen = !this.isFullscreen
    },
    handleSelectionChange(val){
      this.clearTree = val.map(item=>{
        return item.id
      })
      console.log(this.clearTree)
    },
    add(){
      this.open = true;
      this.title = "添加";
      this.reset();
    },
    /** 审核按钮操作 */
    examine(row) {
      this.open = true;
      this.title = "审核";
      // const configId = row.configId || this.ids
      getConfig().then(response => {
        this.form = response.data;
      });
    },
    /** 查看按钮操作 */
    checkData(row) {
      this.open = true;
      this.title = "查看";
      // const configId = row.configId || this.ids
      getConfig().then(response => {
        this.form = response.data;
      });
    },
    /** 修改按钮操作 */
    update(row) {
      this.open = true;
      this.title = "修改";
      // const configId = row.configId || this.ids
      getConfig().then(response => {
        this.form = response.data;
      });
    },
    /** 提交按钮 */
    submitForm: function() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          certRequest.add(this.form).then(response => {
            this.$modal.msgSuccess("签发成功");
            this.open = false;
            this.$parent.getList();
          });
        }
      });
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.resetForm("form");
    },
  }
}
</script>

<style>
  .title{
    font-size: 15px;
    color: #1890ff;
  }
  .el-table tr .heade-cell{
    color: #333;
    background-color:#eff3f8;
  }
</style>
<style scoped lang="scss">
.dialog-bar{
  position: relative;
  .icon-full{
    position: absolute;
    right: 30px;
    font-size: 12px;
    top: 2px;
    cursor: pointer;
  }
}
.form{
  overflow-x: hidden;
  overflow-y: scroll;
}
.form::-webkit-scrollbar{
  display: none;
}
.upload-demo{
  display: flex;
  align-items: center;
  justify-content: flex-start;
}
.date-select{
  /*display: flex;*/
  align-items: center;
  justify-content: flex-start;
}
</style>
