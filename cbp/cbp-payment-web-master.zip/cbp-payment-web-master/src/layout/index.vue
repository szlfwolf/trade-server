<template>
  <div :class="classObj" class="app-wrapper" :style="{'--current-color': theme}">
    <div v-if="device==='mobile'&&sidebar.opened" class="drawer-bg" @click="handleClickOutside"/>
    <sidebar v-if="!sidebar.hide" class="sidebar-container" :style="{ width: barWidth }" />
    <div :class="{hasTagsView:needTagsView,sidebarHide:sidebar.hide}" :style="{ 'margin-left': barWidth }" class="main-container">
      <el-tooltip class="item" effect="dark" content="鼠标左键按下并左右拖拽" placement="top-start">
        <p style="color:#000" id="split-panel" @mouseup="moveSlideBar"></p>
      </el-tooltip>
      <div :class="{'fixed-header':fixedHeader}">
        <navbar />
        <tags-view v-if="needTagsView" />
      </div>
      <app-main />
      <right-panel>
        <settings />
      </right-panel>
    </div>
  </div>
</template>

<script>
import RightPanel from '@/components/RightPanel'
import { AppMain, Navbar, Settings, Sidebar, TagsView } from './components'
import ResizeMixin from './mixin/ResizeHandler'
import { mapState } from 'vuex'
import variables from '@/assets/styles/variables.scss'

export default {
  name: 'Layout',
  components: {
    AppMain,
    Navbar,
    RightPanel,
    Settings,
    Sidebar,
    TagsView
  },
  mixins: [ResizeMixin],
  data(){
    return {
      sideBarDefaultWidth:210
    }
  },
  computed: {
    ...mapState({
      theme: state => state.settings.theme,
      sideTheme: state => state.settings.sideTheme,
      sidebar: state => state.app.sidebar,
      device: state => state.app.device,
      needTagsView: state => state.settings.tagsView,
      fixedHeader: state => state.settings.fixedHeader,
      barWidth() {
        // console.log(this.sideBarDefaultWidth)
        if (!this.sidebar.opened) {
          //关闭时，右侧内容主题left设置为默认的54
          return '54px'
        } else {
          if(this.sideBarDefaultWidth > 270){
            this.sideBarDefaultWidth = 270
          }
          return `${this.sideBarDefaultWidth}px`
        }
      }
    }),
    classObj() {
      return {
        hideSidebar: !this.sidebar.opened,
        openSidebar: this.sidebar.opened,
        withoutAnimation: this.sidebar.withoutAnimation,
        mobile: this.device === 'mobile'
      }
    },
    variables() {
      return variables;
    }
  },
  methods: {
    handleClickOutside() {
      this.$store.dispatch('app/closeSideBar', { withoutAnimation: false })
    },
    moveSlideBar: function() {
      let _this = this
      let splitPanel = document.getElementById('split-panel')
      splitPanel.onmousedown = function(e) {
        splitPanel.style.background = '#409eff'
        let startX = e.clientX
        document.onmousemove = function(e) {
          let endX = e.clientX
          let moveLen = startX - endX
          startX = endX
          // 设置拖动幅度
          _this.sideBarDefaultWidth -= moveLen
          if(_this.sideBarDefaultWidth < 210){
            _this.sideBarDefaultWidth = 210
          }
          // console.log(_this.sideBarDefaultWidth)
        }
        document.onmouseup = function() {
          // 重置slipte
          splitPanel.style.background = ''
          document.onmousemove = null
          document.onmouseup = null
        }
        return false
      }
    }
  }
}
</script>

<style lang="scss" scoped>
  @import "~@/assets/styles/mixin.scss";
  @import "~@/assets/styles/variables.scss";

  .app-wrapper {
    @include clearfix;
    position: relative;
    height: 100%;
    width: 100%;

    &.mobile.openSidebar {
      position: fixed;
      top: 0;
    }
  }

  .drawer-bg {
    background: #000;
    opacity: 0.3;
    width: 100%;
    top: 0;
    height: 100%;
    position: absolute;
    z-index: 999;
  }

  .fixed-header {
    position: fixed;
    top: 0;
    right: 0;
    z-index: 9;
    width: calc(100% - #{$base-sidebar-width});
    transition: width 0.28s;
  }

  .hideSidebar .fixed-header {
    width: calc(100% - 54px);
  }

  .sidebarHide .fixed-header {
    width: 100%;
  }

  .mobile .fixed-header {
    width: 100%;
  }
</style>
<style scoped>
#split-panel {
  cursor: w-resize;
  height: 100%;
  width: 5px;
  position: absolute;
  top: 0;
  left: 0;
  z-index: 123;
  margin: 0;
}
</style>
