package com.smartpay.cbp.channel.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * @author Carer
 * @desc
 * @date 2022/11/23 11:30
 */
@ApiModel(value = "关联人信息")
@Data
@EqualsAndHashCode(callSuper = false)
public class CustManager implements Serializable {
    private static final long serialVersionUID = -946298365815805242L;

    /**
     * 关联人员类别
     */
    @ApiModelProperty(value = "关联人员类别")
    @JsonProperty("manager_type")
    private String managerType;

    /**
     * 关联人名称
     */
    @ApiModelProperty(value = "关联人名称")
    @JsonProperty("manager_name")
    private String managerName;

    /**
     * 关联人证件种类
     */
    @ApiModelProperty(value = "关联人证件种类")
    @JsonProperty("manager_id_type")
    private String managerIdType;

    /**
     * 关联人证件号码
     */
    @ApiModelProperty(value = "关联人证件号码")
    @JsonProperty("manager_id_no")
    private String managerIdNo;

    /**
     * 关联人证件有效期
     */
    @ApiModelProperty(value = "关联人证件有效期")
    @JsonProperty("manager_exp_date")
    private String managerExpDate;

    /**
     * 受益人国籍
     */
    @ApiModelProperty(value = "受益人国籍")
    @JsonProperty("manager_nationality")
    private String managerNationality;

    /**
     * 受益人地址
     */
    @ApiModelProperty(value = "受益人地址")
    @JsonProperty("manager_address")
    private String managerAddress;

    /**
     * 受益人直接或间接持有股权占比(百分比)
     */
    @ApiModelProperty(value = "受益人直接或间接持有股权占比(百分比)")
    @JsonProperty("manager_stock_right_ratio")
    private String managerStockRightRatio;

    /**
     * 受益人公司职务
     */
    @ApiModelProperty(value = "受益人公司职务")
    @JsonProperty("manager_company_position")
    private String managerCompanyPosition;
}
