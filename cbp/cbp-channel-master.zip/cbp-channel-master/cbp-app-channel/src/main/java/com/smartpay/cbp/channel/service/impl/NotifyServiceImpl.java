package com.smartpay.cbp.channel.service.impl;

import cn.hutool.core.date.LocalDateTimeUtil;
import cn.hutool.core.util.CharsetUtil;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.bocom.api.BocomResponse;
import com.bocom.api.utils.BocomSignature;
import com.bocom.api.utils.enums.EncryptType;
import com.smartpay.cbp.channel.config.BcmOpenConfigProperties;
import com.smartpay.cbp.channel.constant.ServerChannelConstants;
import com.smartpay.cbp.channel.dto.RegisterNotifyBizContent;
import com.smartpay.cbp.channel.dto.RegisterNotifyInfoDto;
import com.smartpay.cbp.channel.dto.RegisterResultNoticeReqDto;
import com.smartpay.cbp.channel.entity.RegisterInfoEntity;
import com.smartpay.cbp.channel.entity.RegisterNotifyInfoEntity;
import com.smartpay.cbp.channel.mapstruct.RegisterNotifyMapStruct;
import com.smartpay.cbp.channel.repository.RegisterInfoRepository;
import com.smartpay.cbp.channel.repository.RegisterNotifyInfoRepository;
import com.smartpay.cbp.channel.service.NotifyService;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.stereotype.Service;

import java.util.Objects;
import java.util.Optional;

/**
 * @author Carer
 * @desc
 * @date 2022/11/17 16:09
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class NotifyServiceImpl implements NotifyService {

    private final BcmOpenConfigProperties bcmOpenConfigProperties;

    private final RegisterNotifyInfoRepository registerNotifyInfoRepository;

    private final RegisterInfoRepository registerInfoRepository;

    private final AmqpTemplate amqpTemplate;

    private final RegisterNotifyMapStruct registerNotifyMapStruct;

    /**
     * 银行备案结果回调
     *
     * @param registerNoticeReq 回调内容
     */
    @SneakyThrows
    @Override
    public BocomResponse registerResultNotify(RegisterResultNoticeReqDto registerNoticeReq) {
        String bizContentStr = JSON.toJSONString(registerNoticeReq.getBizContent());
        boolean passed = BocomSignature.verify(EncryptType.RSA_AND_AES, bizContentStr
                , bcmOpenConfigProperties.getOpenApigwPubKey(), CharsetUtil.UTF_8, registerNoticeReq.getSign());
        BocomResponse respObject = new BocomResponse();
        if(!passed){
            log.error("签名校验异常！");
            respObject.setBizState("F");
            respObject.setRspCode("999999");
            respObject.setRspMsg("签名验证异常！");
            return respObject;
        }
        RegisterNotifyInfoEntity registerNotifyInfo = buildBizContent(bizContentStr, registerNoticeReq.getBizContent());
        registerNotifyInfoRepository.save(registerNotifyInfo);
        amqpTemplate.convertAndSend(ServerChannelConstants.CHANNEL_EXCHANGE, ServerChannelConstants.REGISTER_NOTIFY_QUEUE
                ,registerNotifyInfo.getId());
        respObject.setRspCode("000000");
        respObject.setBizState("S");
        respObject.setRspMsg("");
        return respObject;
    }

    /**
     * 根据主键获取备案回调通知内容
     *
     * @param id 通知内容
     * @return 回调信息
     */
    @Override
    public RegisterNotifyInfoDto getRegisterNotifyInfoById(String id) {
        RegisterNotifyInfoEntity registerNotifyInfoEntity = registerNotifyInfoRepository.getById(id);
        return registerNotifyMapStruct.toDto(Optional.ofNullable(registerNotifyInfoEntity)
                .orElseThrow(() ->new RuntimeException("备案回调信息不存在！")));
    }

    /**
     * 通知更新回调处理成功
     *
     * @param id 主键
     */
    @Override
    public void updateNotifyFinish(String id) {
        registerNotifyInfoRepository.update(Wrappers.<RegisterNotifyInfoEntity>lambdaUpdate()
                .set(RegisterNotifyInfoEntity::getNotifyDealStatus,"1").eq(RegisterNotifyInfoEntity::getId,id));
    }

    private RegisterNotifyInfoEntity buildBizContent(String bizContentStr, RegisterNotifyBizContent bizContent){
        RegisterInfoEntity registerInfoEntity = registerInfoRepository.getByReqNo(bizContent.getChnlSeqNo());
        RegisterNotifyInfoEntity registerNotifyInfoEntity = new RegisterNotifyInfoEntity();
        registerNotifyInfoEntity.setNotifyContent(bizContentStr);
        registerNotifyInfoEntity.setNotifyTime(LocalDateTimeUtil.now());
        registerNotifyInfoEntity.setReqNo(bizContent.getChnlSeqNo());
        registerNotifyInfoEntity.setParentReqNo(Objects.isNull(registerInfoEntity)? bizContent.getChnlSeqNo()
                :registerInfoEntity.getParentReqNo());
        registerNotifyInfoEntity.setNotifyResult(bizContent.getStatus());
        registerNotifyInfoEntity.setNotifyDealStatus("0");
        registerNotifyInfoEntity.setRemark(bizContent.getRemarks());
        return registerNotifyInfoEntity;
    }
}
