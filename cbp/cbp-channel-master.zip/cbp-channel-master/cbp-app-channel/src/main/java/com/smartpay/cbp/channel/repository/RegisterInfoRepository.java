package com.smartpay.cbp.channel.repository;

import com.baomidou.mybatisplus.extension.service.IService;
import com.smartpay.cbp.channel.dto.ChannelRegisterPageReqDto;
import com.smartpay.cbp.channel.dto.ChannelRegisterPageRspDto;
import com.smartpay.cbp.channel.entity.RegisterInfoEntity;

import java.util.List;

/**
 * @author Carer
 * @desc
 * @date 2022/11/9 15:58
 */
public interface RegisterInfoRepository extends IService<RegisterInfoEntity> {

    /**
     * 分页查询备案信息
     * @param channelRegisterPageReqDto 分页请求查询参数
     * @return 查询分页内容
     */
    List<ChannelRegisterPageRspDto> pageList(ChannelRegisterPageReqDto channelRegisterPageReqDto);

    /**
     * 根据请求流水号获取备案对象
     * @param seqNo 请求流水号
     * @return 备案对象
     */
    RegisterInfoEntity getByReqNo(String seqNo);
}
