package com.smartpay.cbp.channel.controller;

import com.smartpay.cbp.channel.dto.MerchantUserInfoReqDto;
import com.smartpay.cbp.channel.dto.UploadReqDto;
import com.smartpay.cbp.channel.dto.UploadRspDto;
import com.smartpay.cbp.channel.service.RegisterService;
import com.smartpay.cbp.common.core.domain.R;
import com.smartpay.cbp.common.security.annotation.InnerAuth;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author Carer
 * @desc
 * @date 2022/11/9 16:04
 */
@RestController
@RequiredArgsConstructor
@Slf4j
@RequestMapping("/register")
public class RegisterController {

    /**
     * 交行渠道，多渠道配置参考粗策略模式
     */
    @Qualifier("bgwRegister")
    private final RegisterService registerService;

    /**
     * 渠道备案发送
     * @param merchantUserInfoDto 备案发送
     * @return 发送请求流水号
     */
    @InnerAuth
    @PostMapping("/send")
    public R<String> registerSend(@RequestBody @Validated MerchantUserInfoReqDto merchantUserInfoDto){
        log.info("备案渠道发送接收参数:{}",merchantUserInfoDto);
        return R.ok(registerService.channelRegisterSend(merchantUserInfoDto));
    }

    /**
     * 文件上传
     * @param uploadReqDto 上传对象
     * @return 上传文件组装参数
     */
    @InnerAuth
    @PostMapping("/upload")
    public R<List<UploadRspDto>> uploadRegisterFile(@RequestBody @Validated UploadReqDto uploadReqDto){
        log.info("备案文件上传给渠道入参,上传对象:{}",uploadReqDto);
        return R.ok(registerService.uploadRegisterFile(uploadReqDto));
    }
}
