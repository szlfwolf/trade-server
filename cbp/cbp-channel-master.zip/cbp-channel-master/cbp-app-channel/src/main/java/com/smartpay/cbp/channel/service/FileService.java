package com.smartpay.cbp.channel.service;

import com.smartpay.cbp.core.dto.FileInfoRspDto;

import java.util.List;

/**
 * @author Carer
 * @desc  文件服务
 * @date 2022/11/14 15:44
 */
public interface FileService {

    /**
     * 根据文件ID获取文件列表
     * @param fileIds   文件指纹Id
     * @return 文件信息列表
     */
    List<FileInfoRspDto> getFileInfosByIds(List<String> fileIds);
}
