package com.smartpay.cbp.channel.controller;

import com.github.pagehelper.PageInfo;
import com.smartpay.cbp.channel.base.Page;
import com.smartpay.cbp.channel.dto.PaymentReqQueryDto;
import com.smartpay.cbp.channel.entity.KltPaymentReq;
import com.smartpay.cbp.channel.mapstruct.KltPaymentReqMapStruct;
import com.smartpay.cbp.channel.service.IKltPaymentReqService;
import com.smartpay.cbp.channel.vo.KltPaymentReqVo;
import com.smartpay.cbp.common.core.utils.PageUtils;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @Description: 提现请求明细
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/22 13:59
 * @Version: 1.0
 */
@Controller
@Slf4j
@RequestMapping("/payment")
@ApiOperation("渠道端提现请求")
@RequiredArgsConstructor
public class KltPaymentReqController {

    private final IKltPaymentReqService kltPaymentReqService;

    private final KltPaymentReqMapStruct kltPaymentReqMapStruct;


    @GetMapping("/page/{number}/{size}")
    @ApiOperation(value = "分页查询提现请求", tags = {""})
    @ResponseBody
    public Page<KltPaymentReqVo> page(@ApiParam(required = true, value = "页码", example = "1") @PathVariable final int number,
                                      @ApiParam(required = true, value = "每页条数，最大值1000", example = "10") @PathVariable final int size,
                                      @Valid final PaymentReqQueryDto condition) {
        PageUtils.startPage(number, size);
        List<KltPaymentReq> paymentReqs = kltPaymentReqService.list(condition);
        PageInfo<KltPaymentReq> pageInfo = new PageInfo<>(paymentReqs);
        List<KltPaymentReqVo> list = paymentReqs.stream().map(kltPaymentReqMapStruct::toKltPaymentReqVo).collect(Collectors.toList());
        return Page.ok(list, pageInfo.getTotal());
    }

}
