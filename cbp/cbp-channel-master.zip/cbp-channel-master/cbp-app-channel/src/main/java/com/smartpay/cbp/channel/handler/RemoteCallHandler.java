package com.smartpay.cbp.channel.handler;

import com.alibaba.fastjson.JSON;
import com.smartpay.cbp.account.dto.req.AccountAgentPayReqDTO;
import com.smartpay.cbp.account.dto.req.AccountAgentPayRollbackReqDTO;
import com.smartpay.cbp.account.dto.res.AccountAgentPayResDTO;
import com.smartpay.cbp.account.dto.res.AccountAgentPayRollbackResDTO;
import com.smartpay.cbp.account.fegin.AccountOperateApiService;
import com.smartpay.cbp.channel.enums.AppCode;
import com.smartpay.cbp.common.core.constant.SecurityConstants;
import com.smartpay.cbp.common.core.domain.R;
import com.smartpay.cbp.core.dto.RemitResultDTO;
import com.smartpay.cbp.core.feign.RemoteCoreApiService;
import com.smartpay.cbp.core.response.RemitOrderResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

/**
 * @author guogangqiang
 * @version <b>1.0.0</b>
 * @date 2022/11/8 19:33
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class RemoteCallHandler {

    private final RemoteCoreApiService remoteCoreApiService;

    private final AccountOperateApiService accountOperateApiService;

    /**
     * 根据提现订单id查询订单明细
     *
     * @param remitOrderId 提现订单id
     * @return 提现订单明细
     */
    public RemitOrderResponse getRemitOrderById(String remitOrderId) {
        log.info("【开始】远程调用查询提现订单,提现订单id:{}", remitOrderId);
        R<RemitOrderResponse> result = remoteCoreApiService.getRemitOrderById(remitOrderId);
        log.info("【结束】远程调用查询提现订单结果：{}", JSON.toJSONString(result));
        if (R.isError(result)) {
            throw AppCode.C03000.toCodeException("【异常】调用远程接口查询提现订单异常：{},{}", result.getCode(), result.getMsg());
        }
        return result.getData();
    }


    /**
     * 通知核心业务端提现结果
     *
     * @param remitResultDTO 提现结果信息
     */
    public boolean notifyRemitResult(RemitResultDTO remitResultDTO) {
        log.info("【开始】调用远程通知核心端提现结果:{}", JSON.toJSONString(remitResultDTO));
        R<Void> result = remoteCoreApiService.notifyRemitResult(remitResultDTO);
        log.info("【结束】调用远程通知核心端提现：{}", JSON.toJSONString(result));
        if (R.isError(result)) {
            log.error("【异常】调用远程通知核心端提现结果异常:{},{}", result.getCode(), result.getMsg());
        }
        return R.isSuccess(result);
    }

    /**
     * 记账操作
     *
     * @param dto
     * @return
     */
    public R<AccountAgentPayResDTO> agentPay(@Valid @NotNull AccountAgentPayReqDTO dto) {
        log.info("【开始】调用远程记账操作:{}", JSON.toJSONString(dto));
        R<AccountAgentPayResDTO> result = accountOperateApiService.agentPay(dto, SecurityConstants.INNER);
        log.info("【结束】调用远程记账结果:{}", JSON.toJSONString(result));
        return result;
    }

    /**
     * 记账回退操作
     *
     * @param dto
     * @return
     */
    public AccountAgentPayRollbackResDTO agentPayRollback(AccountAgentPayRollbackReqDTO dto) {
        log.info("【开始】调用远程记账回退操作:{}", JSON.toJSONString(dto));
        R<AccountAgentPayRollbackResDTO> result = accountOperateApiService.agentPayRollback(dto, SecurityConstants.INNER);
        log.info("【结束】调用远程记账回退结果:{}", JSON.toJSONString(result));
        if (R.isError(result)) {
            throw AppCode.C03000.toCodeException("【异常】调用远程记账回退操作异常：%s,%s", result.getCode(), result.getMsg());
        }
        return result.getData();
    }

}
