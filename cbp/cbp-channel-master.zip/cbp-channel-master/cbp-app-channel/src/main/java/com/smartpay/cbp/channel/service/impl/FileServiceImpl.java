package com.smartpay.cbp.channel.service.impl;

import com.smartpay.cbp.channel.service.FileService;
import com.smartpay.cbp.common.core.constant.SecurityConstants;
import com.smartpay.cbp.common.core.domain.R;
import com.smartpay.cbp.core.dto.FileInfoRspDto;
import com.smartpay.cbp.core.feign.RemoteCoreApiService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Carer
 * @desc  实现类
 * @date 2022/11/14 15:45
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class FileServiceImpl implements FileService {

    private final RemoteCoreApiService remoteCoreApiService;


    /**
     * 根据文件ID获取文件列表
     *
     * @param fileIds 文件指纹Id
     * @return 文件信息列表
     */
    @Override
    public List<FileInfoRspDto> getFileInfosByIds(List<String> fileIds) {
        log.info("远程获取文件信息入参：{}",fileIds);
        R<List<FileInfoRspDto>> fileInfosR = remoteCoreApiService.getFileInfos(fileIds, SecurityConstants.INNER);
        log.info("远程获取文件信息响应：{}",fileInfosR);
        if(Boolean.TRUE.equals(R.isError(fileInfosR))){
            throw new RuntimeException("远程获取文件信息异常！");
        }
        return fileInfosR.getData();
    }
}
