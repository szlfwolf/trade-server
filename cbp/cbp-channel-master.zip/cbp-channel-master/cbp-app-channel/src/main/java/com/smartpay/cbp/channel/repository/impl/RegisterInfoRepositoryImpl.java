package com.smartpay.cbp.channel.repository.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.smartpay.cbp.channel.dto.ChannelRegisterPageReqDto;
import com.smartpay.cbp.channel.dto.ChannelRegisterPageRspDto;
import com.smartpay.cbp.channel.entity.RegisterInfoEntity;
import com.smartpay.cbp.channel.mapper.RegisterInfoMapper;
import com.smartpay.cbp.channel.repository.RegisterInfoRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Carer
 * @desc
 * @date 2022/11/9 15:59
 */
@Repository
@RequiredArgsConstructor
@Slf4j
public class RegisterInfoRepositoryImpl extends ServiceImpl<RegisterInfoMapper, RegisterInfoEntity>
        implements RegisterInfoRepository {

    /**
     * 分页查询备案信息
     *
     * @param channelRegisterPageReqDto 分页请求查询参数
     * @return 查询分页内容
     */
    @Override
    public List<ChannelRegisterPageRspDto> pageList(ChannelRegisterPageReqDto channelRegisterPageReqDto) {
        return getBaseMapper().pageList(channelRegisterPageReqDto);
    }

    /**
     * 根据请求流水号获取备案对象
     *
     * @param seqNo 请求流水号
     * @return 备案对象
     */
    @Override
    public RegisterInfoEntity getByReqNo(String seqNo) {
        return getOne(Wrappers.<RegisterInfoEntity>lambdaQuery().eq(RegisterInfoEntity::getReqNo,seqNo));
    }
}
