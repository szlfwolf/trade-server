package com.smartpay.cbp.channel.service;

import com.smartpay.cbp.channel.entity.KltPaymentRecord;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author admin
* @description 针对表【t_klt_payment_record(请求互联网单笔代付记录表)】的数据库操作Service
* @createDate 2022-11-08 14:26:41
*/
public interface IKltPaymentRecordService extends IService<KltPaymentRecord> {

}
