package com.smartpay.cbp.channel.enums;

import java.util.Arrays;
import java.util.Objects;

/**
 * @Description: 开联通互联网返回订单状态
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/11 14:15
 * @Version: 1.0
 */
public enum KltPaymentOrderStatus {

    INIT("初始化"),

    SEND_FAIL("发送失败"),

    SEND_SUCCESS("发送成功"),

    CREATE("已受理"),
    IN_PROCESS("处理中"),
    FAIL("处理失败"),
    SUCCESS("处理成功"),
    REFUSE("拒绝交易"),

    ;

    public final String desc;

    KltPaymentOrderStatus(String desc) {
        this.desc = desc;
    }

    /**
     * 根据枚举name值匹配枚举
     *
     * @param orderStatus
     * @return
     */
    public static KltPaymentOrderStatus toEnum(String orderStatus) {
        return Arrays.stream(KltPaymentOrderStatus.values())
                .filter(kltPaymentOrderStatus -> Objects.equals(kltPaymentOrderStatus.name(), orderStatus))
                .findFirst()
                .orElse(INIT);
    }

}
