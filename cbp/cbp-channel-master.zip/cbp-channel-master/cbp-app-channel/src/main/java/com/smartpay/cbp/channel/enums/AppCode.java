package com.smartpay.cbp.channel.enums;


import com.smartpay.cbp.common.core.utils.ICode;

/**
 * 全局响应代码，异常响应代码: 限制区间在 A00000 - A00999
 * 定义 com.support.mvc.entity.base.Result#setCode(Code) 返回编码
 */
public enum AppCode implements ICode {

    C03000("调用远程接口异常"),
    C03001("未查询到当前提现记录"),
    C03002("已发送成功无法重发"),


    ;
    /**
     * 枚举属性说明
     */
    public final String comment;

    AppCode(String comment) {
        this.comment = comment;
    }

    @Override
    public String getComment() {
        return this.comment;
    }
}
