package com.smartpay.cbp.channel.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author Carer
 * @desc
 * @date 2022/11/8 16:34
 */
@Getter
@AllArgsConstructor
public enum ReqResultType {

    //
    SUCCESS("S","成功"),
    FAIL("F","失败"),
    ;

    private final String code;
    private final String desc;
}
