package com.smartpay.cbp.channel.config;

import com.xxl.job.core.executor.impl.XxlJobSpringExecutor;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.commons.util.InetUtils;
import org.springframework.cloud.commons.util.InetUtilsProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/23 09:55
 */
@Slf4j
@Data
@RefreshScope
@Component
@RequiredArgsConstructor
@ConfigurationProperties(prefix = "xxl-job")
public class XxlJobConfig {

    private String adminAddresses;

    private String appName;

    private Integer port;

    private String accessToken;

    private String logPath;

    private Integer logRetentionDays;


    private final InetUtilsProperties inetUtilsProperties;


    @Bean(initMethod = "start", destroyMethod = "destroy")
    public XxlJobSpringExecutor xxlJobExecutor() {
        log.info(">>>>>>>>>>> xxl-job config init.");
        XxlJobSpringExecutor xxlJobSpringExecutor = new XxlJobSpringExecutor();
        xxlJobSpringExecutor.setAdminAddresses(adminAddresses);
        xxlJobSpringExecutor.setAppName(appName);
        try (InetUtils inetUtils = new InetUtils(inetUtilsProperties)) {
            String ip = inetUtils.findFirstNonLoopbackHostInfo().getIpAddress();
            xxlJobSpringExecutor.setIp(ip);
        }
        xxlJobSpringExecutor.setPort(port);
        xxlJobSpringExecutor.setLogPath(logPath);
        xxlJobSpringExecutor.setLogRetentionDays(logRetentionDays);
        return xxlJobSpringExecutor;
    }

}
