package com.smartpay.cbp.channel.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.validation.constraints.NotBlank;

/**
 * @author Carer
 * @desc
 * @date 2022/11/23 13:38
 */
@ApiModel(value = "渠道备案重发入参",parent = RegisterApplyRequestV2Biz.class)
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class RegisterRetryReqDto extends RegisterApplyRequestV2Biz{
    private static final long serialVersionUID = -431898548899491913L;

    /**
     * 数据主键
     */
    @ApiModelProperty(value = "重发数据主键",required = true)
    @NotBlank(message = "重发数据主键不能为空")
    private String id;
}
