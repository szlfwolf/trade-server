package com.smartpay.cbp.channel.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @Description: 提现请求vo
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/21 17:55
 * @Version: 1.0
 */
@Data
public class KltPaymentReqVo {

    @ApiModelProperty("商户号")
    private String merchantNo;

    @ApiModelProperty("商户名称")
    private String merchantName;

    @ApiModelProperty("批次号")
    private String batchNo;

    @ApiModelProperty("订单号")
    private String mchtOrderNo;

    @ApiModelProperty("卖家编号")
    private String platformUserNo;

    @ApiModelProperty("币种")
    private String currencyType;

    @ApiModelProperty("金额")
    private Long amt;

    @ApiModelProperty("手续费")
    private Long feeAmt;

    @ApiModelProperty("账户类型")
    private String accountType;

    @ApiModelProperty("账户名称")
    private String bankAccountName;

    @ApiModelProperty("账户号")
    private String accountName;

    @ApiModelProperty("银行名称")
    private String bankName;

    @ApiModelProperty("状态")
    private String orderState;

    @ApiModelProperty("返回信息")
    private String responseMsg;

    @ApiModelProperty("创建时间")
    private Date crtTime;

    @ApiModelProperty("更新时间")
    private Date uptTime;

}
