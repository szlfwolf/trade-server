package com.smartpay.cbp.channel.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * @author Carer
 * @desc
 * @date 2022/11/23 11:31
 */
@ApiModel(value = "附件信息")
@Data
@EqualsAndHashCode(callSuper = false)
public class Doc implements Serializable {

    private static final long serialVersionUID = -8854173538082084477L;
    /**
     * 上传附件返回的docId
     */
    @ApiModelProperty(value = "附件Id")
    @JsonProperty("doc_id")
    private String docId;

    /**
     * 附件名称
     */
    @ApiModelProperty(value = "附件名称")
    @JsonProperty("doc_name")
    private String docName;
}
