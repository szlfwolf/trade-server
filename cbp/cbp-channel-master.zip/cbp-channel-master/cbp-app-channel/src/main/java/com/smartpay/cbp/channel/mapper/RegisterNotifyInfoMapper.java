package com.smartpay.cbp.channel.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.smartpay.cbp.channel.entity.RegisterNotifyInfoEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author admin
 */
@Mapper
public interface RegisterNotifyInfoMapper extends BaseMapper<RegisterNotifyInfoEntity> {

}