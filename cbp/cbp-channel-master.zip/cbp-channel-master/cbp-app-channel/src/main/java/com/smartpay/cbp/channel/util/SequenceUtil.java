package com.smartpay.cbp.channel.util;

import cn.hutool.core.date.DatePattern;
import cn.hutool.extra.spring.SpringUtil;
import com.smartpay.cbp.channel.constants.Constants;
import com.smartpay.cbp.channel.enums.SequenceType;
import org.redisson.api.RAtomicLong;
import org.redisson.api.RedissonClient;

import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 * @description ：流水号工具类
 * @author ：jmwang
 * @version ：V1.0
 * @date ：2022/11/8 14:59
 */
public class SequenceUtil {

    /**
     * 自增流水号(每日)
     *
     * @param type 流水类型
     * @return 例 20221108000001
     */
    public static String genSerialNo(SequenceType type) {
        String date = DatePattern.PURE_DATE_FORMAT.format(new Date());
        StringBuilder builder = new StringBuilder();
        builder.append(type.getPrefix()).append(date);
        RedissonClient redissonClient = SpringUtil.getBean(RedissonClient.class);
        RAtomicLong atomicLong = redissonClient.getAtomicLong(type.getCode() + ":" + date);
        if (!atomicLong.isExists()) {
            atomicLong.expire(1, TimeUnit.DAYS);
        }
        builder.append(String.format("%" + Constants.FILL_ZERO + type.getLength() +  "d", atomicLong.incrementAndGet()));
        return builder.toString();
    }
}
