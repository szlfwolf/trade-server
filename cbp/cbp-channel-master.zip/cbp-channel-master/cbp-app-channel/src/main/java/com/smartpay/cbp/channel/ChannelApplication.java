package com.smartpay.cbp.channel;
import com.smartpay.cbp.common.security.annotation.EnableCustomConfig;
import com.smartpay.cbp.common.security.annotation.EnableRyFeignClients;
import com.smartpay.cbp.common.swagger.annotation.EnableCustomSwagger2;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Carer
 * @desc   渠道主启动类
 * @date 2022/10/26 17:37
 */
@EnableCustomConfig
@EnableCustomSwagger2
@EnableRyFeignClients
@SpringBootApplication
public class ChannelApplication {

    public static void main(String[] args) {
        SpringApplication.run(ChannelApplication.class, args);
    }
}
