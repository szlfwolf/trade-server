package com.smartpay.cbp.channel.repository.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.smartpay.cbp.channel.entity.RegisterNotifyInfoEntity;
import com.smartpay.cbp.channel.mapper.RegisterNotifyInfoMapper;
import com.smartpay.cbp.channel.repository.RegisterNotifyInfoRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

/**
 * @author Carer
 * @desc
 * @date 2022/11/17 16:27
 */
@Repository
@RequiredArgsConstructor
@Slf4j
public class RegisterNotifyInfoRepositoryImpl extends ServiceImpl<RegisterNotifyInfoMapper, RegisterNotifyInfoEntity>
        implements RegisterNotifyInfoRepository {
}
