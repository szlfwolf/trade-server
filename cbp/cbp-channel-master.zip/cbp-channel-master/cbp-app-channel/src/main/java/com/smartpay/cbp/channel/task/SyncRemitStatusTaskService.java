package com.smartpay.cbp.channel.task;

import com.alibaba.fastjson2.JSON;
import com.smartpay.cbp.channel.constants.Constants;
import com.smartpay.cbp.channel.dto.SinglePaymentQueryDTO;
import com.smartpay.cbp.channel.entity.KltPaymentReq;
import com.smartpay.cbp.channel.enums.KltPaymentOrderStatus;
import com.smartpay.cbp.channel.response.SinglePaymentQueryResp;
import com.smartpay.cbp.channel.service.IKltPaymentReqService;
import com.smartpay.cbp.channel.service.IKltRemoteApiService;
import com.smartpay.cbp.channel.util.KltCertUtil;
import com.smartpay.cbp.core.dto.RemitResultDTO;
import com.smartpay.cbp.core.feign.RemoteCoreApiService;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.JobHandler;
import com.xxl.job.core.log.XxlJobLogger;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Objects;

/**
 * @Description: 定时任务同步提现状态
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/14 11:02
 * @Version: 1.0
 */
@Slf4j
@RequiredArgsConstructor
@Component
@JobHandler("syncRemitStatusJobHandler")
public class SyncRemitStatusTaskService extends IJobHandler {

    private final IKltPaymentReqService kltPaymentReqService;

    private final RemoteCoreApiService remoteCoreApiService;

    private final IKltRemoteApiService remoteApiService;

    private final KltCertUtil kltCertUtil;


    /**
     * 定时任务查询代付状态
     */
    @Override
    public ReturnT<String> execute(String s) {
        List<KltPaymentReq> kltPaymentReqs = kltPaymentReqService.listForSyncStatusTask();
        log.info("【开始】定时同步代付状态,需同步条数:{}", kltPaymentReqs.size());
        XxlJobLogger.log("【开始】定时同步代付状态,需同步条数:{}", kltPaymentReqs.size());
        kltPaymentReqs.forEach(kltPaymentReq -> {
            try {
                syncRemitStatus(kltPaymentReq);
            } catch (Exception e) {
                log.error("【异常】定时任务查询单笔代付状态异常,代付订单id：{}", kltPaymentReq.getRemitOrderId(), e);
                XxlJobLogger.log("【异常】定时任务查询单笔代付状态异常,代付订单id：{}", kltPaymentReq.getRemitOrderId(), e);
            }
        });
        log.info("【结束】定时任务同步代付状态完成，等待下次执行");
        XxlJobLogger.log("【结束】定时任务同步代付状态完成，等待下次执行");
        return null;
    }


    /**
     * 同步代付状态
     *
     * @param kltPaymentReq
     */
    private void syncRemitStatus(@NotNull KltPaymentReq kltPaymentReq) {

        RemitResultDTO remitResultDTO;

        /**
         * 1.存在终态未同步则直接同步给核心业务
         * 2.未存在终态则调用互联网单笔代付查询接口查询处理结果
         */
        if (StringUtils.equals(String.valueOf(KltPaymentOrderStatus.FAIL.ordinal()), kltPaymentReq.getOrderState())
                || StringUtils.equals(String.valueOf(KltPaymentOrderStatus.SUCCESS.ordinal()), kltPaymentReq.getOrderState())
                || StringUtils.equals(String.valueOf(KltPaymentOrderStatus.REFUSE.ordinal()), kltPaymentReq.getOrderState())) {
            remitResultDTO = RemitResultDTO.builder()
                    .remitOrderId(kltPaymentReq.getRemitOrderId())
                    .orderStatus(kltPaymentReq.getOrderState())
                    .responseMsg(kltPaymentReq.getResponseMsg())
                    .responseCode(kltPaymentReq.getResponseCode())
                    .build();
        } else {
            //调用互联网单笔代付查询接口同步提现/代付状态
            SinglePaymentQueryResp singlePaymentQueryResp = queryKltPaymentStatus(kltPaymentReq);
            if (Objects.isNull(singlePaymentQueryResp)) {
                return;
            }
            boolean verifySuccess = kltCertUtil.verify(singlePaymentQueryResp, Constants.SIGN_FIELD_NAME);
            if (!verifySuccess) {
                log.error("【错误】代付查询解签失败,渠道端提现订单id:{}", kltPaymentReq.getId());
                return;
            }

            KltPaymentOrderStatus kltPaymentOrderStatus = KltPaymentOrderStatus.toEnum(singlePaymentQueryResp.getOrderState());

            //没有终态则不需要同步和更改当前代付状态
            if (kltPaymentOrderStatus != KltPaymentOrderStatus.REFUSE
                    && kltPaymentOrderStatus != KltPaymentOrderStatus.SUCCESS
                    && kltPaymentOrderStatus != KltPaymentOrderStatus.FAIL) {
                return;
            }

            //填充渠道端代付状态
            kltPaymentReq.setOrderState(String.valueOf(kltPaymentOrderStatus.ordinal()));
            kltPaymentReq.setResponseMsg(singlePaymentQueryResp.getResponseMsg());
            kltPaymentReq.setResponseCode(singlePaymentQueryResp.getResponseCode());
            remitResultDTO = RemitResultDTO.builder()
                    .orderStatus(String.valueOf(kltPaymentOrderStatus.ordinal()))
                    .responseCode(singlePaymentQueryResp.getResponseCode())
                    .responseMsg(singlePaymentQueryResp.getResponseMsg())
                    .build();

        }
        //提现订单状态同步至核心业务系统
        remitResultDTO.setRemitOrderId(kltPaymentReq.getRemitOrderId());
        boolean syncSuccess = syncToCore(remitResultDTO);
        kltPaymentReq.setSyncSucceeded(syncSuccess);
        kltPaymentReqService.updateById(kltPaymentReq);
    }


    /**
     * 调用互联网单笔代付查询
     *
     * @param kltPaymentReq 代付请求 {@link KltPaymentReq}
     * @return 是否查询成功
     */
    private SinglePaymentQueryResp queryKltPaymentStatus(@NotNull KltPaymentReq kltPaymentReq) {
        //查询请求体
        SinglePaymentQueryDTO paymentQueryDTO = SinglePaymentQueryDTO.builder()
                .mchtOrderNo(kltPaymentReq.getMchtOrderNo())
                .paymentBusinessType("SINGLE_PAY")
                .merchantNo(kltPaymentReq.getMerchantNo())
                .build();
        return remoteApiService.singlePaymentQuery(paymentQueryDTO, kltPaymentReq.getId());
    }

    /**
     * 同步代付状态至核心业务端
     *
     * @param remitResultDTO 单笔代付响应结果
     * @return 是否同步成功
     */
    private boolean syncToCore(@Valid @NotNull RemitResultDTO remitResultDTO) {
        log.info("【开始】定时任务同步状态至核心业务端，请求体：{}", JSON.toJSONString(remitResultDTO));
        try {
            remoteCoreApiService.notifyRemitResult(remitResultDTO);
            log.info("【结束】定时任务同步状态至核心业务端成功");
            return true;
        } catch (Exception e) {
            log.error("【异常】渠道端同步至核心业务提现状态异常", e);
            return false;
        }
    }


}
