package com.smartpay.cbp.channel.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDateTime;

/**
 * t_channel_register_info
 * @author carer
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_channel_register_info")
public class RegisterInfoEntity extends Model<RegisterInfoEntity> {
    /**
     * 主键
     */
    @TableId(type = IdType.ASSIGN_ID)
    private String id;

    /**
     * 请求流水号
     */
    private String reqNo;

    /**
     * 父请求号
     */
    private String parentReqNo;

    /**
     * 备案渠道编号
     */
    private String channelNo;

    /**
     * 系统用户号
     */
    private String userNo;

    /**
     * 渠道用户号
     */
    private String openUserNo;

    /**
     * 用户类型,1-企业，2-个人
     */
    private String userType;

    /**
     * 姓名、法人姓名
     */
    private String nameEnc;

    /**
     * 姓名、法人姓名
     */
    private String nameMask;

    /**
     * 手机号-加密
     */
    private String mobileNoEnc;

    /**
     * 手机号-脱敏
     */
    private String mobileNoMask;

    /**
     * 证件类型
     */
    private String certType;

    /**
     * 证件号-加密
     */
    private String certIdEnc;

    /**
     * 证件号-脱敏
     */
    private String certIdMask;

    /**
     * 回调地址
     */
    private String notifyUrl;

    /**
     * 请求数据
     */
    private String reqData;

    /**
     * http请求响应结果 S-成功，F-失败
     */
    private String reqResult;

    /**
     * 异步请求标识 0-同步，1-异步
     */
    private String asyncFlag;

    /**
     * 异步请求查询结果 S-成功，F-失败，P-进行中
     */
    private String reqQryResult;

    /**
     * 异步请求终态时间
     */
    private LocalDateTime asyncEndTime;

    /**
     * 请求响应数据
     */
    private String rspData;

    /**
     * 请求时间
     */
    private LocalDateTime reqTime;

    /**
     * 响应时间
     */
    private LocalDateTime rspTime;

    /**
     * 备注
     */
    private String remark;

    /**
     * 逻辑删除标识 0-未删除，1删除
     */
    @TableLogic(value = "0",delval = "1")
    private String delFlag;

    /**
     * 创建人
     */
    private String crtBy;

    /**
     * 创建时间
     */
    private LocalDateTime crtTime;

    /**
     * 更新人
     */
    private String uptBy;

    /**
     * 更新时间
     */
    private LocalDateTime uptTime;

    private static final long serialVersionUID = 1L;
}