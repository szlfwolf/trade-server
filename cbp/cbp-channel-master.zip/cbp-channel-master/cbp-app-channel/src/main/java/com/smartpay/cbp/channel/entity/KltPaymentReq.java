package com.smartpay.cbp.channel.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * 互联网单笔代付请求表
 *
 * @TableName t_klt_payment_req
 */
@TableName(value = "t_klt_payment_req")
@Data
@Accessors(chain = true)
public class KltPaymentReq implements Serializable {
    /**
     * 主键id
     */
    @TableId(value = "id")
    private String id;

    /**
     * 关联下发订单id(t_remit_order)
     */
    @TableField(value = "remit_order_id")
    private String remitOrderId;

    /**
     * 商户号
     */
    @TableField(value = "merchant_no")
    private String merchantNo;

    /**
     * 批次号
     */
    @TableField(value = "batch_no")
    private String batchNo;

    /**
     * 币别
     */
    @TableField(value = "currency_type")
    private String currencyType;

    /**
     * 交易状态 {@link com.smartpay.cbp.channel.enums.KltPaymentOrderStatus}
     */
    @TableField(value = "order_state")
    private String orderState;

    /**
     * 发送类型（正常发送，重发）{@link com.smartpay.cbp.channel.enums.KltPaymentSendType}
     */
    @TableField(value = "send_type")
    private String sendType;

    /**
     * 商户订单号
     */
    @TableField(value = "mcht_order_no")
    private String mchtOrderNo;

    /**
     * 商户订单时间
     */
    @TableField(value = "order_date_time")
    private Date orderDateTime;

    /**
     * 收款方账号
     */
    @TableField(value = "account_no")
    private String accountNo;

    /**
     * 收款方姓名
     */
    @TableField(value = "account_name")
    private String accountName;

    /**
     * 收款方账户类型，固定值，可取值：
     * 1代表个人账户
     * 2代表企业账户
     */
    @TableField(value = "account_type")
    private String accountType;

    /**
     * 收款方开户行行号（电子联行号）对公需要校验，对私填写000000000000（12个0）
     */
    @TableField(value = "bank_no")
    private String bankNo;

    /**
     * 收款方开户行名称（企业账户精确到支行，比如中国工商银行上海市浦东大道支行）
     * 个人账户只写银行名
     */
    @TableField(value = "bank_name")
    private String bankName;

    /**
     * 金额，正整数，单位为分。例如，票款为1280元，则表示为“128000”
     */
    @TableField(value = "amt")
    private Long amt;

    /**
     * 手续费金额
     */
    @TableField(value = "fee_amt")
    private Long feeAmt;

    /**
     * 手续费货币类型
     */
    @TableField(value = "fee_currency_type")
    private String feeCurrencyType;


    /**
     * 用途
     */
    @TableField(value = "purpose")
    private String purpose;

    /**
     * 产品编码
     */
    @TableField(value = "product_code")
    private String productCode;

    /**
     * 备注
     */
    @TableField(value = "remark")
    private String remark;

    /**
     * 代理记账id
     */
    @TableField("agent_pay_id")
    private String agentPayId;

    /**
     * 响应码
     */
    @TableField(value = "response_code")
    private String responseCode;

    /**
     * 响应信息
     */
    @TableField(value = "response_msg")
    private String responseMsg;

    /**
     * 回调地址
     */
    @TableField(value = "notify_url")
    private String notifyUrl;

    /**
     * 状态同步是否成功
     */
    @TableField(value = "sync_succeeded")
    private Boolean syncSucceeded;

    /**
     * 创建人
     */
    @TableField(value = "crt_by")
    private String crtBy;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField(value = "crt_time")
    private Date crtTime;

    /**
     * 修改人
     */
    @TableField(value = "upt_by")
    private String uptBy;

    /**
     * 修改时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField(value = "upt_time")
    private Date uptTime;

    /**
     * 是否删除
     */
    @TableField(value = "del_flag")
    private Boolean delFlag;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}