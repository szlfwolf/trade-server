package com.smartpay.cbp.channel.controller;

import com.smartpay.cbp.channel.dto.*;
import com.smartpay.cbp.channel.service.ChannelRegisterService;
import com.smartpay.cbp.common.core.domain.Result;
import com.smartpay.cbp.common.core.utils.poi.ExcelUtil;
import com.smartpay.cbp.common.core.web.controller.BaseController;
import com.smartpay.cbp.common.core.web.page.TableDataInfo;
import com.smartpay.cbp.common.security.annotation.RequiresPermissions;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @author Carer
 * @desc  用户渠道备案控制器
 * @date 2022/11/23 9:38
 */
@Api(tags = "渠道备案菜单")
@RestController
@RequestMapping("/channel/register")
@RequiredArgsConstructor
@Slf4j
public class ChannelRegisterController extends BaseController {

    private final ChannelRegisterService channelRegisterService;

    /**
     * 获取分页用户渠道备案信息
     * @param channelRegisterPageReqDto 查询参数
     * @return 分页数据信息
     */
    @ApiOperation(value = "获取分页用户渠道备案信息",response = TableDataInfo.class)
    @RequiresPermissions("channel:register:list")
    @GetMapping("/pages")
    public TableDataInfo pageList(ChannelRegisterPageReqDto channelRegisterPageReqDto){
        log.info("用户渠道备案分页查询入参:{}",channelRegisterPageReqDto);
        startPage();
        List<ChannelRegisterPageRspDto> channelRegisterPages
                = channelRegisterService.pageList(channelRegisterPageReqDto);
        return getDataTable(channelRegisterPages);
    }

    /**
     * 导出用户渠道备案信息
     * @param response                  响应体
     * @param channelRegisterPageReqDto    分页查询入参
     */
    @ApiOperation(value = "导出用户渠道备案信息")
    @RequiresPermissions("channel:register:export")
    @PostMapping("/export")
    public void export(HttpServletResponse response,ChannelRegisterPageReqDto channelRegisterPageReqDto){
        log.info("用户渠道备案导出查询入参:{}",channelRegisterPageReqDto);
        List<ChannelRegisterPageRspDto> channelRegisterPages = channelRegisterService.pageList(channelRegisterPageReqDto);
        ExcelUtil<ChannelRegisterPageRspDto> util = new ExcelUtil<>(ChannelRegisterPageRspDto.class);
        util.exportExcel(response, channelRegisterPages, "用户渠道备案数据");
    }

    /**
     * 根据数据主键查询备案详情
     * @param id    数据主键
     * @return 渠道备案详情
     */
    @ApiOperation(value = "根据主键查询用户渠道备案详细信息",response = ChannelRegisterDetailDto.class)
    @GetMapping("/detail/{id}")
    public Result<RegisterApplyRequestV2Biz> detailById(@PathVariable("id")String id){
        log.info("获取渠道备案详情入参:{}",id);
        return Result.ok(channelRegisterService.detailById(id));
    }

    /**
     * 备案重发
     * @param retryReqDto 重发数据
     * @return 重发结果
     */
    @ApiOperation(value = "渠道备案重发",response = Result.class)
    @PostMapping("/retry")
    public Result<Boolean> retry(RegisterRetryReqDto retryReqDto){
        log.info("渠道备案重发入参:{}",retryReqDto);
        return Result.ok(channelRegisterService.retry(retryReqDto));
    }
}
