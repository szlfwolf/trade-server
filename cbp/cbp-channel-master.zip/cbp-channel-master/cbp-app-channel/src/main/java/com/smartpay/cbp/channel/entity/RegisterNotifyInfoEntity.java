package com.smartpay.cbp.channel.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDateTime;
import java.util.Date;

/**
 * t_channel_register_notify_info
 * @author carer
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_channel_register_notify_info")
public class RegisterNotifyInfoEntity extends Model<RegisterNotifyInfoEntity> {
    /**
     * 主键
     */
    @TableId(type = IdType.ASSIGN_ID)
    private String id;

    /**
     * 请求流水号
     */
    private String reqNo;

    /**
     * 父请求流水号
     */
    private String parentReqNo;

    /**
     * 回调内容
     */
    private String notifyContent;

    /**
     * 回调时间
     */
    private LocalDateTime notifyTime;

    /**
     * 回调结果 S-成功，F-失败，N-未知
     */
    private String notifyResult;

    /**
     * 回调处理状态 0未处理，1已处理
     */
    private String notifyDealStatus;

    /**
     * 备注
     */
    private String remark;

    /**
     * 逻辑删除标识 0-未删除，1删除
     */
    @TableLogic(value = "0",delval = "1")
    private String delFlag;

    /**
     * 创建人
     */
    private String crtBy;

    /**
     * 创建时间
     */
    private LocalDateTime crtTime;

    /**
     * 更新人
     */
    private String uptBy;

    /**
     * 更新时间
     */
    private LocalDateTime uptTime;

    private static final long serialVersionUID = 1L;
}