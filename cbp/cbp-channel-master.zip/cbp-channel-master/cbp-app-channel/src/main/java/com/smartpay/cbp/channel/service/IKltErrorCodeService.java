package com.smartpay.cbp.channel.service;

import com.smartpay.cbp.channel.entity.KltErrorCode;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author admin
* @description 针对表【t_klt_error_code(渠道失败响应码配置表)】的数据库操作Service
* @createDate 2022-11-08 14:26:41
*/
public interface IKltErrorCodeService extends IService<KltErrorCode> {

}
