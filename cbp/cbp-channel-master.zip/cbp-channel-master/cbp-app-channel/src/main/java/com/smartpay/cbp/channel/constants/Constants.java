package com.smartpay.cbp.channel.constants;

/**
 * @author ：guogangqiang
 * @version ：V1.0
 * @description ：系统常量
 * @date ：2022/11/8 16:45
 */
public class Constants {

    public static final String FILL_ZERO = "0";

    /**
     * 提现MQ队列配置相关
     */
    public static final String PAYMENT_APPLY_QUEUE = "PAYMENT_APPLY_QUEUE";
    public static final String REMIT_EXCHANGE = "REMIT_EXCHANGE";


    /**
     * 开联通代付返回成功码
     */
    public static final String KLT_PAYMENT_SUCCESS_CODE = "000000";

    /**
     * 开联通返回签名字段
     */
    public static final String SIGN_FIELD_NAME = "signMsg";
}
