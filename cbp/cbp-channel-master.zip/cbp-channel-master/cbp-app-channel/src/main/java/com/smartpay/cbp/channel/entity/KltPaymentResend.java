package com.smartpay.cbp.channel.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 代付重发记录表
 * @TableName t_klt_payment_resend
 */
@TableName(value ="t_klt_payment_resend")
@Data
public class KltPaymentResend implements Serializable {
    /**
     * 主键id
     */
    @TableId(value = "id")
    private String id;

    /**
     * 关联订单id(t_remit_order)
     */
    @TableField(value = "remit_order_id")
    private String remitOrderId;

    /**
     * 商户号
     */
    @TableField(value = "merchant_no")
    private String merchantNo;

    /**
     * 订单号
     */
    @TableField(value = "order_no")
    private String orderNo;

    /**
     * 订单金额
     */
    @TableField(value = "amt")
    private Long amt;

    /**
     * 重发状态
     */
    @TableField(value = "status")
    private String status;

    /**
     * 创建人
     */
    @TableField(value = "crt_by")
    private String crtBy;

    /**
     * 创建时间
     */
    @TableField(value = "crt_time")
    private Date crtTime;

    /**
     * 更新人
     */
    @TableField(value = "upt_by")
    private String uptBy;

    /**
     * 更新时间
     */
    @TableField(value = "upt_time")
    private Date uptTime;

    /**
     * 是否删除
     */
    @TableField(value = "del_flag")
    private String delFlag;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}