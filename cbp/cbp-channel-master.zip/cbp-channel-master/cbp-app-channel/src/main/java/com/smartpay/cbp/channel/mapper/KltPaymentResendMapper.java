package com.smartpay.cbp.channel.mapper;

import com.smartpay.cbp.channel.entity.KltPaymentResend;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author admin
* @description 针对表【t_klt_payment_resend(代付重发记录表)】的数据库操作Mapper
* @createDate 2022-11-08 14:26:41
* @Entity com.smartpay.cbp.channel.entity.KltPaymentResend
*/
public interface KltPaymentResendMapper extends BaseMapper<KltPaymentResend> {

}




