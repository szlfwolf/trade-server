package com.smartpay.cbp.channel.mapper;

import com.smartpay.cbp.channel.entity.KltPaymentRecord;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author admin
* @description 针对表【t_klt_payment_record(请求互联网单笔代付记录表)】的数据库操作Mapper
* @createDate 2022-11-08 14:26:41
* @Entity com.smartpay.cbp.channel.entity.KltPaymentRecord
*/
public interface KltPaymentRecordMapper extends BaseMapper<KltPaymentRecord> {

}




