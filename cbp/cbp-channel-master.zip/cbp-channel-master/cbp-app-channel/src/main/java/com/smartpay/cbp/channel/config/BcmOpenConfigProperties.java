package com.smartpay.cbp.channel.config;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;

import java.io.Serializable;

/**
 * @author admin
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ConfigurationProperties(prefix = "bcm.open")
@RefreshScope
public class BcmOpenConfigProperties implements Serializable {

    private static final long serialVersionUID = 1L;

    private String openAppId;

    private String openPrivateKey;

    private String openApigwPubKey;

    private String chnlFlag;

    /**
     * 支付公司统一社会信用代码
     */
    private String comIdNo;

    /**
     * 支付公司名称
     */
    private String comName;

    private String hostUrl;

    private String uploadUrl;

    private String registerPath = "/api/tfis/registerApply/v2";

    private String uploadPath = "/api/common/fileUpload/v1";

    /**
     * 连接超时时间设置
     */
    private Integer connectTimeout;

    /**
     * 响应超时时间设置
     */
    private Integer readTimeout;

}
