package com.smartpay.cbp.channel.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.rabbitmq.client.Channel;
import com.smartpay.cbp.channel.dto.PaymentReqQueryDto;
import com.smartpay.cbp.channel.entity.KltPaymentReq;

import java.util.List;

/**
 * @author admin
 * @description 针对表【t_klt_payment_req(互联网单笔代付请求表)】的数据库操作Service
 * @createDate 2022-11-08 14:26:41
 */
public interface IKltPaymentReqService extends IService<KltPaymentReq> {

    /**
     * 发送互联网单笔代付
     *
     * @param remitOrderId 代付订单id
     */
    void singlePayment(String remitOrderId);

    /**
     * 查询发送成功未同步的代付请求
     *
     * @return 代付请求计划 {@link KltPaymentReq}
     */
    List<KltPaymentReq> listForSyncStatusTask();

    /**
     * 重发代付
     *
     * @param kltPaymentReqId 渠道端代付id {@link KltPaymentReq}
     */
    void resendPayment(String kltPaymentReqId);

    /**
     * 条件查询
     *
     * @param condition 条件筛选实体
     * @return 提现订单
     */
    List<KltPaymentReq> list(PaymentReqQueryDto condition);

}
