package com.smartpay.cbp.channel.config;

import cn.hutool.core.lang.Snowflake;
import org.springframework.stereotype.Component;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/7 10:36
 */
@Component
public class IdGenerator {

    private final Snowflake snowflake = new Snowflake();

    /**
     * 生成字符串id
     *
     * @return 字符串id
     */
    public String nextId() {

        return snowflake.nextIdStr();
    }

    /**
     * 根据算法生成的id获取id生成时间
     *
     * @param id 待推断的id
     * @return 生成id的毫秒时间戳
     */
    public long getGenerateDateTime(String id) {
        return snowflake.getGenerateDateTime(Long.parseLong(id));
    }

}
