package com.smartpay.cbp.channel.service;

import com.smartpay.cbp.channel.dto.MerchantUserInfoReqDto;
import com.smartpay.cbp.channel.dto.RegisterRetryReqDto;
import com.smartpay.cbp.channel.dto.UploadReqDto;
import com.smartpay.cbp.channel.dto.UploadRspDto;
import com.smartpay.cbp.channel.entity.RegisterInfoEntity;

import java.util.List;

/**
 * @author Carer
 * @desc 注册服务
 * @date 2022/11/9 16:11
 */
public interface RegisterService {

    /**
     * 渠道发送备案信息
     * @param merchantUserInfo 用户备案信息
     * @return 请求流水号
     */
    String channelRegisterSend(MerchantUserInfoReqDto merchantUserInfo);

    /**
     * 文件上传
     * @param uploadReqDto 上传对象
     * @return 上传文件组装参数
     */
    List<UploadRspDto> uploadRegisterFile(UploadReqDto uploadReqDto);

    /**
     * 是否支持渠道
     * @return true支持，false不支持
     */
    Boolean supportChannel(String channelNo);

    /**
     * 重发
     * @param registerInfoEntity 原始数据
     * @param retryReqDto 页面组装数据
     */
    void retry(RegisterInfoEntity registerInfoEntity, RegisterRetryReqDto retryReqDto);
}
