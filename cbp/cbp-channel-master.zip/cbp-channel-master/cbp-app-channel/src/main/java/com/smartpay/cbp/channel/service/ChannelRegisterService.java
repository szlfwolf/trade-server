package com.smartpay.cbp.channel.service;

import com.smartpay.cbp.channel.dto.*;

import java.util.List;

/**
 * @author Carer
 * @desc
 * @date 2022/11/23 10:23
 */
public interface ChannelRegisterService {

    /**
     * 获取分页用户渠道备案信息
     * @param channelRegisterPageReqDto 查询参数
     * @return 分页数据信息
     */
    List<ChannelRegisterPageRspDto> pageList(ChannelRegisterPageReqDto channelRegisterPageReqDto);

    /**
     * 根据数据主键查询备案详情
     * @param id    数据主键
     * @return 渠道备案详情
     */
    RegisterApplyRequestV2Biz detailById(String id);

    /**
     * 备案重发
     * @param retryReqDto 重发数据
     * @return 重发结果
     */
    Boolean retry(RegisterRetryReqDto retryReqDto);
}
