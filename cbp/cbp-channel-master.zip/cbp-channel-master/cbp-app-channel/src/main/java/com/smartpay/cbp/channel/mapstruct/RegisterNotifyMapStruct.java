package com.smartpay.cbp.channel.mapstruct;

import com.smartpay.cbp.channel.dto.RegisterNotifyInfoDto;
import com.smartpay.cbp.channel.entity.RegisterNotifyInfoEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * @author Carer
 * @desc
 * @date 2022/11/17 16:59
 */
@Mapper(componentModel = "spring")
public interface RegisterNotifyMapStruct {

    /**
     * 转换成Dto对象
     * @param registerNotifyInfoEntity 数据库实体
     * @return 映射对象
     */
    @Mapping(target = "modifyAll", ignore = true)
    RegisterNotifyInfoDto toDto(RegisterNotifyInfoEntity registerNotifyInfoEntity);
}
