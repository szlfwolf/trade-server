package com.smartpay.cbp.channel.dto;

import com.bocom.api.BizContent;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.util.List;

/**
 * @author Carer
 * @desc
 * @date 2022/11/23 11:28
 */
@ApiModel(value = "用户渠道备案详情")
@Data
@EqualsAndHashCode(callSuper = false)
public class RegisterApplyRequestV2Biz implements BizContent, Serializable {

    private static final long serialVersionUID = 927481976559520537L;
    /**
     * 渠道标识
     */
    @ApiModelProperty(value = "渠道标识")
    @JsonProperty("chnl_flag")
    private String chnlFlag;

    /**
     * 渠道流水号
     */
    @ApiModelProperty(value = "渠道流水号")
    @JsonProperty("chnl_seq_no")
    private String chnlSeqNo;

    /**
     * 操作标识
     */
    @ApiModelProperty(value = "操作标识")
    @JsonProperty("opt_flag")
    private String optFlag;

    /**
     * 客户类型
     */
    @ApiModelProperty(value = "客户类型")
    @JsonProperty("cust_type")
    private String custType;

    /**
     * 客户证件类型
     */
    @ApiModelProperty(value = "客户证件类型")
    @JsonProperty("cust_id_type")
    private String custIdType;

    /**
     * 客户证件号码
     */
    @ApiModelProperty(value = "客户证件号码")
    @JsonProperty("cust_id_no")
    private String custIdNo;

    /**
     * 客户名称
     */
    @ApiModelProperty(value = "客户名称")
    @JsonProperty("cust_name")
    private String custName;

    /**
     * 商户编号
     */
    @ApiModelProperty(value = "商户编号")
    @JsonProperty("merch_no")
    private String merchNo;

    /**
     * 税务登记证号
     */
    @ApiModelProperty(value = "税务登记证号")
    @JsonProperty("tax_registration_no")
    private String taxRegistrationNo;

    /**
     * 营业执照号
     */
    @ApiModelProperty(value = "营业执照号")
    @JsonProperty("license_no")
    private String licenseNo;

    /**
     * 证件有效期
     */
    @ApiModelProperty(value = "证件有效期")
    @JsonProperty("exp_date")
    private String expDate;

    /**
     * 职业
     */
    @ApiModelProperty(value = "职业")
    @JsonProperty("profession")
    private String profession;

    /**
     * 国籍
     */
    @ApiModelProperty(value = "国籍")
    @JsonProperty("nationality")
    private String nationality;

    /**
     * 性别
     */
    @ApiModelProperty(value = "性别")
    @JsonProperty("sex")
    private String sex;

    /**
     * 出生日期
     */
    @ApiModelProperty(value = "出生日期")
    @JsonProperty("birth_date")
    private String birthDate;

    /**
     * 支付公司证件类型
     */
    @ApiModelProperty(value = "支付公司证件类型")
    @JsonProperty("com_id_type")
    private String comIdType;

    /**
     * 支付公司证件号
     */
    @ApiModelProperty(value = "支付公司证件号")
    @JsonProperty("com_id_no")
    private String comIdNo;

    /**
     * 支付公司名称
     */
    @ApiModelProperty(value = "支付公司名称")
    @JsonProperty("com_name")
    private String comName;

    /**
     * 住所/营业场所代码
     */
    @ApiModelProperty(value = "住所/营业场所代码")
    @JsonProperty("bus_addr_code")
    private String busAddrCode;

    /**
     * 住所/营业场所名称
     */
    @ApiModelProperty(value = "住所/营业场所名称")
    @JsonProperty("bus_addr_name")
    private String busAddrName;

    /**
     * 经营地址
     */
    @ApiModelProperty(value = "经营地址")
    @JsonProperty("bus_address")
    private String busAddress;

    /**
     * 常驻国家代码
     */
    @ApiModelProperty(value = "常驻国家代码")
    @JsonProperty("resi_country_code")
    private String resiCountryCode;

    /**
     * 常驻国家名称
     */
    @ApiModelProperty(value = "常驻国家名称")
    @JsonProperty("resi_country_name")
    private String resiCountryName;

    /**
     * 经济类型代码
     */
    @ApiModelProperty(value = "经济类型代码")
    @JsonProperty("eco_type_code")
    private String ecoTypeCode;

    /**
     * 所属行业属性代码
     */
    @ApiModelProperty(value = "所属行业属性代码")
    @JsonProperty("indus_attri_code")
    private String indusAttriCode;

    /**
     * 是否特殊经济区内企业
     */
    @ApiModelProperty(value = "是否特殊经济区内企业")
    @JsonProperty("special_eco_region")
    private String specialEcoRegion;

    /**
     * 所属外汇局代码
     */
    @ApiModelProperty(value = "所属外汇局代码")
    @JsonProperty("belo_ex_office_code")
    private String beloExOfficeCode;

    /**
     * 企业类型
     */
    @ApiModelProperty(value = "企业类型")
    @JsonProperty("enterprise_type")
    private String enterpriseType;

    /**
     * 申报方式
     */
    @ApiModelProperty(value = "申报方式")
    @JsonProperty("declare_way")
    private String declareWay;

    /**
     * 机构地址
     */
    @ApiModelProperty(value = "机构地址")
    @JsonProperty("address")
    private String address;

    /**
     * 邮政编码
     */
    @ApiModelProperty(value = "邮政编码")
    @JsonProperty("post_code")
    private String postCode;

    /**
     * 联系EMAIL
     */
    @ApiModelProperty(value = "联系EMAIL")
    @JsonProperty("email")
    private String email;

    /**
     * 经办行名称
     */
    @ApiModelProperty(value = "经办行名称")
    @JsonProperty("hand_bank_name")
    private String handBankName;

    /**
     * 主营业务（经营范围）
     */
    @ApiModelProperty(value = "主营业务（经营范围）")
    @JsonProperty("main_business")
    private String mainBusiness;

    /**
     * 注册国别代码
     */
    @ApiModelProperty(value = "注册国别代码")
    @JsonProperty("register_country_code")
    private String registerCountryCode;

    /**
     * 注册国别名称
     */
    @ApiModelProperty(value = "注册国别名称")
    @JsonProperty("register_country_name")
    private String registerCountryName;

    /**
     * 机构联系人
     */
    @ApiModelProperty(value = "机构联系人")
    @JsonProperty("contacts")
    private String contacts;

    /**
     * 机构联系电话
     */
    @ApiModelProperty(value = "机构联系电话")
    @JsonProperty("contact_phone")
    private String contactPhone;

    /**
     * 机构传真号码
     */
    @ApiModelProperty(value = "机构传真号码")
    @JsonProperty("fax")
    private String fax;

    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    @JsonProperty("remarks")
    private String remarks;

    /**
     * 备注1
     */
    @ApiModelProperty(value = "备注1")
    @JsonProperty("remarks1")
    private String remarks1;

    /**
     * LEI编码
     */
    @ApiModelProperty(value = "LEI编码")
    @JsonProperty("lei_code")
    private String leiCode;

    /**
     * 关联人
     */
    @ApiModelProperty(value = "关联人信息")
    @JsonProperty("cust_manager_list")
    private List<CustManager> custManagerList;

    /**
     * 外方投资者国别
     */
    @ApiModelProperty(value = "外方投资者国别")
    @JsonProperty("inv_country_list")
    private List<InvCountry> invCountryList;

    /**
     * 附件信息
     */
    @ApiModelProperty(value = "附件信息")
    @JsonProperty("doc_list")
    private List<Doc> docList;
}
