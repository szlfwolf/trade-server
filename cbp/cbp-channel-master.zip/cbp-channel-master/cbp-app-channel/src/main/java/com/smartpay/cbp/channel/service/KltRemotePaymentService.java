package com.smartpay.cbp.channel.service;

/**
 * @Description: 调用远程开联通服务
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/16 11:30
 * @Version: 1.0
 */
public interface KltRemotePaymentService {
}
