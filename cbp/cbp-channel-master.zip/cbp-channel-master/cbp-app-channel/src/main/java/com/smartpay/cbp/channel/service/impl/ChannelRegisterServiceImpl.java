package com.smartpay.cbp.channel.service.impl;

import com.alibaba.fastjson.JSON;
import com.smartpay.cbp.channel.dto.ChannelRegisterPageReqDto;
import com.smartpay.cbp.channel.dto.ChannelRegisterPageRspDto;
import com.smartpay.cbp.channel.dto.RegisterApplyRequestV2Biz;
import com.smartpay.cbp.channel.dto.RegisterRetryReqDto;
import com.smartpay.cbp.channel.entity.RegisterInfoEntity;
import com.smartpay.cbp.channel.repository.RegisterInfoRepository;
import com.smartpay.cbp.channel.service.ChannelRegisterService;
import com.smartpay.cbp.channel.service.RegisterService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * @author Carer
 * @desc
 * @date 2022/11/23 10:23
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class ChannelRegisterServiceImpl implements ChannelRegisterService {

    private final RegisterInfoRepository registerInfoRepository;

    private final RegisterService registerService;

    /**
     * 获取分页用户渠道备案信息
     *
     * @param channelRegisterPageReqDto 查询参数
     * @return 分页数据信息
     */
    @Override
    public List<ChannelRegisterPageRspDto> pageList(ChannelRegisterPageReqDto channelRegisterPageReqDto) {
        return registerInfoRepository
                .pageList(channelRegisterPageReqDto);
    }

    /**
     * 根据数据主键查询备案详情
     *
     * @param id 数据主键
     * @return 渠道备案详情
     */
    @Override
    public RegisterApplyRequestV2Biz detailById(String id) {
        RegisterInfoEntity registerInfoEntity = Optional.ofNullable(registerInfoRepository.getById(id))
                .orElseThrow(() -> new RuntimeException("渠道备案信息不存在！"));
        return JSON.parseObject(registerInfoEntity.getReqData(), RegisterApplyRequestV2Biz.class);
    }

    /**
     * 备案重发
     *
     * @param retryReqDto 重发数据
     * @return 重发结果
     */
    @Override
    public Boolean retry(RegisterRetryReqDto retryReqDto) {
        RegisterInfoEntity registerInfoEntity = Optional.ofNullable(registerInfoRepository.getById(retryReqDto.getId()))
                .orElseThrow(() -> new RuntimeException("渠道备案信息不存在！"));
        registerService.retry(registerInfoEntity,retryReqDto);
        return Boolean.TRUE;
    }
}
