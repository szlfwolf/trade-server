package com.smartpay.cbp.channel.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * @author Carer
 * @desc
 * @date 2022/11/17 15:59
 */
@Data
@EqualsAndHashCode
@ToString(callSuper = true)
public class RegisterNotifyBizContent {

    /**
     * 该参数必输，为通知第三方的URL.
     */
    @JsonProperty("notify_url")
    private String notifyUrl;

    /**
     * 渠道标识
     */
    @JsonProperty("chnl_flag")
    private String chnlFlag;

    /**
     * 报文标识号
     */
    @JsonProperty("trace_no")
    private String traceNo;

    /**
     * 原备案流水号
     */
    @JsonProperty("chnl_seq_no")
    private String chnlSeqNo;

    /**
     * 000-注册备案；
     * 001-汇款申请；
     * 002-锁汇
     * 005-商户提现与订单统计
     */
    @JsonProperty("ope_type")
    private String opeType;

    /**
     * 我行申请编号
     */
    @JsonProperty("app_code")
    private String appCode;

    /**
     * 收款人账号
     */
    @JsonProperty("req_acct")
    private String reqAcct;

    /**
     * 收款人名称
     */
    @JsonProperty("req_name")
    private String reqName;

    /**
     * 收款人常驻国家地区代码
     */
    @JsonProperty("req_country_code")
    private String reqCountryCode;

    /**
     * 付款人账号
     */
    @JsonProperty("pay_acct")
    private String payAcct;

    /**
     * 付款人名称
     */
    @JsonProperty("pay_name")
    private String payName;

    /**
     * 收款人常驻国家地区代码
     */
    @JsonProperty("pay_country_code")
    private String payCountryCode;

    /**
     * 手续费
     */
    @JsonProperty("serv_charge")
    private String servCharge;

    /**
     * 交易状态    000-注册备案：1-成功 0-失败
     * 001-汇款申请：1-成功 0-失败 2-处理中
     * 002-锁汇：1-已锁汇  0-已撤销
     * 005:1成功0-失败
     */
    @JsonProperty("status")
    private String status;

    /**
     * 委托书编号   操作类型002-锁汇、0-已撤销必输
     */
    @JsonProperty("contract_no")
    private String contractNo;

    /**
     * 原合约牌价  操作类型002-锁汇、0-已撤销必输
     */
    @JsonProperty("rate")
    private String rate;

    /**
     * 原交割日  操作类型002-锁汇、0-已撤销必输
     */
    @JsonProperty("origin_deliv_date")
    private String originDelivDate;

    /**
     * 损益币种  操作类型002-锁汇、0-已撤销必输
     * 默认为CNY
     */
    @JsonProperty("branch_pl_cur")
    private String branchPlCur;

    /**
     * 损益金额  操作类型002-锁汇、0-已撤销必输
     */
    @JsonProperty("branch_pl_amt")
    private String branchPlAmt;

    /**
     * 备注   暂定格式示例：
     * XXXXAA01：客户反洗钱未通过|XXXXBB02：客户外管局类型检查未通过
     */
    @JsonProperty("remarks")
    private String remarks;

    /**
     * 备注1 预留字段
     */
    @JsonProperty("remarks1")
    private String remarks1;
}
