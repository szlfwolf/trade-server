package com.smartpay.cbp.channel.rabbit;

import com.alibaba.fastjson2.JSON;
import com.rabbitmq.client.Channel;
import com.smartpay.cbp.channel.constants.Constants;
import com.smartpay.cbp.channel.dto.RemitOrderMqDTO;
import com.smartpay.cbp.channel.service.IKltPaymentReqService;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.annotation.*;
import org.springframework.amqp.support.AmqpHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Objects;

/**
 * @Description: 校验失败提现明细文件监听
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/9 14:21
 * @Version: 1.0
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class RemitOrderListen {

    private final IKltPaymentReqService kltPaymentReqService;


    /**
     * 监听提现订单请求
     *
     * @param message mq信息
     */
    @SneakyThrows
    @RabbitListener(bindings = {@QueueBinding(value = @Queue(value = Constants.PAYMENT_APPLY_QUEUE)
            , exchange = @Exchange(Constants.REMIT_EXCHANGE), key = Constants.PAYMENT_APPLY_QUEUE)}
            , ackMode = "MANUAL")
    @RabbitHandler
    public void onMessage(Message message, Channel channel, String msg) {
        MessageProperties messageProperties = message.getMessageProperties();
        try {
            //预取模式20条处理完成再继续消费MQ信息
            channel.basicQos(0, 20, false);
            if (log.isInfoEnabled()) {
                log.info("【开始】代付订单发送互联网,消息内容：{}", msg);
            }
            if (!StringUtils.isBlank(msg)) {
                RemitOrderMqDTO remitOrderMqDTO = JSON.parseObject(msg, RemitOrderMqDTO.class);
                if (Objects.nonNull(remitOrderMqDTO)) {
                    //消费提现订单发送互联网
                    kltPaymentReqService.singlePayment(remitOrderMqDTO.getRemitOrderId());
                }
            }
            //手动确认消息消费成功
            channel.basicAck(messageProperties.getDeliveryTag(), true);
            log.info("【结束】发送互联网处理成功，请求订单id:{}", msg);
        } catch (IOException e) {
            log.error("【异常】渠道端代付发送互联网异常", e);
            channel.basicNack(messageProperties.getDeliveryTag(), false, true);
        }
    }
}
