package com.smartpay.cbp.channel.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * @author Carer
 * @desc  列表页响应参数
 * @date 2022/11/23 10:28
 */
@ApiModel(value = "用户渠道备案列表响应")
@Data
@EqualsAndHashCode(callSuper = false)
public class ChannelRegisterPageRspDto implements Serializable {
    private static final long serialVersionUID = -5989049657911462786L;

    /**
     * 数据主键
     */
    @ApiModelProperty(value = "数据主键")
    private String id;

    /**
     * 请求流水号
     */
    @ApiModelProperty(value = "请求流水号")
    private String reqNo;

    /**
     * 渠道用户号
     */
    @ApiModelProperty(value = "渠道用户号")
    private String openUserNo;

    /**
     * 用户类型,1-企业，2-个人
     */
    @ApiModelProperty(value = "用户类型:1-企业,2-个人")
    private String userType;

    /**
     * 姓名、法人姓名
     */
    @ApiModelProperty(value = "姓名-脱敏")
    private String nameMask;

    /**
     * 证件号-脱敏
     */
    @ApiModelProperty(value = "证件号-脱敏")
    private String certIdMask;

    /**
     * 备案渠道编号
     */
    @ApiModelProperty(value = "备案渠道编号")
    private String channelNo;

    /**
     * 备案渠道名称
     */
    @ApiModelProperty(value = "备案渠道名称")
    private String channelName;
}
