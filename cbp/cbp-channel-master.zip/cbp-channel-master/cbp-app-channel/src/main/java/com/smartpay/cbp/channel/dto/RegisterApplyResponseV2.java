package com.smartpay.cbp.channel.dto;

import com.bocom.api.BocomResponse;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author admin
 */
public class RegisterApplyResponseV2 extends BocomResponse {
    /**
     * 备注
     */
    @JsonProperty("remarks")
    private String remarks;

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}