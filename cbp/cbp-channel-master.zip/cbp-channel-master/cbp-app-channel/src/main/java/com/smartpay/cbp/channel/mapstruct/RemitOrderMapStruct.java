package com.smartpay.cbp.channel.mapstruct;

import com.smartpay.cbp.channel.dto.SinglePaymentDTO;
import com.smartpay.cbp.channel.entity.KltPaymentReq;
import com.smartpay.cbp.core.response.RemitOrderResponse;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

/**
 * @Description: 提现订单转化
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/10 11:45
 * @Version: 1.0
 */
@Mapper(componentModel = "spring")
public interface RemitOrderMapStruct {

    @Mappings({
            @Mapping(source = "crtTime", target = "orderDateTime", dateFormat = "yyyyMMddHHmmss"),
            @Mapping(source = "bankAccountNo", target = "accountNo"),
            @Mapping(source = "bankAccountName", target = "accountName"),
            @Mapping(source = "remitType", target = "accountType"),
            @Mapping(source = "cnapsNo", target = "bankNo"),
            @Mapping(source = "bankName", target = "bankName")
    })
    SinglePaymentDTO toSinglePaymentDTO(RemitOrderResponse remitOrderResponse);

    @Mappings({
            @Mapping(source = "id", target = "remitOrderId"),
            @Mapping(source = "orderNo", target = "mchtOrderNo"),
            @Mapping(source = "crtTime", target = "orderDateTime", dateFormat = "yyyy-MM-dd HH:mm:ss"),
            @Mapping(source = "bankAccountNo", target = "accountNo"),
            @Mapping(source = "bankAccountName", target = "accountName"),
            @Mapping(source = "remitType", target = "accountType"),
            @Mapping(source = "cnapsNo", target = "bankNo"),
            @Mapping(source = "bankName", target = "bankName")
    })
    KltPaymentReq toKltPaymentReq(RemitOrderResponse remitOrderResponse);

}
