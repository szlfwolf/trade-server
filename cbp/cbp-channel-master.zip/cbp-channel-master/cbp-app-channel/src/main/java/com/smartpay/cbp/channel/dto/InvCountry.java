package com.smartpay.cbp.channel.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * @author Carer
 * @desc
 * @date 2022/11/23 11:30
 */
@ApiModel(value = "外方投资者国别")
@Data
@EqualsAndHashCode(callSuper = false)
public class InvCountry implements Serializable {
    private static final long serialVersionUID = 6917044243057282621L;

    /**
     * 外方投资者国别（地区）名称
     */
    @ApiModelProperty(value = "外方投资者国别（地区）名称")
    @JsonProperty("inv_country_name")
    private String invCountryName;

    /**
     * 外方投资者国别（地区）代码
     */
    @ApiModelProperty(value = "外方投资者国别（地区）代码")
    @JsonProperty("inv_country_code")
    private String invCountryCode;
}
