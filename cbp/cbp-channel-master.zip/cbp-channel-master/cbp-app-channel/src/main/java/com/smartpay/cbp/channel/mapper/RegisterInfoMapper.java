package com.smartpay.cbp.channel.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.smartpay.cbp.channel.dto.ChannelRegisterPageReqDto;
import com.smartpay.cbp.channel.dto.ChannelRegisterPageRspDto;
import com.smartpay.cbp.channel.entity.RegisterInfoEntity;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @author admin
 */
@Mapper
public interface RegisterInfoMapper extends BaseMapper<RegisterInfoEntity> {

    /**
     * 分页查询备案信息
     *
     * @param channelRegisterPageReqDto 分页请求查询参数
     * @return 查询分页内容
     */
    List<ChannelRegisterPageRspDto> pageList(ChannelRegisterPageReqDto channelRegisterPageReqDto);
}