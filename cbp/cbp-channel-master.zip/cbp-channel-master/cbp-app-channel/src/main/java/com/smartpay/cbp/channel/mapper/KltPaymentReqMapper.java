package com.smartpay.cbp.channel.mapper;

import com.smartpay.cbp.channel.entity.KltPaymentReq;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author admin
* @description 针对表【t_klt_payment_req(互联网单笔代付请求表)】的数据库操作Mapper
* @createDate 2022-11-08 14:26:41
* @Entity com.smartpay.cbp.channel.entity.KltPaymentReq
*/
public interface KltPaymentReqMapper extends BaseMapper<KltPaymentReq> {

}




