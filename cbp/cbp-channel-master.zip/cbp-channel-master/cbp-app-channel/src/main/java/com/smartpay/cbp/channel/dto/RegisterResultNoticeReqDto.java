package com.smartpay.cbp.channel.dto;

import com.bocom.api.BizContent;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.io.Serializable;

/**
 * @author Carer
 * @desc
 * @date 2022/11/17 15:58
 */
@Data
@EqualsAndHashCode
@ToString(callSuper = true)
public class RegisterResultNoticeReqDto implements Serializable {

    private static final long serialVersionUID = 6196111394817773310L;

    /**
     * 通知内容
     */
    @JsonProperty("notify_biz_content")
    private RegisterNotifyBizContent bizContent;

    /**
     * 前面
     */
    @JsonProperty("sign")
    private String sign;
}
