package com.smartpay.cbp.channel.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * 请求互联网单笔代付记录表
 *
 * @TableName t_klt_payment_record
 */
@TableName(value = "t_klt_payment_record")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class KltPaymentRecord implements Serializable {
    /**
     * 主键id
     */
    @TableId(value = "id")
    private String id;

    /**
     * 关联互联网代付请求id
     */
    @TableField(value = "payment_req_id")
    private String paymentReqId;

    /**
     * 商户号
     */
    @TableField(value = "merchant_no")
    private String merchantNo;

    /**
     * 商户订单号
     */
    @TableField(value = "merchant_order_no")
    private String merchantOrderNo;

    /**
     * 日志标签 {@link com.smartpay.cbp.channel.enums.KltPaymentTag}
     */
    @TableField(value = "tag")
    private String tag;

    /**
     * 异常信息
     */
    @TableField(value = "exception")
    private String exception;

    /**
     * 请求体
     */
    @TableField(value = "request")
    private String request;

    /**
     * 响应体
     */
    @TableField(value = "response")
    private String response;

    /**
     * 创建人
     */
    @TableField(value = "crt_by")
    private String crtBy;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField(value = "crt_time")
    private Date crtTime;

    /**
     * 修改人
     */
    @TableField(value = "upt_by")
    private String uptBy;

    /**
     * 修改时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField(value = "upt_time")
    private Date uptTime;

    /**
     * 是否删除
     */
    @TableField(value = "del_flag")
    private String delFlag;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}