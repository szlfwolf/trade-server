package com.smartpay.cbp.channel.dto;


import com.bocom.api.BocomResponse;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author admin
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class FileUploadResponseV1 extends BocomResponse {


    @JsonProperty("document_id")
    private String documentId;

}
