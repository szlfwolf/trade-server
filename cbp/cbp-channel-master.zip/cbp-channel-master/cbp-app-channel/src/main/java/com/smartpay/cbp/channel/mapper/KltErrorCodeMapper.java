package com.smartpay.cbp.channel.mapper;

import com.smartpay.cbp.channel.entity.KltErrorCode;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author admin
* @description 针对表【t_klt_error_code(渠道失败响应码配置表)】的数据库操作Mapper
* @createDate 2022-11-08 14:26:41
* @Entity com.smartpay.cbp.channel.entity.KltErrorCode
*/
public interface KltErrorCodeMapper extends BaseMapper<KltErrorCode> {

}




