package com.smartpay.cbp.channel.config;

import cn.hutool.core.lang.Snowflake;
import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.RandomUtil;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author Carer
 * @desc
 * @date 2022/11/10 11:04
 */
@Configuration
public class SnowflakeConfig {

    /**
     * 雪花算法配置
     * @return 雪花算法
     */
    @Bean
    @ConditionalOnMissingBean(value = Snowflake.class)
    public Snowflake createSnowflake(){
        //随机值不能太大，0~31之间即可
        return IdUtil.getSnowflake(RandomUtil.randomLong(0,31),RandomUtil.randomLong(0,31));
    }
}
