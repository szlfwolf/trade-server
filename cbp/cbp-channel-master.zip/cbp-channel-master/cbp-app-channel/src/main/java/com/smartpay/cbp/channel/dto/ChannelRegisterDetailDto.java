package com.smartpay.cbp.channel.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * @author Carer
 * @desc  渠道备案详情
 * @date 2022/11/23 10:45
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class ChannelRegisterDetailDto implements Serializable {
    private static final long serialVersionUID = -8485865259578044944L;


}
