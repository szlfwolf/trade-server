package com.smartpay.cbp.channel.enums;

/**
 * @Description: 发送类型（正常发送，重发）
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/11 16:30
 * @Version: 1.0
 */
public enum KltPaymentSendType {

    FIRST_SEND("首次发送"),
    RESEND("重发"),

    ;

    public final String desc;

    KltPaymentSendType(String desc) {
        this.desc = desc;
    }

}
