package com.smartpay.cbp.channel.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.smartpay.cbp.account.dto.req.AccountAgentPayReqDTO;
import com.smartpay.cbp.account.dto.req.AccountAgentPayRollbackReqDTO;
import com.smartpay.cbp.account.dto.res.AccountAgentPayResDTO;
import com.smartpay.cbp.account.dto.res.AccountAgentPayRollbackResDTO;
import com.smartpay.cbp.channel.config.IdGenerator;
import com.smartpay.cbp.channel.constants.Constants;
import com.smartpay.cbp.channel.dto.PaymentReqQueryDto;
import com.smartpay.cbp.channel.dto.SinglePaymentDTO;
import com.smartpay.cbp.channel.entity.KltPaymentReq;
import com.smartpay.cbp.channel.enums.AppCode;
import com.smartpay.cbp.channel.enums.KltPaymentOrderStatus;
import com.smartpay.cbp.channel.enums.KltPaymentSendType;
import com.smartpay.cbp.channel.enums.SequenceType;
import com.smartpay.cbp.channel.handler.RemoteCallHandler;
import com.smartpay.cbp.channel.mapper.KltPaymentReqMapper;
import com.smartpay.cbp.channel.mapstruct.KltPaymentReqMapStruct;
import com.smartpay.cbp.channel.mapstruct.RemitOrderMapStruct;
import com.smartpay.cbp.channel.response.SinglePaymentResp;
import com.smartpay.cbp.channel.service.IKltPaymentReqService;
import com.smartpay.cbp.channel.service.IKltRemoteApiService;
import com.smartpay.cbp.channel.util.KltCertUtil;
import com.smartpay.cbp.channel.util.SequenceUtil;
import com.smartpay.cbp.common.core.domain.R;
import com.smartpay.cbp.core.dto.RemitResultDTO;
import com.smartpay.cbp.core.response.RemitOrderResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static com.smartpay.cbp.channel.util.Dates.Pattern.yyyyMMddHHmmss;

/**
 * @author admin
 * @description 针对表【t_klt_payment_req(互联网单笔代付请求表)】的数据库操作Service实现
 * @createDate 2022-11-08 14:26:41
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class KltPaymentReqServiceImpl extends ServiceImpl<KltPaymentReqMapper, KltPaymentReq>
        implements IKltPaymentReqService {

    /**
     * 默认每次最多处理300条
     */
    private final static int DEFAULT_LIMIT = 300;

    private final RemoteCallHandler remoteCallHandler;

    private final RemitOrderMapStruct remitOrderMapStruct;

    private final IKltRemoteApiService kltRemoteApiService;

    @Lazy
    @Autowired
    private IKltPaymentReqService kltPaymentReqService;

    private final IdGenerator idGenerator;

    private final KltCertUtil kltCertUtil;

    private final KltPaymentReqMapStruct kltPaymentReqMapStruct;


    /**
     * 发送互联网单笔代付
     *
     * @param remitOrderId 代付订单id
     */
    @Override
    public void singlePayment(@NotNull String remitOrderId) {

        RemitOrderResponse remitOrder = remoteCallHandler.getRemitOrderById(remitOrderId);
        if (Objects.isNull(remitOrder)) {
            log.error("【结束】未查询到提现订单信息，提现订单id：{}", remitOrderId);
            return;
        }
        //构建互联网请求体，保存请求体
        KltPaymentReq kltPaymentReq = remitOrderMapStruct.toKltPaymentReq(remitOrder);
        String kltPaymentReqId = idGenerator.nextId();
        kltPaymentReq.setId(kltPaymentReqId)
                .setSendType(String.valueOf(KltPaymentSendType.FIRST_SEND.ordinal()))
                .setOrderState(String.valueOf(KltPaymentOrderStatus.INIT.ordinal()))
                .setSyncSucceeded(true);
        kltPaymentReqService.save(kltPaymentReq);

        SinglePaymentDTO singlePaymentDTO = remitOrderMapStruct.toSinglePaymentDTO(remitOrder);
        singlePaymentDTO.setAccountType(StringUtils.equals(remitOrder.getRemitType(), "P") ? "1" : "2");
        singlePaymentDTO.setMchtOrderNo(kltPaymentReqId);

        //发送开联通单笔代付
        sendKltPayment(kltPaymentReq, singlePaymentDTO);


    }

    /**
     * 查询发送成功，状态未同步的代付请求
     *
     * @return
     */
    @Override
    public List<KltPaymentReq> listForSyncStatusTask() {
        return kltPaymentReqService.lambdaQuery()
                .eq(KltPaymentReq::getSyncSucceeded, false)
                .eq(KltPaymentReq::getOrderState, String.valueOf(KltPaymentOrderStatus.SEND_SUCCESS.ordinal()))
                .eq(KltPaymentReq::getDelFlag, false)
                .last(String.format("limit %d", DEFAULT_LIMIT))
                .list();
    }

    /**
     * 重发代付
     *
     * @param kltPaymentReqId 渠道端代付id {@link KltPaymentReq}
     */
    @Override
    public void resendPayment(String kltPaymentReqId) {
        KltPaymentReq paymentReq = Optional.ofNullable(kltPaymentReqService.getById(kltPaymentReqId))
                .orElseThrow(AppCode.C03001::toCodeException);
        //发送失败的代付请求才可重发
        AppCode.C03002.assertHasTrue(Objects.equals(paymentReq.getOrderState(), String.valueOf(KltPaymentOrderStatus.SEND_FAIL.ordinal())));
        paymentReq.setSendType(String.valueOf(KltPaymentSendType.RESEND));
        SinglePaymentDTO singlePaymentDTO = kltPaymentReqMapStruct.toSinglePaymentDTO(paymentReq);
        //发送开联通单笔代付
        sendKltPayment(paymentReq, singlePaymentDTO);
    }

    /**
     * 分页条件查询
     *
     * @param condition 条件筛选实体
     * @return
     */
    @Override
    public List<KltPaymentReq> list(PaymentReqQueryDto condition) {
        return lambdaQuery().eq(StringUtils.isNotBlank(condition.getMerchantNo()), KltPaymentReq::getMerchantNo, condition.getMerchantNo())
                .eq(StringUtils.isNotBlank(condition.getStatus()), KltPaymentReq::getOrderState, condition.getStatus())
                .eq(StringUtils.isNotBlank(condition.getBatchNo()), KltPaymentReq::getBatchNo, condition.getBatchNo())
                .eq(StringUtils.isNotBlank(condition.getAccountType()), KltPaymentReq::getAccountType, condition.getAccountType())
                .eq(StringUtils.isNotBlank(condition.getBatchNo()), KltPaymentReq::getBatchNo, condition.getBatchNo())
                .eq(StringUtils.isNotBlank(condition.getMchtOrderNo()), KltPaymentReq::getMchtOrderNo, condition.getMchtOrderNo())
                .ge(Objects.isNull(condition.getCrtStartTime()), KltPaymentReq::getCrtTime, condition.getCrtStartTime())
                .le(Objects.isNull(condition.getCrtEndTime()), KltPaymentReq::getCrtTime, condition.getCrtEndTime())
                .eq(KltPaymentReq::getDelFlag, false)
                .orderByDesc(KltPaymentReq::getId)
                .list();
    }

    /**
     * 发送互联网代付
     *
     * @param kltPaymentReq
     * @param singlePaymentDTO
     */
    private void sendKltPayment(KltPaymentReq kltPaymentReq, SinglePaymentDTO singlePaymentDTO) {
        // 手续费记账
        String agentPayId = agentPay(kltPaymentReq);
        kltPaymentReq.setAgentPayId(agentPayId);

        //记账失败修改状态
        if (StringUtils.isBlank(agentPayId)) {
            kltPaymentReqService.updateById(kltPaymentReq);
            return;
        }

        //发送互联网单笔代付
        SinglePaymentResp singlePaymentResp = kltRemoteApiService.singlePayment(singlePaymentDTO, kltPaymentReq.getId());
        if (Objects.isNull(singlePaymentResp)) {
            //代付失败回退记账
            agentPayRollback(agentPayId, kltPaymentReq.getMerchantNo(), kltPaymentReq.getId());
            kltPaymentReq.setOrderState(String.valueOf(KltPaymentOrderStatus.SEND_FAIL.ordinal()));
            kltPaymentReqService.updateById(kltPaymentReq);
            return;
        }
        //解签失败不进行状态同步修改
        boolean verifySuccess = kltCertUtil.verify(singlePaymentResp, Constants.SIGN_FIELD_NAME);
        if (!verifySuccess) {
            log.error("【结束】互联网代付响应解签失败,渠道端提现订单id:{}", singlePaymentDTO.getMchtOrderNo());
            return;
        }
        if (!Objects.equals(singlePaymentResp.getResponseCode(), Constants.KLT_PAYMENT_SUCCESS_CODE)) {
            //代付失败回退记账
            agentPayRollback(agentPayId, kltPaymentReq.getMerchantNo(), kltPaymentReq.getId());
        }
        //修改渠道端代付状态
        String orderStatus = String.valueOf(KltPaymentOrderStatus.SEND_SUCCESS.ordinal());
        KltPaymentOrderStatus kltPaymentOrderStatus = KltPaymentOrderStatus.toEnum(singlePaymentResp.getOrderState());
        if (kltPaymentOrderStatus != KltPaymentOrderStatus.INIT) {
            orderStatus = String.valueOf(kltPaymentOrderStatus.ordinal());
        }
        kltPaymentReq.setOrderState(orderStatus);
        kltPaymentReq.setResponseCode(singlePaymentResp.getResponseCode());
        kltPaymentReq.setResponseMsg(singlePaymentResp.getResponseMsg());
        kltPaymentReqService.updateById(kltPaymentReq);

        //没有终态不进行状态同步
        if (kltPaymentOrderStatus == KltPaymentOrderStatus.IN_PROCESS ||
                kltPaymentOrderStatus == KltPaymentOrderStatus.INIT) {
            return;
        }

        //提现代付状态同步至核心业务端
        boolean syncSuccess = syncToCore(singlePaymentResp, kltPaymentReq.getRemitOrderId());
        if (!syncSuccess) {
            kltPaymentReq.setSyncSucceeded(false);
            kltPaymentReqService.updateById(kltPaymentReq);
        }
    }

    /**
     * 记账操作（手续费+账户余额）
     *
     * @param kltPaymentReq
     * @return
     */
    private String agentPay(KltPaymentReq kltPaymentReq) {
        AccountAgentPayReqDTO request = new AccountAgentPayReqDTO();
        request.setFee(kltPaymentReq.getFeeAmt());
        request.setAmount(kltPaymentReq.getAmt());
        request.setAgentPayNo(kltPaymentReq.getMchtOrderNo());
        request.setCurrency(kltPaymentReq.getFeeCurrencyType());
        request.setSecondLevelProductCode(kltPaymentReq.getProductCode());
        request.setAgentPaySerialId(kltPaymentReq.getId());
        request.setPayeeName(kltPaymentReq.getAccountName());
        request.setPayeeAccount(kltPaymentReq.getAccountNo());
        request.setPayeeBank(kltPaymentReq.getBankName());

        request.setMerchantNo(kltPaymentReq.getMerchantNo());
        request.setRequestSystemId(kltPaymentReq.getId());
        request.setRequestId(SequenceUtil.genSerialNo(SequenceType.AGENT_PAY_REQUEST));
        request.setRequestTime(yyyyMMddHHmmss.now());

        R<AccountAgentPayResDTO> result = remoteCallHandler.agentPay(request);
        if (R.isError(result)) {
            kltPaymentReq.setOrderState(String.valueOf(KltPaymentOrderStatus.SEND_FAIL.ordinal()));
            kltPaymentReq.setResponseMsg(result.getMsg());
            kltPaymentReq.setResponseCode(result.getCode());
            return null;
        }
        return Objects.isNull(result.getData()) ? null : result.getData().getTxnId();
    }


    /**
     * 回退记账操作（手续费+账户余额）
     *
     * @param agentPayId
     * @return
     */
    private String agentPayRollback(String agentPayId, String merchantNo, String kltPaymentReqId) {
        AccountAgentPayRollbackReqDTO request = new AccountAgentPayRollbackReqDTO();
        request.setOriginTxnId(agentPayId);

        request.setMerchantNo(merchantNo);
        request.setRequestSystemId(kltPaymentReqId);
        request.setRequestId(SequenceUtil.genSerialNo(SequenceType.AGENT_PAY_REQUEST));
        request.setRequestTime(yyyyMMddHHmmss.now());

        AccountAgentPayRollbackResDTO result = remoteCallHandler.agentPayRollback(request);
        return result.getTxnId();
    }

    /**
     * 同步代付状态至核心业务端
     *
     * @param singlePaymentResp 单笔代付响应结果
     * @param remitOrderId      提现订单id
     * @return 是否同步成功
     */
    private boolean syncToCore(@NotNull SinglePaymentResp singlePaymentResp, @NotNull String remitOrderId) {
        //通知核心业务端提现状态信息
        RemitResultDTO remitResultDTO = RemitResultDTO.builder()
                .orderStatus(singlePaymentResp.getOrderState())
                .responseMsg(singlePaymentResp.getResponseMsg())
                .responseCode(singlePaymentResp.getResponseCode())
                .remitOrderId(remitOrderId)
                .build();
        try {
            return remoteCallHandler.notifyRemitResult(remitResultDTO);
        } catch (Exception e) {
            log.error("【异常】渠道端同步至核心业务提现状态异常", e);
            return false;
        }
    }

}




