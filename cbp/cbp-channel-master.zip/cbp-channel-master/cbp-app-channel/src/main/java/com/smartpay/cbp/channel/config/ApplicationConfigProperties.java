package com.smartpay.cbp.channel.config;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @author Carer
 * @desc
 * @date 2022/11/10 13:49
 */
@Component
@ConfigurationProperties(prefix = "app.channel")
@Data
@EqualsAndHashCode(callSuper = false)
public class ApplicationConfigProperties {

    /**
     * 域名访问地址
     */
    private String domainHost;
}
