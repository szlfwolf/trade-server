package com.smartpay.cbp.channel.controller;

import com.bocom.api.BocomResponse;
import com.smartpay.cbp.channel.dto.RegisterNotifyInfoDto;
import com.smartpay.cbp.channel.dto.RegisterResultNoticeReqDto;
import com.smartpay.cbp.channel.service.NotifyService;
import com.smartpay.cbp.common.core.domain.R;
import com.smartpay.cbp.common.security.annotation.InnerAuth;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

/**
 * @author Carer
 * @desc 回调处理器
 * @date 2022/11/17 15:14
 */
@RestController
@RequestMapping("/notify")
@Slf4j
@RequiredArgsConstructor
public class NotifyController {

    private final NotifyService notifyService;

    /**
     * 银行备案结果回调
     * @param registerNoticeReq 回调内容
     * @return 响应
     */
    @PostMapping("/register/result")
    public BocomResponse registerResultNotify(@RequestBody RegisterResultNoticeReqDto registerNoticeReq){
        log.info("备案用户银行回调入参:{}",registerNoticeReq);
        return notifyService.registerResultNotify(registerNoticeReq);
    }

    /**
     * 根据主键获取备案回调通知内容
     * @param id 通知主键
     * @return 回调信息
     */
    @InnerAuth
    @GetMapping("/register/info/{id}")
    public R<RegisterNotifyInfoDto> getRegisterNotifyInfo(@PathVariable("id")String id){
        log.info("根据主键获取备案回调通知内容入参id:{}",id);
        return R.ok(notifyService.getRegisterNotifyInfoById(id));
    }

    /**
     * 通知更新回调处理成功
     * @param id 主键
     * @return 更新
     */
    @InnerAuth
    @PostMapping("/update/{id}")
    public R<Boolean> updateNotifyFinish(@PathVariable("id")String id){
        log.info("修改备案表数据处理成功！入参：{}",id);
        notifyService.updateNotifyFinish(id);
        return R.ok(Boolean.TRUE);
    }
}
