package com.smartpay.cbp.channel.service;

import com.smartpay.cbp.channel.dto.SinglePaymentDTO;
import com.smartpay.cbp.channel.dto.SinglePaymentQueryDTO;
import com.smartpay.cbp.channel.response.SinglePaymentQueryResp;
import com.smartpay.cbp.channel.response.SinglePaymentResp;

/**
 * @Description: 远程调用开联通互联网接口
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/17 9:32
 * @Version: 1.0
 */
public interface IKltRemoteApiService {

    /**
     * 互联网单笔代付
     *
     * @param singlePaymentDTO
     * @param kltPaymentReqId
     * @return
     */
    SinglePaymentResp singlePayment(SinglePaymentDTO singlePaymentDTO, String kltPaymentReqId);

    /**
     * 单笔代付查询
     *
     * @param singlePaymentQueryResp
     * @param singlePaymentQueryDTO
     * @param paymentReqId
     * @return
     */
    SinglePaymentQueryResp singlePaymentQuery(SinglePaymentQueryDTO singlePaymentQueryDTO,
                                              String paymentReqId);

}
