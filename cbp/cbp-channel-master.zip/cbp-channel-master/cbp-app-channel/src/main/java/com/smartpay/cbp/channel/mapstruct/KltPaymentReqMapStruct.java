package com.smartpay.cbp.channel.mapstruct;

import com.smartpay.cbp.channel.dto.SinglePaymentDTO;
import com.smartpay.cbp.channel.entity.KltPaymentReq;
import com.smartpay.cbp.channel.vo.KltPaymentReqVo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * @Description: 请求开联通互联网
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/17 20:51
 * @Version: 1.0
 */
@Mapper(componentModel = "spring")
public interface KltPaymentReqMapStruct {

    @Mapping(source = "id", target = "mchtOrderNo")
    SinglePaymentDTO toSinglePaymentDTO(KltPaymentReq kltPaymentReq);

    KltPaymentReqVo toKltPaymentReqVo(KltPaymentReq kltPaymentReq);

}
