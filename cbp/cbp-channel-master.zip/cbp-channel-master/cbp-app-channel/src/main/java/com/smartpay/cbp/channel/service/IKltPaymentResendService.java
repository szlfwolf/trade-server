package com.smartpay.cbp.channel.service;

import com.smartpay.cbp.channel.entity.KltPaymentResend;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author admin
* @description 针对表【t_klt_payment_resend(代付重发记录表)】的数据库操作Service
* @createDate 2022-11-08 14:26:41
*/
public interface IKltPaymentResendService extends IService<KltPaymentResend> {

}
