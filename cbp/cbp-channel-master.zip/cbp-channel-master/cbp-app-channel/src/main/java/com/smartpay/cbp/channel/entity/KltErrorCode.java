package com.smartpay.cbp.channel.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 渠道失败响应码配置表
 *
 * @TableName t_klt_error_code
 */
@TableName(value = "t_klt_error_code")
@Data
public class KltErrorCode implements Serializable {
    /**
     * 主键id
     */
    @TableId(value = "id")
    private String id;

    /**
     * 错误响应码
     */
    @TableField(value = "error_code")
    private String errorCode;

    /**
     * 错误响应信息
     */
    @TableField(value = "error_msg")
    private String errorMsg;

    /**
     * 禁用状态
     */
    @TableField(value = "disabled")
    private String disabled;

    /**
     * 创建人
     */
    @TableField(value = "crt_by")
    private String crtBy;

    /**
     * 创建时间
     */
    @TableField(value = "crt_time")
    private Date crtTime;

    /**
     * 修改人
     */
    @TableField(value = "upt_by")
    private String uptBy;

    /**
     * 修改时间
     */
    @TableField(value = "upt_time")
    private Date uptTime;

    /**
     * 是否删除
     */
    @TableField(value = "del_flag")
    private String delFlag;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}