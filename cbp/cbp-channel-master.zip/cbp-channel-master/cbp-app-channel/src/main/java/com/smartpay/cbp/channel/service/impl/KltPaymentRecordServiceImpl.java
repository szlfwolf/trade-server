package com.smartpay.cbp.channel.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.smartpay.cbp.channel.entity.KltPaymentRecord;
import com.smartpay.cbp.channel.service.IKltPaymentRecordService;
import com.smartpay.cbp.channel.mapper.KltPaymentRecordMapper;
import org.springframework.stereotype.Service;

/**
* @author admin
* @description 针对表【t_klt_payment_record(请求互联网单笔代付记录表)】的数据库操作Service实现
* @createDate 2022-11-08 14:26:41
*/
@Service
public class KltPaymentRecordServiceImpl extends ServiceImpl<KltPaymentRecordMapper, KltPaymentRecord>
    implements IKltPaymentRecordService {

}




