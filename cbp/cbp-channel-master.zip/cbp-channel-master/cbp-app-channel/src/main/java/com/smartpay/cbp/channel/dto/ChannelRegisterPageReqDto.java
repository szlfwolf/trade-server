package com.smartpay.cbp.channel.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author Carer
 * @desc  用户渠道备案列表查询入参
 * @date 2022/11/23 10:16
 */
@ApiModel(value = "用户渠道备案列表查询入参")
@Data
@EqualsAndHashCode(callSuper = false)
public class ChannelRegisterPageReqDto implements Serializable {
    private static final long serialVersionUID = 8525660287101433353L;

    /**
     * 用户编号
     */
    @ApiModelProperty(value = "用户编号")
    private String userNo;

    /**
     * 渠道用户号
     */
    @ApiModelProperty(value = "渠道用户号")
    private String openUserNo;

    /**
     * 创建起始日期
     */
    @ApiModelProperty(value = "创建起始日期：yyyy-MM-dd 00:00:00")
    @DateTimeFormat(pattern = "yyyy-MM-dd 00:00:00")
    private LocalDateTime crtStart;

    /**
     * 创建结束日期
     */
    @ApiModelProperty(value = "创建结束日期：yyyy-MM-dd 23:59:59")
    @DateTimeFormat(pattern = "yyyy-MM-dd 23:59:59")
    private LocalDateTime crtEnd;

    /**
     * 用户类型,${@link com.smartpay.cbp.core.constant.UserType}
     */
    @ApiModelProperty(value = "用户类型")
    private String userType;

    /**
     * 请求状态
     */
    @ApiModelProperty(value = "请求状态")
    private String reqStatus;

    /**
     * 备案状态
     */
    @ApiModelProperty(value = "备案状态")
    private String regStatus;

    /**
     * 用户名称
     */
    @ApiModelProperty(value = "用户名称")
    private String name;

    /**
     * 证件号
     */
    @ApiModelProperty(value = "证件号")
    private String certId;
}
