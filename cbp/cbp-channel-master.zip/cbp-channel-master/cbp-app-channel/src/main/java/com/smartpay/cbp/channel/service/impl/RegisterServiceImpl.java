package com.smartpay.cbp.channel.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.LocalDateTimeUtil;
import cn.hutool.core.io.FileUtil;
import cn.hutool.core.lang.Snowflake;
import cn.hutool.core.text.CharSequenceUtil;
import cn.hutool.core.util.IdcardUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.http.HttpUtil;
import com.alibaba.fastjson.JSON;
import com.bocom.api.BocomApiException;
import com.bocom.api.DefaultBocomClient;
import com.bocom.api.utils.FileItem;
import com.smartpay.cbp.channel.config.ApplicationConfigProperties;
import com.smartpay.cbp.channel.config.BcmOpenConfigProperties;
import com.smartpay.cbp.channel.constant.ReqResultType;
import com.smartpay.cbp.channel.constant.ServerChannelConstants;
import com.smartpay.cbp.channel.constant.UserType;
import com.smartpay.cbp.channel.dto.*;
import com.smartpay.cbp.channel.entity.RegisterInfoEntity;
import com.smartpay.cbp.channel.repository.RegisterInfoRepository;
import com.smartpay.cbp.channel.service.FileService;
import com.smartpay.cbp.channel.service.RegisterService;
import com.smartpay.cbp.channel.util.KltMaskUtil;
import com.smartpay.cbp.core.dto.FileInfoRspDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Carer
 * @desc
 * @date 2022/11/9 16:12
 */
@Service("bgwRegister")
@RequiredArgsConstructor
@Slf4j
public class RegisterServiceImpl implements RegisterService {


    private final BcmOpenConfigProperties bcmOpenConfigProperties;

    @Qualifier("bocomClient")
    private final DefaultBocomClient bocomClient;

    @Qualifier("bocomFileClient")
    private final DefaultBocomClient bocomFileClient;

    private final Snowflake snowflake;

    private final RegisterInfoRepository registerInfoRepository;

    private final ApplicationConfigProperties applicationConfigProperties;

    private final FileService fileService;

    private static final String[] ID_TYPE = new String[]{"11","12","13"};

    /**
     * 澳门证件类型Id
     */
    private static final String AM_ID = "820000";

    /**
     * 渠道发送备案信息
     *
     * @param merchantUserInfo 用户备案信息
     * @return 请求流水号
     */
    @Override
    public String channelRegisterSend(MerchantUserInfoReqDto merchantUserInfo) {
        //判断备案类型，组装发送参数，存入数据库
        String msgId = snowflake.nextIdStr();
        RegisterApplyRequestV2 req = buildUserRegisterReq(merchantUserInfo,msgId);
        String reqJsonStr = JSON.toJSONString(req.getBizContent());
        RegisterInfoEntity registerInfoEntity = saveRegisterEntity(merchantUserInfo, msgId, reqJsonStr);
        log.info("渠道流水号：{},请求内容：{}",msgId,reqJsonStr);
        String respStr = sendBgw(msgId,req,registerInfoEntity);
        log.info("渠道流水号：{},备案响应:{}" ,msgId, respStr);
        registerInfoEntity.setRspTime(LocalDateTimeUtil.now());
        registerInfoEntity.setRspData(respStr);
        registerInfoRepository.updateById(registerInfoEntity);
        return msgId;
    }

    private String sendBgw(String msgId,RegisterApplyRequestV2 req,RegisterInfoEntity registerInfoEntity){
        String respStr;
        try {
            RegisterApplyResponseV2 resp = bocomClient.execute(req, msgId);
            respStr = JSON.toJSONString(resp);
            if(!resp.isSuccess()){
                registerInfoEntity.setReqResult(ReqResultType.FAIL.getCode());
            }else {
                registerInfoEntity.setReqResult(ReqResultType.SUCCESS.getCode());
            }
        } catch (BocomApiException e) {
            respStr = MessageFormat.format("渠道备案发送异常！错误码:{0},错误内容:{1},异常信息:{2}"
                    ,e.getErrCode(),e.getErrMsg(),e.getMessage());
            registerInfoEntity.setReqResult(ReqResultType.FAIL.getCode());
        }
        return respStr;
    }

    /**
     * 文件上传
     * @param uploadReqDto 上传对象
     * @return 上传文件组装参数
     */
    @Override
    public List<UploadRspDto> uploadRegisterFile(UploadReqDto uploadReqDto) {
        List<FileInfoRspDto> fileInfos = fileService.getFileInfosByIds(uploadReqDto.getFileIds());
        if(CollUtil.isEmpty(fileInfos)){
            return Collections.emptyList();
        }
        return fileInfos.stream().map(this::uploadFileBgw).collect(Collectors.toList());
    }

    /**
     * 是否支持渠道
     *
     * @param channelNo    渠道号
     * @return true支持，false不支持
     */
    @Override
    public Boolean supportChannel(String channelNo) {
        return "BGW".equals(channelNo);
    }

    /**
     * 重发
     *
     * @param registerInfoEntity 原始数据
     * @param retryReqDto        页面组装数据
     */
    @Override
    public void retry(RegisterInfoEntity registerInfoEntity, RegisterRetryReqDto retryReqDto) {
        String msgId = snowflake.nextIdStr();
        registerInfoEntity.setId(null);
        registerInfoEntity.setReqNo(msgId);
        registerInfoEntity.setAsyncFlag("0");
        registerInfoEntity.setReqData(JSON.toJSONString(retryReqDto));
        registerInfoEntity.setReqTime(LocalDateTimeUtil.now());
        registerInfoRepository.save(registerInfoEntity);
        RegisterApplyRequestV2 request = new RegisterApplyRequestV2();
        request.setServiceUrl(bcmOpenConfigProperties.getHostUrl() + bcmOpenConfigProperties.getRegisterPath());
        log.info("备案请求重发送url:{}",request.getServiceUrl());
        request.setBizContent(retryReqDto);
        log.info("备案重发渠道流水号：{},请求内容：{}",msgId,registerInfoEntity.getReqData());
        String respStr = sendBgw(msgId,request,registerInfoEntity);
        log.info("备案重发渠道流水号：{},备案响应:{}" ,msgId, respStr);
        registerInfoEntity.setRspTime(LocalDateTimeUtil.now());
        registerInfoEntity.setRspData(respStr);
        registerInfoRepository.updateById(registerInfoEntity);
    }

    private UploadRspDto uploadFileBgw(FileInfoRspDto fileInfoRspDto){
        FileUploadRequestV1 request = new FileUploadRequestV1();
        request.setServiceUrl(bcmOpenConfigProperties.getUploadUrl() + bcmOpenConfigProperties.getUploadPath());
        request.setFileItem(new FileItem(HttpUtil.downloadFileFromUrl(fileInfoRspDto.getFileLink()
                ,FileUtil.file(System.getProperty("java.io.tmpdir")))));
        String msgId = snowflake.nextIdStr();
        UploadRspDto uploadRspDto = new UploadRspDto();
        uploadRspDto.setFileName(fileInfoRspDto.getFileName());
        try {
            FileUploadResponseV1 resp = bocomFileClient.execute(request, msgId);
            if(resp.isSuccess()){
                uploadRspDto.setDocId(resp.getDocumentId());
            }
        } catch (BocomApiException e) {
            log.error("银行上传文件异常:ErrCode-{},ErrMsg-{}",e.getErrCode(),e.getErrMsg());
            throw new RuntimeException(e);
        }
        return uploadRspDto;
    }

    private RegisterInfoEntity saveRegisterEntity(MerchantUserInfoReqDto merchantUserInfo,String msgId,String reqJsonData){
        RegisterInfoEntity registerInfoEntity = new RegisterInfoEntity();
        registerInfoEntity.setReqNo(msgId);
        registerInfoEntity.setParentReqNo(registerInfoEntity.getReqNo());
        registerInfoEntity.setChannelNo(merchantUserInfo.getChannelNo());
        registerInfoEntity.setUserNo(merchantUserInfo.getUserNo());
        registerInfoEntity.setOpenUserNo(merchantUserInfo.getOpenUserNo());
        registerInfoEntity.setUserType(merchantUserInfo.getUserType());
        //TODO 证件加密存储
        registerInfoEntity.setNameEnc(merchantUserInfo.getName());
        registerInfoEntity.setNameMask(KltMaskUtil.nameMask(merchantUserInfo.getName()));
        //TODO 手机号加密存储
        registerInfoEntity.setMobileNoEnc(merchantUserInfo.getMobileNo());
        registerInfoEntity.setMobileNoMask(KltMaskUtil.phoneNoMask(merchantUserInfo.getMobileNo()));
        registerInfoEntity.setCertType(merchantUserInfo.getCertType());
        //TODO 证件号加密存储
        registerInfoEntity.setCertIdEnc(merchantUserInfo.getCertId());
        registerInfoEntity.setCertIdMask(KltMaskUtil.idNoMask(merchantUserInfo.getCertId()));
        registerInfoEntity.setNotifyUrl(applicationConfigProperties.getDomainHost()+"/notify");
        registerInfoEntity.setReqData(reqJsonData);
        registerInfoEntity.setAsyncFlag("0");
        registerInfoEntity.setReqTime(LocalDateTimeUtil.now());
        registerInfoRepository.save(registerInfoEntity);
        return registerInfoEntity;
    }

    private void commonBuild(RegisterApplyRequestV2Biz bizContent,MerchantUserInfoReqDto merchantUserInfo){
        bizContent.setChnlFlag(bcmOpenConfigProperties.getChnlFlag());
        bizContent.setOptFlag("1");
        bizContent.setComIdType("02");
        bizContent.setComIdNo(bcmOpenConfigProperties.getComIdNo());
        bizContent.setComName(bcmOpenConfigProperties.getComName());
        bizContent.setMerchNo(merchantUserInfo.getOpenUserNo());
        bizContent.setContacts(merchantUserInfo.getName());
        bizContent.setContactPhone(merchantUserInfo.getMobileNo());
        bizContent.setAddress(merchantUserInfo.getAddress());
        bizContent.setResiCountryCode("CHN");
        bizContent.setResiCountryName("中国");
        bizContent.setBusAddress(merchantUserInfo.getAddress());
        //文件上传后响应内容
        if(CollUtil.isNotEmpty(merchantUserInfo.getUploadFiles())){
            bizContent.setDocList(merchantUserInfo.getUploadFiles().stream().filter(ObjectUtil::isNotNull)
                    .map(undress ->{
                        Doc doc =
                                new Doc();
                        doc.setDocId(undress.getDocId());
                        doc.setDocName(undress.getFileName());
                        return doc;
                    }).collect(Collectors.toList()));
        }
    }

    private void personBuild(RegisterApplyRequestV2Biz bizContent,MerchantUserInfoReqDto merchantUserInfo){
        bizContent.setCustType("D");
        String idType = getCustIdTypeByIdCard(merchantUserInfo.getCertId());
        bizContent.setCustIdType(idType);
        if(CharSequenceUtil.equalsAny(idType,ID_TYPE)){
            //并且客户类型选择F－对私中国非居民
            bizContent.setCustType("F");
        }
        bizContent.setCustIdNo(merchantUserInfo.getCertId());
        bizContent.setCustName(merchantUserInfo.getName());
        bizContent.setProfession(merchantUserInfo.getProfessionCode());
        bizContent.setNationality("CHN");
        bizContent.setSex(IdcardUtil.getGenderByIdCard(merchantUserInfo.getCertId())==1? "1":"2");
        bizContent.setBirthDate(IdcardUtil.getBirth(merchantUserInfo.getCertId()));
        bizContent.setExpDate(CharSequenceUtil.replace(merchantUserInfo.getCertExpEndDate(),"-", ""));
        bizContent.setSpecialEcoRegion("0");
        bizContent.setContacts(merchantUserInfo.getName());
        bizContent.setBusAddress(merchantUserInfo.getAddress());
    }

    private void companyBuild(RegisterApplyRequestV2Biz bizContent,MerchantUserInfoReqDto merchantUserInfo){
        bizContent.setCustType("C");
        bizContent.setCustIdType("02");
        bizContent.setCustIdNo(merchantUserInfo.getLicenseNo());
        //原系统custName未传值
        bizContent.setCustName(merchantUserInfo.getName());
        //法人姓名
        bizContent.setContacts(merchantUserInfo.getName());
        bizContent.setExpDate(CharSequenceUtil.replace(merchantUserInfo.getLicenseEndDate(),"-",""));
        bizContent.setContactPhone(merchantUserInfo.getMobileNo());
        List<CustManager> custManagers = new ArrayList<>();
        CustManager mama = new CustManager();
        mama.setManagerType("1");
        //法人证件号
        mama.setManagerIdNo(merchantUserInfo.getCertId());
        //法人姓名
        mama.setManagerName(merchantUserInfo.getName());
        mama.setManagerIdType("01");
        mama.setManagerExpDate(CharSequenceUtil.replace(merchantUserInfo.getCertExpEndDate(),"-",""));
        mama.setManagerAddress("");
        mama.setManagerNationality("CHN");
        mama.setManagerStockRightRatio("");
        mama.setManagerCompanyPosition("");
        custManagers.add(mama);
        bizContent.setCustManagerList(custManagers);
        String countryList = merchantUserInfo.getInvCountryCode();
        if (CharSequenceUtil.isNotBlank(countryList)) {
            List<String> invCountryArr = CharSequenceUtil.split(countryList, "|");
            List<InvCountry> invCountryList = invCountryArr.stream()
                    .map(invCountry -> {
                String countryName = ServerChannelConstants.getCountryMap().get(invCountry);
                InvCountry model = new InvCountry();
                model.setInvCountryCode(invCountry);
                model.setInvCountryName(countryName);
                return model;
            }).collect(Collectors.toList());
            bizContent.setInvCountryList(invCountryList);
        }
        bizContent.setBusAddrCode(merchantUserInfo.getAreaCode());
        bizContent.setDeclareWay("01");
        bizContent.setMainBusiness(CharSequenceUtil
                .sub(merchantUserInfo.getBizScope(),0,500));
        bizContent.setBusAddress(merchantUserInfo.getOpAddr());
        // 住所/营业场所名称
        bizContent.setBusAddrName(ServerChannelConstants.getAreaCodeMap().get(merchantUserInfo.getAreaCode()));
        // 经济类型代码
        bizContent.setEcoTypeCode(merchantUserInfo.getAttrCode());
        // 所属行业属性代码
        bizContent.setIndusAttriCode(merchantUserInfo.getIndustryCode());
        bizContent.setSpecialEcoRegion(CharSequenceUtil.isNotBlank(merchantUserInfo.getIsTaxFree())?
                merchantUserInfo.getIsTaxFree():"0");
        bizContent.setEnterpriseType(merchantUserInfo.getTaxFreeCode());
        bizContent.setResiCountryName("中国");
        bizContent.setRegisterCountryCode("CHN");
        bizContent.setRegisterCountryName("中国");
        bizContent.setPostCode(merchantUserInfo.getPostCode());
    }

    private RegisterApplyRequestV2 buildUserRegisterReq(MerchantUserInfoReqDto merchantUserInfo,String msgId) {
        RegisterApplyRequestV2 request = new RegisterApplyRequestV2();
        request.setServiceUrl(bcmOpenConfigProperties.getHostUrl() + bcmOpenConfigProperties.getRegisterPath());
        log.info("备案请求发送url:{}",request.getServiceUrl());
        RegisterApplyRequestV2Biz bizContent = new RegisterApplyRequestV2Biz();
        bizContent.setChnlSeqNo(msgId);
        commonBuild(bizContent,merchantUserInfo);
        if(UserType.PERSON.getCode().equals(merchantUserInfo.getUserType())){
            personBuild(bizContent,merchantUserInfo);
        }else {
            companyBuild(bizContent,merchantUserInfo);
        }
        request.setBizContent(bizContent);
        return request;
    }

    /**
     * 通过证据号码返回证件类型
     * @param idCard 证件号
     * @return 证件类型码值
     */
    private String getCustIdTypeByIdCard(String idCard) {
        if(CharSequenceUtil.isBlank(idCard)){
            log.info("证件号码为空，返回默认的证件类型 01。");
            return "01";
        }

        if(IdcardUtil.isValidHKCard(idCard)){
            log.info("证据号码:{},香港居民公民身份号码地址码使用810000，对应传给交行证件类型：11",idCard);
            return "11";
        }
        if(CharSequenceUtil.startWith(idCard,AM_ID)){
            log.info("证据号码:{},澳门居民公民身份号码地址码使用820000，对应传给交行证件类型：12",idCard);
            return "12";
        }
        if(IdcardUtil.isValidTWCard(idCard)){
            log.info("证据号码:{},台湾居民公民身份号码地址码使用830000，对应传给交行证件类型：13",idCard);
            return "13";
        }
        log.info("证据号码:{},返回默认的证件类型 01",idCard);
        return "01";
    }

}
