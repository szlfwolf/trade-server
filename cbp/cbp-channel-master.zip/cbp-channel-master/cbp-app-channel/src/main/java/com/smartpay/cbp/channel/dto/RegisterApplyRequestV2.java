package com.smartpay.cbp.channel.dto;

import com.bocom.api.AbstractBocomRequest;
import com.bocom.api.BizContent;


/**
 * @author admin
 */
public class RegisterApplyRequestV2 extends AbstractBocomRequest<RegisterApplyResponseV2> {

    @Override
    public Class<RegisterApplyResponseV2> getResponseClass() {
        return RegisterApplyResponseV2.class;
    }

    @Override
    public boolean isNeedEncrypt() {
        return false;
    }

    @Override
    public String getMethod() {
        return "POST";
    }

    @Override
    public Class<? extends BizContent> getBizContentClass() {
        return RegisterApplyRequestV2Biz.class;
    }

}