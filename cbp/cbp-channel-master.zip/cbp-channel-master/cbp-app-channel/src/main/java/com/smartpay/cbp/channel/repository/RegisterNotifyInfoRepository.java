package com.smartpay.cbp.channel.repository;

import com.baomidou.mybatisplus.extension.service.IService;
import com.smartpay.cbp.channel.entity.RegisterNotifyInfoEntity;

/**
 * @author Carer
 * @desc
 * @date 2022/11/17 16:26
 */
public interface RegisterNotifyInfoRepository extends IService<RegisterNotifyInfoEntity> {
}
