package com.smartpay.cbp.channel.config;

import com.bocom.api.BocomConstants;
import com.bocom.api.DefaultBocomClient;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.Serializable;

/**
 * @author Carer
 * @desc
 * @date 2022/11/9 17:33
 */
@Configuration
@EnableConfigurationProperties(value = {BcmOpenConfigProperties.class})
public class BocomConfiguration implements Serializable {

    private static final long serialVersionUID = -5153208712006585841L;

    @Bean("bocomClient")
    public DefaultBocomClient bocomClient(BcmOpenConfigProperties bcmOpenConfigProperties){
        DefaultBocomClient defaultBocomClient = new DefaultBocomClient(bcmOpenConfigProperties.getOpenAppId()
                , bcmOpenConfigProperties.getOpenPrivateKey()
                , bcmOpenConfigProperties.getOpenApigwPubKey());
        defaultBocomClient.setConnectTimeout(bcmOpenConfigProperties.getConnectTimeout());
        defaultBocomClient.setReadTimeout(bcmOpenConfigProperties.getReadTimeout());
        return defaultBocomClient;
    }

    @Bean("bocomFileClient")
    public DefaultBocomClient bocomFileClient(BcmOpenConfigProperties bcmOpenConfigProperties){
        DefaultBocomClient bocomClient = new DefaultBocomClient(bcmOpenConfigProperties.getOpenAppId()
                , bcmOpenConfigProperties.getOpenPrivateKey(), BocomConstants.CHARSET_UTF8,
                BocomConstants.FMT_FILE, bcmOpenConfigProperties.getOpenApigwPubKey()
                , null, null, null);
        bocomClient.ignoreSSLHostnameVerifier();
        bocomClient.setConnectTimeout(bcmOpenConfigProperties.getConnectTimeout());
        bocomClient.setReadTimeout(bcmOpenConfigProperties.getReadTimeout());
        return bocomClient;
    }
}
