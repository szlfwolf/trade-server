package com.smartpay.cbp.channel.service.impl;

import com.alibaba.fastjson.JSON;
import com.smartpay.cbp.channel.config.IdGenerator;
import com.smartpay.cbp.channel.dto.SinglePaymentDTO;
import com.smartpay.cbp.channel.dto.SinglePaymentQueryDTO;
import com.smartpay.cbp.channel.entity.KltPaymentRecord;
import com.smartpay.cbp.channel.enums.KltPaymentTag;
import com.smartpay.cbp.channel.feign.RemoteKltPaymentApiService;
import com.smartpay.cbp.channel.response.SinglePaymentQueryResp;
import com.smartpay.cbp.channel.response.SinglePaymentResp;
import com.smartpay.cbp.channel.service.IKltPaymentRecordService;
import com.smartpay.cbp.channel.service.IKltRemoteApiService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * @Description: 开联通互联网接口调用
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/17 9:23
 * @Version: 1.0
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class KltRemoteApiServiceImpl implements IKltRemoteApiService {

    private final RemoteKltPaymentApiService remoteKltPaymentApiService;

    private final IdGenerator idGenerator;

    private final IKltPaymentRecordService kltPaymentRecordService;


    @Override
    public SinglePaymentResp singlePayment(SinglePaymentDTO singlePaymentDTO, String kltPaymentReqId) {
        log.info("【开始】调用互联网单笔代付，请求内容：{}", JSON.toJSONString(singlePaymentDTO));
        SinglePaymentResp resp = null;
        //构建请求互联网记录
        KltPaymentRecord paymentRecord = KltPaymentRecord.builder()
                .id(idGenerator.nextId())
                .paymentReqId(kltPaymentReqId)
                .merchantNo(singlePaymentDTO.getMerchantNo())
                .merchantOrderNo(singlePaymentDTO.getMchtOrderNo())
                .tag(String.valueOf(KltPaymentTag.PAYMENT_SEND.ordinal()))
                .request(JSON.toJSONString(singlePaymentDTO))
                .build();

        singlePaymentDTO.setNotifyUrl("test");
        singlePaymentDTO.setMerchantNo("903310112340001");
        try {
            resp = remoteKltPaymentApiService.singlePayment(singlePaymentDTO);
            log.info("【结束】调用互联网单笔代付，响应体：{}", JSON.toJSONString(resp));
        } catch (Exception e) {
            log.error("【异常】请求互联网单笔代付失败，订单号：{}", singlePaymentDTO.getMchtOrderNo(), e);
            paymentRecord.setException(JSON.toJSONString(e));
        } finally {
            //保存提现代付请求日志
            paymentRecord.setResponse(JSON.toJSONString(resp));
            kltPaymentRecordService.save(paymentRecord);
        }
        return resp;
    }

    /**
     * 单笔代付查询
     *
     * @param singlePaymentQueryDTO 代付请求体
     * @param paymentReqId          代付id {@link com.smartpay.cbp.channel.entity.KltPaymentReq}
     * @return
     */
    @Override
    public SinglePaymentQueryResp singlePaymentQuery(SinglePaymentQueryDTO singlePaymentQueryDTO,
                                                     String paymentReqId) {
        log.info("【开始】调用互联网查询提现状态，请求内容：{}", JSON.toJSONString(singlePaymentQueryDTO));
        SinglePaymentQueryResp singlePaymentQueryResp = null;
        //构建请求互联网记录
        KltPaymentRecord paymentRecord = KltPaymentRecord.builder()
                .id(idGenerator.nextId())
                .paymentReqId(paymentReqId)
                .merchantNo(singlePaymentQueryDTO.getMerchantNo())
                .merchantOrderNo(singlePaymentQueryDTO.getMchtOrderNo())
                .tag(String.valueOf(KltPaymentTag.PAYMENT_QUERY.ordinal()))
                .request(JSON.toJSONString(singlePaymentQueryDTO))
                .build();
        try {
            singlePaymentQueryResp = remoteKltPaymentApiService.singlePaymentQuery(singlePaymentQueryDTO);
            log.info("【结束】调用互联网查询提现状态，响应体：{}", JSON.toJSONString(singlePaymentQueryResp));
            return singlePaymentQueryResp;
        } catch (Exception e) {
            log.error("【异常】查询互联网单笔代付状态失败,订单号：{}", singlePaymentQueryDTO.getMchtOrderNo(), e);
            paymentRecord.setException(JSON.toJSONString(e));
            return null;
        } finally {
            //保存提现代付请求日志
            paymentRecord.setResponse(JSON.toJSONString(singlePaymentQueryResp));
            kltPaymentRecordService.save(paymentRecord);
        }
    }

}
