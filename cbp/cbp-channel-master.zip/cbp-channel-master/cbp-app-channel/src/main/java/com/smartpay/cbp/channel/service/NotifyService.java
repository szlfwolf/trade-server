package com.smartpay.cbp.channel.service;

import com.bocom.api.BocomResponse;
import com.smartpay.cbp.channel.dto.RegisterNotifyInfoDto;
import com.smartpay.cbp.channel.dto.RegisterResultNoticeReqDto;

/**
 * @author Carer
 * @desc 回调服务
 * @date 2022/11/17 16:06
 */
public interface NotifyService {

    /**
     * 银行备案结果回调
     * @param registerNoticeReq 回调内容
     */
    BocomResponse registerResultNotify(RegisterResultNoticeReqDto registerNoticeReq);

    /**
     * 根据主键获取备案回调通知内容
     * @param id 通知内容
     * @return 回调信息
     */
    RegisterNotifyInfoDto getRegisterNotifyInfoById(String id);

    /**
     * 通知更新回调处理成功
     * @param id 主键
     */
    void updateNotifyFinish(String id);
}
