package com.smartpay.cbp.channel.dto;

import com.bocom.api.BizContent;
import com.bocom.api.BocomUploadRequest;
import com.bocom.api.utils.FileItem;

/**
 * @author admin
 */
public class FileUploadRequestV1 extends BocomUploadRequest<FileUploadResponseV1> {

    private FileItem fileItem;

    @Override
    public Class<FileUploadResponseV1> getResponseClass() {
        return FileUploadResponseV1.class;
    }

    @Override
    public boolean isNeedEncrypt() {
        return false;
    }

    @Override
    public String getMethod() {
        return "POST";
    }

    @Override
    public Class<? extends BizContent> getBizContentClass() {
        return null;
    }


    /**
     * @return the fileItem
     */
    @Override
    public FileItem getFileItem() {
        return fileItem;
    }

    /**
     * @param fileItem the fileItem to set
     */
    public void setFileItem(FileItem fileItem) {
        this.fileItem = fileItem;
    }
}
