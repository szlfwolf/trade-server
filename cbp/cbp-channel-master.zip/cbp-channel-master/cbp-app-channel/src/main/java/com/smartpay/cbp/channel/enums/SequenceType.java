package com.smartpay.cbp.channel.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author ：jmwang
 * @version ：V1.0
 * @description ：流水号枚举
 * @date ：2022/11/8 19:43
 */
@Getter
@AllArgsConstructor
public enum SequenceType {

    // 流水号枚举
    AGENT_PAY_REQUEST("AGENT_PAY_REQUEST", "REMIT", 6, "提现请求流水号"),

    ;

    /**
     * redis键
     */
    private String code;

    /**
     * 流水号前缀
     */
    private String prefix;

    /**
     * 序列长度
     */
    private int length;

    /**
     * 说明
     */
    private String comment;
}
