package com.smartpay.cbp.channel.enums;

/**
 * @Description: 代付请求Tag
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/17 14:54
 * @Version: 1.0
 */
public enum KltPaymentTag {

    PAYMENT_SEND("互联网代付发送"),
    PAYMENT_QUERY("互联网代付查询"),

    ;

    public final String desc;

    KltPaymentTag(String desc) {
        this.desc = desc;
    }

}
