package com.smartpay.cbp.channel.dto;

import lombok.Builder;
import lombok.Data;

@Data
public class SinglePaymentRequest extends BaseRequest {

    private static final long serialVersionUID = 1L;

    private Content content; // 请求体

    @Data
    @Builder
    public static class Content {

        private String encrypt;

    }


}
