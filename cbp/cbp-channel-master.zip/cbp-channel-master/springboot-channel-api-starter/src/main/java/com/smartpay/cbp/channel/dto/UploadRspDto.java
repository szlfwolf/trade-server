package com.smartpay.cbp.channel.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * @author Carer
 * @desc 银行上传后响应内容
 * @date 2022/11/10 10:17
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class UploadRspDto implements Serializable {

    private static final long serialVersionUID = 4026285582697941284L;

    /**
     * 银行响应Id
     */
    private String docId;

    /**
     * 文件名
     */
    private String fileName;

}
