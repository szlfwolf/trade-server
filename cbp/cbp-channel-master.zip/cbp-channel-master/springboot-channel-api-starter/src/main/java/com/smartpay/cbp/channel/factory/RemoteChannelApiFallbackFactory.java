package com.smartpay.cbp.channel.factory;

import com.smartpay.cbp.channel.dto.MerchantUserInfoReqDto;
import com.smartpay.cbp.channel.dto.RegisterNotifyInfoDto;
import com.smartpay.cbp.channel.dto.UploadReqDto;
import com.smartpay.cbp.channel.dto.UploadRspDto;
import com.smartpay.cbp.channel.feign.RemoteChannelApiService;
import com.smartpay.cbp.common.core.domain.R;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.openfeign.FallbackFactory;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author Carer
 * @desc
 * @date 2022/10/27 19:00
 */
@Slf4j
@Component
public class RemoteChannelApiFallbackFactory implements FallbackFactory<RemoteChannelApiService> {

    @Override
    public RemoteChannelApiService create(Throwable throwable) {
        throwable.printStackTrace();
        return new RemoteChannelApiService() {
            @Override
            public R<String> registerSend(MerchantUserInfoReqDto merchantUserInfoDto, String source) {
                log.error("渠道备案发送调用失败,入参：{}，异常：{}",merchantUserInfoDto,throwable.getMessage());
                return R.fail();
            }

            @Override
            public R<List<UploadRspDto>> uploadRegisterFile(UploadReqDto uploadReqDto, String source) {
                log.error("渠道文件发送银行调用失败,入参：{}，异常：{}",uploadReqDto,throwable.getMessage());
                return R.fail();
            }

            @Override
            public R<RegisterNotifyInfoDto> getRegisterNotifyInfo(String id, String source) {
                log.error("备案回调信息获取失败,入参id：{}，异常：{}",id,throwable.getMessage());
                return R.fail();
            }

            @Override
            public R<Boolean> updateNotifyFinish(String id, String source) {
                log.error("更新回调处理状态失败spring,入参id：{}，异常：{}",id,throwable.getMessage());
                return R.fail();
            }

        };
    }
}
