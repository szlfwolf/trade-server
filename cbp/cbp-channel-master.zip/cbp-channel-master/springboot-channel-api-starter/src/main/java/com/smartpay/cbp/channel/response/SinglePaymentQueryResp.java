package com.smartpay.cbp.channel.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class SinglePaymentQueryResp implements Serializable {

    @ApiModelProperty("响应码，000000表示接口响应正常，其它表示失败")
    private String responseCode;

    @ApiModelProperty("响应描述")
    private String responseMsg;

    @ApiModelProperty("请求流水")
    private String requestId;

    @ApiModelProperty("商户号")
    private String mchtId;

    @ApiModelProperty("商户订单号")
    private String mchtOrderNo;

    @ApiModelProperty("交易状态，SUCCESS：成功，IN_PROCESS：处理中，FAIL：失败，CREATE：已受理，REFUSE：拒绝交易，只有在开联通系统创建了订单后该属性才有值(此字段用于判断业务执行状态)")
    private String orderState;

    @ApiModelProperty("订单状态描述")
    private String orderDesc;

    @ApiModelProperty("交易金额，单位为分")
    private String amount;

    @ApiModelProperty("订单处理响应码")
    private String errorCode;

    @ApiModelProperty("订单处理响信息")
    private String errorMsg;

    @ApiModelProperty("签名类型，固定选择值： 2；2:表示订单上送和交易结果通知都使用RSA进行签名")
    private String signType;

    @ApiModelProperty("签名内容")
    private String signMsg;
}

