package com.smartpay.cbp.channel.config;

import com.smartpay.cbp.channel.dto.KltongConfParam;
import com.smartpay.cbp.channel.util.KltCertUtil;
import lombok.Getter;
import lombok.Setter;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @Description: 开联通国密配置
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/16 15:50
 * @Version: 1.0
 */
@Slf4j
@Getter
@Setter
@Configuration
@ConfigurationProperties(prefix = "spring.klt")
public class KltCertConfigure {

    /**
     * 开联通公钥路径
     */
    private String kltPubPath;

    /**
     * 商户加验签证书
     */
    private String mchSignCertPath;

    /**
     * 商户加解密证书
     */
    private String mchEncCertPath;

    /**
     * 商户私钥密码
     */
    private String mchPriPwd;

    /**
     * 签名类型
     */
    private String signType;

    /**
     * 版本号
     */
    private String version;

    /**
     * 渠道商户号
     */
    private String chnlMchNo;

    @SneakyThrows
    @Bean
    public KltCertUtil KltCertUtil() {
        return new KltCertUtil(KltongConfParam.builder()
                .kltPubPath(kltPubPath)
                .mchEncCertPath(mchEncCertPath)
                .mchSignCertPath(mchSignCertPath)
                .mchPriPwd(mchPriPwd)
                .chnlMchNo(chnlMchNo)
                .build());
    }


}
