package com.smartpay.cbp.channel.feign;

import com.smartpay.cbp.channel.constant.ServerChannelConstants;
import com.smartpay.cbp.channel.dto.MerchantUserInfoReqDto;
import com.smartpay.cbp.channel.dto.RegisterNotifyInfoDto;
import com.smartpay.cbp.channel.dto.UploadReqDto;
import com.smartpay.cbp.channel.dto.UploadRspDto;
import com.smartpay.cbp.channel.factory.RemoteChannelApiFallbackFactory;
import com.smartpay.cbp.common.core.constant.SecurityConstants;
import com.smartpay.cbp.common.core.domain.R;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author Carer
 * @desc  feign远程调用
 * @date 2022/10/27 18:51
 */
@FeignClient(contextId = "remoteChannelService", value = ServerChannelConstants.CHANNEL_SERVICE
        , fallbackFactory = RemoteChannelApiFallbackFactory.class)
public interface RemoteChannelApiService {

    /**
     * 渠道备案发送
     * @param merchantUserInfoDto 备案发送
     * @param source              内部调用标识
     * @return 发送请求流水号
     */
    @PostMapping("/register/send")
    R<String> registerSend(@RequestBody @Validated MerchantUserInfoReqDto merchantUserInfoDto
            , @RequestHeader(SecurityConstants.FROM_SOURCE) String source);

    /**
     * 文件上传
     * @param uploadReqDto 文件上传对象
     * @param source  内部调用标识
     * @return 上传文件组装参数
     */
    @PostMapping("/register/upload")
    R<List<UploadRspDto>> uploadRegisterFile(@RequestBody UploadReqDto uploadReqDto
            , @RequestHeader(SecurityConstants.FROM_SOURCE) String source);

    /**
     * 根据主键获取备案回调通知内容
     * @param id 通知内容
     * @param source 内部调用标识
     * @return 回调信息
     */
    @GetMapping("/notify/register/info/{id}")
    R<RegisterNotifyInfoDto> getRegisterNotifyInfo(@PathVariable("id")String id
            , @RequestHeader(SecurityConstants.FROM_SOURCE) String source);

    /**
     * 更新处理状态
     * @param id        主键
     * @param source    内部调用标识
     * @return  执行结果
     */
    @PostMapping("/notify/update/{id}")
    R<Boolean> updateNotifyFinish(@PathVariable("id")String id
            , @RequestHeader(SecurityConstants.FROM_SOURCE) String source);
}
