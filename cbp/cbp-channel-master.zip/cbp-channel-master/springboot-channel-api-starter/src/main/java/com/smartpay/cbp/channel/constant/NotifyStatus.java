package com.smartpay.cbp.channel.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author Carer
 * @desc
 * @date 2022/11/17 18:01
 */
@AllArgsConstructor
@Getter
public enum NotifyStatus {

    //
    SUCCESS("1","成功"),
    FAIL("0","失败"),
    ;

    private final String code;
    private final String desc;
}
