package com.smartpay.cbp.channel.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @Description: 开联通单笔代付请求
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/9 14:21
 * @Version: 1.0
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SinglePaymentDTO implements Serializable {

    @NotNull
    @ApiModelProperty("商户号")
    private String merchantNo;

    @NotNull
    @ApiModelProperty("商户订单号，单笔实时代付中不能重复")
    private String mchtOrderNo;

    @NotNull
    @ApiModelProperty("商户订单时间:yyyyMMddHHmmss")
    private String orderDateTime;

    @NotNull
    @ApiModelProperty("收款方账号")
    private String accountNo;

    @NotNull
    @ApiModelProperty("收款方姓名")
    private String accountName;

    @NotNull
    @ApiModelProperty("收款方账户类型，固定值，可取值：1代表个人账户，2代表企业账户")
    private String accountType;

    @NotNull
    @ApiModelProperty("收款方开户行行号（电子联行号）对公需要校验，对私填写000000000000（12个0）")
    private String bankNo;

    @NotNull
    @ApiModelProperty("收款方开户行名称（企业账户精确到支行，比如中国工商银行上海市浦东大道支行）个人账户只写银行名")
    private String bankName;

    @NotNull
    @ApiModelProperty("金额，正整数，单位为分。例如，票款为1280元，则表示为“128000”")
    private Long amt;

    @NotNull
    @ApiModelProperty("用途")
    private String purpose;

    @ApiModelProperty("备注")
    private String remark;

    @NotNull
    @ApiModelProperty("用于接收开联通的交易结果通知")
    private String notifyUrl;

}
