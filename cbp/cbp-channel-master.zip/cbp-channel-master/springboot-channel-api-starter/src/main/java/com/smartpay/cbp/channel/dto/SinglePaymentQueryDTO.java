package com.smartpay.cbp.channel.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @Description: 开联通单笔代付结果查询
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/9 14:21
 * @Version: 1.0
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SinglePaymentQueryDTO implements Serializable {

    @NotNull
    @ApiModelProperty("商户订单号")
    private String mchtOrderNo;

    @NotNull
    @ApiModelProperty("交易模式：SINGLE_PAY")
    private String paymentBusinessType;

    @NotNull
    @ApiModelProperty(value = "商户号")
    private String merchantNo;

}
