package com.smartpay.cbp.channel.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author Carer
 * @desc 回调信息实体
 * @date 2022/11/17 16:57
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class RegisterNotifyInfoDto implements Serializable {
    private static final long serialVersionUID = 7687009697407272281L;

    /**
     * 请求流水号
     */
    private String reqNo;

    /**
     * 父请求流水号
     */
    private String parentReqNo;

    /**
     * 回调内容
     */
    private String notifyContent;

    /**
     * 回调结果 1成功，0失败
     */
    private String notifyResult;

    /**
     * 回调时间
     */
    private LocalDateTime notifyTime;

    /**
     * 备注
     */
    private String remark;

    /**
     * 修改全部标识
     */
    private Boolean modifyAll;
}
