package com.smartpay.cbp.channel.util;

import cfca.sadk.algorithm.sm2.SM2PrivateKey;
import cfca.sadk.util.KeyUtil;
import cn.hutool.core.util.HexUtil;
import cn.hutool.core.util.ReflectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.crypto.BCUtil;
import cn.hutool.crypto.SmUtil;
import cn.hutool.crypto.asymmetric.KeyType;
import cn.hutool.crypto.asymmetric.SM2;
import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONObject;
import com.smartpay.cbp.channel.dto.Head;
import com.smartpay.cbp.channel.dto.KltongConfParam;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.bouncycastle.crypto.engines.SM2Engine;
import org.bouncycastle.crypto.params.ECPublicKeyParameters;
import org.bouncycastle.crypto.signers.PlainDSAEncoding;
import org.bouncycastle.jcajce.provider.asymmetric.ec.BCECPublicKey;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

import java.io.FileInputStream;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.security.PublicKey;
import java.security.Security;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * @Author kasim
 * @Date 2022/8/3
 */
@Slf4j
public class KltCertUtil {
    private SM2PrivateKey signPvtKey;

    private SM2PrivateKey encPvtKey;

    private PublicKey kltongPubKey;

    private String merchantId;

    /**
     * 加签
     *
     * @param dataToSign 需要加签数据
     * @return 加签后数据
     */
    public String sign(String dataToSign) {
        SM2 sm2 = SmUtil.sm2(HexUtil.encodeHexStr(signPvtKey.getD_Bytes()), null);
        sm2.usePlainEncoding();
        byte[] byteToSign = sm2.sign(dataToSign.getBytes(StandardCharsets.UTF_8),
                merchantId.getBytes(StandardCharsets.UTF_8));
        return HexUtil.encodeHexStr(byteToSign);
    }

    /**
     * 数据加密
     *
     * @param dataToEncrypt 需要加密数据
     * @return 加密后数据
     */
    public String encrypt(String dataToEncrypt) {
        String x = ((BCECPublicKey) kltongPubKey).getQ().getXCoord().toString();
        String y = ((BCECPublicKey) kltongPubKey).getQ().getYCoord().toString();
        ECPublicKeyParameters ecPublicKeyParameters = BCUtil.toSm2Params(x, y);
        SM2 sm2 = SmUtil.sm2(null, ecPublicKeyParameters);
        sm2.setMode(SM2Engine.Mode.C1C2C3);
        sm2.usePlainEncoding();
        sm2.setEncoding(new PlainDSAEncoding());
        return sm2.encryptBcd(dataToEncrypt, KeyType.PublicKey).substring(2);
    }

    public String decrypt(String dataToDecrypt) {
        SM2 sm2 = SmUtil.sm2(HexUtil.encodeHexStr(encPvtKey.getD_Bytes()), null);
        sm2.setMode(SM2Engine.Mode.C1C2C3);
        sm2.usePlainEncoding();
        return StrUtil.utf8Str(sm2.decrypt(dataToDecrypt, KeyType.PrivateKey));
    }

    /**
     * 校验签名
     *
     * @param response
     * @param signFieldName
     * @return
     */
    @SneakyThrows
    public boolean verify(Object response, String signFieldName) {
        Field signField = ReflectUtil.getField(response.getClass(), signFieldName);
        signField.setAccessible(true);
        // 缓存签名串
        Object signedData = signField.get(response);
        // 去除signMsg字段
        signField.set(response, null);
        // 获取除了signMsg字段之外的所有字段拼成的字符串
        String strToSign = buildStrToSign(JSON.parseObject(JSON.toJSONString(response)), null);
        //校验签名是否正确
        SM2 sm2 = SmUtil.sm2(null, kltongPubKey);
        sm2.usePlainEncoding();
        return sm2.verify(strToSign.getBytes(StandardCharsets.UTF_8), HexUtil.decodeHex((String) signedData),
                merchantId.getBytes(StandardCharsets.UTF_8));
    }

    public KltCertUtil(KltongConfParam kltongConfParam) {
        try {
            // 初始化商户签名私钥对象
            signPvtKey = KeyUtil.getPrivateKeyFromSM2(kltongConfParam.getMchSignCertPath(), kltongConfParam.getMchPriPwd());
            encPvtKey = KeyUtil.getPrivateKeyFromSM2(kltongConfParam.getMchEncCertPath(), kltongConfParam.getMchPriPwd());
            // 初始化开联通公钥对象
            Security.addProvider(new BouncyCastleProvider());
            CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509", "BC");
            FileInputStream fileInputStream = new FileInputStream(kltongConfParam.getKltPubPath());
            X509Certificate x509Certificate = (X509Certificate) certificateFactory.generateCertificate(fileInputStream);
            kltongPubKey = x509Certificate.getPublicKey();
            merchantId = kltongConfParam.getChnlMchNo();
        } catch (Exception e) {
            log.error("初始化互联网国密工具类失败");
        }
    }


    /**
     * 构建需要加签/验签的内容
     *
     * @param body   请求体
     * @param header 请求头
     * @return 需要加签的内容
     */
    public String buildStrToSign(JSONObject body, Head header) {
        List<String> keyValueList = new ArrayList<>();
        for (Map.Entry<String, Object> entry : body.entrySet()) {
            fillKeyValueList(entry.getKey(), entry.getValue(), keyValueList);
        }
        if (header != null) {
            JSONObject head = JSON.parseObject(JSON.toJSONString(header));
            for (Map.Entry<String, Object> entry : head.entrySet()) {
                fillKeyValueList(entry.getKey(), entry.getValue(), keyValueList);
            }
        }
        // 排序
        keyValueList.sort((o1, o2) -> {
            // 按照=分隔
            String[] split1 = o1.split("=");
            String[] split2 = o2.split("=");
            return split1[0].compareTo(split2[0]);
        });
        // 连接
        return StrUtil.join("&", keyValueList);
    }

    @SneakyThrows
    private void fillKeyValueList(String key, Object value, List<String> keyValueList) {
        if (Objects.isNull(value)) {
            return;
        }
        String str;
        if (Boolean.FALSE.equals(value instanceof String)) {
            str = JSON.toJSONString(value);
        } else {
            str = value.toString();
        }
        keyValueList.add(key + "=" + str);
    }


}
