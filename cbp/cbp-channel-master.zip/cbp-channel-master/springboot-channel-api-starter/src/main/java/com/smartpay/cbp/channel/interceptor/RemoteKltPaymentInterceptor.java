package com.smartpay.cbp.channel.interceptor;

import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONObject;
import com.smartpay.cbp.channel.dto.Head;
import com.smartpay.cbp.channel.dto.SinglePaymentRequest;
import com.smartpay.cbp.channel.util.KltCertUtil;
import feign.RequestInterceptor;
import feign.RequestTemplate;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * @Author: guogangqiang
 * @Date: 2022/7/11 15:27
 * @Description: 黑洞引擎接口请求头对接
 */
@Slf4j
@RequiredArgsConstructor
@Data
public class RemoteKltPaymentInterceptor implements RequestInterceptor {

    private final KltCertUtil kltCertUtil;


    /**
     * 开联通互联网请求加签加密
     *
     * @param requestTemplate
     */
    @Override
    public void apply(RequestTemplate requestTemplate) {
        if (log.isInfoEnabled()) {
            log.info("调用互联网接口：{}", requestTemplate.url());
        }
        //请求体
        String body = new String(requestTemplate.body());
        JSONObject jsonObject = JSON.parseObject(body);
        if (log.isInfoEnabled()) {
            log.info("请求互联网请求体明文：{}", body);
        }
        //设置请求头
        Head head = new Head();
        head.setVersion("1.0.0");
        head.setSignType("3");
//        head.setMerchantId(jsonObject.getString("merchantNo"));
        head.setMerchantId("903310112340001");
        //加签
        String toSign = kltCertUtil.buildStrToSign(jsonObject, head);
        log.info("【互联网接口加签】需要加签的内容:{}", toSign);
        String sign = kltCertUtil.sign(toSign);
        head.setSign(sign);
        //请求体加密
        String encrypt = kltCertUtil.encrypt(body);
        //加密和加签内容组成新的请求体
        SinglePaymentRequest singlePaymentRequest = new SinglePaymentRequest();
        singlePaymentRequest.setHead(head);
        singlePaymentRequest.setContent(SinglePaymentRequest.Content.builder().encrypt(encrypt).build());
        requestTemplate.body(JSON.toJSONString(singlePaymentRequest));
        if (log.isInfoEnabled()) {
            log.info("请求互联网请求加密加签后：{}", JSON.toJSONString(singlePaymentRequest));
        }
    }


}
