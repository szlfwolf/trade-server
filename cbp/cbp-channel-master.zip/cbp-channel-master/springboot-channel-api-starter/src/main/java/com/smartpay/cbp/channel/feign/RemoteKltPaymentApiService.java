package com.smartpay.cbp.channel.feign;

import com.smartpay.cbp.channel.dto.SinglePaymentDTO;
import com.smartpay.cbp.channel.dto.SinglePaymentQueryDTO;
import com.smartpay.cbp.channel.interceptor.RemoteKltPaymentInterceptor;
import com.smartpay.cbp.channel.response.SinglePaymentQueryResp;
import com.smartpay.cbp.channel.response.SinglePaymentResp;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

/**
 * @Description: 调用互联网代付
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/9 15:57
 * @Version: 1.0
 */
@FeignClient(name = "RemoteKltPaymentApiService", url = "https://openapi.chinasmartpay.com/openapi", configuration = {RemoteKltPaymentInterceptor.class})
public interface RemoteKltPaymentApiService {

    /**
     * 调用互联网单笔代付
     *
     * @param singlePaymentDTO 单笔代付请求
     * @return 单笔代付响应
     */
    @PostMapping(value = "/singlePayment/payment", produces = APPLICATION_JSON_VALUE, consumes = APPLICATION_JSON_VALUE)
    SinglePaymentResp singlePayment(@Valid @NotNull SinglePaymentDTO singlePaymentDTO);

    /**
     * 互联网单笔代付查询
     *
     * @param singlePaymentQueryDTO 单笔代付查询
     * @return 响应信息
     */
    @PostMapping(value = "/singlePayment/query", produces = APPLICATION_JSON_VALUE, consumes = APPLICATION_JSON_VALUE)
    SinglePaymentQueryResp singlePaymentQuery(@Valid @NotNull SinglePaymentQueryDTO singlePaymentQueryDTO);

}
