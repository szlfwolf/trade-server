package com.smartpay.cbp.channel.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @ClassName KltongConfParam
 * @Company 开联通支付服务有限公司
 * @Description 开联通配置参数实体
 * @Author wq
 * @Date 2022/10/13 9:44
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class KltongConfParam {

    /**
     * 渠道商户号
     */
    private String chnlMchNo;

    /**
     * 开联通公钥路径
     */
    private String kltPubPath;

    /**
     * 商户加验签证书
     */
    private String mchSignCertPath;

    /**
     * 商户加解密证书
     */
    private String mchEncCertPath;

    /**
     * 商户私钥密码
     */
    private String mchPriPwd;
}
