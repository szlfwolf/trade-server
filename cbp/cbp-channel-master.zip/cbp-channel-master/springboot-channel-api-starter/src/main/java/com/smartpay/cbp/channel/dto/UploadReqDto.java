package com.smartpay.cbp.channel.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.util.List;

/**
 * @author Carer
 * @desc  上传对象
 * @date 2022/11/15 15:43
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class UploadReqDto implements Serializable {
    private static final long serialVersionUID = 1547983770185358808L;

    @NotEmpty(message = "文件指纹Id不能未空")
    private List<String> fileIds;

    @NotBlank(message = "渠道号不能为空！")
    private String channelNo;
}
