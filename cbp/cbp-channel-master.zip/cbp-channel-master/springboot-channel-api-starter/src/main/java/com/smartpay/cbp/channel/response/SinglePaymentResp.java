package com.smartpay.cbp.channel.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class SinglePaymentResp implements Serializable {

    @ApiModelProperty("商户号")
    private String mchtId;

    @ApiModelProperty("签名类型")
    private String signType;

    @ApiModelProperty("签名")
    private String signMsg;

    @ApiModelProperty("请求流水")
    private String requestId;

    @ApiModelProperty("交易状态")
    private String orderState;

    @ApiModelProperty("响应码")
    private String responseCode;

    @ApiModelProperty("响应信息")
    private String responseMsg;
}
