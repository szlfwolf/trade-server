package com.smartpay.cbp.channel.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class Head implements Serializable {

    @ApiModelProperty("版本号，必填")
    private String version;

    @ApiModelProperty("签名类型， 固定值 3")
    private String signType;

    @ApiModelProperty("签名信息，必填")
    private String sign; // M,签名信息

    @ApiModelProperty("开联通商户号，必填")
    private String merchantId;
}
