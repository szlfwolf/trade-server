package com.smartpay.cbp.channel.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.util.List;

/**
 * @author Carer
 * @desc
 * @date 2022/11/9 16:09
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class MerchantUserInfoReqDto implements Serializable {
    private static final long serialVersionUID = -6128573988994933832L;

    /**
     * 系统商户号
     */
    private String merchantNo;

    /**
     * 系统用户号
     */
    private String userNo;

    /**
     * 备案渠道号
     */
    private String channelNo;

    /**
     * 渠道用户号
     */
    private String openUserNo;

    /**
     * 商户侧用户编号
     */
    private String merchantUserNo;

    /**
     * 卖家平台注册时间
     */
    private String regTime;

    /**
     * 用户类型,1-企业，2-个人
     */
    private String userType;

    /**
     * 国别
     */
    private String nationality;

    /**
     * 姓名、法人姓名
     */
    private String name;

    /**
     * 手机号
     */
    private String mobileNo;

    /**
     * 证件类型
     */
    private String certType;

    /**
     * 证件号
     */
    private String certId;

    /**
     * 证件有效期始
     */
    private String certExpBeginDate;

    /**
     * 证件有效期止
     */
    private String certExpEndDate;

    /**
     * 邮箱地址
     */
    private String email;

    /**
     * 联系地址
     */
    private String address;

    /**
     * 职业代码
     */
    private String professionCode;

    /**
     * 职业名称
     */
    private String professionName;

    /**
     * 支行联行号
     */
    private String bankCode;

    /**
     * 支行名称
     */
    private String branchName;

    /**
     * 开户银行
     */
    private String bankName;

    /**
     * 银行账号
     */
    private String bankAcct;

    /**
     * 统一社会信用代码
     */
    private String licenseNo;

    /**
     * 营业执照起始时间
     */
    private String licenseStartDate;

    /**
     * 营业执照结束时间
     */
    private String licenseEndDate;

    /**
     * 企业简称
     */
    private String shortName;

    /**
     * 企业类型 1-个体工商户 2-企业
     */
    private String bizType;

    /**
     * 经营范围
     */
    private String bizScope;

    /**
     * 邮编
     */
    private String postCode;

    /**
     * 经营地址
     */
    private String opAddr;

    /**
     * 账户类型
     */
    private String acctType;

    /**
     * 账户名称
     */
    private String acctName;

    private String provinceCode;

    private String cityCode;

    private String areaCode;

    /**
     * 所属行业属性代码
     */
    private String industryCode;

    /**
     * 经济类型代码
     */
    private String attrCode;

    /**
     * 是否特殊经济区内企业
     */
    private String isTaxFree;

    /**
     * 特殊经济区内企业类型
     */
    private String taxFreeCode;

    /**
     * 外方投资者国别信息
     */
    private String invCountryCode;

    /**
     * 店铺网址
     */
    private String storeLink;

    /**
     * 备注
     */
    private String remark;


    private List<UploadRspDto> uploadFiles;
}
