package com.smartpay.cbp.account.config;

import com.xxl.job.core.executor.impl.XxlJobSpringExecutor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.commons.util.InetUtils;
import org.springframework.cloud.commons.util.InetUtilsProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/23 09:53
 */
@Slf4j
@Configuration
public class XxlJobConfig {

    @Autowired
    private InetUtilsProperties inetUtilsProperties;

    @Autowired
    private XxlJobConfigProperties xxlJobConfigProperties;

    @Bean(initMethod = "start", destroyMethod = "destroy")
    public XxlJobSpringExecutor xxlJobExecutor() {
        log.info(">>>>>>>>>>> xxl-job config init.");
        XxlJobSpringExecutor xxlJobSpringExecutor = new XxlJobSpringExecutor();
        xxlJobSpringExecutor.setAdminAddresses(xxlJobConfigProperties.getAdminAddresses());
        xxlJobSpringExecutor.setAppName(xxlJobConfigProperties.getAppName());
        try (InetUtils inetUtils = new InetUtils(inetUtilsProperties)) {
            String ip = inetUtils.findFirstNonLoopbackHostInfo().getIpAddress();
            xxlJobSpringExecutor.setIp(ip);
        }
        xxlJobSpringExecutor.setPort(xxlJobConfigProperties.getPort());
        xxlJobSpringExecutor.setLogPath(xxlJobConfigProperties.getLogPath());
        xxlJobSpringExecutor.setLogRetentionDays(xxlJobConfigProperties.getLogRetentionDays());
        return xxlJobSpringExecutor;
    }
}
