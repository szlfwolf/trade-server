package com.smartpay.cbp.account.handler;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.io.IoUtil;
import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.smartpay.cbp.account.base.Constants;
import com.smartpay.cbp.account.base.enums.AccountStatusEnum;
import com.smartpay.cbp.account.config.IdGenerator;
import com.smartpay.cbp.account.dto.res.ExportAccountStatementInfoResDTO;
import com.smartpay.cbp.account.entity.AccountInfo;
import com.smartpay.cbp.account.entity.MchtDailyStatementRecord;
import com.smartpay.cbp.account.service.AccountChangeService;
import com.smartpay.cbp.account.service.AccountInfoService;
import com.smartpay.cbp.account.service.MchtDailyStatementRecordService;
import com.smartpay.cbp.common.core.utils.poi.ExcelUtil;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.JobHandler;
import com.xxl.job.core.log.XxlJobLogger;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.util.TempFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/23 10:25
 */
@Slf4j
@Component
@JobHandler("mchtDailyAccountStatementJobHandler")
public class MchtDailyAccountStatementJobHandler extends IJobHandler {

    @Autowired
    private AccountInfoService accountInfoService;

    @Autowired
    private AccountChangeService accountChangeService;

    @Autowired
    private FileHandler fileHandler;

    @Autowired
    private IdGenerator idGenerator;

    @Autowired
    private MchtDailyStatementRecordService mchtDailyStatementRecordService;

    @Override
    public ReturnT<String> execute(String s) throws Exception {
        XxlJobLogger.log("XXL-JOB：商户每日账户对账单, 参数：{}", s);
        // 获取所有商户的账户信息
        List<AccountInfo> accountInfos = queryAllAccountInfo();

        // 获取指定日志或者前一日所有的账户变动记录
        Date date;
        if (StringUtils.hasText(s)) {
            date = DateUtil.parse(s, Constants.YMD);
        } else {
            date = DateUtil.yesterday();
        }
        Map<String, List<ExportAccountStatementInfoResDTO>> statementInfoMap = queryAllAccountStatementInfo(date);

        String ymd = DateUtil.format(date, Constants.YMD);
        for (AccountInfo accountInfo : accountInfos) {
            List<ExportAccountStatementInfoResDTO> dtos = statementInfoMap.get(accountInfo.getId());
            if (CollectionUtils.isEmpty(dtos)) {
                continue;
            }

            // 创建对账单文件并上传到文件服务器
            String fileUrl = createFileAndUpload(ymd, accountInfo, dtos);

            // 保存对账单记录
            saveStatementRecord(ymd, accountInfo.getExtAccountNo(), fileUrl);
        }

        return SUCCESS;
    }

    private void saveStatementRecord(String date, String mchtNo, String fileUrl) {
        MchtDailyStatementRecord entity = new MchtDailyStatementRecord();
        entity.setId(idGenerator.nextId());
        entity.setStatementDate(date);
        entity.setMerchantNo(mchtNo);
        entity.setStatementFileUrl(fileUrl);
        entity.setCrtTime(new Date());
        entity.setUptTime(new Date());
        Wrapper<MchtDailyStatementRecord> updateWrapper = Wrappers.lambdaUpdate(MchtDailyStatementRecord.class)
                .eq(MchtDailyStatementRecord::getStatementDate, date)
                .eq(MchtDailyStatementRecord::getMerchantNo, mchtNo);
        mchtDailyStatementRecordService.saveOrUpdate(entity, updateWrapper);
    }

    private String createFileAndUpload(String date, AccountInfo accountInfo,
                                     List<ExportAccountStatementInfoResDTO> dtos) throws IOException {
        dtos.sort((o1, o2) -> o2.getId().compareTo(o1.getId()));
        String fileType = ".xlsx";
        File tmplFile = TempFile.createTempFile("account-poi-sxssf-template", fileType);
        try (FileOutputStream fos = new FileOutputStream(tmplFile);
             FileInputStream fis = new FileInputStream(tmplFile)) {
            ExcelUtil<ExportAccountStatementInfoResDTO> util = new ExcelUtil<>(ExportAccountStatementInfoResDTO.class);
            util.exportExcel(fos, dtos, date + "对账单");
            String mchtNo = accountInfo.getExtAccountNo();
            String fileName = mchtNo + "-" + date + "-对账单" + fileType;
            return fileHandler.upload(date, fileName, IoUtil.readBytes(fis));
        } finally {
            // 删除临时文件
            try {
                tmplFile.delete();
            } catch (Exception e) {
                log.error("删除文件【{}】失败！！", tmplFile.getAbsolutePath());
            }
        }
    }

    private Map<String, List<ExportAccountStatementInfoResDTO>> queryAllAccountStatementInfo(Date date) {
        List<ExportAccountStatementInfoResDTO> list = accountChangeService.queryStatementInfo(null, date, date);
        return list.stream().collect(Collectors.groupingBy(ExportAccountStatementInfoResDTO::getAccountId));
    }

    private List<AccountInfo> queryAllAccountInfo() {
        Wrapper<AccountInfo> wrapper = Wrappers.lambdaQuery(AccountInfo.class)
                .in(AccountInfo::getStatus, AccountStatusEnum.NORMAL.getValue(), AccountStatusEnum.FREEZE.getValue());
        return accountInfoService.list(wrapper);
    }
}
