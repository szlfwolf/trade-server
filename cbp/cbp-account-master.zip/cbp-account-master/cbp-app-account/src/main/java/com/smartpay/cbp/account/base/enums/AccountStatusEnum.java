package com.smartpay.cbp.account.base.enums;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/7 11:56
 */
public enum AccountStatusEnum {

    /**
     * 正常
     */
    NORMAL("1"),
    /**
     * 冻结
     */
    FREEZE("2"),
    /**
     * 注销
     */
    LOGOFF("3");

    private String value;

    AccountStatusEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
