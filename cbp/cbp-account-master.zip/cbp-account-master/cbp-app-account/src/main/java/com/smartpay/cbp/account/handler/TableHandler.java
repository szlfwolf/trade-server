package com.smartpay.cbp.account.handler;

import com.smartpay.cbp.account.base.RedisKeyConstants;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Set;
import java.util.function.Consumer;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/9 16:26
 */
@Component
public class TableHandler {

    private static final Set<String> TABLE_NAMES = new HashSet<>();

    @Autowired
    private RedissonClient redissonClient;

    public void createTable(String tableName, Consumer<String> createTable) {
        if (TABLE_NAMES.contains(tableName)) {
            return;
        }

        String lockKey = RedisKeyConstants.LOCK_PREFIX + tableName;
        RLock lock = redissonClient.getLock(lockKey);
        lock.lock();
        try {
            if (TABLE_NAMES.contains(tableName)) {
                return;
            }
            createTable.accept(tableName);
            TABLE_NAMES.add(tableName);
        } finally {
            lock.unlock();
        }
    }
}
