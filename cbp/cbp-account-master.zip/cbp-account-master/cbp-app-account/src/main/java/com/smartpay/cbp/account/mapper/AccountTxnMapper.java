package com.smartpay.cbp.account.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.smartpay.cbp.account.entity.AccountTxn;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/4 16:25
 */
@Mapper
public interface AccountTxnMapper extends BaseMapper<AccountTxn> {

}
