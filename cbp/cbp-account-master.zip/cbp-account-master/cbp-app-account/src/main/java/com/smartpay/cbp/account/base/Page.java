package com.smartpay.cbp.account.base;

import com.smartpay.cbp.common.core.domain.R;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.Collection;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/14 13:42
 */
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class Page<E> extends R<Collection<E>> {

    private Long total;

    public static <E> Page<E> ok(Collection<E> collection, Long total) {
        Page<E> page = new Page<>();
        page.setCode(R.SUCCESS);
        page.setMsg("success");
        page.setData(collection);
        page.setTotal(total);
        return page;
    }
}
