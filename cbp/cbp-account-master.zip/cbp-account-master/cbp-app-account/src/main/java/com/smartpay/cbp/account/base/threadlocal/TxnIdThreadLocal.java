package com.smartpay.cbp.account.base.threadlocal;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/8 11:13
 */
public class TxnIdThreadLocal {

    private static final ThreadLocal<String> TL = new ThreadLocal<>();

    public static void set(String txnId) {
        TL.set(txnId);
    }

    public static String get() {
        return TL.get();
    }

    public static void remove() {
        TL.remove();
    }
}
