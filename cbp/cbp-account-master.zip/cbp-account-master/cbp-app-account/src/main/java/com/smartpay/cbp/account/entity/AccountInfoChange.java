package com.smartpay.cbp.account.entity;

import lombok.Data;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/11 15:05
 */
@Data
public class AccountInfoChange {

    /**
     * 交易码
     */
    private String merchantNo;

    /**
     * 交易码
     */
    private String txnCode;

    /**
     * 账户id
     */
    private String accountId;

    /**
     * 账户类型
     */
    private String accountType;

    /**
     * 充值金额
     */
    private Long amount;

    /**
     * 交易币种
     */
    private String currency;
}
