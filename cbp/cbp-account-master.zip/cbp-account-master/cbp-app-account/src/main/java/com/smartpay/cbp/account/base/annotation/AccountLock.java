package com.smartpay.cbp.account.base.annotation;

import com.smartpay.cbp.account.base.RedisKeyConstants;

import java.lang.annotation.*;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/8 14:56
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface AccountLock {

    String prefix() default RedisKeyConstants.ACCOUNT_OPERATE_PREFIX;

}
