package com.smartpay.cbp.account.mapper;

import com.smartpay.cbp.account.entity.AccountChange;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.smartpay.cbp.account.entity.AccountStatement;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * 账户变动记录表 Mapper 接口
 * </p>
 *
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/7 13:39
 */
@Mapper
public interface AccountChangeMapper extends BaseMapper<AccountChange> {

    List<AccountStatement> selectStatementStatistic(@Param("mchtNo") String mchtNo,
                                                    @Param("accountType") String accountType,
                                                    @Param("currency") String currency,
                                                    @Param("start") Date start,
                                                    @Param("end") Date end);
}
