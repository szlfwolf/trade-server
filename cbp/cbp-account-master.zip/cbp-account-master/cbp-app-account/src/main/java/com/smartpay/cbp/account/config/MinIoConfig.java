package com.smartpay.cbp.account.config;

import io.minio.MinioClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/23 11:29
 */
@Configuration
public class MinIoConfig {

    @Bean
    public MinioClient minioClient(MinIoConfigProperties properties) {
        return MinioClient.builder()
                .endpoint(properties.getUrl())
                .credentials(properties.getAccessKey(), properties.getSecretKey())
                .build();
    }
}
