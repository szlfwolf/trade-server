package com.smartpay.cbp.account.service;

import com.smartpay.cbp.account.dto.req.*;
import com.smartpay.cbp.account.dto.res.AccountAgentPayResDTO;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/8 10:06
 */
public interface AccountOperateService {

    /**
     * 账户开户
     *
     * @param dto 开户参数
     * @return 账户id
     */
    String openAccount(OpenAccountReqDTO dto);

    void accountIncrease(AccountIncreaseReqDTO dto);

    void accountDecrease(AccountDecreaseReqDTO dto);

    AccountAgentPayResDTO agentPay(AccountAgentPayReqDTO dto);

    void agentPayRollback(AccountAgentPayRollbackReqDTO dto);
}
