package com.smartpay.cbp.account.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.smartpay.cbp.account.dto.req.BaseDTO;
import com.smartpay.cbp.account.entity.AccountTxn;

import java.util.Collection;
import java.util.List;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/4 17:09
 */
public interface AccountTxnService extends IService<AccountTxn> {

    void saveTxn(AccountTxn accountTxn);

    AccountTxn saveTxn(BaseDTO dto);

    void updateTxn(String txnId, String status, String responseCode, String responseMsg);

    List<AccountTxn> getByIds(Collection<String> ids);
}
