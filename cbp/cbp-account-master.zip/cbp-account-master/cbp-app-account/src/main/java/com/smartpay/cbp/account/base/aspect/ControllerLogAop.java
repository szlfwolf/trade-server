package com.smartpay.cbp.account.base.aspect;

import com.smartpay.cbp.account.util.WebUtils;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/18 17:09
 */
@Slf4j
@Aspect
@Component
public class ControllerLogAop {

    @Around("execution(public * com.smartpay.cbp.account.controller.*.*(..))")
    public Object around(ProceedingJoinPoint pjp) throws Throwable {
        Signature signature = pjp.getSignature();
        MethodSignature methodSignature = (MethodSignature) signature;
        Method method = methodSignature.getMethod();
        ApiOperation apiOperation = method.getAnnotation(ApiOperation.class);
        if (apiOperation != null) {
            log.info("<<<<< {}，uri：{}，参数：{}", apiOperation.value(), WebUtils.currentRequest().getRequestURI(), pjp.getArgs());
        } else {
            log.info("<<<<< class = {}, method = {}, args = {}", pjp.getTarget().getClass(), method, pjp.getArgs());
        }
        return pjp.proceed();
    }
}
