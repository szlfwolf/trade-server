package com.smartpay.cbp.account.handler;

import com.smartpay.cbp.account.base.ApiException;
import com.smartpay.cbp.account.base.enums.ErrorEnum;
import com.smartpay.cbp.account.config.MinIoConfigProperties;
import io.minio.MinioClient;
import io.minio.PutObjectArgs;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/23 11:34
 */
@Slf4j
@Component
public class FileHandler {

    @Autowired
    private MinIoConfigProperties minIoConfigProperties;

    @Autowired
    private MinioClient minioClient;

    public String upload(String path, String fileName, byte[] content) {
        if (path.startsWith("/")) {
            path = path.substring(1);
        }
        if (path.endsWith("/")) {
            path = path.substring(0, path.length() -1);
        }
        String pathName = String.join("/", path, fileName);
        PutObjectArgs args = PutObjectArgs.builder()
                .bucket(minIoConfigProperties.getBucketName())
                .object(pathName)
                .stream(new ByteArrayInputStream(content), content.length, -1)
                .contentType(fileName.substring(fileName.lastIndexOf(".")))
                .build();
        try {
            minioClient.putObject(args);
        } catch (Exception e) {
            log.error("MinIO上传文件出现异常！！", e);
            throw new ApiException(ErrorEnum.SYSTEM_ERROR);
        }
        return String.join("/", minIoConfigProperties.getUrl(), minIoConfigProperties.getBucketName(), pathName);
    }
}
