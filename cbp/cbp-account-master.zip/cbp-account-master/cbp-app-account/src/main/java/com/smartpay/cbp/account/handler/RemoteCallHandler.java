package com.smartpay.cbp.account.handler;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.smartpay.cbp.account.base.ApiException;
import com.smartpay.cbp.common.core.constant.SecurityConstants;
import com.smartpay.cbp.common.core.domain.R;
import com.smartpay.cbp.console.dto.MerchantChargeFeignDto;
import com.smartpay.cbp.console.dto.MerchantInfoForeignDto;
import com.smartpay.cbp.console.dto.MerchantInfoListDto;
import com.smartpay.cbp.console.feign.CommonApiService;
import com.smartpay.cbp.console.feign.MerchantInfoApiService;
import com.smartpay.cbp.console.vo.MerchantInfoListVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/8 19:33
 */
@Slf4j
@Component
public class RemoteCallHandler {

    private static final Cache<String, String> MCHT_NAME_CACHE = CacheBuilder.newBuilder()
            .concurrencyLevel(Runtime.getRuntime().availableProcessors())
            .maximumSize(10)
            .expireAfterWrite(5, TimeUnit.MINUTES)
            .build();

    private static final Cache<String, String> MCHT_PRODUCT_FEE_MODE_CACHE = CacheBuilder.newBuilder()
            .concurrencyLevel(Runtime.getRuntime().availableProcessors())
            .maximumSize(32)
            .expireAfterWrite(3, TimeUnit.MINUTES)
            .build();

    @Autowired
    private MerchantInfoApiService merchantInfoApiService;
    
    @Autowired
    private CommonApiService commonApiService;

    public String getMchtName(String mchtNo) {
        String cacheValue = MCHT_NAME_CACHE.getIfPresent(mchtNo);
        if (!StringUtils.hasText(cacheValue)) {
            log.info("调用远程接口根据商户号【{}】查询商户信息。。。", mchtNo);
            R<MerchantInfoForeignDto> result = merchantInfoApiService.queryMerchantForeign(mchtNo, SecurityConstants.INNER);
            log.info("调用远程接口根据商户号【{}】查询商户信息结果：【{}】", mchtNo, result);
            if (Boolean.TRUE.equals(R.isError(result))) {
                throw new ApiException(result.getCode(), result.getMsg());
            }
            MerchantInfoForeignDto data = result.getData();
            MCHT_NAME_CACHE.put(mchtNo, data.getMerchantName());
            cacheValue = data.getMerchantName();
        }
        return cacheValue;
    }

    public String getMchtFeeMode(String merchantNo, String secondLevelProductCode) {
        R<MerchantChargeFeignDto> result = commonApiService.findChargeInfo(merchantNo, secondLevelProductCode, SecurityConstants.INNER);
        if (Boolean.TRUE.equals(R.isError(result))) {
            throw new ApiException(result.getCode(), result.getMsg());
        }
        MerchantChargeFeignDto data = result.getData();
        return data.getDeliveryPattern();
    }

    public Map<String, String> getMchtName(Collection<String> mchtNos) {
        Map<String, String> result = new HashMap<>();
        if (CollectionUtils.isEmpty(mchtNos)) {
            return result;
        }
        Set<String> needQueryMchtNos = new HashSet<>();
        for (String mchtNo : mchtNos) {
            String cacheValue = MCHT_NAME_CACHE.getIfPresent(mchtNo);
            if (StringUtils.hasText(cacheValue)) {
                result.put(mchtNo, cacheValue);
                continue;
            }
            needQueryMchtNos.add(mchtNo);
        }
        if (!needQueryMchtNos.isEmpty()) {
            log.info("调用远程接口：根据商户号【{}】查询商户名称。。。", needQueryMchtNos);
            MerchantInfoListVo vo = new MerchantInfoListVo();
            vo.setMerchantNo(new ArrayList<>(needQueryMchtNos));
            R<List<MerchantInfoListDto>> remoteResult = merchantInfoApiService.queryMerchantInfoList(vo, SecurityConstants.INNER);
            log.info("调用远程接口：根据商户号【{}】查询商户名称结果：【{}】", needQueryMchtNos, remoteResult);
            if (Boolean.TRUE.equals(R.isError(remoteResult))) {
                throw new ApiException(remoteResult.getCode(), remoteResult.getMsg());
            }
            if (CollectionUtils.isEmpty(remoteResult.getData())) {
                return result;
            }
            for (MerchantInfoListDto dto : remoteResult.getData()) {
                MCHT_NAME_CACHE.put(dto.getMerchantNo(), dto.getMerchantName());
                result.put(dto.getMerchantNo(), dto.getMerchantName());
            }
        }
        return result;
    }
}
