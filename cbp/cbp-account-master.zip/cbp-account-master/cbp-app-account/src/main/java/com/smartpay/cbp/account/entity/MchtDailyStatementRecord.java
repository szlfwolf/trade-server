package com.smartpay.cbp.account.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 商户每日对账单记录表
 * </p>
 *
 * @author zhuzw
 * @since 2022-11-23
 */
@Data
@TableName("T_MCHT_DAILY_STATEMENT_RECORD")
@ApiModel(value = "MchtDailyStatementRecord对象", description = "商户每日对账单记录表")
public class MchtDailyStatementRecord implements Serializable {

    private static final long serialVersionUID = 1L;

    private String id;

    @ApiModelProperty("对账单日期")
    private String statementDate;

    @ApiModelProperty("商户号")
    private String merchantNo;

    @ApiModelProperty("账户类型")
    private String accountType;

    @ApiModelProperty("币种")
    private String currency;

    @ApiModelProperty("账户id")
    private String accountId;

    @ApiModelProperty("对账单文件地址")
    private String statementFileUrl;

    private Date crtTime;

    private Date uptTime;

}
