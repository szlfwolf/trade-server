package com.smartpay.cbp.account.config;

import com.alibaba.fastjson.JSON;
import com.smartpay.cbp.common.core.domain.R;
import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

import java.lang.reflect.Method;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 全局响应增强
 *
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/4 16:42
 */
@RestControllerAdvice(basePackages = "com.smartpay.cbp.account.controller")
public class GlobalResponseAdvice implements ResponseBodyAdvice<Object> {

    private final ConcurrentHashMap<Method, Boolean> reference = new ConcurrentHashMap<>();

    @Override
    public boolean supports(MethodParameter returnType, Class<? extends HttpMessageConverter<?>> converterType) {
        Method method = returnType.getMethod();
        if (method == null) {
            return false;
        }
        return reference.computeIfAbsent(method, m -> m.isAnnotationPresent(ResponseBody.class) || m.getDeclaringClass().isAnnotationPresent(RestController.class));
    }

    @Override
    public Object beforeBodyWrite(Object body, MethodParameter returnType, MediaType selectedContentType, Class<? extends HttpMessageConverter<?>> selectedConverterType, ServerHttpRequest request, ServerHttpResponse response) {
        if (body instanceof R) {
            return body;
        }
        R result = R.ok(body);
        if (body instanceof String || selectedConverterType.isAssignableFrom(StringHttpMessageConverter.class)) {
            return JSON.toJSONString(result);
        }
        return result;
    }
}
