package com.smartpay.cbp.account.service;

import com.smartpay.cbp.account.entity.AccountChange;

import java.util.Date;
import java.util.List;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/15 19:32
 */
public interface AccountQuerySerivce {

    List<AccountChange> accountChangeList(String accountId, Date startTime, Date endTime, String txnType, Long amount, boolean page);
}
