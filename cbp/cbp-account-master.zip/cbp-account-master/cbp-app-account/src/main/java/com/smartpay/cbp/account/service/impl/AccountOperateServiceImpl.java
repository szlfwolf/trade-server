package com.smartpay.cbp.account.service.impl;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.smartpay.cbp.account.base.ApiException;
import com.smartpay.cbp.account.base.annotation.AccountLock;
import com.smartpay.cbp.account.base.annotation.Txn;
import com.smartpay.cbp.account.base.enums.AccountStatusEnum;
import com.smartpay.cbp.account.base.enums.CreditDebitEnum;
import com.smartpay.cbp.account.base.enums.ErrorEnum;
import com.smartpay.cbp.account.base.enums.ReversalFlagEnum;
import com.smartpay.cbp.account.base.threadlocal.TxnIdThreadLocal;
import com.smartpay.cbp.account.config.IdGenerator;
import com.smartpay.cbp.account.constant.AccountTxnTypeEnum;
import com.smartpay.cbp.account.constant.AccountTypeEnum;
import com.smartpay.cbp.account.dto.req.*;
import com.smartpay.cbp.account.dto.res.AccountAgentPayResDTO;
import com.smartpay.cbp.account.entity.AccountChange;
import com.smartpay.cbp.account.entity.AccountInfo;
import com.smartpay.cbp.account.entity.AccountInfoChange;
import com.smartpay.cbp.account.entity.AccountTxn;
import com.smartpay.cbp.account.handler.AccountInfoSignHandler;
import com.smartpay.cbp.account.handler.RemoteCallHandler;
import com.smartpay.cbp.account.service.AccountChangeService;
import com.smartpay.cbp.account.service.AccountInfoService;
import com.smartpay.cbp.account.service.AccountOperateService;
import com.smartpay.cbp.account.service.AccountTxnService;
import com.smartpay.cbp.account.util.EnumUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/8 10:06
 */
@Slf4j
@Service
public class AccountOperateServiceImpl implements AccountOperateService {

    @Autowired
    private AccountInfoService accountInfoService;

    @Autowired
    private AccountChangeService accountChangeService;

    @Autowired
    private IdGenerator idGenerator;

    @Autowired
    private AccountInfoSignHandler accountInfoSignHandler;

    @Autowired
    private AccountTxnService accountTxnService;

    @Autowired
    private RemoteCallHandler remoteCallHandler;

    /**
     * 账户开户
     *
     * @param dto 开户参数
     * @return 账户id
     */
    @Override
    @Txn
    @AccountLock
    @Transactional(rollbackFor = Exception.class)
    public String openAccount(OpenAccountReqDTO dto) {
        // 查询商户名下所有账户，检查是否商户是否已开户
        Wrapper<AccountInfo> wrapper = Wrappers.lambdaQuery(AccountInfo.class)
                .eq(AccountInfo::getExtAccountNo, dto.getMerchantNo())
                .eq(AccountInfo::getCurrency, dto.getCurreny())
                .eq(AccountInfo::getAccountType, dto.getAccountType())
                .in(AccountInfo::getStatus, AccountStatusEnum.NORMAL.getValue(), AccountStatusEnum.FREEZE.getValue());
        AccountInfo oldAccountInfo = accountInfoService.getOne(wrapper);
        // 如果账户已经开通了，直接结束
        if (oldAccountInfo != null) {
            return oldAccountInfo.getId();
        }
        AccountInfo accountInfo = new AccountInfo();
        accountInfo.setId(idGenerator.nextId());
        accountInfo.setExtAccountNo(dto.getMerchantNo());
        accountInfo.setBalance(0L);
        accountInfo.setCurrency(dto.getCurreny());
        accountInfo.setAccountType(dto.getAccountType());
        accountInfo.setDac(accountInfoSignHandler.sign(accountInfo));
        accountInfo.setStatus(AccountStatusEnum.NORMAL.getValue());
        accountInfo.setCrtTime(new Date());
        accountInfo.setUptTime(new Date());
        accountInfoService.save(accountInfo);
        return accountInfo.getId();
    }

    /**
     * 账户加款
     *
     * @param dto 请求参数
     */
    @Override
    @Txn
    @AccountLock
    @Transactional(rollbackFor = Exception.class)
    public void accountIncrease(AccountIncreaseReqDTO dto) {
        AccountInfoChange aic = new AccountInfoChange();
        aic.setMerchantNo(dto.getMerchantNo());
        aic.setTxnCode(dto.getTxnCode());
        aic.setAccountType(dto.getAccountType());
        aic.setAmount(dto.getAmount());
        aic.setCurrency(dto.getCurrency());
        handleAccountInfoChange(aic, CreditDebitEnum.CREDIT);
    }

    /**
     * 账户减款
     *
     * @param dto 请求参数
     */
    @Override
    @Txn
    @AccountLock
    @Transactional(rollbackFor = Exception.class)
    public void accountDecrease(AccountDecreaseReqDTO dto) {
        AccountInfoChange aic = new AccountInfoChange();
        aic.setMerchantNo(dto.getMerchantNo());
        aic.setTxnCode(dto.getTxnCode());
        aic.setAccountType(dto.getAccountType());
        aic.setAmount(dto.getAmount());
        aic.setCurrency(dto.getCurrency());
        handleAccountInfoChange(aic, CreditDebitEnum.DEBIT);
    }

    @Override
    @Txn
    @AccountLock
    @Transactional(rollbackFor = Exception.class)
    public AccountAgentPayResDTO agentPay(AccountAgentPayReqDTO dto) {
        // 查询商户手续费模式 1-后收 2-预收 3-实收
        String feeMode = remoteCallHandler.getMchtFeeMode(dto.getMerchantNo(), dto.getSecondLevelProductCode());
        // 根据手续费模式选择手续费账户，1：后收外扣，2：预收外扣，3：实收内扣
        // 1和2的手续费由商户承担，3的手续费由收款人承担
        AccountTypeEnum feeAccountType = null;
        CreditDebitEnum feeCreditDebitEnum = null;
        switch (feeMode) {
            case "1":
                feeAccountType = AccountTypeEnum.AFTER_RECEIVING_FEE_ACCOUNT;
                feeCreditDebitEnum = CreditDebitEnum.CREDIT;
                break;
            case "2":
                feeAccountType = AccountTypeEnum.PRECOLLECTED_FEE_ACCOUNT;
                feeCreditDebitEnum = CreditDebitEnum.DEBIT;
                break;
            case "3":
                feeAccountType = AccountTypeEnum.REALTIME_FEE_ACCOUNT;
                feeCreditDebitEnum = CreditDebitEnum.CREDIT;
                break;
            default:
                throw new ApiException(ErrorEnum.UNABLE_TO_HADNLE);
        }

        // 添加账户变动记录、修改账户信息（余额账户+对应的手续费账户）
        AccountInfoChange balanceInfoChange = new AccountInfoChange();
        balanceInfoChange.setMerchantNo(dto.getMerchantNo());
        balanceInfoChange.setTxnCode(AccountTxnTypeEnum.D002.getCode());
        balanceInfoChange.setAccountType(AccountTypeEnum.BALANCE_ACCOUNT.getCode());
        balanceInfoChange.setCurrency(dto.getCurrency());
        balanceInfoChange.setAmount(dto.getAmount());
        handleAccountInfoChange(balanceInfoChange, CreditDebitEnum.DEBIT);

        AccountInfoChange feeInfoChange = new AccountInfoChange();
        feeInfoChange.setMerchantNo(dto.getMerchantNo());
        feeInfoChange.setTxnCode(AccountTxnTypeEnum.D003.getCode());
        feeInfoChange.setAccountType(feeAccountType.getCode());
        feeInfoChange.setCurrency(dto.getCurrency());
        feeInfoChange.setAmount(dto.getFee());
        handleAccountInfoChange(feeInfoChange, feeCreditDebitEnum);

        AccountAgentPayResDTO res = new AccountAgentPayResDTO();
        res.setTxnId(TxnIdThreadLocal.get());
        return res;
    }

    @Override
    @Txn
    @AccountLock
    @Transactional(rollbackFor = Exception.class)
    public void agentPayRollback(AccountAgentPayRollbackReqDTO dto) {
        // 重新查询原交易信息，并判断原交易是否可以回退（1、原交易不是回退交易，2、原交易还没有回退成功过）
        AccountTxn originTxn = accountTxnService.getById(dto.getOriginTxnId());
        if (originTxn.getTxnCode().equals(AccountTxnTypeEnum.I003.getCode())) {
            log.error("交易【{}】为退款交易，不允许对退款交易进行退款！", originTxn);
            throw new ApiException(ErrorEnum.REFUND_TO_REFUND);
        }
        if (ReversalFlagEnum.ALREADY.getValue().equals(originTxn.getReversalFlag())) {
            log.error("交易【{}】已退款，不允许重复退款！", originTxn);
            throw new ApiException(ErrorEnum.REPEAT_REFUND);
        }

        // 根据原账户交易查询对应的账户变动记录
        Wrapper<AccountChange> wrapper = Wrappers.lambdaQuery(AccountChange.class)
                .eq(AccountChange::getTxnId, originTxn.getId())
                .ge(AccountChange::getCrtTime, originTxn.getCrtTime());
        List<AccountChange> changes = accountChangeService.list(wrapper);
        for (AccountChange change : changes) {
            String originCrDr = change.getCrDr();
            CreditDebitEnum targetCrDr;
            if (CreditDebitEnum.DEBIT.getValue().equals(originCrDr)) {
                targetCrDr = CreditDebitEnum.CREDIT;
            } else if (CreditDebitEnum.CREDIT.getValue().equals(originCrDr)) {
                targetCrDr = CreditDebitEnum.DEBIT;
            } else {
                throw new ApiException(ErrorEnum.SYSTEM_ERROR);
            }
            AccountInfoChange aic = new AccountInfoChange();
            aic.setMerchantNo(dto.getMerchantNo());
            aic.setTxnCode(AccountTxnTypeEnum.I003.getCode());
            aic.setAccountType(change.getAccountType());
            aic.setAccountId(change.getAccountId());
            aic.setAmount(change.getAmount());
            aic.setCurrency(change.getCurrency());
            handleAccountInfoChange(aic, targetCrDr);
        }

        // 更新原交易信息，使其变成已冲正
        AccountTxn at = new AccountTxn();
        at.setId(originTxn.getId());
        at.setReversalFlag(ReversalFlagEnum.ALREADY.getValue());
        at.setUptTime(new Date());
        accountTxnService.updateById(at);

    }

    private void handleAccountInfoChange(AccountInfoChange aic, CreditDebitEnum creditDebitEnum) {
        AccountInfo oldInfo = getAndCheckAccountInfo(aic);

        long newBalance = computeAfterBalance(oldInfo, aic, creditDebitEnum);

        String txnId = TxnIdThreadLocal.get();
        Date txnTime = idGenerator.getGenerateDate(txnId);

        AccountChange accountChange = new AccountChange();
        accountChange.setId(idGenerator.nextId());
        accountChange.setTxnId(txnId);
        accountChange.setTxnCode(aic.getTxnCode());
        accountChange.setAccountId(oldInfo.getId());
        accountChange.setAccountType(aic.getAccountType());
        accountChange.setExtAccountNo(aic.getMerchantNo());
        accountChange.setAmount(aic.getAmount());
        accountChange.setBeforeBalance(oldInfo.getBalance());
        accountChange.setAfterBalance(newBalance);
        accountChange.setCurrency(aic.getCurrency());
        accountChange.setCrDr(creditDebitEnum.getValue());
        accountChange.setCrtTime(txnTime);
        accountChange.setUptTime(txnTime);
        accountChangeService.save(accountChange);

        AccountInfoSignHandler.AccountInfoSign sign = new AccountInfoSignHandler.AccountInfoSign();
        sign.setAccountId(oldInfo.getId());
        sign.setCurrency(oldInfo.getCurrency());
        sign.setAccountType(oldInfo.getAccountType());
        sign.setBalance(newBalance);
        AccountInfo accountInfo = new AccountInfo();
        accountInfo.setId(oldInfo.getId());
        accountInfo.setDac(accountInfoSignHandler.sign(sign));
        accountInfo.setBalance(newBalance);
        accountInfo.setUptTime(txnTime);
        accountInfoService.updateById(accountInfo);
    }

    private long computeAfterBalance(AccountInfo oldInfo, AccountInfoChange aic, CreditDebitEnum creditDebitEnum) {
        if (creditDebitEnum.equals(CreditDebitEnum.CREDIT)) {
            return oldInfo.getBalance() + aic.getAmount();
        } else if (creditDebitEnum.equals(CreditDebitEnum.DEBIT)) {
            long newBalance = oldInfo.getBalance() - aic.getAmount();
            if (newBalance < 0) {
                String accountTypeDesc = EnumUtils.getAccountTypeEnum(aic.getAccountType()).getDesc();
                log.error("{}余额【{}】不足以进行扣减操作金额【{}】!", accountTypeDesc, oldInfo.getBalance(), aic.getAmount());
                throw new ApiException(ErrorEnum.ACCOUNT_BALANCE_IS_SHORT, accountTypeDesc);
            }
            return newBalance;
        } else {
            log.error("非约定的参数！！==》【{}】", creditDebitEnum);
            throw new ApiException(ErrorEnum.SYSTEM_ERROR);
        }
    }

    private AccountInfo getAndCheckAccountInfo(AccountInfoChange aic) {
        // 查询账户余额
        AccountInfo oldInfo;
        if (aic.getAccountId() != null) {
            oldInfo = accountInfoService.getById(aic.getAccountId());
        } else {
            Wrapper<AccountInfo> wrapper = Wrappers.lambdaQuery(AccountInfo.class)
                    .eq(AccountInfo::getExtAccountNo, aic.getMerchantNo())
                    .eq(AccountInfo::getAccountType, aic.getAccountType())
                    .eq(AccountInfo::getCurrency, aic.getCurrency());
            oldInfo = accountInfoService.getOne(wrapper);
        }
        if (oldInfo == null) {
            log.error("根据参数【{}】查询账户信息为空！！", aic);
            throw new ApiException(ErrorEnum.ACCOUNT_NO_EXIST);
        }
        if (!oldInfo.getStatus().equals(AccountStatusEnum.NORMAL.getValue())) {
            log.error("账户状态为非正常状态，不允许进行加、减款操作！");
            throw new ApiException(ErrorEnum.ACCOUNT_STATUS_ABNORMAL);
        }

        // 账户DAC校验
        accountInfoSignHandler.validator(oldInfo.getDac(), oldInfo);

        return oldInfo;
    }
}
