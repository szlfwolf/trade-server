package com.smartpay.cbp.account.controller;

import cn.hutool.core.date.DateUnit;
import cn.hutool.core.date.DateUtil;
import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.github.pagehelper.PageInfo;
import com.smartpay.cbp.account.base.ApiException;
import com.smartpay.cbp.account.base.Constants;
import com.smartpay.cbp.account.base.Page;
import com.smartpay.cbp.account.base.enums.AccountStatusEnum;
import com.smartpay.cbp.account.base.enums.ErrorEnum;
import com.smartpay.cbp.account.dto.res.AccountChangeResDTO;
import com.smartpay.cbp.account.dto.res.AccountInfoResDTO;
import com.smartpay.cbp.account.dto.res.MchtAccountSatementQueryResDTO;
import com.smartpay.cbp.account.entity.AccountChange;
import com.smartpay.cbp.account.entity.AccountInfo;
import com.smartpay.cbp.account.entity.MchtDailyStatementRecord;
import com.smartpay.cbp.account.service.AccountInfoService;
import com.smartpay.cbp.account.service.AccountQuerySerivce;
import com.smartpay.cbp.account.service.MchtDailyStatementRecordService;
import com.smartpay.cbp.account.util.BeanUtils;
import com.smartpay.cbp.account.util.ConvertUtils;
import com.smartpay.cbp.common.core.utils.PageUtils;
import com.smartpay.cbp.common.core.utils.StringUtils;
import com.smartpay.cbp.common.security.utils.SecurityUtils;
import com.smartpay.cbp.system.api.model.LoginUser;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.List;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/23 16:57
 */
@Api(tags = "商服-账户查询")
@Slf4j
@RestController
@RequestMapping("accountQueryForMcht")
public class AccountQueryForMchtController {

    @Autowired
    private AccountInfoService accountInfoService;

    @Autowired
    private AccountQuerySerivce accountQuerySerivce;

    @Autowired
    private MchtDailyStatementRecordService mchtDailyStatementRecordService;

    /**
     * 查询商户的账户列表
     *
     * @param accountType 账户类型
     * @param currency    币种
     * @return 账户列表
     */
    @ApiOperation("查询商户的账户列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "accountType", value = "账户类型", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "currency", value = "币种", dataType = "String", paramType = "query")})
    @GetMapping("accountList")
    public List<AccountInfoResDTO> accountList(@RequestParam(value = "accountType", required = false) String accountType,
                                               @RequestParam(value = "currency", required = false) String currency) {

        String merchantNo = getLoginMcht();

        Wrapper<AccountInfo> wrapper = Wrappers.lambdaQuery(AccountInfo.class)
                .eq(AccountInfo::getExtAccountNo, merchantNo)
                .eq(StringUtils.hasText(accountType), AccountInfo::getAccountType, accountType)
                .eq(StringUtils.hasText(currency), AccountInfo::getCurrency, currency)
                .in(AccountInfo::getStatus, AccountStatusEnum.NORMAL.getValue(), AccountStatusEnum.FREEZE.getValue());
        List<AccountInfo> list = accountInfoService.list(wrapper);
        return BeanUtils.mapping(list, e -> ConvertUtils.toAccountInfoDTO(e, null));
    }

    @ApiOperation("账户变动记录列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "pageNum", value = "页码", dataType = "Integer", paramType = "query", required = true),
            @ApiImplicitParam(name = "pageSize", value = "页大小", dataType = "Integer", paramType = "query", required = true),
            @ApiImplicitParam(name = "accountId", value = "账户号", dataType = "String", paramType = "query", required = true),
            @ApiImplicitParam(name = "startTime", value = "开始时间", dataType = "String", paramType = "query", required = true),
            @ApiImplicitParam(name = "endTime", value = "结束时间", dataType = "String", paramType = "query", required = true),
            @ApiImplicitParam(name = "txnType", value = "交易类型", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "amount", value = "变动金额", dataType = "Long", paramType = "query")})
    @GetMapping("accountChangeList")
    public Page<AccountChangeResDTO> accountChangeList(@RequestParam("accountId") String accountId,
                                                       @RequestParam("startTime") String startTime,
                                                       @RequestParam("endTime") String endTime,
                                                       @RequestParam(value = "txnType", required = false) String txnType,
                                                       @RequestParam(value = "amount", required = false) Long amount) {
        if (org.apache.commons.lang3.StringUtils.isAnyBlank(accountId, startTime, endTime)) {
            throw new ApiException(ErrorEnum.PARAM_ERROR);
        }
        Date start = DateUtil.parse(startTime);
        Date end = DateUtil.parse(endTime);
        if (DateUtil.between(start, end, DateUnit.DAY) > 93) {
            throw new ApiException(ErrorEnum.TIME_SPAN_TOO_LONG);
        }

        // 根据账户id查询账户信息
        AccountInfo ai = accountInfoService.getById(accountId);
        if (ai == null) {
            log.error("根据账户id【{}】查询账户信息为空！！", accountId);
            throw new ApiException(ErrorEnum.PARAM_ERROR);
        }
        if (!getLoginMcht().equals(ai.getExtAccountNo())) {
            log.error("参数账户id【{}】对应的商户号不是登陆用户的商户号【{}】！", accountId, ai.getExtAccountNo());
            throw new ApiException(ErrorEnum.UNLAWFUL_PARAM);
        }

        // 查询账户变动记录
        List<AccountChange> changes = accountQuerySerivce.accountChangeList(accountId, start, end, txnType,
                amount, true);

        List<AccountChangeResDTO> dtos = BeanUtils.mapping(changes, e -> ConvertUtils.toAccountChangeDTO(e, null));
        PageInfo<AccountChange> pageInfo = new PageInfo<>(changes);
        return Page.ok(dtos, pageInfo.getTotal());
    }

    @ApiOperation("查询账户对账单")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "accountType", value = "账户类型", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "currency", value = "币种", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "startTime", value = "开始时间", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "endTime", value = "结束时间", dataType = "String", paramType = "query")})
    @GetMapping("queryAccountSatement")
    public Page<MchtAccountSatementQueryResDTO> queryAccountSatement(@RequestParam(value = "accountType", required = false) String accountType,
                                                                     @RequestParam(value = "currency", required = false) String currency,
                                                                     @RequestParam(value = "startTime", required = false) String startTime,
                                                                     @RequestParam(value = "endTime", required = false) String endTime) {

        String mchtNo = getLoginMcht();
        String start = null;
        String end = null;
        if (StringUtils.hasText(startTime)) {
            start = DateUtil.format(DateUtil.parse(startTime), Constants.YMD);
        }
        if (StringUtils.hasText(endTime)) {
            end = DateUtil.format(DateUtil.parse(endTime), Constants.YMD);
        }

        PageUtils.startPage();
        Wrapper<MchtDailyStatementRecord> wrapper = Wrappers.lambdaQuery(MchtDailyStatementRecord.class)
                .eq(MchtDailyStatementRecord::getMerchantNo, mchtNo)
                .eq(StringUtils.hasText(accountType), MchtDailyStatementRecord::getAccountType, accountType)
                .eq(StringUtils.hasText(currency), MchtDailyStatementRecord::getCurrency, currency)
                .le(StringUtils.hasText(end), MchtDailyStatementRecord::getStatementDate, end)
                .ge(StringUtils.hasText(start), MchtDailyStatementRecord::getStatementDate, start);
        List<MchtDailyStatementRecord> list = mchtDailyStatementRecordService.list(wrapper);

        List<MchtAccountSatementQueryResDTO> dtos = BeanUtils.mapping(list, e -> {
            MchtAccountSatementQueryResDTO dto = new MchtAccountSatementQueryResDTO();
            dto.setAccountId(e.getAccountId());
            dto.setAccountType(e.getAccountType());
            dto.setCurrency(e.getCurrency());
            dto.setStatementDate(e.getStatementDate());
            dto.setStatementFileUrl(e.getStatementFileUrl());
            return dto;
        });
        PageInfo<MchtDailyStatementRecord> pageInfo = new PageInfo<>(list);
        return Page.ok(dtos, pageInfo.getTotal());
    }

    private String getLoginMcht() {
        LoginUser loginUser = SecurityUtils.getLoginUser();
        String merchantNo = loginUser.getSysUser().getMerchantNo();
        if (!StringUtils.hasText(merchantNo)) {
            log.error("未找到商户号信息！");
            throw new ApiException(ErrorEnum.NOT_MCHT_NO);
        }
        return merchantNo;
    }
}
