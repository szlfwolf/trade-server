package com.smartpay.cbp.account.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.util.Date;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/7 09:30
 */
@Data
@TableName("T_ACCOUNT_CHANGE")
public class AccountChange {

    private String id;

    private String txnId;

    private String txnCode;

    private String accountId;

    private String accountType;

    private String extAccountNo;

    private Long amount;

    private Long beforeBalance;

    private Long afterBalance;

    private String currency;

    private String crDr;

    private Date crtTime;

    private Date uptTime;

    @TableField(exist = false)
    private AccountTxn accountTxn;
}
