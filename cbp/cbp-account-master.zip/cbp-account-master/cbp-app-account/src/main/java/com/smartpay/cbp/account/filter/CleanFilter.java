package com.smartpay.cbp.account.filter;

import com.smartpay.cbp.account.handler.CleanHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import java.io.IOException;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/8 11:31
 */
@WebFilter
@Component
public class CleanFilter implements Filter {

    @Autowired
    private CleanHandler cleanHandler;

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        try {
            filterChain.doFilter(servletRequest, servletResponse);
        } finally {
            cleanHandler.handle();
        }
    }
}
