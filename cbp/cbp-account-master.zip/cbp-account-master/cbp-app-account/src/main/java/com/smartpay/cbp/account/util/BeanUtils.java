package com.smartpay.cbp.account.util;

import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Function;

/**
 * bean操作工具类
 *
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/6/30 19:51
 */
public class BeanUtils {

    /**
     * list集合元素映射
     *
     * @param list            list集合
     * @param mappingFunction 映射函数
     * @param <INT>           list集合元素类型
     * @param <OUT>           映射结果类型
     * @return 映射结果集合
     */
    public static <INT, OUT> List<OUT> mapping(List<INT> list, Function<INT, OUT> mappingFunction) {
        if (CollectionUtils.isEmpty(list)) {
            return Collections.emptyList();
        }
        List<OUT> outs = new ArrayList<>(list.size());
        for (INT e : list) {
            OUT out = mappingFunction.apply(e);
            if (out != null) {
                outs.add(out);
            }
        }
        return outs;
    }

}
