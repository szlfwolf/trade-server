package com.smartpay.cbp.account.service.impl;

import cn.hutool.core.date.DateUtil;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.smartpay.cbp.account.base.enums.CreditDebitEnum;
import com.smartpay.cbp.account.dto.res.ExportAccountStatementInfoResDTO;
import com.smartpay.cbp.account.entity.AccountChange;
import com.smartpay.cbp.account.entity.AccountStatement;
import com.smartpay.cbp.account.entity.AccountTxn;
import com.smartpay.cbp.account.entity.AccountTxnExtInfo;
import com.smartpay.cbp.account.mapper.AccountChangeMapper;
import com.smartpay.cbp.account.service.AccountChangeService;
import com.smartpay.cbp.account.service.AccountTxnService;
import com.smartpay.cbp.account.util.BeanUtils;
import com.smartpay.cbp.account.util.EnumUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * <p>
 * 账户变动记录表 服务实现类
 * </p>
 *
 * @author zhuzw
 * @since 2022-11-07
 */
@Service
public class AccountChangeServiceImpl extends ServiceImpl<AccountChangeMapper, AccountChange> implements AccountChangeService {

    @Autowired
    private AccountChangeMapper accountChangeMapper;

    @Autowired
    private AccountTxnService accountTxnService;

    @Override
    public List<AccountStatement> queryStatement(String mchtNo, String accountType, String currency, String startTime, String endTime) {
        Date start = parseOrYesterday(startTime);
        Date end = parseOrYesterday(endTime);
        start = DateUtil.beginOfDay(start);
        end = DateUtil.endOfDay(end);
        return accountChangeMapper.selectStatementStatistic(mchtNo, accountType, currency, start, end);
    }

    @Override
    public List<ExportAccountStatementInfoResDTO> queryStatementInfo(String accountId, Date start, Date end) {
        Wrapper<AccountChange> wrapper = Wrappers.lambdaQuery(AccountChange.class)
                .eq(StringUtils.hasText(accountId), AccountChange::getAccountId, accountId)
                .ge(AccountChange::getCrtTime, DateUtil.beginOfDay(start))
                .le(AccountChange::getCrtTime, DateUtil.endOfDay(end))
                .orderByDesc(AccountChange::getId);
        List<AccountChange> list = baseMapper.selectList(wrapper);

        Set<String> txnIds = list.stream().map(AccountChange::getTxnId).collect(Collectors.toSet());
        List<AccountTxn> txns = accountTxnService.getByIds(txnIds);
        Map<String, AccountTxn> txnMap = txns.stream().collect(Collectors.toMap(AccountTxn::getId, e -> e));
        return BeanUtils.mapping(list, e -> {
            ExportAccountStatementInfoResDTO res = new ExportAccountStatementInfoResDTO();
            res.setId(e.getId());
            res.setAccountId(e.getAccountId());
            res.setBeforeBalance(e.getBeforeBalance());
            res.setAfterBalance(e.getAfterBalance());
            res.setAmount(e.getAmount());
            res.setSymbol(CreditDebitEnum.getByValue(e.getCrDr()).getSymbol());
            AccountTxn txn = txnMap.get(e.getTxnId());
            res.setMchtOrderNo(txn.getExtOriginTxnId());
            res.setTxnDate(DateUtil.formatDate(e.getCrtTime()));
            String extInfo = txn.getExtInfo();
            if (StringUtils.hasText(extInfo)) {
                AccountTxnExtInfo info = JSON.parseObject(extInfo, AccountTxnExtInfo.class);
                res.setSerialNo(info.getAgentPaySerialId());
                res.setPayeeAccount(info.getPayeeAccount());
                res.setPayeeBank(info.getPayeeBank());
                res.setPayeeName(info.getPayeeName());
            }
            res.setDesc(EnumUtils.getAccountTxnTypeEnum(e.getTxnCode()).getDesc());
            return res;
        });
    }

    private Date parseOrYesterday(String datetime) {
        if (StringUtils.hasText(datetime)) {
            return DateUtil.parse(datetime);
        }
        return DateUtil.yesterday();
    }
}
