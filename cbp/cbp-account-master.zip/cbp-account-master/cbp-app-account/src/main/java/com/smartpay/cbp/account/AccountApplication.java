package com.smartpay.cbp.account;

import com.smartpay.cbp.common.security.annotation.EnableCustomConfig;
import com.smartpay.cbp.common.security.annotation.EnableRyFeignClients;
import com.smartpay.cbp.common.swagger.annotation.EnableCustomSwagger2;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Carer
 * @desc  账户模块主启动程序
 * @date 2022/10/26 17:31
 */
@EnableCustomConfig
@EnableCustomSwagger2
@EnableRyFeignClients
@SpringBootApplication
@MapperScan("com.smartpay.cbp.account.mapper")
public class AccountApplication {

    public static void main(String[] args) {
        SpringApplication.run(AccountApplication.class, args);
    }
}
