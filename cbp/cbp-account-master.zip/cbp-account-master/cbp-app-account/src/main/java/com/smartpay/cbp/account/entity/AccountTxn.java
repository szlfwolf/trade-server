package com.smartpay.cbp.account.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.util.Date;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/4 17:31
 */
@Data
@TableName("T_ACCOUNT_TXN")
public class AccountTxn {

    private String id;

    private String requestId;

    private String requestSystemId;

    private String requestTime;

    private String extAccountNo;

    private String extOriginTxnId;

    private String txnCode;

    private Long amount;

    private Long fee;

    private String originTxnId;

    private String remark;

    private String status;

    private String reversalFlag;

    private String extInfo;

    private String responseCode;

    private String responseMsg;

    private Date crtTime;

    private Date uptTime;
}
