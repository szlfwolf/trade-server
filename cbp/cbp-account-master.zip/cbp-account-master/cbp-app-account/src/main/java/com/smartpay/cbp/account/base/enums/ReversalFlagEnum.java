package com.smartpay.cbp.account.base.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/11 11:05
 */
@Getter
@ToString
@AllArgsConstructor
public enum ReversalFlagEnum {

    /**
     * 未冲正
     */
    NO("0"),
    /**
     * 已冲正
     */
    ALREADY("1");

    private String value;

}
