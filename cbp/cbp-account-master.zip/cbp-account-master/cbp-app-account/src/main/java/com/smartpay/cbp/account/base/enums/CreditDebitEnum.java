package com.smartpay.cbp.account.base.enums;

import com.smartpay.cbp.account.base.ApiException;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 借贷标识
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/7 14:41
 */
@Getter
@AllArgsConstructor
public enum CreditDebitEnum {

    /**
     * 借记（账户减）
     */
    DEBIT("0", "-"),
    /**
     * 贷记(账户加)
     */
    CREDIT("1", "+"),
    /**
     * 非借非贷
     */
    NO("2", "");

    private String value;

    private String symbol;

    public static CreditDebitEnum getByValue(String value) {
        for (CreditDebitEnum creditDebitEnum : values()) {
            if (creditDebitEnum.getValue().equals(value)) {
                return creditDebitEnum;
            }
        }
        throw new ApiException(ErrorEnum.PARAM_ERROR);
    }
}
