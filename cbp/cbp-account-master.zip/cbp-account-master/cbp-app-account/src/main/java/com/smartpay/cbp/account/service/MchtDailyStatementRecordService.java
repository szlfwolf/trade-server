package com.smartpay.cbp.account.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.smartpay.cbp.account.entity.MchtDailyStatementRecord;

/**
 * <p>
 * 商户每日对账单记录表 服务类
 * </p>
 *
 * @author zhuzw
 * @since 2022-11-23
 */
public interface MchtDailyStatementRecordService extends IService<MchtDailyStatementRecord> {

}
