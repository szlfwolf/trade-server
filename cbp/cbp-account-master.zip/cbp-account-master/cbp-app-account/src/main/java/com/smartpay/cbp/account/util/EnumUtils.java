package com.smartpay.cbp.account.util;

import com.smartpay.cbp.account.base.ApiException;
import com.smartpay.cbp.account.base.enums.ErrorEnum;
import com.smartpay.cbp.account.constant.AccountTxnTypeEnum;
import com.smartpay.cbp.account.constant.AccountTypeEnum;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/18 09:47
 */
public class EnumUtils {

    public static AccountTypeEnum getAccountTypeEnum(String code) {
        AccountTypeEnum accountTypeEnum = AccountTypeEnum.getByCode(code);
        if (accountTypeEnum == null) {
            throw new ApiException(ErrorEnum.PARAM_ERROR);
        }
        return accountTypeEnum;
    }

    public static AccountTxnTypeEnum getAccountTxnTypeEnum(String code) {
        AccountTxnTypeEnum accountTxnTypeEnum = AccountTxnTypeEnum.getByCode(code);
        if (accountTxnTypeEnum == null) {
            throw new ApiException(ErrorEnum.PARAM_ERROR);
        }
        return accountTxnTypeEnum;
    }
}
