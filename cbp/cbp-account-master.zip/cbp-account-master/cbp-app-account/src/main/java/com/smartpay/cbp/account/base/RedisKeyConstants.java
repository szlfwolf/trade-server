package com.smartpay.cbp.account.base;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/8 14:20
 */
public interface RedisKeyConstants {

    String APP_NAME = "cbp_account";

    String SEPARATOR = ":";

    String CONNECT = "_";

    String REQUEST_CHECK_PREFIX = APP_NAME + SEPARATOR + "request_check" + SEPARATOR;

    String OPEN_ACCOUNT_PREFIX = APP_NAME + SEPARATOR + "open_account" + SEPARATOR;

    String ACCOUNT_OPERATE_PREFIX = APP_NAME + SEPARATOR + "open_account" + SEPARATOR;

    String LOCK_PREFIX = APP_NAME + SEPARATOR + "LOCK" + SEPARATOR;
}
