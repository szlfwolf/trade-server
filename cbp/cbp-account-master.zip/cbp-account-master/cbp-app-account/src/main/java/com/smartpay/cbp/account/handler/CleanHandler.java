package com.smartpay.cbp.account.handler;

import com.smartpay.cbp.account.base.threadlocal.AccountOperateThreadLocal;
import com.smartpay.cbp.account.base.threadlocal.TxnIdThreadLocal;
import org.springframework.stereotype.Component;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/8 11:35
 */
@Component
public class CleanHandler {

    public void handle() {
        cleanThreadLocal();
    }

    private void cleanThreadLocal() {
        TxnIdThreadLocal.remove();
        AccountOperateThreadLocal.remove();
    }
}
