package com.smartpay.cbp.account.mapper;

import com.smartpay.cbp.account.entity.AccountDict;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 账户字典表 Mapper 接口
 * </p>
 *
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/7 13:39
 */
public interface AccountDictMapper extends BaseMapper<AccountDict> {

}
