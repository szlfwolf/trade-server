package com.smartpay.cbp.account.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/23 09:55
 */
@Data
@RefreshScope
@Component
@ConfigurationProperties(prefix = "xxl-job")
public class XxlJobConfigProperties {

    private String adminAddresses;

    private String appName;

    private String ip;

    private Integer port = 8899;

    private String accessToken;

    private String logPath;

    private Integer logRetentionDays = -1;

}
