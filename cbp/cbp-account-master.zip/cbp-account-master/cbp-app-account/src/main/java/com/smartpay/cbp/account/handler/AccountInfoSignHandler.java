package com.smartpay.cbp.account.handler;

import cn.hutool.crypto.SmUtil;
import com.smartpay.cbp.account.base.ApiException;
import com.smartpay.cbp.account.base.enums.ErrorEnum;
import com.smartpay.cbp.account.entity.AccountInfo;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cglib.beans.BeanMap;
import org.springframework.stereotype.Component;

import java.util.TreeMap;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/7 15:02
 */
@Slf4j
@Component
public class AccountInfoSignHandler {

    /**
     * DAC校验开
     **/
    private static final Integer DAC_VALIDATOR_OPEN = 1;

    /**
     * DAC必须校验环境
     */
    private static final String DAC_MUST_CHECK_ENV = "prod";

    @Value("${validator_dac_switch: 1}")
    private Integer validatorDacSwitch;

    @Value("${spring.profiles.active}")
    private String env;

    public void validator(String originalDac, AccountInfo acctInfo) {
        // 跳过DAC的校验必须同时满足下面两个条件
        // 1. 当前环境不是DAC必须校验环境
        // 2. dac开关未开启
        if (!StringUtils.equals(DAC_MUST_CHECK_ENV, env)
                && !DAC_VALIDATOR_OPEN.equals(validatorDacSwitch)) {
            log.info("跳过账户信息DAC校验, 当前读取到的所属环境:{}, DAC校验配置开关值(0-关, 1-开):{}", env, validatorDacSwitch);
            return;
        }

        if (!originalDac.equals(sign(acctInfo))) {
            throw new ApiException(ErrorEnum.ACCOUNT_INFO_ILLEGAL);
        }

    }

    public String sign(AccountInfo acctInfo) {
        AccountInfoSign sign = new AccountInfoSign();
        sign.setAccountId(acctInfo.getId());
        sign.setAccountType(acctInfo.getAccountType());
        sign.setCurrency(acctInfo.getCurrency());
        sign.setBalance(acctInfo.getBalance());
        return sign(sign);
    }

    public String sign(AccountInfoSign sign) {
        String signBody = getSignBody(sign);
        return SmUtil.sm3(signBody).toUpperCase();
    }

    private String getSignBody(AccountInfoSign sign) {
        BeanMap beanMap = BeanMap.create(sign);
        StringBuilder pa = new StringBuilder();
        TreeMap sortParam = new TreeMap<>(beanMap);
        sortParam.forEach((k, v) -> {
                    if (v != null) {
                        pa.append(k).append("=").append(v).append("&");
                    }
                }
        );
        return pa.substring(0, pa.length() - 1);
    }

    @Data
    public static class AccountInfoSign {

        /**
         * 账户号
         */
        private String accountId;

        /**
         * 账户类型
         */
        private String accountType;

        /**
         * 币种
         */
        private String currency;

        /**
         * 当前余额
         */
        private Long balance;

    }

}
