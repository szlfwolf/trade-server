package com.smartpay.cbp.account.base.threadlocal;

import com.smartpay.cbp.account.entity.AccountOperate;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/11 16:11
 */
public class AccountOperateThreadLocal {

    private static final ThreadLocal<AccountOperate> TL = new ThreadLocal<>();

    public static void set(AccountOperate accountOperate) {
        TL.set(accountOperate);
    }

    public static AccountOperate get() {
        return TL.get();
    }

    public static void remove() {
        TL.remove();
    }

}
