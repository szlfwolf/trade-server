package com.smartpay.cbp.account.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/11 16:12
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountOperate {

    private String merchantNo;

    private Long txnAmount;

    private Long txnFee;

    private String txnCode;

    private String txnId;

    private String originTxnId;

    private String extOriginTxnId;

    private String extInfo;
}
