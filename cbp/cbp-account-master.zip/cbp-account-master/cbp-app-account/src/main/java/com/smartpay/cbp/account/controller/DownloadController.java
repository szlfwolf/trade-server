package com.smartpay.cbp.account.controller;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.smartpay.cbp.account.base.ApiException;
import com.smartpay.cbp.account.base.enums.ErrorEnum;
import com.smartpay.cbp.account.dto.req.ExportAccountChangeInfoReqDTO;
import com.smartpay.cbp.account.dto.req.ExportAccountInfoReqDTO;
import com.smartpay.cbp.account.dto.req.ExportAccountSatementReqDTO;
import com.smartpay.cbp.account.dto.res.ExportAccountChangeInfoResDTO;
import com.smartpay.cbp.account.dto.res.ExportAccountInfoResDTO;
import com.smartpay.cbp.account.dto.res.ExportAccountStatementInfoResDTO;
import com.smartpay.cbp.account.entity.AccountChange;
import com.smartpay.cbp.account.entity.AccountInfo;
import com.smartpay.cbp.account.entity.AccountTxn;
import com.smartpay.cbp.account.handler.RemoteCallHandler;
import com.smartpay.cbp.account.service.AccountChangeService;
import com.smartpay.cbp.account.service.AccountInfoService;
import com.smartpay.cbp.account.service.AccountQuerySerivce;
import com.smartpay.cbp.account.util.BeanUtils;
import com.smartpay.cbp.account.util.EnumUtils;
import com.smartpay.cbp.common.core.utils.poi.ExcelUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/15 16:33
 */
@Slf4j
@Api(tags = "文件下载")
@RestController
@RequestMapping("download")
public class DownloadController {

    @Autowired
    private AccountInfoService accountInfoService;

    @Autowired
    private RemoteCallHandler remoteCallHandler;

    @Autowired
    private AccountChangeService accountChangeService;

    @Autowired
    private AccountQuerySerivce accountQuerySerivce;

    @ApiOperation("下载账户余额信息")
    @PostMapping("exportAccountInfo")
    public void exportAccountInfo(HttpServletResponse response, @Validated ExportAccountInfoReqDTO dto) {
        List<AccountInfo> list = accountInfoService.list(dto.getMerchantNo(), dto.getAccountType(), dto.getCurrency());

        Set<String> mchtNoList = list.stream().map(AccountInfo::getExtAccountNo).collect(Collectors.toSet());
        Map<String, String> mchtMap = remoteCallHandler.getMchtName(mchtNoList);

        List<ExportAccountInfoResDTO> dtos = BeanUtils.mapping(list, e -> {
            ExportAccountInfoResDTO res = new ExportAccountInfoResDTO();
            res.setMerchantNo(e.getExtAccountNo());
            res.setMerchantName(mchtMap.get(e.getExtAccountNo()));
            res.setAccountId(e.getId());
            res.setAccountType(EnumUtils.getAccountTypeEnum(e.getAccountType()).getDesc());
            res.setCurrency(e.getCurrency());
            res.setBalance(BigDecimal.valueOf(e.getBalance()).movePointLeft(2));
            return res;
        });

        ExcelUtil<ExportAccountInfoResDTO> util = new ExcelUtil<>(ExportAccountInfoResDTO.class);
        util.exportExcel(response, dtos, "账户余额信息");
    }

    @ApiOperation("下载账户变动明细")
    @PostMapping("exportAccountChangeInfo")
    public void exportAccountChangeInfo(HttpServletResponse response, @Validated ExportAccountChangeInfoReqDTO dto) {
        String accountId = dto.getAccountId();
        // 根据账户id查询账户信息
        AccountInfo ai = accountInfoService.getById(accountId);
        if (ai == null) {
            log.error("根据账户id【{}】查询账户信息为空！！", accountId);
            throw new ApiException(ErrorEnum.PARAM_ERROR);
        }

        // 查询商户信息
        String mchtName = remoteCallHandler.getMchtName(ai.getExtAccountNo());

        // 查询账户变动记录
        DateTime start = DateUtil.parse(dto.getStartTime());
        DateTime end = DateUtil.parse(dto.getEndTime());
        List<AccountChange> changes = accountQuerySerivce.accountChangeList(accountId, start, end, dto.getTxnType(),
                dto.getAmount(), false);

        List<ExportAccountChangeInfoResDTO> dtos = BeanUtils.mapping(changes, e -> {
            ExportAccountChangeInfoResDTO res = new ExportAccountChangeInfoResDTO();
            res.setMerchantNo(e.getExtAccountNo());
            res.setMerchantName(mchtName);
            res.setAccountId(e.getAccountId());
            res.setAccountType(EnumUtils.getAccountTypeEnum(e.getAccountType()).getDesc());
            res.setCurrency(e.getCurrency());
            res.setAmount(e.getAmount());
            res.setBeforeBalance(e.getBeforeBalance());
            res.setAfterBalance(e.getAfterBalance());
            AccountTxn accountTxn = e.getAccountTxn();
            if (accountTxn != null) {
                res.setAgentPayNo(accountTxn.getExtOriginTxnId());
            }
            res.setTxnId(e.getTxnId());
            res.setTxnCode(EnumUtils.getAccountTxnTypeEnum(e.getTxnCode()).getDesc());
            res.setTxnTime(DateUtil.formatDateTime(e.getCrtTime()));
            return res;
        });
        ExcelUtil<ExportAccountChangeInfoResDTO> util = new ExcelUtil<>(ExportAccountChangeInfoResDTO.class);
        util.exportExcel(response, dtos, "账户变动明细");
    }

    @ApiOperation("下载账户对账单")
    @PostMapping("exportAccountSatement")
    public void exportAccountSatement(HttpServletResponse response, @Validated ExportAccountSatementReqDTO dto) {

        List<ExportAccountStatementInfoResDTO> dtos = accountChangeService.queryStatementInfo(dto.getAccountId(),
                DateUtil.parse(dto.getStartTime()), DateUtil.parse(dto.getEndTime()));
        ExcelUtil<ExportAccountStatementInfoResDTO> util = new ExcelUtil<>(ExportAccountStatementInfoResDTO.class);
        util.exportExcel(response, dtos, "对账单");
    }
}
