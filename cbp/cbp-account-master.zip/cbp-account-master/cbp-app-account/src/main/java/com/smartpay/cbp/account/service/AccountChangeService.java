package com.smartpay.cbp.account.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.smartpay.cbp.account.dto.res.ExportAccountStatementInfoResDTO;
import com.smartpay.cbp.account.entity.AccountChange;
import com.smartpay.cbp.account.entity.AccountStatement;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * 账户变动记录表 服务类
 * </p>
 *
 * @author zhuzw
 * @since 2022-11-07
 */
public interface AccountChangeService extends IService<AccountChange> {

    List<AccountStatement> queryStatement(String mchtNo, String accountType, String currency, String startTime, String endTime);

    List<ExportAccountStatementInfoResDTO> queryStatementInfo(String accountId, Date start, Date end);
}
