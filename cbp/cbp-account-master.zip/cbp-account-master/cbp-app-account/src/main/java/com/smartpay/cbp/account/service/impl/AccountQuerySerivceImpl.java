package com.smartpay.cbp.account.service.impl;

import cn.hutool.core.date.DateUtil;
import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.smartpay.cbp.account.constant.AccountTxnTypeEnum;
import com.smartpay.cbp.account.entity.AccountChange;
import com.smartpay.cbp.account.entity.AccountTxn;
import com.smartpay.cbp.account.service.AccountChangeService;
import com.smartpay.cbp.account.service.AccountQuerySerivce;
import com.smartpay.cbp.account.service.AccountTxnService;
import com.smartpay.cbp.common.core.utils.PageUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/15 19:32
 */
@Slf4j
@Service
public class AccountQuerySerivceImpl implements AccountQuerySerivce {

    @Autowired
    private AccountChangeService accountChangeService;

    @Autowired
    private AccountTxnService accountTxnService;

    @Override
    public List<AccountChange> accountChangeList(String accountId, Date startTime, Date endTime, String txnType, Long amount, boolean page) {
        if (page) {
            PageUtils.startPage();
        }
        Wrapper<AccountChange> wrapper = Wrappers.lambdaQuery(AccountChange.class)
                .eq(AccountChange::getAccountId, accountId)
                .eq(StringUtils.hasText(txnType), AccountChange::getTxnCode, txnType)
                .eq(amount != null, AccountChange::getAmount, amount)
                .ge(AccountChange::getCrtTime, DateUtil.beginOfDay(startTime))
                .le(AccountChange::getCrtTime, DateUtil.endOfDay(endTime))
                .orderByDesc(AccountChange::getId);
        List<AccountChange> changes = accountChangeService.list(wrapper);
        // 抽取代付交易的账户变动记录，并查询对应的提现订单号
        List<AccountChange> agentPayChanges = changes.stream()
                .filter(e -> AccountTxnTypeEnum.D002.getCode().equals(e.getTxnCode()))
                .collect(Collectors.toList());
        List<String> agentPayTxnIds = agentPayChanges.stream().map(AccountChange::getTxnId).collect(Collectors.toList());
        List<AccountTxn> txns = accountTxnService.getByIds(agentPayTxnIds);
        Map<String, AccountTxn> txnMap = txns.stream().collect(Collectors.toMap(AccountTxn::getId, e -> e));
        for (AccountChange change : changes) {
            change.setAccountTxn(txnMap.get(change.getTxnId()));
        }
        return changes;
    }
}
