package com.smartpay.cbp.account.base.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 *
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/4 16:45
 */
@Getter
@AllArgsConstructor
public enum ErrorEnum {

    SYSTEM_ERROR("999999", "未知异常！"),

    ACCOUNT_BALANCE_IS_SHORT("A01001", "%s余额不足！"),
    ACCOUNT_INFO_ILLEGAL("A01002", "账户信息已被修改"),
    PARAM_ERROR("A01003", "请求参数错误"),
    REQUEST_TIME_OUT("A01004", "请求已过期"),
    REQUEST_ID_REPETITION("A01005", "请求id重复"),
    ACCOUNT_STATUS_ABNORMAL("A01006", "账户状态为非正常状态，不允许进行操作！"),
    REPEAT_REFUND("A01007", "交易已退款，不允许重复退款！"),
    REFUND_TO_REFUND("A01008", "不允许对退款交易进行退款！"),
    UNABLE_TO_HADNLE("A01009", "出现意料之外的情况，程序无法处理！"),
    ACCOUNT_NO_EXIST("A01010", "账户不存在！"),
    NOT_MCHT_NO("A01011", "未找到商户号信息！"),
    UNLAWFUL_PARAM("A01012", "非法请求参数！！！"),
    TIME_SPAN_TOO_LONG("A01013", "时间跨度超过设定时长！"),
    ;

    private String code;

    private String msg;

    public String getMsg(Object... args) {
        return String.format(msg, args);
    }
}
