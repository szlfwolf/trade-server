package com.smartpay.cbp.account.controller;

import cn.hutool.core.date.DateUnit;
import cn.hutool.core.date.DateUtil;
import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.github.pagehelper.PageInfo;
import com.smartpay.cbp.account.base.ApiException;
import com.smartpay.cbp.account.base.Page;
import com.smartpay.cbp.account.base.enums.AccountStatusEnum;
import com.smartpay.cbp.account.base.enums.ErrorEnum;
import com.smartpay.cbp.account.dto.res.AccountChangeResDTO;
import com.smartpay.cbp.account.dto.res.AccountInfoResDTO;
import com.smartpay.cbp.account.dto.res.AccountSatementQueryResDTO;
import com.smartpay.cbp.account.dto.res.AccountTxnQueryResDTO;
import com.smartpay.cbp.account.entity.AccountChange;
import com.smartpay.cbp.account.entity.AccountInfo;
import com.smartpay.cbp.account.entity.AccountStatement;
import com.smartpay.cbp.account.entity.AccountTxn;
import com.smartpay.cbp.account.handler.RemoteCallHandler;
import com.smartpay.cbp.account.service.AccountChangeService;
import com.smartpay.cbp.account.service.AccountInfoService;
import com.smartpay.cbp.account.service.AccountQuerySerivce;
import com.smartpay.cbp.account.service.AccountTxnService;
import com.smartpay.cbp.account.util.BeanUtils;
import com.smartpay.cbp.account.util.ConvertUtils;
import com.smartpay.cbp.common.core.utils.PageUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotEmpty;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * 账户查询接口
 *
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/8 15:24
 */
@Slf4j
@Api(tags = "账户查询")
@RestController
@RequestMapping("accountQuery")
public class AccountQueryController {

    @Autowired
    private AccountInfoService accountInfoService;

    @Autowired
    private RemoteCallHandler remoteCallHandler;

    @Autowired
    private AccountChangeService accountChangeService;

    @Autowired
    private AccountTxnService accountTxnService;

    @Autowired
    private AccountQuerySerivce accountQuerySerivce;

    /**
     * 查询某个商户的账户列表
     *
     * @param merchantNo 商户号
     * @return 账户列表
     */
    @ApiOperation("查询某个商户的账户列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "merchantNo", value = "商户号", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "accountType", value = "账户类型", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "currency", value = "币种", dataType = "String", paramType = "query")})
    @GetMapping("accountList")
    public List<AccountInfoResDTO> accountList(@RequestParam("merchantNo") String merchantNo,
                                               @RequestParam(value = "accountType", required = false) String accountTytpe,
                                               @RequestParam(value = "currency", required = false) String currency) {
        Wrapper<AccountInfo> wrapper = Wrappers.lambdaQuery(AccountInfo.class)
                .eq(AccountInfo::getExtAccountNo, merchantNo)
                .eq(StringUtils.hasText(accountTytpe), AccountInfo::getAccountType, accountTytpe)
                .eq(StringUtils.hasText(currency), AccountInfo::getCurrency, currency)
                .in(AccountInfo::getStatus, AccountStatusEnum.NORMAL.getValue(), AccountStatusEnum.FREEZE.getValue());
        List<AccountInfo> list = accountInfoService.list(wrapper);
        String mchtName = remoteCallHandler.getMchtName(merchantNo);
        return BeanUtils.mapping(list, e -> ConvertUtils.toAccountInfoDTO(e, mchtName));
    }

    /**
     * 查询账户信息
     *
     * @param merchantNo  商户号
     * @param accountType 账户类型
     * @param currency    币种
     * @return 账户信息
     */
    @ApiOperation("查询账户信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "merchantNo", value = "商户号", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "accountType", value = "账户类型", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "currency", value = "币种", dataType = "String", paramType = "query")})
    @GetMapping("accountInfo")
    public AccountInfoResDTO accountInfo(@RequestParam("merchantNo") String merchantNo,
                                         @RequestParam("accountType") String accountType,
                                         @RequestParam("currency") String currency) {

        Wrapper<AccountInfo> warpper = Wrappers.lambdaQuery(AccountInfo.class)
                .eq(AccountInfo::getExtAccountNo, merchantNo)
                .eq(AccountInfo::getAccountType, accountType)
                .eq(AccountInfo::getCurrency, currency)
                .in(AccountInfo::getStatus, AccountStatusEnum.NORMAL.getValue(), AccountStatusEnum.FREEZE.getValue());
        AccountInfo info = accountInfoService.getOne(warpper);
        String mchtName = remoteCallHandler.getMchtName(merchantNo);
        return ConvertUtils.toAccountInfoDTO(info, mchtName);
    }

    /**
     * 查询账户信息
     *
     * @param accountId 账户号
     * @return 账户信息
     */
    @ApiOperation("查询账户信息")
    @ApiImplicitParams(@ApiImplicitParam(name = "accountId", value = "账户号", dataType = "String", paramType = "query"))
    @GetMapping("accountInfoById")
    public AccountInfoResDTO accountInfoById(@RequestParam("accountId") String accountId) {
        AccountInfo info = accountInfoService.getById(accountId);
        String mchtName = remoteCallHandler.getMchtName(info.getExtAccountNo());
        return ConvertUtils.toAccountInfoDTO(info, mchtName);
    }

    /**
     * 查询账户信息
     *
     * @param accountIds 账户号集合
     * @return 账户信息
     */
    @ApiOperation("查询账户信息")
    @ApiImplicitParams(@ApiImplicitParam(name = "accountIds", value = "账户号集合", dataType = "JSONArray", paramType = "body"))
    @PostMapping("accountInfoByIds")
    public List<AccountInfoResDTO> accountInfoByIds(@RequestBody @NotEmpty List<String> accountIds) {
        List<AccountInfo> list = accountInfoService.listByIds(accountIds);
        return BeanUtils.mapping(list, e -> ConvertUtils.toAccountInfoDTO(e, null));
    }

    @ApiOperation("管理台查询账户列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "pageNum", value = "页码", dataType = "Integer", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "页大小", dataType = "Integer", paramType = "query"),
            @ApiImplicitParam(name = "merchantNo", value = "商户号", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "accountType", value = "账户类型", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "currency", value = "币种", dataType = "String", paramType = "query")})
    @GetMapping("consoleQueryAccountList")
    public Page<AccountInfoResDTO> queryAccountChangeList(@RequestParam(value = "merchantNo", required = false) String merchantNo,
                                                          @RequestParam(value = "accountType", required = false) String accountType,
                                                          @RequestParam(value = "currency", required = false) String currency) {

        PageUtils.startPage();
        List<AccountInfo> list = accountInfoService.list(merchantNo, accountType, currency);

        Set<String> mchtNoList = list.stream().map(AccountInfo::getExtAccountNo).collect(Collectors.toSet());
        Map<String, String> mchtMap = remoteCallHandler.getMchtName(mchtNoList);

        List<AccountInfoResDTO> dtos = BeanUtils.mapping(list, e -> ConvertUtils.toAccountInfoDTO(e,
                mchtMap.get(e.getExtAccountNo())));
        PageInfo<AccountInfo> pageInfo = new PageInfo<>(list);
        return Page.ok(dtos, pageInfo.getTotal());
    }

    @ApiOperation("账户变动记录列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "pageNum", value = "页码", dataType = "Integer", paramType = "query", required = true),
            @ApiImplicitParam(name = "pageSize", value = "页大小", dataType = "Integer", paramType = "query", required = true),
            @ApiImplicitParam(name = "accountId", value = "账户号", dataType = "String", paramType = "query", required = true),
            @ApiImplicitParam(name = "startTime", value = "开始时间", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "endTime", value = "结束时间", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "txnType", value = "交易类型", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "amount", value = "变动金额", dataType = "Long", paramType = "query")})
    @GetMapping("accountChangeList")
    public Page<AccountChangeResDTO> accountChangeList(@RequestParam("accountId") String accountId,
                                                       @RequestParam(value = "startTime") String startTime,
                                                       @RequestParam(value = "endTime") String endTime,
                                                       @RequestParam(value = "txnType", required = false) String txnType,
                                                       @RequestParam(value = "amount", required = false) Long amount) {

        if (org.apache.commons.lang3.StringUtils.isAnyBlank(accountId, startTime, endTime)) {
            throw new ApiException(ErrorEnum.PARAM_ERROR);
        }

        Date start = DateUtil.parse(startTime);
        Date end = DateUtil.parse(endTime);
        if (DateUtil.between(start, end, DateUnit.DAY) > 93) {
            throw new ApiException(ErrorEnum.TIME_SPAN_TOO_LONG);
        }

        // 根据账户id查询账户信息
        AccountInfo ai = accountInfoService.getById(accountId);
        if (ai == null) {
            log.error("根据账户id【{}】查询账户信息为空！！", accountId);
            throw new ApiException(ErrorEnum.PARAM_ERROR);
        }

        // 查询商户信息
        String mchtName = remoteCallHandler.getMchtName(ai.getExtAccountNo());

        // 查询账户变动记录
        List<AccountChange> changes = accountQuerySerivce.accountChangeList(accountId, start, end, txnType,
                amount, true);

        List<AccountChangeResDTO> dtos = BeanUtils.mapping(changes, e -> ConvertUtils.toAccountChangeDTO(e, mchtName));
        PageInfo<AccountChange> pageInfo = new PageInfo<>(changes);
        return Page.ok(dtos, pageInfo.getTotal());
    }

    /**
     * 根据账户交易ID（账户交易时返回的txnId）查询交易结果信息
     *
     * @param txnId 账户交易时返回的txnId
     * @return 交易结果信息
     */
    @ApiOperation("查询交易结果信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "accountTxnId", value = "账户交易时返回的txnId", dataType = "String", paramType = "query")})
    @GetMapping("queryAccountTxn")
    public AccountTxnQueryResDTO queryAccountTxn(@RequestParam("accountTxnId") String txnId) {
        AccountTxn accountTxn = accountTxnService.getById(txnId);
        return ConvertUtils.toAccountTxnQueryDTO(accountTxn);
    }

    @ApiOperation("查询账户对账单")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "mchtNo", value = "商户号", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "accountType", value = "账户类型", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "currency", value = "币种", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "startTime", value = "开始时间", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "endTime", value = "结束时间", dataType = "String", paramType = "query")})
    @GetMapping("queryAccountSatement")
    public Page<AccountSatementQueryResDTO> queryAccountSatement(@RequestParam(value = "mchtNo", required = false) String mchtNo,
                                                                 @RequestParam(value = "accountType", required = false) String accountType,
                                                                 @RequestParam(value = "currency", required = false) String currency,
                                                                 @RequestParam(value = "startTime", required = false) String startTime,
                                                                 @RequestParam(value = "endTime", required = false) String endTime) {
        PageUtils.startPage();
        List<AccountStatement> list = accountChangeService.queryStatement(mchtNo, accountType, currency, startTime, endTime);
        Set<String> mchtNos = list.stream().map(AccountStatement::getMchtNo).collect(Collectors.toSet());
        Map<String, String> mchtMap = remoteCallHandler.getMchtName(mchtNos);
        List<AccountSatementQueryResDTO> dtos = BeanUtils.mapping(list, e -> ConvertUtils.toAccountSatementQueryResDTO(e, mchtMap.get(e.getMchtNo())));
        PageInfo<AccountStatement> pageInfo = new PageInfo<>(list);
        return Page.ok(dtos, pageInfo.getTotal());
    }

}
