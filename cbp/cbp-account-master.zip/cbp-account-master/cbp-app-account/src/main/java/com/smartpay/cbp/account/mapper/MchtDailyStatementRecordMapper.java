package com.smartpay.cbp.account.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.smartpay.cbp.account.entity.MchtDailyStatementRecord;

/**
 * <p>
 * 商户每日对账单记录表 Mapper 接口
 * </p>
 *
 * @author zhuzw
 * @since 2022-11-23
 */
public interface MchtDailyStatementRecordMapper extends BaseMapper<MchtDailyStatementRecord> {

}
