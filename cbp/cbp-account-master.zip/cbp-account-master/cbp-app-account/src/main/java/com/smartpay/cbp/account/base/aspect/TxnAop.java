package com.smartpay.cbp.account.base.aspect;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.smartpay.cbp.account.base.ApiException;
import com.smartpay.cbp.account.base.Constants;
import com.smartpay.cbp.account.base.RedisKeyConstants;
import com.smartpay.cbp.account.base.enums.ErrorEnum;
import com.smartpay.cbp.account.base.enums.TxnStatusEnum;
import com.smartpay.cbp.account.base.threadlocal.TxnIdThreadLocal;
import com.smartpay.cbp.account.dto.req.BaseDTO;
import com.smartpay.cbp.account.entity.AccountTxn;
import com.smartpay.cbp.account.service.AccountTxnService;
import com.smartpay.cbp.common.core.domain.R;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/7 10:30
 */
@Slf4j
@Aspect
@Order(Integer.MIN_VALUE)
@Component
public class TxnAop {

    @Autowired
    private AccountTxnService accountTxnService;

    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Around("@annotation(com.smartpay.cbp.account.base.annotation.Txn)")
    public Object around(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        Object[] args = proceedingJoinPoint.getArgs();
        if (args.length == 0 || !(args[0] instanceof BaseDTO)) {
            log.error("@txn注解使用的切点【{}】不符合约定！！", proceedingJoinPoint.getTarget());
            throw new ApiException(ErrorEnum.SYSTEM_ERROR);
        }
        BaseDTO arg = (BaseDTO) args[0];
        check(arg);

        AccountTxn save = accountTxnService.saveTxn(arg);
        TxnIdThreadLocal.set(save.getId());
        String responseCode = R.SUCCESS;
        String responseMsg = null;
        TxnStatusEnum status = TxnStatusEnum.SUCCESS;
        try {
            return proceedingJoinPoint.proceed();
        } catch (Throwable throwable) {
            status = TxnStatusEnum.FAILD;
            if (throwable instanceof ApiException) {
                ApiException ae = (ApiException) throwable;
                responseCode = ae.getErrorCode();
                responseMsg = ae.getErrorMsg();
            } else {
                responseCode = ErrorEnum.SYSTEM_ERROR.getCode();
                responseMsg = ErrorEnum.SYSTEM_ERROR.getMsg();
            }
            throw throwable;
        } finally {
            accountTxnService.updateTxn(save.getId(), status.getValue(), responseCode, responseMsg);
        }
    }

    private void check(BaseDTO arg) {
        // 验证请求是否有效（1、请求时间是否在当前时间一分钟内，2请求id是否重复）
        DateTime requestTime = DateUtil.parse(arg.getRequestTime(), Constants.YMDHMS);
        if (DateUtil.offsetMinute(requestTime, 1).isBeforeOrEquals(new Date())) {
            log.error("请求【{}】已过期！", arg);
            throw new ApiException(ErrorEnum.REQUEST_TIME_OUT);
        }
        String suffix = String.join(RedisKeyConstants.CONNECT, arg.getRequestSystemId(), arg.getRequestId());
        String key = RedisKeyConstants.REQUEST_CHECK_PREFIX + suffix;
        Boolean isAbsent = stringRedisTemplate.opsForValue().setIfAbsent(key, arg.getRequestTime(), 1, TimeUnit.DAYS);
        if (Boolean.FALSE.equals(isAbsent)) {
            log.error("请求id重复！==》【{}】", arg);
            throw new ApiException(ErrorEnum.REQUEST_ID_REPETITION);
        }
    }
}
