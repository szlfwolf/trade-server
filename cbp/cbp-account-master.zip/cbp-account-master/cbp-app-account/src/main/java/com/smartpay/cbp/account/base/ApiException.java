package com.smartpay.cbp.account.base;

import com.smartpay.cbp.account.base.enums.ErrorEnum;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/4 16:45
 */
public class ApiException extends RuntimeException {

    private final String errorCode;
    private final String errorMsg;

    public ApiException(String errorCode, String errorMsg) {
        super(errorMsg + "【" + errorCode + "】");
        this.errorCode = errorCode;
        this.errorMsg = errorMsg;
    }

    public ApiException(ErrorEnum errorEnum) {
        this(errorEnum.getCode(), errorEnum.getMsg());
    }

    public ApiException(ErrorEnum errorEnum, Object... args) {
        this(errorEnum.getCode(), errorEnum.getMsg(args));
    }

    public String getErrorCode() {
        return errorCode;
    }

    public String getErrorMsg() {
        return errorMsg;
    }
}
