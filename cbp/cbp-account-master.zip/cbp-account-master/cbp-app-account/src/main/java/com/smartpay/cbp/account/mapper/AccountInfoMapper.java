package com.smartpay.cbp.account.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.smartpay.cbp.account.entity.AccountInfo;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/7 09:59
 */
@Mapper
public interface AccountInfoMapper extends BaseMapper<AccountInfo> {

}
