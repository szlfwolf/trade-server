package com.smartpay.cbp.account.util;

import cn.hutool.core.date.DateUtil;
import com.smartpay.cbp.account.dto.res.AccountChangeResDTO;
import com.smartpay.cbp.account.dto.res.AccountInfoResDTO;
import com.smartpay.cbp.account.dto.res.AccountSatementQueryResDTO;
import com.smartpay.cbp.account.dto.res.AccountTxnQueryResDTO;
import com.smartpay.cbp.account.entity.AccountChange;
import com.smartpay.cbp.account.entity.AccountInfo;
import com.smartpay.cbp.account.entity.AccountStatement;
import com.smartpay.cbp.account.entity.AccountTxn;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/8 16:04
 */
public class ConvertUtils {

    public static AccountInfoResDTO toAccountInfoDTO(AccountInfo accountInfo, String mchtName) {
        AccountInfoResDTO dto = new AccountInfoResDTO();
        if (accountInfo == null) {
            return dto;
        }
        dto.setMerchantNo(accountInfo.getExtAccountNo());
        dto.setMerchantName(mchtName);
        dto.setAccountId(accountInfo.getId());
        dto.setAccountType(accountInfo.getAccountType());
        dto.setCurrency(accountInfo.getCurrency());
        dto.setBalance(accountInfo.getBalance());
        dto.setStatus(accountInfo.getStatus());
        return dto;
    }

    public static AccountChangeResDTO toAccountChangeDTO(AccountChange accountChange, String mchtName) {
        AccountChangeResDTO dto = new AccountChangeResDTO();
        if (accountChange == null) {
            return dto;
        }
        dto.setMerchantNo(accountChange.getExtAccountNo());
        dto.setMerchantName(mchtName);
        dto.setAccountId(accountChange.getAccountId());
        dto.setAccountType(accountChange.getAccountType());
        dto.setCurrency(accountChange.getCurrency());
        dto.setAmount(accountChange.getAmount());
        dto.setBeforeBalance(accountChange.getBeforeBalance());
        dto.setAfterBalance(accountChange.getAfterBalance());
        if (accountChange.getAccountTxn() != null) {
            dto.setAgentPayNo(accountChange.getAccountTxn().getExtOriginTxnId());
        }
        dto.setTxnId(accountChange.getTxnId());
        dto.setTxnCode(accountChange.getTxnCode());
        dto.setTxnTime(accountChange.getCrtTime());
        return dto;
    }

    public static AccountTxnQueryResDTO toAccountTxnQueryDTO(AccountTxn accountTxn) {
        AccountTxnQueryResDTO dto = new AccountTxnQueryResDTO();
        if (accountTxn == null) {
            return dto;
        }
        dto.setMerchantNo(accountTxn.getExtAccountNo());
        dto.setRequestId(accountTxn.getRequestId());
        dto.setRequestTime(accountTxn.getRequestTime());
        dto.setRequestSystemId(accountTxn.getRequestSystemId());
        dto.setAgentPayNo(accountTxn.getExtOriginTxnId());
        dto.setAmount(accountTxn.getAmount());
        dto.setFee(accountTxn.getFee());
        dto.setRemark(accountTxn.getRemark());
        dto.setOriginTxnId(accountTxn.getOriginTxnId());
        dto.setReversalFlag(accountTxn.getReversalFlag());
        dto.setTxnCode(accountTxn.getTxnCode());
        dto.setStatus(accountTxn.getStatus());
        dto.setResponseCode(accountTxn.getResponseCode());
        dto.setResponseMsg(accountTxn.getResponseMsg());
        return dto;
    }

    public static AccountSatementQueryResDTO toAccountSatementQueryResDTO(AccountStatement statement, String mchtName) {
        AccountSatementQueryResDTO dto = new AccountSatementQueryResDTO();
        if (statement == null) {
            return dto;
        }
        dto.setMerchantNo(statement.getMchtNo());
        dto.setMerchantName(mchtName);
        dto.setAccountId(statement.getAccountId());
        dto.setAccountType(statement.getAccountType());
        dto.setCurrency(statement.getCurrency());
        dto.setAmount(statement.getAmount());
        dto.setStartTime(DateUtil.formatDate(statement.getStartTime()));
        dto.setEndTime(DateUtil.formatDate(statement.getEndTime()));
        return dto;
    }
}
