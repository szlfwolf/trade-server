package com.smartpay.cbp.account.entity;

import lombok.Data;

import java.util.Date;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/15 14:27
 */
@Data
public class AccountStatement {

    private String mchtNo;

    private String accountId;

    private String accountType;

    private String currency;

    private Long amount;

    private Date startTime;

    private Date endTime;
}
