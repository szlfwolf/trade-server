package com.smartpay.cbp.account.base;

/**
 * 常量
 *
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/3 15:12
 */
public interface Constants {

    String Y = "yyyy";

    String YM = "yyyyMM";

    String YMD = "yyyyMMdd";

    String YMDH = "yyyyMMddHH";

    String YMDHM = "yyyyMMddHHmm";

    String YMDHMS = "yyyyMMddHHmmss";

    String ACCOUNT_TXN_TABLE_PREFIX = "t_account_txn_";

    String ACCOUNT_CHANGE_TABLE_PREFIX = "t_account_change_";

}
