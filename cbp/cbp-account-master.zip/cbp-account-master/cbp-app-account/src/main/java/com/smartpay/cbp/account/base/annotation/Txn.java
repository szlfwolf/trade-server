package com.smartpay.cbp.account.base.annotation;

import java.lang.annotation.*;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/7 10:29
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Txn {

}
