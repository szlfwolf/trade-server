package com.smartpay.cbp.account.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.smartpay.cbp.account.base.enums.ReversalFlagEnum;
import com.smartpay.cbp.account.base.enums.TxnStatusEnum;
import com.smartpay.cbp.account.base.threadlocal.AccountOperateThreadLocal;
import com.smartpay.cbp.account.config.IdGenerator;
import com.smartpay.cbp.account.dto.req.BaseDTO;
import com.smartpay.cbp.account.entity.AccountOperate;
import com.smartpay.cbp.account.entity.AccountTxn;
import com.smartpay.cbp.account.mapper.AccountTxnMapper;
import com.smartpay.cbp.account.service.AccountTxnService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/4 17:09
 */
@Service
public class AccountTxnServiceImpl extends ServiceImpl<AccountTxnMapper, AccountTxn> implements AccountTxnService {

    @Autowired
    private AccountTxnMapper accountTxnMapper;

    @Autowired
    private IdGenerator idGenerator;

    @Override
    public void saveTxn(AccountTxn accountTxn) {
        accountTxnMapper.insert(accountTxn);
    }

    @Override
    public AccountTxn saveTxn(BaseDTO dto) {
        AccountOperate accountOperate = AccountOperateThreadLocal.get();
        // 严格根据雪花算法生成的id生成创建时间，避免分片时间临界值问题
        String id = idGenerator.nextId();
        Date date = idGenerator.getGenerateDate(id);
        AccountTxn accountTxn = new AccountTxn();
        accountTxn.setId(id);
        accountTxn.setExtAccountNo(dto.getMerchantNo());
        accountTxn.setExtOriginTxnId(accountOperate.getExtOriginTxnId());
        accountTxn.setRequestId(dto.getRequestId());
        accountTxn.setRequestSystemId(dto.getRequestSystemId());
        accountTxn.setRequestTime(dto.getRequestTime());
        accountTxn.setTxnCode(accountOperate.getTxnCode());
        accountTxn.setAmount(accountOperate.getTxnAmount());
        accountTxn.setFee(accountOperate.getTxnFee());
        accountTxn.setRemark(dto.getRemark());
        accountTxn.setStatus(TxnStatusEnum.INIT.getValue());
        accountTxn.setOriginTxnId(accountOperate.getOriginTxnId());
        accountTxn.setReversalFlag(ReversalFlagEnum.NO.getValue());
        accountTxn.setExtInfo(accountOperate.getExtInfo());
        accountTxn.setCrtTime(date);
        accountTxnMapper.insert(accountTxn);
        return accountTxn;
    }

    @Override
    public void updateTxn(String txnId, String status, String responseCode, String responseMsg) {
        AccountTxn accountTxn = new AccountTxn();
        accountTxn.setId(txnId);
        accountTxn.setStatus(status);
        accountTxn.setResponseCode(responseCode);
        accountTxn.setResponseMsg(responseMsg);
        accountTxn.setUptTime(new Date());
        accountTxnMapper.updateById(accountTxn);
    }

    @Override
    public List<AccountTxn> getByIds(Collection<String> ids) {
        if (CollectionUtils.isEmpty(ids)) {
            return new ArrayList<>();
        }
        return baseMapper.selectBatchIds(ids);
    }
}
