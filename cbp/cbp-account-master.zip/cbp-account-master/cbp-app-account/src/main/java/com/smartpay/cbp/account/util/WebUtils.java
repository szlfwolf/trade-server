package com.smartpay.cbp.account.util;

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/4 17:12
 */
public class WebUtils {

    private WebUtils() {}

    public static HttpServletRequest currentRequest() {
        ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        return requestAttributes.getRequest();
    }
}
