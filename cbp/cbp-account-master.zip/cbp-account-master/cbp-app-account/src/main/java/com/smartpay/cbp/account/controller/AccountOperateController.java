package com.smartpay.cbp.account.controller;

import com.alibaba.fastjson.JSON;
import com.smartpay.cbp.account.base.ApiException;
import com.smartpay.cbp.account.base.enums.ErrorEnum;
import com.smartpay.cbp.account.base.threadlocal.AccountOperateThreadLocal;
import com.smartpay.cbp.account.base.threadlocal.TxnIdThreadLocal;
import com.smartpay.cbp.account.constant.AccountTxnTypeEnum;
import com.smartpay.cbp.account.dto.req.*;
import com.smartpay.cbp.account.dto.res.*;
import com.smartpay.cbp.account.entity.AccountOperate;
import com.smartpay.cbp.account.entity.AccountTxn;
import com.smartpay.cbp.account.entity.AccountTxnExtInfo;
import com.smartpay.cbp.account.service.AccountOperateService;
import com.smartpay.cbp.account.service.AccountTxnService;
import com.smartpay.cbp.account.util.EnumUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 账户操作接口
 *
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/7 15:50
 */
@Slf4j
@Api(tags = "账户操作")
@RestController
@RequestMapping("accountOperate")
public class AccountOperateController {

    @Autowired
    private AccountOperateService accountOperateService;

    @Autowired
    private AccountTxnService accountTxnService;

    @ApiOperation("账户开户")
    @PostMapping("openAccount")
    public OpenAccountResDTO openAccount(@RequestBody @Validated OpenAccountReqDTO dto) {
        buildAndSetAccountOperate(dto.getMerchantNo(), 0L, AccountTxnTypeEnum.O001);
        String accountId = accountOperateService.openAccount(dto);
        return new OpenAccountResDTO(accountId);
    }

    @ApiOperation("账户调账加款")
    @PostMapping("increaseAdjust")
    public AccountIncreaseResDTO increaseAdjust(@RequestBody @Validated AccountIncreaseReqDTO dto) {
        buildAndSetAccountOperate(dto.getMerchantNo(), dto.getAmount(), EnumUtils.getAccountTxnTypeEnum(dto.getTxnCode()));
        accountOperateService.accountIncrease(dto);
        return new AccountIncreaseResDTO(TxnIdThreadLocal.get());
    }

    @ApiOperation("账户调账减款")
    @PostMapping("decreaseAdjust")
    public AccountDecreaseResDTO decreaseAdjust(@RequestBody @Validated AccountDecreaseReqDTO dto) {
        buildAndSetAccountOperate(dto.getMerchantNo(), dto.getAmount(), EnumUtils.getAccountTxnTypeEnum(dto.getTxnCode()));
        accountOperateService.accountDecrease(dto);
        return new AccountDecreaseResDTO(TxnIdThreadLocal.get());
    }

    @ApiOperation("代付")
    @PostMapping("agentPay")
    public AccountAgentPayResDTO agentPay(@RequestBody @Validated AccountAgentPayReqDTO dto) {
        AccountTxnExtInfo extInfo = new AccountTxnExtInfo();
        extInfo.setAgentPaySerialId(dto.getAgentPaySerialId());
        extInfo.setPayeeName(dto.getPayeeName());
        extInfo.setPayeeAccount(dto.getPayeeAccount());
        extInfo.setPayeeBank(dto.getPayeeBank());
        buildAndSetAccountOperate(dto.getMerchantNo(), dto.getAmount(), dto.getFee(), AccountTxnTypeEnum.D002,
                dto.getAgentPayNo(), null, JSON.toJSONString(extInfo));
        return accountOperateService.agentPay(dto);
    }

    @ApiOperation("代付回退")
    @PostMapping("agentPayRollback")
    public AccountAgentPayRollbackResDTO agentPayRollback(@RequestBody @Validated AccountAgentPayRollbackReqDTO dto) {
        // 根据原txnId查询交易记录
        AccountTxn originTxn = accountTxnService.getById(dto.getOriginTxnId());
        if (originTxn == null) {
            log.error("根据原账户交易id【{}】未查询到对应的交易记录！！", dto.getOriginTxnId());
            throw new ApiException(ErrorEnum.PARAM_ERROR);
        }
        buildAndSetAccountOperate(dto.getMerchantNo(), originTxn.getAmount(), originTxn.getFee(),
                AccountTxnTypeEnum.I003, dto.getOriginTxnId());

        accountOperateService.agentPayRollback(dto);
        return new AccountAgentPayRollbackResDTO(TxnIdThreadLocal.get());
    }

    private void buildAndSetAccountOperate(String merchantNo, Long amount, AccountTxnTypeEnum accountTxnType) {
        buildAndSetAccountOperate(merchantNo, amount, null, accountTxnType, null);
    }

    private void buildAndSetAccountOperate(String mchtNo, long txnAmount, Long txnFee,
                                           AccountTxnTypeEnum accountTxnType, String originTxnId) {
        buildAndSetAccountOperate(mchtNo, txnAmount, txnFee, accountTxnType, null, originTxnId, null);
    }

    private void buildAndSetAccountOperate(String mchtNo, long txnAmount, Long txnFee,
                                           AccountTxnTypeEnum accountTxnType, String extOriginTxnId,
                                           String originTxnId, String extInfo) {
        AccountOperate ao = new AccountOperate();
        ao.setMerchantNo(mchtNo);
        ao.setTxnAmount(txnAmount);
        ao.setTxnFee(txnFee);
        ao.setTxnCode(accountTxnType.getCode());
        ao.setExtOriginTxnId(extOriginTxnId);
        ao.setOriginTxnId(originTxnId);
        ao.setExtInfo(extInfo);
        AccountOperateThreadLocal.set(ao);
    }
}
