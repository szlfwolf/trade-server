package com.smartpay.cbp.account.base.enums;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/4 17:51
 */
public enum AccountDictTypeEnum {

    TXN_CODE("txn_code"),
    ACCT_TYPE("acct_type")
    ;

    private String value;

    AccountDictTypeEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
