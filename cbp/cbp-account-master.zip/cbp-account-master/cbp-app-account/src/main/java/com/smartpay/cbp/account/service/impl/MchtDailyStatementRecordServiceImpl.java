package com.smartpay.cbp.account.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.smartpay.cbp.account.entity.MchtDailyStatementRecord;
import com.smartpay.cbp.account.mapper.MchtDailyStatementRecordMapper;
import com.smartpay.cbp.account.service.MchtDailyStatementRecordService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 商户每日对账单记录表 服务实现类
 * </p>
 *
 * @author zhuzw
 * @since 2022-11-23
 */
@Service
public class MchtDailyStatementRecordServiceImpl extends ServiceImpl<MchtDailyStatementRecordMapper, MchtDailyStatementRecord> implements MchtDailyStatementRecordService {

}
