package com.smartpay.cbp.account.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.util.Date;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/4 17:37
 */
@Data
@TableName("T_ACCOUNT_INFO")
public class AccountInfo {

    private String id;

    private String extAccountNo;

    private String accountType;

    private String currency;

    private Long balance;

    private String dac;

    private String status;

    private Date crtTime;

    private Date uptTime;
}
