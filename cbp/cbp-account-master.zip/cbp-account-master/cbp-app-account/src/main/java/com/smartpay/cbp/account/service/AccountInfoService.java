package com.smartpay.cbp.account.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.smartpay.cbp.account.entity.AccountInfo;

import java.util.List;

/**
 * 账户信息 服务层
 *
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/7 09:53
 */
public interface AccountInfoService extends IService<AccountInfo> {

    /**
     * 查询商户名下所有账户信息
     *
     * @param mchtNo 商户号
     * @return 账户集合
     */
    List<AccountInfo> listByMchtNo(String mchtNo);

    /**
     * 根据商户号和账户类型查询账户信息
     *
     * @param mchtNo      商户号
     * @param accountType 账户类型
     * @return 账户信息
     */
    AccountInfo getByMchtNoAndAccountType(String mchtNo, String accountType);

    /**
     * 列表查询
     *
     * @param merchantNo  商户号
     * @param accountType 账户类型
     * @param currency    币种
     * @return 集合
     */
    List<AccountInfo> list(String merchantNo, String accountType, String currency);
}
