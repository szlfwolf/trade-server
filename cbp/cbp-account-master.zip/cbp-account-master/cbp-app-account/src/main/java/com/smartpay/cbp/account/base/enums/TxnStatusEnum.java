package com.smartpay.cbp.account.base.enums;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/7 10:51
 */
public enum TxnStatusEnum {

    INIT("0"),
    SUCCESS("1"),
    FAILD("2");

    private String value;

    TxnStatusEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
