package com.smartpay.cbp.account.entity;

import lombok.Data;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/15 13:57
 */
@Data
public class AccountTxnExtInfo {

    /**
     * 代付流水号
     */
    private String agentPaySerialId;

    /**
     * 收款人姓名
     */
    private String payeeName;

    /**
     * 收款人账号
     */
    private String payeeAccount;

    /**
     * 收款人银行
     */
    private String payeeBank;
}
