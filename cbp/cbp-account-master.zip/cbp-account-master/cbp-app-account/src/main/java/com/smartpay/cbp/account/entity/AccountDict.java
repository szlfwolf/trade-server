package com.smartpay.cbp.account.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/4 17:48
 */
@Data
@TableName("T_ACCOUNT_DICT")
public class AccountDict {

    private String id;

    private String dictType;

    private String dictDesc;

    private String dictKey;

    private String dictValue;

    private Boolean isValid;
}
