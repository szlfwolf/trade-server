package com.smartpay.cbp.account.service.impl;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.smartpay.cbp.account.base.ApiException;
import com.smartpay.cbp.account.base.enums.AccountStatusEnum;
import com.smartpay.cbp.account.base.enums.ErrorEnum;
import com.smartpay.cbp.account.entity.AccountInfo;
import com.smartpay.cbp.account.mapper.AccountInfoMapper;
import com.smartpay.cbp.account.service.AccountInfoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

/**
 * 账户信息 服务层
 *
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/7 09:53
 */
@Slf4j
@Service
public class AccountInfoServiceImpl extends ServiceImpl<AccountInfoMapper, AccountInfo> implements AccountInfoService {

    @Override
    public List<AccountInfo> listByMchtNo(String mchtNo) {
        Wrapper<AccountInfo> wrapper = Wrappers.lambdaQuery(AccountInfo.class)
                .eq(AccountInfo::getExtAccountNo, mchtNo)
                .in(AccountInfo::getStatus, AccountStatusEnum.NORMAL.getValue(), AccountStatusEnum.FREEZE.getValue());
        return baseMapper.selectList(wrapper);
    }

    @Override
    public AccountInfo getByMchtNoAndAccountType(String mchtNo, String accountType) {
        Wrapper<AccountInfo> wrapper = Wrappers.lambdaQuery(AccountInfo.class)
                .eq(AccountInfo::getExtAccountNo, mchtNo)
                .eq(AccountInfo::getAccountType, accountType)
                .in(AccountInfo::getStatus, AccountStatusEnum.NORMAL.getValue(), AccountStatusEnum.FREEZE.getValue());
        AccountInfo accountInfo = baseMapper.selectOne(wrapper);
        if (accountInfo == null) {
            log.error("根据商户号【{}】和账户类型【{}】查询账户信息为空！！", mchtNo, accountType);
            throw new ApiException(ErrorEnum.PARAM_ERROR);
        }
        return accountInfo;
    }

    @Override
    public List<AccountInfo> list(String merchantNo, String accountType, String currency) {
        Wrapper<AccountInfo> warpper = Wrappers.lambdaQuery(AccountInfo.class)
                .eq(StringUtils.hasText(merchantNo), AccountInfo::getExtAccountNo, merchantNo)
                .eq(StringUtils.hasText(accountType), AccountInfo::getAccountType, accountType)
                .eq(StringUtils.hasText(currency), AccountInfo::getCurrency, currency)
                .in(AccountInfo::getStatus, AccountStatusEnum.NORMAL.getValue(), AccountStatusEnum.FREEZE.getValue());
        return baseMapper.selectList(warpper);
    }
}
