package com.smartpay.cbp.account.base.aspect;

import com.smartpay.cbp.account.base.threadlocal.AccountOperateThreadLocal;
import com.smartpay.cbp.account.base.ApiException;
import com.smartpay.cbp.account.base.enums.ErrorEnum;
import com.smartpay.cbp.account.base.annotation.AccountLock;
import com.smartpay.cbp.account.dto.req.BaseDTO;
import com.smartpay.cbp.account.entity.AccountOperate;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/8 15:07
 */
@Slf4j
@Aspect
@Order(Integer.MIN_VALUE + 1)
@Component
public class LockAop {

    @Autowired
    private RedissonClient redissonClient;

    @Around("@annotation(accountLock)")
    public Object around(ProceedingJoinPoint proceedingJoinPoint, AccountLock accountLock) throws Throwable {
        // 先从ThreadLocal中获取商户号，如果获取不到再从参数获取
        AccountOperate ao = AccountOperateThreadLocal.get();
        String merchantNo;
        if (ao != null && ao.getMerchantNo() != null) {
            merchantNo = ao.getMerchantNo();
        } else {
            Object[] args = proceedingJoinPoint.getArgs();
            if (args.length == 0 || !(args[0] instanceof BaseDTO)) {
                log.error("@txn注解使用的切点【{}】不符合约定！！", proceedingJoinPoint.getTarget());
                throw new ApiException(ErrorEnum.SYSTEM_ERROR);
            }
            BaseDTO arg = (BaseDTO) args[0];
            merchantNo = arg.getMerchantNo();
        }
        String prefix = accountLock.prefix();
        String key = prefix + merchantNo;
        RLock lock = redissonClient.getLock(key);
        lock.lock();
        try {
            return proceedingJoinPoint.proceed();
        } finally {
            try {
                lock.unlock();
            } catch (Exception e) {
                log.error("释放锁【{}】出现异常！！", key, e);
            }
        }
    }
}
