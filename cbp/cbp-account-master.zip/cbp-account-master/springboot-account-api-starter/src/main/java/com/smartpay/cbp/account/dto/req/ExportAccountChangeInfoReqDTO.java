package com.smartpay.cbp.account.dto.req;

import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/15 19:18
 */
@Data
public class ExportAccountChangeInfoReqDTO {

    @NotBlank(message = "账户id不能为空")
    private String accountId;

    @NotBlank(message = "开始时间不能为空")
    private String startTime;

    @NotBlank(message = "结束时间不能为空")
    private String endTime;

    private String txnType;

    private Long amount;
}
