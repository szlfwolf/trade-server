package com.smartpay.cbp.account.dto.req;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/8 10:04
 */
@Getter
@Setter
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class AccountIncreaseReqDTO extends BaseDTO {

    private static final long serialVersionUID = -4203853459163922511L;

    /**
     * 交易码
     */
    @NotBlank(message = "txnCode交易码不能为空")
    @Length(max = 16, message = "txnCode长度不能超过16位")
    private String txnCode;

    /**
     * 账户类型
     */
    @NotBlank(message = "acctType不能为空")
    @Length(max = 32, message = "acctType长度不能超过32位")
    private String accountType;

    /**
     * 充值金额
     */
    @NotNull(message = "金额不能为空")
    @Min(value = 1, message = "金额最小值为1")
    private Long amount;

    /**
     * 交易币种
     */
    @NotBlank(message = "交易币种不能为空")
    private String currency;
}
