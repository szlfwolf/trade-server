package com.smartpay.cbp.account.dto.res;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/23 17:35
 */
@Data
public class MchtAccountSatementQueryResDTO {


    @ApiModelProperty("对账单日期")
    private String statementDate;

    @ApiModelProperty("账户类型")
    private String accountType;

    @ApiModelProperty("币种")
    private String currency;

    @ApiModelProperty("账户id")
    private String accountId;

    @ApiModelProperty("对账单文件地址")
    private String statementFileUrl;
}
