package com.smartpay.cbp.account.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/4 18:00
 */
@Getter
@AllArgsConstructor
public enum AccountTxnTypeEnum {

    /**
     * Oxxx 账户操作
     */
    O001("O001", "账户开户"),
    O002("O002", "账户冻结"),
    O003("O003", "账户销户"),

    /**
     * Ixxx 加款
     */
    I001("I001", "充值"),
    I002("I002", "人工加款"),
    I003("I003", "提现回退"),

    /**
     * Dxxx 减款
     */
    D001("D001", "人工减款"),
    D002("D002", "提现"),
    D003("D003", "代付通道"),
    D004("D004", "鉴权通道"),
    ;

    private String code;

    private String desc;

    public static AccountTxnTypeEnum getByCode(String code) {
        for (AccountTxnTypeEnum value : values()) {
            if (value.getCode().equals(code)) {
                return value;
            }
        }
        return null;
    }
}
