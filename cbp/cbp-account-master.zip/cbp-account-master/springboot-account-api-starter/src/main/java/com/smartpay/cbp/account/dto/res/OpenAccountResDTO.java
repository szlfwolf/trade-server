package com.smartpay.cbp.account.dto.res;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/11 10:07
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class OpenAccountResDTO implements Serializable {
    private static final long serialVersionUID = -7428203830248632387L;

    private String accountId;
}
