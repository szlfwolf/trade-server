package com.smartpay.cbp.account.dto.req;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.validation.constraints.NotBlank;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/11 10:22
 */
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class AccountAgentPayRollbackReqDTO extends BaseDTO {

    private static final long serialVersionUID = -358970839288771260L;

    @ApiModelProperty("代付原请求账户交易id")
    @NotBlank(message = "代付原请求账户交易id不能为空")
    private String originTxnId;

}
