package com.smartpay.cbp.account.dto.res;

import lombok.Data;

import java.io.Serializable;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/15 14:12
 */
@Data
public class AccountSatementQueryResDTO implements Serializable {
    private static final long serialVersionUID = -1878961286620482954L;

    private String merchantNo;

    private String merchantName;

    private String accountId;

    private String accountType;

    private String currency;

    private Long amount;

    private String startTime;

    private String endTime;
}
