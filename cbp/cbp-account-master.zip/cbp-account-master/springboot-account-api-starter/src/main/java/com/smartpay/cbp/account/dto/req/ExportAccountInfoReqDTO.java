package com.smartpay.cbp.account.dto.req;

import lombok.Data;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/15 16:38
 */
@Data
public class ExportAccountInfoReqDTO {

    private String merchantNo;

    private String accountType;

    private String currency;
}
