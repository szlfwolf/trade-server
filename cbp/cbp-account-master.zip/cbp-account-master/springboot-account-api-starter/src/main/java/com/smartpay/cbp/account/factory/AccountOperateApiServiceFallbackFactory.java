package com.smartpay.cbp.account.factory;

import com.smartpay.cbp.account.constant.Constants;
import com.smartpay.cbp.account.dto.req.*;
import com.smartpay.cbp.account.dto.res.*;
import com.smartpay.cbp.account.fegin.AccountOperateApiService;
import com.smartpay.cbp.common.core.domain.R;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.openfeign.FallbackFactory;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/14 09:25
 */
@Slf4j
public class AccountOperateApiServiceFallbackFactory implements FallbackFactory<AccountOperateApiService> {
    @Override
    public AccountOperateApiService create(Throwable cause) {
        return new AccountOperateApiService() {
            @Override
            public R<OpenAccountResDTO> openAccount(OpenAccountReqDTO dto, String source) {
                log.error("开户失败，请求参数：{}", dto, cause);
                return R.fail(Constants.COMMON_ERROR_MSG);
            }

            @Override
            public R<AccountIncreaseResDTO> increaseAdjust(AccountIncreaseReqDTO dto, String source) {
                log.error("账户加款失败，请求参数：{}", dto, cause);
                return R.fail(Constants.COMMON_ERROR_MSG);
            }

            @Override
            public R<AccountDecreaseResDTO> decreaseAdjust(AccountDecreaseReqDTO dto, String source) {
                log.error("账户减款失败，请求参数：{}", dto, cause);
                return R.fail(Constants.COMMON_ERROR_MSG);
            }

            @Override
            public R<AccountAgentPayResDTO> agentPay(AccountAgentPayReqDTO dto, String source) {
                log.error("账户代付交易扣款失败，请求参数：{}", dto, cause);
                return R.fail(Constants.COMMON_ERROR_MSG);
            }

            @Override
            public R<AccountAgentPayRollbackResDTO> agentPayRollback(AccountAgentPayRollbackReqDTO dto, String source) {
                log.error("账户代付交易扣款回滚，请求参数：{}", dto, cause);
                return R.fail(Constants.COMMON_ERROR_MSG);
            }
        };
    }
}
