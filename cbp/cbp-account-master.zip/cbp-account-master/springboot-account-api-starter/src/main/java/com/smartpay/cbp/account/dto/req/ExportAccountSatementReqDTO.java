package com.smartpay.cbp.account.dto.req;

import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/15 15:36
 */
@Data
public class ExportAccountSatementReqDTO {

    @NotBlank(message = "账户id不能为空")
    private String accountId;

    @NotBlank(message = "开始时间不能为空")
    private String startTime;

    @NotBlank(message = "结束时间不能为空")
    private String endTime;

}
