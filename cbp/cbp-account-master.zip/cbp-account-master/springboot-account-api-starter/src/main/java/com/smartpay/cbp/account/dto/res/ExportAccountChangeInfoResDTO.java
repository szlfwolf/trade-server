package com.smartpay.cbp.account.dto.res;

import com.smartpay.cbp.common.core.annotation.Excel;
import lombok.Data;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/15 19:53
 */
@Data
public class ExportAccountChangeInfoResDTO {

    @Excel(name = "商户号")
    private String merchantNo;

    @Excel(name = "商户名称")
    private String merchantName;

    @Excel(name = "账户号")
    private String accountId;

    @Excel(name = "账户类型")
    private String accountType;

    @Excel(name = "交易流水号")
    private String txnId;

    @Excel(name = "交易类型")
    private String txnCode;

    @Excel(name = "币种")
    private String currency;

    @Excel(name = "变更前余额", cellType = Excel.ColumnType.NUMERIC)
    private Long beforeBalance;

    @Excel(name = "变更余额", cellType = Excel.ColumnType.NUMERIC)
    private Long amount;

    @Excel(name = "变更后余额", cellType = Excel.ColumnType.NUMERIC)
    private Long afterBalance;

    @Excel(name = "商户提现订单号")
    private String agentPayNo;

    @Excel(name = "交易时间")
    private String txnTime;
}
