package com.smartpay.cbp.account.dto.res;

import lombok.Data;

import java.io.Serializable;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/14 11:14
 */
@Data
public class AccountTxnQueryResDTO implements Serializable {

    private static final long serialVersionUID = 8796864603672121062L;

    private String requestId;

    private String requestSystemId;

    private String requestTime;

    private String merchantNo;

    private String agentPayNo;

    private String txnCode;

    private Long amount;

    private Long fee;

    private String originTxnId;

    private String remark;

    private String status;

    private String reversalFlag;

    private String responseCode;

    private String responseMsg;

}
