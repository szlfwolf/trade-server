package com.smartpay.cbp.account.constant;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/4 17:51
 */
public enum AccountTypeEnum {

    /**
     * 余额账户
     */
    BALANCE_ACCOUNT("9931", "余额账户"),

    /**
     * 手续费账户
     */
    PRECOLLECTED_FEE_ACCOUNT("9932", "预收商户手续费账户"),

    /**
     * 手续费账户
     */
    REALTIME_FEE_ACCOUNT("9933", "实收手续费账户"),

    /**
     * 手续费账户
     */
    AFTER_RECEIVING_FEE_ACCOUNT("9934", "后收手续费账户"),

    ;

    private String code;

    private String desc;

    AccountTypeEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    public static AccountTypeEnum getByCode(String code) {
        for (AccountTypeEnum value : values()) {
            if (value.getCode().equals(code)) {
                return value;
            }
        }
        return null;
    }

}
