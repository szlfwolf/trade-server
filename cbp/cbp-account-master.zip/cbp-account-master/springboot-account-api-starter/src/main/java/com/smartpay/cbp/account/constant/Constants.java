package com.smartpay.cbp.account.constant;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/14 09:28
 */
public interface Constants {

    String APP_NAME = "cbp-app-account";

    String COMMON_ERROR_MSG = "接口被降级，请稍后再请求！";
}
