package com.smartpay.cbp.account.dto.res;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/14 09:33
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountDecreaseResDTO implements Serializable {

    private static final long serialVersionUID = 5741944904292717277L;

    private String txnId;
}
