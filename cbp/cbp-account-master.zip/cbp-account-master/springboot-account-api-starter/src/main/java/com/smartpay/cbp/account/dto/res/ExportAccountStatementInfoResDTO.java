package com.smartpay.cbp.account.dto.res;

import com.smartpay.cbp.common.core.annotation.Excel;
import com.smartpay.cbp.common.core.annotation.Excel.ColumnType;
import lombok.Data;


/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/15 15:50
 */
@Data
public class ExportAccountStatementInfoResDTO {

    private String id;

    private String accountId;

    @Excel(name = "期初余额", cellType = ColumnType.NUMERIC)
    private Long beforeBalance;

    @Excel(name = "期末余额", cellType = ColumnType.NUMERIC)
    private Long afterBalance;

    @Excel(name = "增减标志")
    private String symbol;

    @Excel(name = "商户流水号")
    private String mchtOrderNo;

    @Excel(name = "交易时间")
    private String txnDate;

    @Excel(name = "我方交易流水号")
    private String serialNo;

    @Excel(name = "金额", cellType = ColumnType.NUMERIC)
    private Long amount;

    @Excel(name = "收款账号")
    private String payeeAccount;

    @Excel(name = "收款银行")
    private String payeeBank;

    @Excel(name = "收款人户名")
    private String payeeName;

    @Excel(name = "描述")
    private String desc;
}
