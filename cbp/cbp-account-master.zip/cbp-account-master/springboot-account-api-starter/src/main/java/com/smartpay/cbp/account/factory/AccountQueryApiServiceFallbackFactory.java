package com.smartpay.cbp.account.factory;

import com.smartpay.cbp.account.constant.Constants;
import com.smartpay.cbp.account.dto.res.AccountInfoResDTO;
import com.smartpay.cbp.account.dto.res.AccountTxnQueryResDTO;
import com.smartpay.cbp.account.fegin.AccountQueryApiService;
import com.smartpay.cbp.common.core.domain.R;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.openfeign.FallbackFactory;

import java.util.List;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/14 09:47
 */
@Slf4j
public class AccountQueryApiServiceFallbackFactory implements FallbackFactory<AccountQueryApiService> {
    @Override
    public AccountQueryApiService create(Throwable cause) {
        return new AccountQueryApiService() {
            @Override
            public R<List<AccountInfoResDTO>> accountList(String merchantNo, String accountType, String currency,
                                                          String source) {
                log.error("查询某个商户的账户列表，请求参数：【{}】:【{}】:【{}】", merchantNo, accountType, currency, cause);
                return R.fail(Constants.COMMON_ERROR_MSG);
            }

            @Override
            public R<AccountInfoResDTO> accountInfo(String merchantNo, String accountTytpe, String currency,
                                                    String source) {
                log.error("查询账户信息，请求参数：【{}】:【{}】:【{}】", merchantNo, accountTytpe, currency, cause);
                return R.fail(Constants.COMMON_ERROR_MSG);
            }

            @Override
            public R<AccountInfoResDTO> accountInfoById(String accountId, String source) {
                log.error("查询账户信息，请求参数：【{}】", accountId, cause);
                return R.fail(Constants.COMMON_ERROR_MSG);
            }

            @Override
            public R<List<AccountInfoResDTO>> accountInfoByIds(List<String> accountIds, String source) {
                log.error("查询账户信息，请求参数：【{}】", accountIds, cause);
                return R.fail(Constants.COMMON_ERROR_MSG);
            }

            @Override
            public R<AccountTxnQueryResDTO> queryAccountTxn(String txnId, String source) {
                log.error("根据账户交易ID查询交易结果信息，请求参数：{}", txnId, cause);
                return R.fail(Constants.COMMON_ERROR_MSG);
            }
        };
    }
}
