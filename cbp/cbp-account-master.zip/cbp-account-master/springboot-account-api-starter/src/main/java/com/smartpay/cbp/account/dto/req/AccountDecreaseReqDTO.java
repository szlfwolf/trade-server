package com.smartpay.cbp.account.dto.req;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/8 10:13
 */
@Getter
@Setter
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class AccountDecreaseReqDTO extends AccountIncreaseReqDTO {

    private static final long serialVersionUID = 7995494060624255654L;
}
