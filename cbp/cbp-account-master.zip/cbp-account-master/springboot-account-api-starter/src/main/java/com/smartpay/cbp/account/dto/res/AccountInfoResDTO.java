package com.smartpay.cbp.account.dto.res;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/8 15:45
 */
@Data
public class AccountInfoResDTO implements Serializable {

    private static final long serialVersionUID = -440231570186830838L;

    private String merchantNo;

    private String merchantName;

    private String accountId;

    private String accountType;

    private String currency;

    private Long balance;

    private String status;

    private Date crtTime;

    private Date uptTime;
}
