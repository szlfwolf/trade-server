package com.smartpay.cbp.account.fegin;

import com.smartpay.cbp.account.constant.Constants;
import com.smartpay.cbp.account.dto.res.AccountInfoResDTO;
import com.smartpay.cbp.account.dto.res.AccountTxnQueryResDTO;
import com.smartpay.cbp.account.factory.AccountQueryApiServiceFallbackFactory;
import com.smartpay.cbp.common.core.constant.SecurityConstants;
import com.smartpay.cbp.common.core.domain.R;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotEmpty;
import java.util.List;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/14 09:46
 */
@FeignClient(contextId = "accountQueryApiService", value = Constants.APP_NAME, fallbackFactory =
        AccountQueryApiServiceFallbackFactory.class)
public interface AccountQueryApiService {

    /**
     * 查询某个商户的账户列表
     *
     * @param merchantNo  商户号
     * @param accountType 账户类型
     * @param currency    币种
     * @return 账户列表
     */
    @GetMapping("/accountQuery/accountList")
    R<List<AccountInfoResDTO>> accountList(@RequestParam("merchantNo") String merchantNo,
                                           @RequestParam(value = "accountType", required = false) String accountType,
                                           @RequestParam(value = "currency", required = false) String currency,
                                           @RequestHeader(SecurityConstants.FROM_SOURCE) String source);

    /**
     * 查询账户信息
     *
     * @param merchantNo  商户号
     * @param accountType 账户类型
     * @param currency    币种
     * @return 账户信息
     */
    @GetMapping("/accountQuery/accountInfo")
    R<AccountInfoResDTO> accountInfo(@RequestParam("merchantNo") String merchantNo,
                                     @RequestParam("accountType") String accountType,
                                     @RequestParam("currency") String currency,
                                     @RequestHeader(SecurityConstants.FROM_SOURCE) String source);

    /**
     * 查询账户信息
     *
     * @param accountId 账户号
     * @return 账户信息
     */
    @GetMapping("/accountQuery/accountInfoById")
    R<AccountInfoResDTO> accountInfoById(@RequestParam("accountId") String accountId,
                                         @RequestHeader(SecurityConstants.FROM_SOURCE) String source);

    /**
     * 查询账户信息
     *
     * @param accountIds 账户号集合
     * @return 账户信息
     */
    @PostMapping("accountInfoByIds")
    R<List<AccountInfoResDTO>> accountInfoByIds(@RequestBody @NotEmpty List<String> accountIds,
                                                @RequestHeader(SecurityConstants.FROM_SOURCE) String source);

    /**
     * 根据账户交易ID（账户交易时返回的txnId）查询交易结果信息
     *
     * @param txnId 账户交易时返回的txnId
     * @return 交易结果信息
     */
    @GetMapping("queryAccountTxn")
    R<AccountTxnQueryResDTO> queryAccountTxn(@RequestParam("accountTxnId") String txnId,
                                             @RequestHeader(SecurityConstants.FROM_SOURCE) String source);
}
