package com.smartpay.cbp.account.dto.req;

import io.swagger.annotations.ApiModelProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.validation.constraints.NotBlank;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/4 17:46
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class OpenAccountReqDTO extends BaseDTO {

    private static final long serialVersionUID = 1454233732594148807L;

    @ApiModelProperty("交易币种")
    @NotBlank(message = "币种不能为空")
    private String curreny;

    @ApiModelProperty("账户类型")
    @NotBlank(message = "账户类型不能为空")
    private String accountType;
}
