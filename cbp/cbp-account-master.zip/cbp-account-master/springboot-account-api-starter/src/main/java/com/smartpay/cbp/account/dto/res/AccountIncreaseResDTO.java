package com.smartpay.cbp.account.dto.res;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/14 09:33
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountIncreaseResDTO implements Serializable {

    private static final long serialVersionUID = 8767286474777072823L;

    private String txnId;
}
