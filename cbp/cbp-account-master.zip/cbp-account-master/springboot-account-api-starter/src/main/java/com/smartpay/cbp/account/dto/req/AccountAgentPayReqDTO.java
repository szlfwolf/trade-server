package com.smartpay.cbp.account.dto.req;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/10 10:46
 */
@Data
@ApiModel("账户代付请求")
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class AccountAgentPayReqDTO extends BaseDTO {

    private static final long serialVersionUID = -753006499805896157L;

    @ApiModelProperty("交易金额")
    @NotNull(message = "交易金额不能为空")
    @Min(value = 1, message = "交易金额最小为1")
    private Long amount;

    @ApiModelProperty("币种")
    @NotBlank(message = "币种不能为空")
    private String currency;

    @ApiModelProperty("手续费")
    @NotNull(message = "手续费不能为空")
    @Min(value = 0, message = "手续费最小为0")
    private Long fee;

    @ApiModelProperty("二级产品code")
    @NotBlank(message = "二级产品code不能为空")
    private String secondLevelProductCode;

    @ApiModelProperty("商户代付订单号")
    @NotBlank(message = "商户代付订单号不能为空")
    private String agentPayNo;

    @ApiModelProperty("代付流水号")
    @NotBlank(message = "代付流水号不能为空")
    private String agentPaySerialId;

    @ApiModelProperty("收款人姓名")
    @NotBlank(message = "收款人姓名不能为空")
    private String payeeName;

    @ApiModelProperty("收款人账户")
    @NotBlank(message = "收款人账户不能为空")
    private String payeeAccount;

    @ApiModelProperty("收款人银行")
    @NotBlank(message = "收款人银行不能为空")
    private String payeeBank;
}
