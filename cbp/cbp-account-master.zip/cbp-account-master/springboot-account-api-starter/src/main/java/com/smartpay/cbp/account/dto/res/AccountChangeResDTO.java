package com.smartpay.cbp.account.dto.res;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/8 20:42
 */
@Data
public class AccountChangeResDTO implements Serializable {

    private static final long serialVersionUID = -727103953663314965L;

    private String merchantNo;

    private String merchantName;

    private String accountId;

    private String accountType;

    private String txnId;

    private String txnCode;

    private String currency;

    private Long beforeBalance;

    private Long amount;

    private Long afterBalance;

    private String agentPayNo;

    private Date txnTime;
}
