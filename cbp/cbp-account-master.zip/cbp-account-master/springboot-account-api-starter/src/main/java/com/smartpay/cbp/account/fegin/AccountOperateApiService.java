package com.smartpay.cbp.account.fegin;

import com.smartpay.cbp.account.constant.Constants;
import com.smartpay.cbp.account.dto.req.*;
import com.smartpay.cbp.account.dto.res.*;
import com.smartpay.cbp.account.factory.AccountOperateApiServiceFallbackFactory;
import com.smartpay.cbp.common.core.constant.SecurityConstants;
import com.smartpay.cbp.common.core.domain.R;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/14 09:22
 */
@FeignClient(contextId = "accountOperateApiService", value = Constants.APP_NAME, fallbackFactory =
        AccountOperateApiServiceFallbackFactory.class)
public interface AccountOperateApiService {

    /**
     * 开户
     *
     * @param dto 开户请求
     * @return 开户结果
     */
    @PostMapping("/accountOperate/openAccount")
    R<OpenAccountResDTO> openAccount(@RequestBody @Validated OpenAccountReqDTO dto,
                                     @RequestHeader(SecurityConstants.FROM_SOURCE) String source);

    /**
     * 账户加款
     *
     * @param dto 加款请求
     * @return 加款结果
     */
    @PostMapping("/accountOperate/increaseAdjust")
    R<AccountIncreaseResDTO> increaseAdjust(@RequestBody @Validated AccountIncreaseReqDTO dto,
                                            @RequestHeader(SecurityConstants.FROM_SOURCE) String source);

    /**
     * 账户减款
     *
     * @param dto 减款请求
     * @return 减款结果
     */
    @PostMapping("/accountOperate/decreaseAdjust")
    R<AccountDecreaseResDTO> decreaseAdjust(@RequestBody @Validated AccountDecreaseReqDTO dto,
                                            @RequestHeader(SecurityConstants.FROM_SOURCE) String source);

    /**
     * 账户代付扣款
     *
     * @param dto 代付扣款请求
     * @return 代付扣款结果
     */
    @PostMapping("/accountOperate/agentPay")
    R<AccountAgentPayResDTO> agentPay(@RequestBody @Validated AccountAgentPayReqDTO dto,
                                      @RequestHeader(SecurityConstants.FROM_SOURCE) String source);

    /**
     * 账户代付扣款回滚
     *
     * @param dto 代付扣款回滚请求
     * @return 代付扣款回滚结果
     */
    @PostMapping("/accountOperate/agentPayRollback")
    R<AccountAgentPayRollbackResDTO> agentPayRollback(@RequestBody @Validated AccountAgentPayRollbackReqDTO dto,
                                                      @RequestHeader(SecurityConstants.FROM_SOURCE) String source);
}
