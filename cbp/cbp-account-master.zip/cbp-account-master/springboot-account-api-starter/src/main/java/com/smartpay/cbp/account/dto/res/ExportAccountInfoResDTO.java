package com.smartpay.cbp.account.dto.res;

import com.smartpay.cbp.common.core.annotation.Excel;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/15 16:42
 */
@Data
public class ExportAccountInfoResDTO {

    @Excel(name = "商户号")
    private String merchantNo;

    @Excel(name = "商户名称")
    private String merchantName;

    @Excel(name = "账户号")
    private String accountId;

    @Excel(name = "账户类型")
    private String accountType;

    @Excel(name = "币种")
    private String currency;

    @Excel(name = "余额", cellType = Excel.ColumnType.NUMERIC)
    private BigDecimal balance;

}
