package com.smartpay.cbp.account.dto.res;

import lombok.Data;

import java.io.Serializable;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/11 10:05
 */
@Data
public class AccountAgentPayResDTO implements Serializable {

    private static final long serialVersionUID = 6304548837625295776L;

    private String txnId;
}
