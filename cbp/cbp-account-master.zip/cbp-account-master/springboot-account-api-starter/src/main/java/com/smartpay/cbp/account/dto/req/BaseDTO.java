package com.smartpay.cbp.account.dto.req;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * @author zhuzw
 * @version <b>1.0.0</b>
 * @date 2022/11/7 10:05
 */
@ApiModel("内部接口基础类")
@Data
public class BaseDTO implements Serializable {

    private static final long serialVersionUID = 677245407538774987L;

    @ApiModelProperty("商户号")
    @NotBlank(message = "商户号不能为空")
    private String merchantNo;

    @ApiModelProperty("内部系统id")
    @NotBlank(message = "内部系统id不能为空")
    private String requestSystemId;

    @ApiModelProperty("请求id")
    @NotBlank(message = "请求id不能为空")
    private String requestId;

    @ApiModelProperty("请求时间，yyyyMMddHHmmss格式")
    @NotBlank(message = "请求时间不能为空")
    private String requestTime;

    @ApiModelProperty("备注信息")
    @Length(max = 128, message = "备注信息最大128字符")
    private String remark;

}
