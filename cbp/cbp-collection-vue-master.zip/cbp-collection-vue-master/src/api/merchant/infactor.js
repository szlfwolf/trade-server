import request from '@/utils/request'
import { gateWay1, gateWay2, gateWay3, gateWay4,  gateWay5 } from "@/api/config"
import { getToken } from '@/utils/auth'
export const exportApi = gateWay1 + "/download/exportAccountSatement" // 下载对账单查询
export const balanceExportApi = gateWay1 + "/download/exportAccountInfo" // 账户余额查询
export const InfoExportApi = gateWay1 + "/download/exportAccountChangeInfo" // 变动明细查询
export const merchantExApi = gateWay2 + "/merchant/export" // 商户信息导出
export const uploadApi = process.env.VUE_APP_BASE_API + "/core/file/page"
export const downPhoto = process.env.VUE_APP_BASE_URL + '/core/file/download/'
export const collExApi =  gateWay2 + "/merchantRemit/export" // 商户信息导出
export const chargeExport =  gateWay2 + "/charge/export" // 商户信息导出
export const userExport =  gateWay4 + "/merchantUser/export" // 用户信息导出
export const userChannelExport =   gateWay5 + "/channel/register/export" // 用户信息导出
export const exportFail =   gateWay4 + "/remit/admin/export-fail/" //
export const exportSuccess = gateWay4 + "/remit/admin/export-success/" //
export const exportReq = gateWay4 + "/remit/admin/export-req" //
export const receiptInfoExport = gateWay4 + "/receiptInfo/export" //
export const headers = {
  'Authorization':'Bearer ' + getToken()
}
/*产品配置接口=------------*/
export const product = {
  // 查询列表
  listPro(query) {
    return request({
      url: gateWay2 + '/product/queryProductConfig',
      method: 'get',
      params: query
    })
  },
  // 一级产品列表
  getParentCodesAction(query) {
    return request({
      url: gateWay2 + '/product/queryAll',
      method: 'get',
      params: query
    })
  },
  // 二级产品列表
  getProductCodesAction(query) {
    return request({
      url: gateWay2 + '/product/queryAllSecondProduct',
      method: 'get',
      params: query
    })
  },
  // 新增产品配置
  addPro(data) {
    return request({
      url: gateWay2 + '/product/addProductConfig',
      method: 'post',
      data: data
    })
  },
  // 修改产品配置
  updatePro(data) {
    return request({
      url: gateWay2 + '/product/updateProductConfig',
      method: 'post',
      data: data
    })
  },
}

/*通道配置接口=------------*/
export const channel= {
  // 查询列表
  listChannel(query) {
    return request({
      url: gateWay2+'/channel/queryChannelInfo',
      method: 'get',
      params: query
    })
  },
  // 通道名称
  getChannelMenu(data) {
    return request({
      url: gateWay2+'/channel/queryAll',
      method: 'get',
      data: data
    })
  },
  // 新增产品配置
  addChannel(data) {
    return request({
      url: gateWay2+'/channel/addChannelConfig',
      method: 'post',
      data: data
    })
  },
  // 修改
  updateChannel(data) {
    return request({
      url: gateWay2+'/channel/updateChannelConfig',
      method: 'post',
      data: data
    })
  },
  // 获取详情
  getChannel(data) {
    return request({
      url: '/system/config',
      method: 'put',
      data: data
    })
  }
}

/*收汇账户配置=------------*/
export const collection = {
  // 查询
  listCollection(query) {
    return request({
      url: gateWay2+'/remittance/queryAccountConfig',
      method: 'get',
      params: query
    })
  },
  // 新增
  addCollection(data) {
    return request({
      url: gateWay2+'/remittance/addAccountConfig',
      method: 'post',
      data: data
    })
  },
  // 修改
  updateCollection(data) {
    return request({
      url: gateWay2+'/remittance/updateAccountConfig',
      method: 'post',
      data: data
    })
  },
  // 获取详情
  getCollection(data) {
    return request({
      url: '/system/config',
      method: 'put',
      data: data
    })
  },
}

/*商户信息查询=------------*/
export const merInfo = {
  // 查询列表
  listMerInfo(query) {
    return request({
      url: gateWay2+'/merchant/queryMerchantInfo',
      method: 'get',
      params: query
    })
  },
  // 新增
  addMerInfo(data) {
    return request({
      url: gateWay2+'/merchant/addMerchantInfo',
      method: 'post',
      data: data
    })
  },
  // 修改
  updateMerInfo(data) {
    return request({
      url: gateWay2+'/merchant/updateMerchantInfo',
      method: 'post',
      data: data
    })
  },
  // 审核
  examineMerInfo(data) {
    return request({
      url: gateWay2+'/merchant/checkMerchantInfo',
      method: 'post',
      data: data
    })
  },
  // 获取详情
  getMerInfo(data) {
    return request({
      url: gateWay2+'/merchant/queryDetailInfo',
      method: 'get',
      params: data
    })
  },
  // 查询所有商户号和商户名(下拉框)
  getMerchantInfo(data) {
    return request({
      url: gateWay2+'/merchant/getMerchantInfo',
      method: 'get',
      params: data
    })
  }
}

/*商户汇款账户信息查询=------------*/
export const merColle = {
  // 查询列表
  listMerColle(query) {
    return request({
      url: gateWay2+'/merchantRemit/queryAccount',
      method: 'get',
      params: query
    })
  },
  // 新增
  addMerColle(data) {
    return request({
      url: gateWay2+'/merchantRemit/addAccount',
      method: 'post',
      data: data
    })
  },
  // 修改
  updateMerColle(data) {
    return request({
      url: gateWay2+'/merchantRemit/updateAccount',
      method: 'post',
      data: data
    })
  },
  // 审核
  examineMerColle(data) {
    return request({
      url: gateWay2+'/merchantRemit/checkAccount',
      method: 'post',
      data: data
    })
  },
  // 获取详情
  getMerColle(data) {
    return request({
      url: '/system/config',
      method: 'put',
      data: data
    })
  },
}

/*商户手续费查询=------------*/
export const Fee = {
  // 查询列表
  listFee(query) {
    return request({
      url: gateWay2+'/charge/queryAll',
      method: 'get',
      params: query
    })
  },
  // 新增
  addFee(data) {
    return request({
      url: gateWay2+'/charge/addCharge',
      method: 'post',
      data: data
    })
  },
  // 修改
  updateFee(data) {
    return request({
      url: gateWay2+'/charge/updateCharge',
      method: 'post',
      data: data
    })
  },
  // 审核
  examineFee(data) {
    return request({
      url: gateWay2+'/charge/checkMerchantInfo',
      method: 'post',
      data: data
    })
  },
  // 获取详情
  getFee(data) {
    return request({
      url: '/system/config',
      method: 'put',
      data: data
    })
  }
}

/*商户证书签发=------------*/
export const certRequest = {
  // 查询列表
  listCert(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
  // 添加
  add(data) {
    return request({
      url: '/system/config',
      method: 'post',
      data: data
    })
  },
  // 签发
  examine(data) {
    return request({
      url: '/system/config',
      method: 'put',
      data: data
    })
  },
  // 停用
  stop(data) {
    return request({
      url: '/system/config',
      method: 'put',
      data: data
    })
  },
  // 恢复
  resumee(data) {
    return request({
      url: '/system/config',
      method: 'put',
      data: data
    })
  },
  // 获取详情
  getDetails(data) {
    return request({
      url: '/system/config',
      method: 'put',
      data: data
    })
  }
}

/*用户信息查询=------------*/
export const userInfoRequest = {
  // 查询列表
  listUsers(query) {
    return request({
      url: gateWay4 + '/merchantUser/pages',
      method: 'get',
      params: query
    })
  },
  // 审核
  examine(data) {
    return request({
      url: gateWay4 + '/merchantUser/approve',
      method: 'post',
      data: data
    })
  },
  // 获取详情
  getDetails(data) {
    return request({
      url: gateWay4 + '/merchantUser/detail/'+data,
      method: 'get',
      data: {}
    })
  }
}

/*用户渠道备案查询=------------*/
export const userChannelRequest = {
  // 查询列表
  list(query) {
    return request({
      url:  gateWay5 + '/channel/register/pages',
      method: 'get',
      params: query
    })
  },
  // 重发
  resend(data) {
    return request({
      url:  gateWay5 + '/register/retry',
      method: 'post',
      data: data
    })
  },
  // 获取详情
  getDetails(data) {
    return request({
      url:  gateWay5 + '/channel/register/detail/'+data,
      method: 'get',
      data: {}
    })
  }
}

/*账户余额查询=------------*/
export const merBalanceRequest = {
  // 查询列表
  list(query) {
    return request({
      url: gateWay1 + '/accountQuery/consoleQueryAccountList',
      method: 'get',
      params: query
    })
  },
  // 修改
  update(data) {
    return request({
      url: '/system/config',
      method: 'put',
      data: data
    })
  },
  // 获取详情
  getDetails(data) {
    return request({
      url: '/system/config',
      method: 'put',
      data: data
    })
  }
}

/*变动明细查询=------------*/
export const balanceDetailRequest = {
  // 查询列表
  list(query) {
    return request({
      url: gateWay1 + '/accountQuery/accountChangeList',
      method: 'get',
      params: query
    })
  },
}

/*账户记账修改查询=------------*/
export const accountBookRequest = {
  // 查询列表
  list(query) {
    return request({
      url: gateWay2 + '/accountAdjustRecord/list',
      method: 'get',
      params: query
    })
  },
  // 审核
  examine(data) {
    return request({
      url: gateWay2 + '/accountAdjustRecord/audit',
      method: 'post',
      data: data
    })
  },
  // 详情
  getDetails(query) {
    return request({
      url: gateWay2 + '/accountAdjustRecord/queryById',
      method: 'get',
      params: query
    })
  },
  // 详情
  getPhone(query) {
    return request({
      url: gateWay2 + '/accountAdjustRecord/queryAccountAdjustAuthorizedPhone',
      method: 'get',
      params: query
    })
  },
  // 详情
  sendCode(data) {
    return request({
      url: gateWay2 + '/accountAdjustRecord/sendSms',
      method: 'post',
      data: data
    })
  },
}

/*商户对账单查询=------------*/
export const merstatementRequest = {
  // 查询列表
  list(query) {
    return request({
      url: gateWay1 + '/accountQuery/queryAccountSatement',
      method: 'get',
      params: query
    })
  },
  // 详情
  getDetails(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
}

/*订单批次查询=------------*/
export const orderBatchRequest = {
  // 查询列表
  list(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
  // 明细列表
  detailsList(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
  // 详情
  getDetails(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
}

/*订单明细查询=------------*/
export const orderDetailsRequest = {
  // 查询列表
  list(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
  // 审核
  examine(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
  // 核查
  check(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
  // 材料补充
  replenish(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
  // 详情
  getDetails(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
}

/*提现批次查询=------------*/
export const withdrawalRequest = {
  // 查询列表
  list(query) {
    return request({
      url: gateWay4 + '/remit/admin/page-req',
      method: 'get',
      params: query
    })
  },
  // 审核
  detailsList(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
  // 详情
  getDetails(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
}

/*提现明细查询=------------*/
export const withdrawalDetailsRequest = {
  // 查询列表
  list(query) {
    return request({
      url: gateWay5 + '/payment/page',
      method: 'get',
      params: query
    })
  },
  // 详情
  getDetails(query) {
    return request({
      url: gateWay4 + '/remit/admin/'+query,
      method: 'get',
    })
  },
}

/*到账信息查询=------------*/
export const noticeInfoRequest = {
  // 查询列表
  list(query) {
    return request({
      url: gateWay2 + '/receiptInfo/queryList',
      method: 'get',
      params: query
    })
  },
  // 通过
  pass(data) {
    return request({
      url: gateWay2 + '/receiptInfo/entryAccountAudit',
      method: 'put',
      data: data
    })
  },
  // 拒绝
  reject(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
  // 详情
  getDetails(query) {
    return request({
      url: gateWay2 + '/receiptInfo/queryInfo',
      method: 'get',
      params: query
    })
  },
  // 汇款账户
  merchantRemitAll(data) {
    return request({
      url: gateWay2 + '/merchantRemit/queryAll',
      method: 'get',
      params: data
    })
  },
  // 入账
  entryAccountOperate(data) {
    return request({
      url: gateWay2 + '/receiptInfo/entryAccountOperate',
      method: 'put',
      data: data
    })
  },
}

/*下发还原关联查询=------------*/
export const issueRestoreRequest = {
  // 查询列表
  list(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
}

/*到账关联申报查询=------------*/
export const uponqueryRequest = {
  // 查询列表
  list(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
}

/*申报批次查询=------------*/
export const batchRequest = {
  // 查询列表
  list(query) {
    return request({
      url: '/monitor2/job/list',
      method: 'get',
      params: query
    })
  },
  // 查询详情列表
  detailslist(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
  // 重发
  resend(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
  // 详情
  getDetails(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
}

/*渠道代发明细查询=------------*/
export const disdetailsRequest = {
  // 查询列表
  list(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
  // 重发
  resend(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
  // 关闭
  close(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
  // 详情
  getDetails(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
}

/*明细失败响应码配置=------------*/
export const failConfigRequest = {
  // 查询列表
  list(query){
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
  // 添加
  add(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
  // 启用
  open(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
  // 停用
  stop(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
}

/*交行提现与订单管理=------------*/
export const whitorderRequest = {
  // 查询列表
  list(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
  // 添加
  add(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
  // 启用
  open(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
  // 停用
  stop(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
}



/*订单批量=------------*/
export const serviceOrderRequest = {
  // 查询列表
  list(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
  // 明细列表
  detailsList(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
  // 详情
  getDetails(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
  // 上传
  upLoad(query) {
    return request({
      url: xue + '/file',
      method: 'post',
      headers:{
        "Content-Type":"multipart/form-data;"
      },
      data: query
    })
  },
}



// 商服
/*提现批次查询=------------*/
export const serviceWhiRequest = {
  // 查询列表
  list(query) {
    return request({
      url: gateWay4 + '/remit/page-req',
      method: 'get',
      params: query
    })
  },
  // 审核
  detailsList(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
  // 详情
  getDetails(query) {
    return request({
      url: '/monitor/job/list',
      method: 'get',
      params: query
    })
  },
}

/*提现明细查询=------------*/
export const serviceDetailsRequest = {
  // 查询列表
  list(query) {
    return request({
      url: gateWay5 + '/payment/page',
      method: 'get',
      params: query
    })
  },
  // 详情
  getDetails(query) {
    return request({
      url: gateWay4 + '/remit/admin/'+query,
      method: 'get',
    })
  },
}
