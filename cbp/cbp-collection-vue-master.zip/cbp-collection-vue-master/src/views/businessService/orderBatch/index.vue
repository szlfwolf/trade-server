<template>
  <div class="app-container">
    <el-form
      :model="queryParams" ref="queryForm" size="small" v-show="showSearch"
      label-width="90px">
      <el-row :gutter="24">
        <el-col :span="6">
          <el-form-item label="上传文件名" prop="configName">
            <el-input
              v-model="queryParams.configName"
              placeholder="请输入上传文件名"
              clearable
              style="width: 100%"
              @keyup.enter.native="handleQuery"
            />
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="状态" prop="configType">
            <el-select style="width: 100%" v-model="queryParams.configType" placeholder="状态" clearable>
              <el-option
                v-for="dict in dict.type.sys_yes_no"
                :key="dict.value"
                :label="dict.label"
                :value="dict.value"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="上传时间">
            <el-date-picker
              style="width: 100%"
              v-model="dateRange"
              value-format="yyyy-MM-dd"
              type="daterange"
              range-separator="-"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
            ></el-date-picker>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="请求流水号" prop="configKey">
            <el-input
              v-model="queryParams.configKey"
              placeholder="请输入请求流水号"
              clearable
              style="width: 100%"
              @keyup.enter.native="handleQuery"
            />
          </el-form-item>
        </el-col>

      </el-row>
      <el-row :gutter="10" class="mb8">
        <el-col :span="1.5">
          <el-button v-hasPermi="['order:batch:query']" type="primary" icon="el-icon-search" size="small" @click="handleQuery">查询</el-button>
        </el-col>
        <el-col :span="1.5">
          <el-button icon="el-icon-refresh" size="small" @click="resetQuery">重置</el-button>
        </el-col>
        <el-col :span="1.5">
          <el-button
            v-hasPermi="['order:batch:query']" type="primary" icon="el-icon-upload" size="small"
            @click="handleUpload">文件上传</el-button>
        </el-col>
        <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
      </el-row>
    </el-form>
    <el-table v-loading="loading" :data="configList" @selection-change="handleSelectionChange">
      <el-table-column fixed="left" label="请求流水号" align="center" prop="configId" />
      <el-table-column label="上传文件名" align="center" prop="configName" :show-overflow-tooltip="true" />
      <el-table-column width="150px" label="总金额" align="center" prop="configKey" :show-overflow-tooltip="true" />
      <el-table-column width="150px" label="总笔数" align="center" prop="configValue" />
      <el-table-column width="150px" label="成功笔数" align="center" prop="configValue" />
      <el-table-column width="150px" label="状态" align="center" prop="remark" :show-overflow-tooltip="true" />
      <el-table-column width="150px" label="上传时间" align="center" prop="remark" :show-overflow-tooltip="true" />
      <el-table-column width="100px" label="失败详情" fixed="right" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            @click="handleDetails(scope.row)"
          >校验失败明细</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />
    <!-- 添加或修改参数配置对话框 -->
    <dialogView ref="dialog"></dialogView>
    <!-- 上传 -->
    <el-dialog :title="title" :visible.sync="open" width="600px" append-to-body>
      <el-row :gutter="24">
        <el-form ref="form" :model="form" :rules="rules" label-width="110px">
          <el-col :span="24">
            <el-form-item label="请求流水号：" prop="configType">
              <el-input
                v-model="queryParams.configKey"
                placeholder="请输入请求流水号"
                clearable
                style="width: 240px"
                @keyup.enter.native="handleQuery"
              />
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="付款币种：" prop="configType">
              <el-select style="width: 240px" v-model="queryParams.configType" placeholder="付款币种" clearable>
                <el-option
                  v-for="dict in dict.type.currency_type"
                  :key="dict.value"
                  :label="dict.label"
                  :value="dict.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="文件上传：" prop="configType">
              <el-upload
                class="upload-demo"
                action=""
                :http-request="httpRequest"
                :on-change="onChange"
                :limit="1"
                :auto-upload="false"
                :data="formData"
                :file-list="fileList">
                <el-button size="small" type="primary">点击上传</el-button>
              </el-upload>
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="模版及说明：">
              <el-button type="text">订单模板下载</el-button>
            </el-form-item>
          </el-col>
        </el-form>
      </el-row>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { serviceOrderRequest } from "@/api/merchant/infactor";
import dialogView from "./dialogView";
export default {
  name: "Config",
  dicts: ['currency_type'],
  components:{
    dialogView
  },
  data() {
    return {
      fileList:[],file:'',
      formData:{
        sourceFrom:"2",
        reqId:"111112",
        merchantNo:"123456789123",
      },
      // 遮罩层
      openUpload: true,
      // 遮罩层
      loading: true,
      // 内层dialog遮罩层
      innerVisible: false,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 参数表格数据
      configList: [{}],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 日期范围
      dateRange: [],
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        configName: undefined,
        configKey: undefined,
        configType: undefined
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        configName: [
          { required: true, message: "参数名称不能为空", trigger: "blur" }
        ],
        configKey: [
          { required: true, message: "参数键名不能为空", trigger: "blur" }
        ],
        configValue: [
          { required: true, message: "参数键值不能为空", trigger: "blur" }
        ]
      }
    };
  },
  created() {
    this.getList();
  },
  methods: {
    httpRequest(file){
      console.log(file)
    },
    onChange(file){
      this.file = file.raw
    },
    /** 查询参数列表 */
    getList() {
      this.loading = true;
      orderBatchRequest.list(this.addDateRange(this.queryParams, this.dateRange)).then(response => {
          this.configList = response.rows;
          this.total = response.total;
          this.loading = false;
        }
      ).catch((e)=>{
        this.loading = false
      });
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        configId: undefined,
        configName: undefined,
        configKey: undefined,
        configValue: undefined,
        configType: "Y",
        remark: undefined
      };
      this.resetForm("form");
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.dateRange = [];
      this.resetForm("queryForm");
      this.handleQuery();
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.reset();
      this.open = true;
      this.title = "添加参数";
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.configId)
      this.single = selection.length!=1
      this.multiple = !selection.length
    },
    /** 明细 */
    handleDetails(row) {
      this.$refs.dialog.checkData()
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.reset();
      this.open = true;
      const configId = row.configId || this.ids
      getConfig(configId).then(response => {
        this.form = response.data;
        this.open = true;
        this.title = "修改参数";
      });
    },
    /** 发送按钮 */
    sendCode(){

    },
    /** 确认按钮 */
    toSure(){

    },
    /** 拒绝按钮 */
    submitJect: function() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.configId != undefined) {
            updateConfig(this.form).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.getList();
            });
          } else {
            addConfig(this.form).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.getList();
            });
          }
        }
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const configIds = row.configId || this.ids;
      this.$modal.confirm('是否确认删除参数编号为"' + configIds + '"的数据项？').then(function() {
          return delConfig(configIds);
        }).then(() => {
          this.getList();
          this.$modal.msgSuccess("删除成功");
        }).catch(() => {});
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download('system/config/export', {
        ...this.queryParams
      }, `config_${new Date().getTime()}.xlsx`)
    },
    /** 上传按钮操作 */
    handleUpload() {
      this.title = "上传";
      this.open = true;
    },
    /** 刷新缓存按钮操作 */
    handleRefreshCache() {
      refreshCache().then(() => {
        this.$modal.msgSuccess("刷新成功");
      });
    },
    submitForm(){
      var formData = new FormData();
      formData.append("file", this.file);
      formData.append("sourceFrom", "2");
      formData.append("reqId", "111112");
      formData.append("merchantNo","123456789123");
      serviceOrderRequest.upLoad(formData).then(res=>{
        if(res.code=="000000"){
          this.$message({type:"success",message:"提交成功"})
        }
      })
    }
  }
};
</script>
