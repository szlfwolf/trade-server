<template>
  <!-- 添加或修改参数配置对话框 -->
  <el-dialog :title="title" :visible.sync="open" width="1000px" append-to-body
             :close-on-press-escape="false"
             :close-on-click-modal="false"
             :fullscreen="isFullscreen"
  >
    <template slot="title">
      <div class="dialog-bar">
        <span>{{title}}</span>
        <el-tooltip content="全屏 / 窗口" effect="dark" placement="bottom">
          <svg-icon @click="onScale" class="icon-full" :icon-class="isFullscreen?'exit-fullscreen':'fullscreen'" />
        </el-tooltip>
      </div>
    </template>
    <el-form disabled ref="form" :model="form" :rules="rules" label-width="100px" class="form">
      <el-tabs v-model="activeName" type="card">
        <el-tab-pane label="基本信息" name="first">
          <el-row :gutter="24">
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label="卖家编号" prop="configKey">
                <el-input v-model="form.configKey" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item  label="用户编号" prop="configKey">
                <el-input v-model="form.configKey" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label="用户名称" prop="configKey">
                <el-input v-model="form.configKey" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label="用户类型" prop="configKey">
                <el-input v-model="form.configKey" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label="证件号码" prop="configKey">
                <el-input v-model="form.configKey" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label="创建时间" prop="configKey">
                <el-input v-model="form.configKey" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label="更新时间" prop="configKey">
                <el-input v-model="form.configKey" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label-width="100px"  label="平台注册时间" prop="configKey">
                <el-input v-model="form.configKey" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label="备案状态" prop="configKey">
                <el-input v-model="form.configKey" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label-width="100px" label="证件有效期起" prop="configKey">
                <el-input v-model="form.configKey" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label-width="100px"  label="证件有效期止" prop="configKey">
                <el-input v-model="form.configKey" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label="注册地址" prop="configKey">
                <el-input v-model="form.configKey" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label-width="100px" label="常驻国家代码" prop="configKey">
                <el-input v-model="form.configKey" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label="邮编" prop="configKey">
                <el-input v-model="form.configKey" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label="企业简称" prop="configKey">
                <el-input v-model="form.configKey" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label="开户银行" prop="configKey">
                <el-input v-model="form.configKey" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label="联行号" prop="configKey">
                <el-input v-model="form.configKey" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label="户名" prop="configKey">
                <el-input v-model="form.configKey" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label="银行卡号" prop="configKey">
                <el-input v-model="form.configKey" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label="经营地址" prop="configKey">
                <el-input v-model="form.configKey" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label="支行名称" prop="configKey">
                <el-input v-model="form.configKey" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label="省份" prop="configKey">
                <el-input v-model="form.configKey" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label="地区" prop="configKey">
                <el-input v-model="form.configKey" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label-width="100px" label="住所/营业场所代码" prop="configKey">
                <el-input v-model="form.configKey" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label-width="100px" label="行业属性代码" prop="configKey">
                <el-input v-model="form.configKey" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label-width="100px" label="经济类型代码" prop="configKey">
                <el-input v-model="form.configKey" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label-width="160px" label="是否特殊经济区内企业" prop="configKey">
                <el-radio-group v-model="form.configKey">
                  <el-radio :label="Y">是</el-radio>
                  <el-radio :label="N">否</el-radio>
                </el-radio-group>
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label="内企业类型" prop="configKey">
                <el-input v-model="form.configKey" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label="经营范围" prop="configKey">
                <el-input v-model="form.configKey" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label="店铺链接" prop="configKey">
                <el-input v-model="form.configKey" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label-width="110px" label="营业执照影印件" prop="configKey">
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="补充材料1" prop="configKey">
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="补充材料2" prop="configKey">
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="补充材料3" prop="configKey">
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="补充材料4" prop="configKey">
              </el-form-item>
            </el-col>
          </el-row>
        </el-tab-pane>
        <el-tab-pane label="法人信息" name="second">
          <el-row :gutter="24">
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label="法人姓名" prop="memberNo">
                <el-input v-model="form.memberNo" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label-width="100px" label="法人件类型" prop="memberNo">
                <el-input v-model="form.memberNo" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label-width="100px" label="法人件号码" prop="memberNo">
                <el-input v-model="form.memberNo" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label-width="110px" label="证件有效期起" prop="memberNo">
                <el-input v-model="form.memberNo" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label-width="110px" label="证件有效期止" prop="memberNo">
                <el-input v-model="form.memberNo" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label="联系电话" prop="memberNo">
                <el-input v-model="form.memberNo" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 8">
              <el-form-item label="联系邮箱" prop="memberNo">
                <el-input v-model="form.memberNo" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 24 : 24">
              <el-form-item label-width="170px" label="法人身份证影印件正面" prop="memberNo">
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 24 : 24">
              <el-form-item label-width="170px" label="法人身份证影印件反面" prop="memberNo">
              </el-form-item>
            </el-col>
          </el-row>
        </el-tab-pane>
      </el-tabs>
    </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
  </el-dialog>
</template>

<script>
import { updateConfig, addConfig, getConfig } from "@/api/merchant/infactor";
export default {
  data(){
    return{
      // dialog全屏
      isFullscreen:false,
      // tabs的显示id
      activeName: 'first',
      // 弹出层标题
      title: "添加",
      // 是否显示弹出层
      open: false,
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        memberNo: [
          { required: true, message: "参数名称不能为空", trigger: "blur" }
        ]
      },
      // 表格集合
      tableData:[
        {
          id:1,
          date: '2016-05-02',
          checked:false,
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
          fileList:[]
        },
        {
          id:12,
          date: '2016-05-02',
          checked:false,
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
          fileList:[]
        },
        {
          id:3,
          date: '2016-05-02',
          checked:false,
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
          fileList:[]
        },
        {
          id:5,
          date: '2016-05-02',
          checked:false,
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
          fileList:[]
        }
      ],
      // 表格集合
      headerStyle:{
        color:"#123456"
      },
    }
  },
  methods:{
    onScale(){
      this.isFullscreen = !this.isFullscreen
    },
    handleSelectionChange(val){
      this.clearTree = val.map(item=>{
        return item.id
      })
      console.log(this.clearTree)
    },
    add(){
      this.open = true;
      this.title = "添加";
      this.reset();
    },
    /** 审核按钮操作 */
    examine(row) {
      this.open = true;
      this.title = "审核";
      // const configId = row.configId || this.ids
      getConfig().then(response => {
        this.form = response.data;
      });
    },
    /** 查看按钮操作 */
    checkData(row) {
      this.open = true;
      this.title = "查看";
      // const configId = row.configId || this.ids
      getConfig().then(response => {
        this.form = response.data;
      });
    },
    /** 修改按钮操作 */
    update(row) {
      this.open = true;
      this.title = "修改";
      // const configId = row.configId || this.ids
      getConfig().then(response => {
        this.form = response.data;
      });
    },
    /** 提交按钮 */
    submitForm: function() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.configId != undefined) {
            updateConfig(this.form).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.getList();
            });
          } else {
            addConfig(this.form).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.getList();
            });
          }
        }
      });
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        configId: undefined,
        memberNo: undefined,
        configKey: undefined,
        configValue: undefined,
        status: "",
        remark: undefined
      };
      this.resetForm("form");
    },
  }
}
</script>

<style>
  .title{
    font-size: 15px;
    color: #1890ff;
  }
  .el-table tr .heade-cell{
    color: #333;
    background-color:#eff3f8;
  }
</style>
<style scoped lang="scss">
.dialog-bar{
  position: relative;
  .icon-full{
    position: absolute;
    right: 30px;
    font-size: 12px;
    top: 2px;
    cursor: pointer;
  }
}
.form{
  overflow-x: hidden;
  overflow-y: scroll;
}
.form::-webkit-scrollbar{
  display: none;
}
.upload-demo{
  display: flex;
  align-items: center;
  justify-content: flex-start;
}
.date-select{
  /*display: flex;*/
  align-items: center;
  justify-content: flex-start;
}
</style>
