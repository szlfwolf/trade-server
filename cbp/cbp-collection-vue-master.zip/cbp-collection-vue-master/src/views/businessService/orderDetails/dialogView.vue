<template>
  <!-- 添加或修改参数配置对话框 -->
  <el-dialog :title="title" :visible.sync="open" width="1000px" append-to-body
             :close-on-press-escape="false"
             :close-on-click-modal="false"
             :fullscreen="isFullscreen"
  >
    <template slot="title">
      <div class="dialog-bar">
        <span>{{title}}</span>
        <el-tooltip content="全屏 / 窗口" effect="dark" placement="bottom">
          <svg-icon @click="onScale" class="icon-full" :icon-class="isFullscreen?'exit-fullscreen':'fullscreen'" />
        </el-tooltip>
      </div>
    </template>
    <el-form ref="form" :model="form" :rules="rules" label-width="120px" class="form">
      <el-row :gutter="24">
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label="批次请求流水号:" prop="configKey">
            <p style="border-bottom: 1px solid #eee">1243</p>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label="明细流水号:" prop="configKey">
            <p style="border-bottom: 1px solid #eee">1243</p>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label="订单编号:" prop="configKey">
            <p style="border-bottom: 1px solid #eee">1243</p>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label="汇款批次号:" prop="configKey">
            <p style="border-bottom: 1px solid #eee">1243</p>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label="卖家编号:" prop="configKey">
            <p style="border-bottom: 1px solid #eee">1243</p>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label="付款币种:" prop="configKey">
            <p style="border-bottom: 1px solid #eee">1243</p>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label="付款金额:" prop="configKey">
            <p style="border-bottom: 1px solid #eee">1243</p>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label="订单时间:" prop="configKey">
            <p style="border-bottom: 1px solid #eee">1243</p>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label="原始订单币别:" prop="configKey">
            <p style="border-bottom: 1px solid #eee">1243</p>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label="原始订单金额:" prop="configKey">
            <p style="border-bottom: 1px solid #eee">1243</p>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label="境外换算汇率:" prop="configKey">
            <p style="border-bottom: 1px solid #eee">1243</p>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label="业务类型:" prop="configKey">
            <p style="border-bottom: 1px solid #eee">1243</p>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label="产品类型:" prop="configKey">
            <p style="border-bottom: 1px solid #eee">1243</p>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label="平台名称:" prop="configKey">
            <p style="border-bottom: 1px solid #eee">1243</p>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label="店铺链接:" prop="configKey">
            <p style="border-bottom: 1px solid #eee">1243</p>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label="物流公司:" prop="configKey">
            <p style="border-bottom: 1px solid #eee">1243</p>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label="物流单号:" prop="configKey">
            <p style="border-bottom: 1px solid #eee">1243</p>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label="店铺编号:" prop="configKey">
            <p style="border-bottom: 1px solid #eee">1243</p>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label="平台类型:" prop="configKey">
            <p style="border-bottom: 1px solid #eee">1243</p>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label="创建时间:" prop="configKey">
            <p style="border-bottom: 1px solid #eee">1243</p>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label="更新时间:" prop="configKey">
            <p style="border-bottom: 1px solid #eee">1243</p>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label="文件材料:" prop="configKey">
            <p style="border-bottom: 1px solid #eee">1243</p>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label="状态:" prop="configKey">
            <p style="border-bottom: 1px solid #eee">1243</p>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label="审核详情:" prop="configKey">
            <p style="border-bottom: 1px solid #eee">1243</p>
          </el-form-item>
        </el-col>
        <el-col :span="24">
          <div class="el-table-init">
           <p class="el-table-title">商品列表</p>
           <el-table
             :data="tableData"
             height="240px"
           >
             <el-table-column
               label="商品名称"
               prop="date"/>
             <el-table-column
               label="商品数量"
               prop="date"/>
             <el-table-column
               label="商品单价"
               prop="date"/>
           </el-table>
            <pagination
              v-show="total>0"
              :total="total"
              :page.sync="queryParams.pageNum"
              :limit.sync="queryParams.pageSize"
              @pagination="getList"
            />
         </div>
        </el-col>
      </el-row>
    </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
  </el-dialog>
</template>

<script>
import { orderDetailsRequest } from "@/api/merchant/infactor";
export default {
  data(){
    return{
      total:10,
      loading: false,
      // dialog全屏
      isFullscreen:false,
      // tabs的显示id
      activeName: 'first',
      // 弹出层标题
      title: "添加",
      // 是否显示弹出层
      open: false,
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        memberNo: [
          { required: true, message: "参数名称不能为空", trigger: "blur" }
        ]
      },
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        memberNo: undefined,
        configKey: undefined,
        status: undefined
      },
      // 表格集合
      tableData:[
        {
          id:1,
          date: '2016-05-02',
          checked:false,
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
          fileList:[]
        },
        {
          id:12,
          date: '2016-05-02',
          checked:false,
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
          fileList:[]
        },
        {
          id:3,
          date: '2016-05-02',
          checked:false,
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
          fileList:[]
        },
        {
          id:3,
          date: '2016-05-02',
          checked:false,
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
          fileList:[]
        },
        {
          id:3,
          date: '2016-05-02',
          checked:false,
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
          fileList:[]
        },
        {
          id:3,
          date: '2016-05-02',
          checked:false,
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
          fileList:[]
        }
      ],
      // 表格集合
      headerStyle:{
        color:"#123456"
      },
    }
  },
  methods:{
    /** 查询商户信息列表 */
    getList() {
      this.loading = true;
      orderDetailsRequest.list(this.addDateRange(this.queryParams, this.dateRange)).then(response => {
          this.tableData = response.rows;
          this.total = response.total;
          this.loading = false;
        }
      ).catch(e=>{
        this.loading = false;
      });
    },
    onScale(){
      this.isFullscreen = !this.isFullscreen
    },
    handleSelectionChange(val){
      this.clearTree = val.map(item=>{
        return item.id
      })
      console.log(this.clearTree)
    },
    add(){
      this.open = true;
      this.title = "添加";
      this.reset();
    },
    /** 审核按钮操作 */
    examine(row) {
      this.open = true;
      this.title = "审核";
      // const configId = row.configId || this.ids
    },
    /** 查看按钮操作 */
    checkData(row) {
      this.open = true;
      this.title = "查看";
      // const configId = row.configId || this.ids
      getConfig().then(response => {
        this.form = response.data;
      });
    },
    /** 编辑按钮操作 */
    edit(row) {
      this.open = true;
      this.title = "编辑";
      // const configId = row.configId || this.ids
    },
    /** 修改按钮操作 */
    update(row) {
      this.open = true;
      this.title = "补充资料";
      // const configId = row.configId || this.ids
    },
    /** 提交按钮 */
    submitForm: function() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.configId != undefined) {
            updateConfig(this.form).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.getList();
            });
          } else {
            addConfig(this.form).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.getList();
            });
          }
        }
      });
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        configId: undefined,
        memberNo: undefined,
        configKey: undefined,
        configValue: undefined,
        status: "",
        remark: undefined
      };
      this.resetForm("form");
    },
  }
}
</script>

<style>
  .title{
    font-size: 15px;
    color: #1890ff;
  }
  .el-table tr .heade-cell{
    color: #333;
    background-color:#eff3f8;
  }
</style>
<style scoped lang="scss">
.el-table-init{
  border-radius: 5px;
  height: 360px;
  .el-table-title{
    font-size: 14px;
    font-weight: 800;
    padding: 10px 10px;
  }
  width: 95%;
  margin-left: 20px;
  border: 1px solid #ebebeb;
  margin-top: 20px;
  margin-bottom: 20px;
  box-shadow: 0px 0px 8px 1px rgba(232,237,250,.6);
}
.dialog-bar{
  position: relative;
  .icon-full{
    position: absolute;
    right: 30px;
    font-size: 12px;
    top: 2px;
    cursor: pointer;
  }
}
.form{
  overflow-x: hidden;
  overflow-y: scroll;
}
.form::-webkit-scrollbar{
  display: none;
}
.upload-demo{
  display: flex;
  align-items: center;
  justify-content: flex-start;
}
.date-select{
  /*display: flex;*/
  align-items: center;
  justify-content: flex-start;
}
</style>
