<template>
  <!-- 添加或修改参数配置对话框 -->
  <el-dialog :title="title" :visible.sync="open" width="1000px" append-to-body
             :close-on-press-escape="false"
             :close-on-click-modal="false"
             :fullscreen="isFullscreen"
  >
    <template slot="title">
      <div class="dialog-bar">
        <span>{{title}}</span>
        <el-tooltip content="全屏 / 窗口" effect="dark" placement="bottom">
          <svg-icon @click="onScale" class="icon-full" :icon-class="isFullscreen?'exit-fullscreen':'fullscreen'" />
        </el-tooltip>
      </div>
    </template>
    <el-form ref="form" :model="form" :rules="rules" label-width="80px" class="form" disabled>
      <el-row :gutter="24">
        <el-col :span="24">
          <el-table row-key="id" :expand-row-keys="expandKeys" v-loading="loading" :data="tableData" @selection-change="handleSelectionChange">
            <el-table-column type="expand">
              <template slot-scope="props">
              <el-form label-position="left" inline class="demo-table-expand">
                <el-row :gutter="24">
                  <el-col :span="8" >
                    <el-form-item label="提现订单号">
                      <span>{{ props.row.name }}</span>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8" >
                    <el-form-item label="金额">
                      <span>{{ props.row.shop }}</span>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8" >
                    <el-form-item label="卖家编号">
                      <span>{{ props.row.id }}</span>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8" >
                    <el-form-item label="银行名称">
                      <span>{{ props.row.shopId }}</span>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8" >
                    <el-form-item label="代发类型">
                      <span>{{ props.row.category }}</span>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8" >
                    <el-form-item label="到账类型">
                      <span>{{ props.row.address }}</span>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8" >
                    <el-form-item label="账号">
                      <span>{{ props.row.desc }}</span>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8" >
                    <el-form-item label="户名">
                      <span>{{ props.row.desc }}</span>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8" >
                    <el-form-item label="证件类型">
                      <span>{{ props.row.desc }}</span>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8" >
                    <el-form-item label="证件号码">
                      <span>{{ props.row.desc }}</span>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8" >
                    <el-form-item label="省份">
                      <span>{{ props.row.desc }}</span>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8" >
                    <el-form-item label="地区">
                      <span>{{ props.row.desc }}</span>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8" >
                    <el-form-item label="支行名">
                      <span>{{ props.row.desc }}</span>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8" >
                    <el-form-item label="联行号">
                      <span>{{ props.row.desc }}</span>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8" >
                    <el-form-item label="用途">
                      <span>{{ props.row.desc }}</span>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8" >
                    <el-form-item label="备注">
                      <span>{{ props.row.desc }}</span>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8" >
                    <el-form-item label="预留手机号">
                      <span>{{ props.row.desc }}</span>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8" >
                    <el-form-item label="业务类型">
                      <span>{{ props.row.desc }}</span>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8" >
                    <el-form-item label="平台名称">
                      <span>{{ props.row.desc }}</span>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8" >
                    <el-form-item label="备注2">
                      <span>{{ props.row.desc }}</span>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8" >
                    <el-form-item label="备注3">
                      <span>{{ props.row.desc }}</span>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8" >
                    <el-form-item label="备注4">
                      <span>{{ props.row.desc }}</span>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8" >
                    <el-form-item label="产品类型">
                      <span>{{ props.row.desc }}</span>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8" >
                    <el-form-item label="失败原因">
                      <span>{{ props.row.desc }}</span>
                    </el-form-item>
                  </el-col>
                </el-row>
              </el-form>
            </template>
            </el-table-column>
            <el-table-column width="150px" label="明细流水号" align="center" prop="name" />
            <el-table-column width="150px" label="订单编号" align="center" prop="configName" :show-overflow-tooltip="true" />
            <el-table-column width="160px" label="订单时间" align="center" prop="configKey" :show-overflow-tooltip="true" />
            <el-table-column width="150px" label="卖家编号" align="center" prop="configValue" />
            <el-table-column width="150px" label="付款币种" align="center" prop="configValue" />
            <el-table-column width="150px" label="付款金额" align="center" prop="configValue" />
           <!-- <el-table-column width="100px" label="原始订单币别" align="center" prop="configType"/>
            <el-table-column width="110px" label="原始订单金额" align="center" prop="remark" :show-overflow-tooltip="true" />
            <el-table-column width="100px" label="境外换算汇率" align="center" prop="remark" :show-overflow-tooltip="true" />
            <el-table-column width="100px" label="业务类型" align="center" prop="remark" :show-overflow-tooltip="true" />
            <el-table-column label="商品名称" align="center" prop="remark" :show-overflow-tooltip="true" />
            <el-table-column label="商品数量" align="center" prop="remark" :show-overflow-tooltip="true" />
            <el-table-column label="商品单价" align="center" prop="remark" :show-overflow-tooltip="true" />
            <el-table-column label="产品类型" align="center" prop="remark" :show-overflow-tooltip="true" />
            <el-table-column label="海外付款人名称" align="center" prop="remark" :show-overflow-tooltip="true" />
            <el-table-column label="海外付款人国别" align="center" prop="remark" :show-overflow-tooltip="true" />
            <el-table-column label="平台名称" align="center" prop="remark" :show-overflow-tooltip="true" />
            <el-table-column label="店铺链接" align="center" prop="remark" :show-overflow-tooltip="true" />
            <el-table-column label="物流公司" align="center" prop="remark" :show-overflow-tooltip="true" />
            <el-table-column label="物流单号" align="center" prop="remark" :show-overflow-tooltip="true" />
            <el-table-column label="海外付款人账号" align="center" prop="remark" :show-overflow-tooltip="true" />
            <el-table-column label="店铺编号" align="center" prop="remark" :show-overflow-tooltip="true" />
            <el-table-column label="备用2" align="center" prop="remark" :show-overflow-tooltip="true" />
            <el-table-column label="备用3" align="center" prop="remark" :show-overflow-tooltip="true" />
            <el-table-column label="平台类型" align="center" prop="remark" :show-overflow-tooltip="true" />
            <el-table-column label="汇款批次号" align="center" prop="remark" :show-overflow-tooltip="true" />
            <el-table-column label="申报方式" align="center" prop="remark" :show-overflow-tooltip="true" />
            <el-table-column label="收款人名称" align="center" prop="remark" :show-overflow-tooltip="true" />
            <el-table-column label="收款人证件类型" align="center" prop="remark" :show-overflow-tooltip="true" />
            <el-table-column label="收款人证件号" align="center" prop="remark" :show-overflow-tooltip="true" />
            <el-table-column label="收款人银行账号" align="center" prop="remark" :show-overflow-tooltip="true" />
            <el-table-column label="收款人地址" align="center" prop="remark" :show-overflow-tooltip="true" />
            <el-table-column label="收款人电话" align="center" prop="remark" :show-overflow-tooltip="true" />
            <el-table-column label="收款人关系" align="center" prop="remark" :show-overflow-tooltip="true" />
            <el-table-column label="失败原因" align="center" prop="remark" :show-overflow-tooltip="true" />-->
          </el-table>
          <pagination
            v-show="total>0"
            :total="total"
            :page.sync="queryParams.pageNum"
            :limit.sync="queryParams.pageSize"
            @pagination="getList"
          />
        </el-col>
      </el-row>
    </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
  </el-dialog>
</template>

<script>
import { withdrawalRequest } from "@/api/merchant/infactor";
export default {
  data(){
    return{
      total:0,
      queryParams:{
        pageNum:1,
        pageSize: 10
      },
      // dialog全屏
      isFullscreen:false,
      // table loading
      loading:false,
      // tabs的显示id
      activeName: 'first',
      // 弹出层标题
      title: "添加",
      // 是否显示弹出层
      open: false,
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        memberNo: [
          { required: true, message: "参数名称不能为空", trigger: "blur" }
        ]
      },
      // 默认展开项
      expandKeys:[1],
      // 表格集合
      tableData:[
        {
          id:1,
          date: '2016-05-02',
          checked:false,
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
          fileList:[]
        },
        {
          id:12,
          date: '2016-05-02',
          checked:false,
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
          fileList:[]
        },
        {
          id:3,
          date: '2016-05-02',
          checked:false,
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
          fileList:[]
        },
        {
          id:5,
          date: '2016-05-02',
          checked:false,
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
          fileList:[]
        }
      ],
      // 表格集合
      headerStyle:{
        color:"#123456"
      },
    }
  },
  methods:{
    getList(){
      this.loading = true;
      withdrawalRequest.detailsList(this.addDateRange(this.queryParams, this.dateRange)).then(response => {
          this.tableData = response.rows;
          this.total = response.total;
          this.loading = false;
        }
      ).catch((e)=>{
        this.loading = false
      });
    },
    onScale(){
      this.isFullscreen = !this.isFullscreen
    },
    handleSelectionChange(val){
      this.clearTree = val.map(item=>{
        return item.id
      })
      console.log(this.clearTree)
    },
    add(){
      this.open = true;
      this.title = "添加";
      this.reset();
    },
    /** 审核按钮操作 */
    examine(row) {
      this.open = true;
      this.title = "审核";
      // const configId = row.configId || this.ids
      getConfig().then(response => {
        this.form = response.data;
      });
    },
    /** 查看按钮操作 */
    checkData(row) {
      this.open = true;
      this.title = "查看";
      // const configId = row.configId || this.ids
      this.getList()
    },
    /** 修改按钮操作 */
    update(row) {
      this.open = true;
      this.title = "修改";
      // const configId = row.configId || this.ids
      getConfig().then(response => {
        this.form = response.data;
      });
    },
    /** 提交按钮 */
    submitForm: function() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.configId != undefined) {
            updateConfig(this.form).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.getList();
            });
          } else {
            addConfig(this.form).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.getList();
            });
          }
        }
      });
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        configId: undefined,
        memberNo: undefined,
        configKey: undefined,
        configValue: undefined,
        status: "",
        remark: undefined
      };
      this.resetForm("form");
    },
  }
}
</script>

<style>
  .title{
    font-size: 15px;
    color: #1890ff;
  }
  .el-table tr .heade-cell{
    color: #333;
    background-color:#eff3f8;
  }
</style>
<style scoped lang="scss">
.demo-table-expand {
  font-size: 0;
}
.demo-table-expand label {
  width: 90px;
  color: #99a9bf;
}
.demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  width: 100%;
}
.dialog-bar{
  position: relative;
  .icon-full{
    position: absolute;
    right: 30px;
    font-size: 12px;
    top: 2px;
    cursor: pointer;
  }
}
.form{
  overflow-x: hidden;
  overflow-y: scroll;
}
.form::-webkit-scrollbar{
  display: none;
}
.upload-demo{
  display: flex;
  align-items: center;
  justify-content: flex-start;
}
.date-select{
  /*display: flex;*/
  align-items: center;
  justify-content: flex-start;
}
</style>
