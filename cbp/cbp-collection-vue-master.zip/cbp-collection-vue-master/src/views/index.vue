<template>
  <div class="app-container home">
    <el-row :gutter="20">
      <el-col :offset="1" :sm="10" :lg="10" style="padding-left: 20px">
        <el-card class="box-card" style="height: 300px">
          <div slot="header" class="clearfix">
            <span class="title">今日任务</span>
            <el-button style="float: right; padding: 3px 0" type="text"></el-button>
          </div>
          <div style="height: 220px;overflow: auto">
            <div class="text item">
              1.商户信息查询菜单存在待审核状态记录。
            </div>
            <div class="text item">
              2.商户手续费查询菜单存在待审核状态记录。
            </div>
          </div>
        </el-card>
      </el-col>
      <el-col :offset="1" :sm="10" :lg="10" style="padding-left: 20px">
        <el-card class="box-card" style="height: 300px">
          <div slot="header" class="clearfix">
            <span class="title">系统公告</span>
            <el-button style="float: right; padding: 3px 0" type="text"></el-button>
          </div>
          <div style="height: 220px;overflow: auto">
            <div class="text item">
              10月20日晚19:00-20:00间，跨境业务系统进行优化升级，优化内容如下：
            </div>
            <div class="text item">
              10月20日晚19:00-20:00间，跨境业务系统进行优化升级，优化内容如下：
            </div>
            <div class="text item">
              1.订单数据备案接口，增加订单编号+卖家编号+平台名称唯一性校验。
            </div>
            <div class="text item">
              2.付款结果查询接口，增加部分错误描述。
            </div>
            <div class="text item">
              上线发版期间将无法进行业务交易，还请知悉!
            </div>
            <div class="text item">
              1.订单数据备案接口，增加订单编号+卖家编号+平台名称唯一性校验。
            </div>
            <div class="text item">
              2.付款结果查询接口，增加部分错误描述。
            </div>
            <div class="text item">
              上线发版期间将无法进行业务交易，还请知悉!
            </div>
            <div class="text item">
              1.订单数据备案接口，增加订单编号+卖家编号+平台名称唯一性校验。
            </div>
            <div class="text item">
              2.付款结果查询接口，增加部分错误描述。
            </div>
            <div class="text item">
              上线发版期间将无法进行业务交易，还请知悉!
            </div>
            <div class="text item">
              1.订单数据备案接口，增加订单编号+卖家编号+平台名称唯一性校验。
            </div>
            <div class="text item">
              2.付款结果查询接口，增加部分错误描述。
            </div>
            <div class="text item">
              上线发版期间将无法进行业务交易，还请知悉!
            </div>
          </div>
        </el-card>
      </el-col>
      <el-col :offset="1" :sm="10" :lg="10" style="padding-left: 20px;margin-top:20px">
        <el-card class="box-card" style="height: 300px">
          <div slot="header" class="clearfix">
            <span class="title">今日订单</span>
            <el-button style="float: right; padding: 3px 0" type="text"></el-button>
          </div>
          <div style="height: 220px;overflow: auto">
            <div class="text item">
              <p class="money">总笔数：<span class="red">108912</span>笔</p>
            </div>
            <div class="text item">
              <p class="money">总金额：<span class="red">10,055,234.12</span>元</p>
            </div>
          </div>
        </el-card>
      </el-col>
      <el-col :offset="1" :sm="10" :lg="10" style="padding-left: 20px;margin-top:20px">
        <el-card class="box-card" style="height: 300px">
          <div slot="header" class="clearfix">
            <span class="title">今日提现</span>
            <el-button style="float: right; padding: 3px 0" type="text"></el-button>
          </div>
          <div style="height: 220px;overflow: auto">
            <div class="text item">
              <p class="money">成功总笔数：<span class="red">108912</span>笔</p>
            </div>
            <div class="text item">
              <p class="money">成功总金额：<span class="red">10,055,234.12</span>元</p>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>
    <el-divider />
  </div>
</template>

<script>
export default {
  name: "Index",
  data() {
    return {
      // 版本号
      version: "3.8.4",
    };
  },
  methods: {
    goTarget(href) {
      window.open(href, "_blank");
    },
  },
};
</script>

<style scoped lang="scss">
.home {
  .title{
    font-weight: 600;
    font-size: 15px;
  }
  .text{
    font-size: 14px;
    line-height: 20px;
    letter-spacing: .5px;
    font-weight: 600;
    .money{
      font-size: 18px;
      line-height: 30px;
      .red{
        color: red;
        font-size: 30px;
        margin-right: 10px;
      }
    }
  }
  blockquote {
    padding: 10px 20px;
    margin: 0 0 20px;
    font-size: 17.5px;
    border-left: 5px solid #eee;
  }
  hr {
    margin-top: 20px;
    margin-bottom: 20px;
    border: 0;
    border-top: 1px solid #eee;
  }
  .col-item {
    margin-bottom: 20px;
  }

  ul {
    padding: 0;
    margin: 0;
  }

  font-family: "open sans", "Helvetica Neue", Helvetica, Arial, sans-serif;
  font-size: 13px;
  color: #676a6c;
  overflow-x: hidden;

  ul {
    list-style-type: none;
  }

  h4 {
    margin-top: 0px;
  }

  h2 {
    margin-top: 10px;
    font-size: 26px;
    font-weight: 100;
  }

  p {
    margin-top: 10px;

    b {
      font-weight: 700;
    }
  }

  .update-log {
    ol {
      display: block;
      list-style-type: decimal;
      margin-block-start: 1em;
      margin-block-end: 1em;
      margin-inline-start: 0;
      margin-inline-end: 0;
      padding-inline-start: 40px;
    }
  }
}
</style>

