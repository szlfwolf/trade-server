<template>
  <div class="app-container">
    <el-form :model="queryParams" inline ref="queryForm" size="small" v-show="showSearch"
             label-width="118px">
      <el-form-item label="通道用户编号" prop="userNo">
        <el-input
          v-model="queryParams.userNo"
          placeholder="请输入通道用户编号"
          clearable
        />
      </el-form-item>
      <el-form-item label="通道请求流水号" prop="configKey">
        <el-input
          v-model="queryParams.configKey"
          placeholder="请输入通道请求流水号"
          clearable
        />
      </el-form-item>
      <el-form-item label="创建时间">
        <el-date-picker
          v-model="dateRange"
          style="width: 100%"
          value-format="yyyy-MM-dd"
          type="daterange"
          range-separator="-"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
        ></el-date-picker>
      </el-form-item>
      <el-form-item label="客户类型" prop="userType">
        <el-select style="width: 100%" v-model="queryParams.userType" placeholder="用户类型" clearable>
          <el-option
            v-for="dict in dict.type.user_type"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="状态" prop="status">
        <el-select style="width: 100%" v-model="queryParams.status" placeholder="状态" clearable>
          <el-option
            v-for="dict in dict.type.register_status"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>

      <el-form-item label="客户名称" prop="configKey">
        <el-input
          v-model="queryParams.configKey"
          placeholder="请输入客户名称"
          clearable
        />
      </el-form-item>
      <el-form-item label="证件号" prop="configKey">
        <el-input
          v-model="queryParams.configKey"
          placeholder="请输入证件号"
          clearable
        />
      </el-form-item>
      <el-form-item label-width="0">
        <el-button v-hasPermi="['user:channelfiling:query']" type="primary" icon="el-icon-search" size="mini" @click="handleQuery">查询</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>
    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          v-hasPermi="['user:channelfiling:export']"
          plain
          type="warning"
          icon="el-icon-download"
          size="mini"
          @click="handleExport">导出</el-button>

        <!--        <el-button-->
<!--          type="primary"-->
<!--          plain-->
<!--          icon="el-icon-plus"-->
<!--          size="mini"-->
<!--          @click="handleAdd"-->
<!--          v-hasPermi="['system:config:add']"-->
<!--        >添加</el-button>-->
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="configList" @selection-change="handleSelectionChange">
      <el-table-column width="150px" label="通道请求流水号" fixed="left"  align="center" prop="reqNo"  />
      <el-table-column width="150px" label="通道用户编号" align="center" prop="openUserNo" :show-overflow-tooltip="true"/>
      <el-table-column label="客户名称" align="center" prop="nameMask" />
      <el-table-column width="150px" label="客户类型" align="center" prop="userType"  />
      <el-table-column width="150px" label="证件号" align="center" prop="certIdMask"  />
      <el-table-column width="150px" label="通道名称" align="center" prop="channelName"  />
      <el-table-column width="120px" label="状态" align="center" prop="remark"  />
      <el-table-column width="120px" label="返回详情" align="center" prop="remark"  />
      <el-table-column width="150px" label="创建时间" align="center" prop="crtDate"  />
      <el-table-column width="150px" label="更新时间" align="center" prop="updDate"  />
      <el-table-column label="操作" fixed="right" width="100px" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            @click="handleView(scope.row)"
            v-hasPermi="['system:config:view']"
          >查看详情</el-button>
          <el-button
            size="mini"
            type="text"
            @click="handleResend(scope.row)"
            v-if="scope.row.status==4"
          >重发</el-button>
        </template>
      </el-table-column>
    </el-table>
    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />
    <personalDialog ref="personalDialog"></personalDialog>
    <bussinessDialog ref="bussinessDialog"></bussinessDialog>
  </div>
</template>

<script>
import { userChannelRequest, userChannelExport } from '@/api/merchant/infactor'
import personalDialog from "./personal";
import bussinessDialog from "./bussiness";
export default {
  name: "Config",
  components:{
    personalDialog,
    bussinessDialog
  },
  dicts:["operation_status","merchant_status","user_type","source_country","register_status"],
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 参数表格数据
      configList: [],
      // 日期范围
      dateRange: [],
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        memberNo: undefined,
        configKey: undefined,
        status: undefined
      },
      // 表单校验
      rules: {
        memberNo: [
          { required: true, message: "不能为空", trigger: "blur" }
        ]
      }
    };
  },
  created() {
    this.getList();
  },
  methods: {
    /** 查询商户信息列表 */
    getList() {
      this.loading = true;
      userChannelRequest.list(this.addDateRange(this.queryParams, this.dateRange)).then(response => {
          this.configList = response.rows;
          this.total = response.total;
          this.loading = false;
        }
      ).catch(e=>{
        this.loading = false;
      });
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.dateRange = [];
      this.resetForm("queryForm");
      this.handleQuery();
    },
    // 多选框选中数据
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.configId)
      this.single = selection.length!=1
      this.multiple = !selection.length
    },
    /** 重发按钮操作 */
    handleResend(row) {
      let refName = "personalDialog"
      if(row.userType == 1){
        refName = 'bussinessDialog'
      }
      // const configId = row.configId || this.ids
      this.$refs[refName].resend(row)
    },
    /** 查看按钮操作 */
    handleView(row) {
      let refName = "personalDialog"
      if(row.userType == 1){
        refName = 'bussinessDialog'
      }
      // const configId = row.configId || this.ids
      this.$refs[refName].checkData(row)
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download(userChannelExport, {
        ...this.queryParams
      }, `用户渠道备案信息查询_${new Date().getTime()}.xlsx`)
    },
  }
};
</script>
