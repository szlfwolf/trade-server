<template>
  <!-- 添加或修改参数配置对话框 -->
  <el-dialog :title="title" :visible.sync="open" width="900px" append-to-body
             :fullscreen="isFullscreen"
  >
    <template slot="title">
      <div class="dialog-bar">
        <span>{{title}}</span>
        <el-tooltip content="全屏 / 窗口" effect="dark" placement="bottom">
          <svg-icon @click="onScale" class="icon-full" :icon-class="isFullscreen?'exit-fullscreen':'fullscreen'" />
        </el-tooltip>
      </div>
    </template>
    <el-form ref="form" :model="form" :rules="rules" label-width="80px" class="form" disabled>
      <el-row :gutter="24">
        <el-col :span="isFullscreen ? 24 : 24">
          <el-form-item label-width="110px" label="通道请求流水号" prop="chnl_seq_no">
            <el-input v-model="form.chnl_seq_no" placeholder="" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label-width="110px" label="通道用户编号" prop="merch_no">
            <el-input v-model="form.merch_no" placeholder="" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label-width="100px" label="客户名称" prop="cust_name">
            <el-input v-model="form.cust_name" placeholder="" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label-width="100px" label="客户类型" prop="cust_type">
            <el-select style="width: 100%" v-model="form.cust_type" placeholder="客户类型" clearable>
              <el-option
                v-for="dict in dict.type.user_type"
                :key="dict.value"
                :label="dict.label"
                :value="dict.value"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label-width="100px" label="客户证件号码" prop="cust_id_no">
            <el-input v-model="form.cust_id_no" placeholder="" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label-width="100px" label="客户证件类型" prop="cust_id_type">
            <el-select style="width: 100%" v-model="form.cust_id_type" placeholder="客户证件类型" clearable>
              <el-option
                v-for="dict in dict.type.certificate_type"
                :key="dict.value"
                :label="dict.label"
                :value="dict.value"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label-width="100px" label="证件有效期止" prop="exp_date">
            <el-input v-model="form.exp_date" placeholder="" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label-width="100px" label="职业" prop="profession">
            <el-input v-model="form.profession" placeholder="" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label-width="100px" label="国籍" prop="nationality">
            <el-select style="width: 100%" v-model="form.nationality" placeholder="性别" clearable>
              <el-option
                v-for="dict in dict.type.source_country"
                :key="dict.value"
                :label="dict.label"
                :value="dict.value"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label-width="100px" label="性别" prop="sex">
              <el-select style="width: 100%" v-model="form.sex" placeholder="性别" clearable>
                <el-option
                  v-for="dict in dict.type.sex_type"
                  :key="dict.value"
                  :label="dict.label"
                  :value="dict.value"
                />
              </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label-width="100px" label="出生日期" prop="birth_date">
            <el-input v-model="form.birth_date" placeholder="" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label-width="100px" label="联系人" prop="contacts">
            <el-input v-model="form.contacts" placeholder="" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label-width="100px" label="联系电话" prop="contact_phone">
            <el-input v-model="form.contact_phone" placeholder="" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label-width="100px" label="地址" prop="address">
            <el-input v-model="form.address" placeholder="" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label-width="100px" label="邮箱" prop="email">
            <el-input v-model="form.email" placeholder="" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label-width="100px" label="创建时间" prop="crtTime">
            <el-input v-model="form.crtTime" placeholder="" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label-width="100px" label="更新时间" prop="uptTime">
            <el-input v-model="form.uptTime" placeholder="" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label-width="100px" label="备案状态" prop="registerStatus">
            <el-select style="width: 100%" v-model="form.registerStatus" placeholder="状态" clearable>
              <el-option
                v-for="dict in dict.type.register_status"
                :key="dict.value"
                :label="dict.label"
                :value="dict.value"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 8">
          <el-form-item label-width="100px" label="通道名称" prop="channelName">
            <el-input v-model="form.channelName" placeholder="" />
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="24">
        <el-col :span="24">
          <el-table
          :data="form.doc_list"
          >
            <el-table-column label="影印件列表" fixed="left"  align="center" prop="doc_name"  />
            <el-table-column label="doc_id" fixed="left"  align="center" prop="doc_id"  />
            <el-table-column label="doc_name" fixed="left"  align="center" prop="doc_name"  />
            <el-table-column label="doc_type" fixed="left"  align="center" prop="doc_type"  />
          </el-table>
        </el-col>
      </el-row>
    </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
  </el-dialog>
</template>

<script>
import { userChannelRequest, userChannelExport } from '@/api/merchant/infactor'
export default {
  dicts:["operation_status","merchant_status","user_type","source_country","register_status","sex_type","certificate_type"],
  data(){
    return{
      // dialog全屏
      isFullscreen:false,
      // tabs的显示id
      activeName: 'first',
      // 弹出层标题
      title: "添加",
      // 是否显示弹出层
      open: false,
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        memberNo: [
          { required: true, message: "参数名称不能为空", trigger: "blur" }
        ]
      },
      // 表格集合
      tableData:[],
      // 表格集合
      headerStyle:{
        color:"#123456"
      },
    }
  },
  methods:{
    onScale(){
      this.isFullscreen = !this.isFullscreen
    },
    handleSelectionChange(val){
      this.clearTree = val.map(item=>{
        return item.id
      })
      console.log(this.clearTree)
    },
    add(){
      this.open = true;
      this.title = "添加";
      this.reset();
    },
    /** 审核按钮操作 */
    resend(row) {
      this.open = true;
      this.title = "审核";
      const id = row.id || ""
      userChannelRequest.getDetails().then(response => {
        this.form = response.data;
      });
    },
    /** 查看按钮操作 */
    checkData(row) {
      this.open = true;
      this.title = "查看";
      const id = row.id || ""
      userChannelRequest.getDetails(id).then(response => {
        this.form = response.data;
      });
    },
    /** 修改按钮操作 */
    update(row) {
      this.open = true;
      this.title = "修改";
      const id = row.id || ""
      userChannelRequest.getDetails(id).then(response => {
        this.form = response.data;
      });
    },
    /** 提交按钮 */
    submitForm: function() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.configId != undefined) {
            updateConfig(this.form).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.getList();
            });
          } else {
            addConfig(this.form).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.getList();
            });
          }
        }
      });
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        configId: undefined,
        memberNo: undefined,
        configKey: undefined,
        configValue: undefined,
        status: "",
        remark: undefined
      };
      this.resetForm("form");
    },
  }
}
</script>

<style>
  .title{
    font-size: 15px;
    color: #1890ff;
  }
  .el-table tr .heade-cell{
    color: #333;
    background-color:#eff3f8;
  }
</style>
<style scoped lang="scss">
.dialog-bar{
  position: relative;
  .icon-full{
    position: absolute;
    right: 30px;
    font-size: 12px;
    top: 2px;
    cursor: pointer;
  }
}
.form{
  overflow-x: hidden;
  overflow-y: scroll;
}
.form::-webkit-scrollbar{
  display: none;
}
.upload-demo{
  display: flex;
  align-items: center;
  justify-content: flex-start;
}
.date-select{
  /*display: flex;*/
  align-items: center;
  justify-content: flex-start;
}
</style>
