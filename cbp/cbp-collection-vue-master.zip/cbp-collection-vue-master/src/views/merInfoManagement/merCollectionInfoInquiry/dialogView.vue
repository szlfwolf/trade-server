<template>
  <!-- 添加或修改参数配置对话框 -->
  <el-dialog :title="title" :visible.sync="open" width="700px" append-to-body
             :close-on-press-escape="false"
             :close-on-click-modal="false"
             :fullscreen="isFullscreen"
  >
    <template slot="title">
      <div class="dialog-bar">
        <span>{{title}}</span>
        <el-tooltip content="全屏 / 窗口" effect="dark" placement="bottom">
          <svg-icon @click="onScale" class="icon-full" :icon-class="isFullscreen?'exit-fullscreen':'fullscreen'" />
        </el-tooltip>
      </div>
    </template>
    <el-form ref="form" :model="form" :rules="rules" label-width="80px" class="form" :disabled="formDis">
      <el-row :gutter="24">
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item label="商户名称" prop="merchantNo">
                <el-select
                  clearable
                  v-model="form.merchantNo"
                  placeholder="选择"
                  style="width: 240px"
                  remote
                  :remote-method="remoteMethod"
                  @change="onChange"
                  @focus="onFocus"
                  filterable
                  :loading="xlloading"
                  v-loadmore="loadmore"
                >
                  <el-option
                    v-for="(item, index) in departmentList"
                    :key="index"
                    :label="item.merchantName"
                    :value="item.merchantNo"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item label="商户号" prop="merchantNo">
                <el-input disabled v-model="form.merchantNo" placeholder="请输入商户号" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item label="账户名称" prop="accountName">
                <el-input v-model="form.accountName" placeholder="请输入账户名称" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item label="账号" prop="accountNo">
                <el-input v-model="form.accountNo" placeholder="请输入账号" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item label-width="110px" label="币别" prop="currency">
                <el-select style="width: 100%" v-model="form.currency" placeholder="币别" clearable>
                  <el-option
                    v-for="dict in dict.type.currency_type"
                    :key="dict.value"
                    :label="dict.label"
                    :value="dict.value"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item label="地址" prop="address">
                <el-input v-model="form.address" placeholder="请输入地址" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item label="所属国别" prop="sourceCountry">
                <el-select style="width: 100%" v-model="form.sourceCountry" placeholder="所属国别" clearable>
                  <el-option
                    v-for="dict in dict.type.source_country"
                    :key="dict.value"
                    :label="dict.label"
                    :value="dict.value"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item label-width="110px" label="SWIFT CODE" prop="swiftCode">
                <el-input v-model="form.swiftCode	" placeholder="请输入SWIFT CODE" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item label="银行名称" prop="bankName">
                <el-input v-model="form.bankName" placeholder="请输入银行名称" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item label-width="110px" label="银行地址" prop="bankAddress">
                <el-input v-model="form.bankAddress" placeholder="请输入银行地址" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item label="账户类型" prop="accountType">
                <el-select style="width: 100%" v-model="form.accountType" placeholder="账户类型" clearable>
                  <el-option
                    v-for="dict in dict.type.account_mer_type"
                    :key="dict.value"
                    :label="dict.label"
                    :value="dict.value"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item label="申报名称" prop="declareName">
                <el-input v-model="form.declareName" placeholder="请输入申报名称" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item label="证件类型" prop="certificateType">
                <el-select style="width: 100%" v-model="form.certificateType" placeholder="账户类型" clearable>
                  <el-option
                    v-for="dict in dict.type.certificate_type"
                    :key="dict.value"
                    :label="dict.label"
                    :value="dict.value"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12">
              <el-form-item label="证件号" prop="certificateNo">
                <el-input v-model="form.certificateNo" placeholder="请输入证件号" />
              </el-form-item>
            </el-col>
            <el-col :span="isFullscreen ? 8 : 12" v-if="type!='add'">
              <el-form-item label="状态" prop="status">
                <el-select style="width: 100%" v-model="form.status" placeholder="状态" clearable>
                  <el-option
                    v-for="dict in dict.type.merchant_status"
                    :key="dict.value"
                    :label="dict.label"
                    :value="dict.value"
                  />
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
    </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="danger" @click="onReject">审核拒绝</el-button>
        <el-button type="primary" @click="onPass">审核通过</el-button>
        <el-button type="primary" @click="submitForm" v-if="type!='view'">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
  </el-dialog>
</template>

<script>
import { merColle, merInfo } from '@/api/merchant/infactor'
export default {
  dicts:["operation_status","merchant_status","currency_type","source_country","certificate_type","account_mer_type"],
  data(){
    return{
      type:'add',
      departmentList: [],
      formDis: false,
      xlloading: false,
      // dialog全屏
      isFullscreen:false,
      // tabs的显示id
      activeName: 'first',
      // 弹出层标题
      title: "添加",
      // 是否显示弹出层
      open: false,
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        merchantNo: [
          { required: true, message: "不能为空", trigger: "blur" }
        ],
        accountName: [
          { required: true, message: "不能为空", trigger: "blur" }
        ],
        accountNo: [
          { required: true, message: "不能为空", trigger: "blur" }
        ],
        currency: [
          { required: true, message: "不能为空", trigger: "blur" }
        ],
        sourceCountry: [
          { required: true, message: "不能为空", trigger: "blur" }
        ],
        swiftCode: [
          { required: true, message: "不能为空", trigger: "blur" }
        ],
        bankName: [
          { required: true, message: "不能为空", trigger: "blur" }
        ],
        accountType: [
          { required: true, message: "不能为空", trigger: "blur" }
        ],
        declareName: [
          { required: true, message: "不能为空", trigger: "blur" }
        ],
        certificateNo: [
          { required: true, message: "不能为空", trigger: "blur" }
        ],
        certificateType: [
          { required: true, message: "不能为空", trigger: "blur" }
        ],
      },
      headerStyle:{
        color:"#123456"
      },
      multipleSelection:[],
      clearTree:[]
    }
  },
  methods:{
    // remoteMethod
    remoteMethod(query) {
      if (query !== '') {
        this.xlloading = true;
        this.merNum = 1
        this.departmentList = []
        this.getMerchantList(query);
      } else {
        this.getMerchantList();
      }
    },
    onFocus(){
      if (!this.form.merchantNo) {
        this.xlloading = true;
        this.merNum = 1
        this.departmentList = []
        this.getMerchantList();
      }
    },
    onChange(val){
      if (!this.form.merchantNo) {
        this.xlloading = true;
        this.merNum = 1
        this.departmentList = []
        this.getMerchantList();
      }
    },
    getMerchantList(query){
      let params = {
        pageNum: this.merNum,
        pageSize: this.merSize,
      }
      if(Number(query)){
        params["merchantNo"] = query
      } else {
        params["merchantName"] = query
      }
      merInfo.getMerchantInfo(params).then(response => {
          this.departmentList = [...this.departmentList,...response.data]
          this.merTotal = Math.ceil(response.total / this.merSize)
        }
      ).catch(e=>{
        this.loading = false;
      }).finally(e=>{
        this.xlloading = false;
      });
    },
    //滑动触底的相关操作
    loadmore(){
      if(this.merNum<this.merTotal){
        this.merNum+=1
        this.getMerchantList()
      }
      console.log(this.merNum,this.merTotal);

      //数据页面更新，数据请求操作
    },
    onScale(){
      this.isFullscreen = !this.isFullscreen
    },
    handleSelectionChange(val){
      this.clearTree = val.map(item=>{
        return item.id
      })
      console.log(this.clearTree)
    },
    add(){
      this.open = true;
      this.formDis = false;
      this.title = "添加";
      this.type = "add";
      this.reset();
    },
    /** 审核按钮操作 */
    examine(row) {
      this.open = true;
      this.type = "view";
      this.formDis = true
      this.title = "审核";
      // const configId = row.configId || this.ids
      this.form = row
    },
    /** 查看按钮操作 */
    checkData(row) {
      this.open = true;
      this.formDis = true
      this.title = "查看";
      this.type = "view";
      // const configId = row.configId || this.ids
      this.form = row
    },
    /** 修改按钮操作 */
    update(row) {
      this.open = true;
      this.formDis = false
      this.title = "修改";
      this.type = "edit";
      // const configId = row.configId || this.ids
      this.form = row
    },
    // 拒绝
    onReject(){
      this.$confirm('是否继续此操作?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'error'
      }).then(() => {
        merColle.examineMerColle({
          id:this.form.id,
          merchantNo:this.form.merchantNo,
          merchantStatus:this.form.status,
          operationStatus: '2',
        }).then(res=>{
          this.$modal.msgSuccess("审核拒绝成功");
          this.open = false;
          this.$parent.getList();
        })
      }).catch(() => {

      });
    },
    // 审核
    onPass(){
      this.$confirm('是否继续此操作?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'success'
      }).then(() => {
        merColle.examineMerColle({
          id:this.form.id,
          merchantNo:this.form.merchantNo,
          merchantStatus:this.form.status,
          operationStatus: '3',
        }).then(res=>{
          this.$modal.msgSuccess("审核通过成功");
          this.open = false;
          this.$parent.getList();
        })
      }).catch(() => {

      });
    },
    /** 提交按钮 */
    submitForm: function() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.id != undefined) {
            merColle.updateMerColle(this.form).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.$parent.getList();
            });
          } else {
            merColle.addMerColle(this.form).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.$parent.getList();
            });
          }
        }
      });
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {};
      this.resetForm("form");
    },
  }
}
</script>

<style>
  .title{
    font-size: 15px;
    color: #1890ff;
  }
  .el-table tr .heade-cell{
    color: #333;
    background-color:#eff3f8;
  }
</style>
<style scoped lang="scss">
.dialog-bar{
  position: relative;
  .icon-full{
    position: absolute;
    right: 30px;
    font-size: 12px;
    top: 2px;
    cursor: pointer;
  }
}
.form{
  overflow-x: hidden;
  overflow-y: scroll;
}
.form::-webkit-scrollbar{
  display: none;
}
.upload-demo{
  display: flex;
  align-items: center;
  justify-content: flex-start;
}
.date-select{
  /*display: flex;*/
  align-items: center;
  justify-content: flex-start;
}
</style>
