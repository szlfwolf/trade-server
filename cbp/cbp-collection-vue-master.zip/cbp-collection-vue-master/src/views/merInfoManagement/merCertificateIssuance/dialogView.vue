<template>
  <!-- 添加或修改参数配置对话框 -->
  <el-dialog :title="title" :visible.sync="open" width="500px" append-to-body
             :close-on-press-escape="false"
             :close-on-click-modal="false"
             :fullscreen="isFullscreen"
  >
    <template slot="title">
      <div class="dialog-bar">
        <span>{{title}}</span>
        <el-tooltip content="全屏 / 窗口" effect="dark" placement="bottom">
          <svg-icon @click="onScale" class="icon-full" :icon-class="isFullscreen?'exit-fullscreen':'fullscreen'" />
        </el-tooltip>
      </div>
    </template>
    <el-form ref="form" :model="form" :rules="rules" label-width="80px" class="form">
      <el-row :gutter="24">
        <el-col :span="isFullscreen ? 8 : 24">
          <el-form-item label="商户名称" prop="memberNo">
            <el-input v-model="form.memberNo" placeholder="请输入商户名称" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 24">
          <el-form-item label="商户号" prop="configKey">
            <el-input v-model="form.configKey" placeholder="请输入商户号" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 24">
          <el-form-item label-width="100px" label="签发邮箱" prop="configKey">
            <el-input v-model="form.configKey" placeholder="请输入签发邮箱" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 24">
          <el-form-item label-width="100px" label="手机号" prop="configKey">
            <el-input v-model="form.configKey" placeholder="请输入手机号" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 24">
          <el-form-item label-width="100px" label="证书有效期" prop="configKey">
            <el-input v-model="form.configKey" placeholder="请输入证书有效期" />
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
  </el-dialog>
</template>

<script>
import { updateConfig, addConfig, getConfig } from "@/api/merchant/infactor";
export default {
  data(){
    return{
      // dialog全屏
      isFullscreen:false,
      // tabs的显示id
      activeName: 'first',
      // 弹出层标题
      title: "添加",
      // 是否显示弹出层
      open: false,
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        memberNo: [
          { required: true, message: "参数名称不能为空", trigger: "blur" }
        ]
      },
      // 表格集合
      tableData:[
        {
          id:1,
          date: '2016-05-02',
          checked:false,
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
          fileList:[]
        },
        {
          id:12,
          date: '2016-05-02',
          checked:false,
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
          fileList:[]
        },
        {
          id:3,
          date: '2016-05-02',
          checked:false,
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
          fileList:[]
        },
        {
          id:5,
          date: '2016-05-02',
          checked:false,
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
          fileList:[]
        }
      ],
      // 表格集合
      headerStyle:{
        color:"#123456"
      },
    }
  },
  methods:{
    onScale(){
      this.isFullscreen = !this.isFullscreen
    },
    handleSelectionChange(val){
      this.clearTree = val.map(item=>{
        return item.id
      })
      console.log(this.clearTree)
    },
    add(){
      this.open = true;
      this.title = "添加";
      this.reset();
    },
    /** 审核按钮操作 */
    examine(row) {
      this.open = true;
      this.title = "审核";
      // const configId = row.configId || this.ids
      getConfig().then(response => {
        this.form = response.data;
      });
    },
    /** 查看按钮操作 */
    checkData(row) {
      this.open = true;
      this.title = "查看";
      // const configId = row.configId || this.ids
      getConfig().then(response => {
        this.form = response.data;
      });
    },
    /** 修改按钮操作 */
    update(row) {
      this.open = true;
      this.title = "修改";
      // const configId = row.configId || this.ids
      getConfig().then(response => {
        this.form = response.data;
      });
    },
    /** 提交按钮 */
    submitForm: function() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.configId != undefined) {
            updateConfig(this.form).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.getList();
            });
          } else {
            addConfig(this.form).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.getList();
            });
          }
        }
      });
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        configId: undefined,
        memberNo: undefined,
        configKey: undefined,
        configValue: undefined,
        status: "",
        remark: undefined
      };
      this.resetForm("form");
    },
  }
}
</script>

<style>
  .title{
    font-size: 15px;
    color: #1890ff;
  }
  .el-table tr .heade-cell{
    color: #333;
    background-color:#eff3f8;
  }
</style>
<style scoped lang="scss">
.dialog-bar{
  position: relative;
  .icon-full{
    position: absolute;
    right: 30px;
    font-size: 12px;
    top: 2px;
    cursor: pointer;
  }
}
.form{
  overflow-x: hidden;
  overflow-y: scroll;
}
.form::-webkit-scrollbar{
  display: none;
}
.upload-demo{
  display: flex;
  align-items: center;
  justify-content: flex-start;
}
.date-select{
  /*display: flex;*/
  align-items: center;
  justify-content: flex-start;
}
</style>
