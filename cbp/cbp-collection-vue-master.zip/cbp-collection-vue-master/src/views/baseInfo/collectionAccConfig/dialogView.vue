<template>
  <!-- 添加或修改参数配置对话框 -->
  <el-dialog :title="title" :visible.sync="open" width="500px" append-to-body
             :close-on-press-escape="false"
             :close-on-click-modal="false"
             :fullscreen="isFullscreen"
  >
    <template slot="title">
      <div class="dialog-bar">
        <span>{{title}}</span>
        <el-tooltip content="全屏 / 窗口" effect="dark" placement="bottom">
          <svg-icon @click="onScale" class="icon-full" :icon-class="isFullscreen?'exit-fullscreen':'fullscreen'" />
        </el-tooltip>
      </div>
    </template>
    <el-form ref="form" :model="form" :rules="rules" label-width="80px" class="form" :disabled="type=='view'">
      <el-row :gutter="24">
        <el-col :span="isFullscreen ? 8 : 24">
          <el-form-item label-width="110px" label="收汇账户名称" prop="accountName">
            <el-input v-model="form.accountName" placeholder="请输入收汇账户名称" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 24">
          <el-form-item label-width="110px" label="收汇账号" prop="accountNo">
            <el-input v-model="form.accountNo" placeholder="请输入收汇账号" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 24">
          <el-form-item label-width="110px" label="收汇银行名称" prop="bankName">
            <el-input v-model="form.bankName" placeholder="请输入收汇银行名称" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 24">
          <el-form-item label-width="170px" label="收汇银行SWIFT CODE" prop="bankSwiftCode">
            <el-input v-model="form.bankSwiftCode" placeholder="请输入收汇银行SWIFT CODE" />
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 24">
          <el-form-item label-width="110px" label="币别" prop="currency">
              <el-select style="width: 100%" v-model="form.currency" placeholder="币别" clearable>
                <el-option
                  v-for="dict in dict.type.currency_type"
                  :key="dict.value"
                  :label="dict.label"
                  :value="dict.value"
                />
              </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="isFullscreen ? 8 : 24">
          <el-form-item label-width="110px" label="所属国别" prop="sourceCountry">
            <el-select style="width: 100%" v-model="form.sourceCountry" placeholder="所属国别" clearable>
              <el-option
                v-for="dict in dict.type.source_country"
                :key="dict.value"
                :label="dict.label"
                :value="dict.value"
              />
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" v-if="type!='view'" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
  </el-dialog>
</template>

<script>
import { collection } from "@/api/merchant/infactor";
export default {
  dicts:['currency_type','source_country'],
  data(){
    return{
      // dialog全屏
      isFullscreen:false,
      onlyView:false,
      // tabs的显示id
      activeName: 'first',
      // 弹出层标题
      title: "添加",
      // 是否显示弹出层
      open: false,
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        accountName: [
          { required: true, message: "收汇账户名称不能为空", trigger: "blur" }
        ],
        accountNo: [
          { required: true, message: "收汇账号不能为空", trigger: "blur" }
        ],
        bankName: [
          { required: true, message: "收汇银行名称不能为空", trigger: "blur" }
        ],
        bankSwiftCode: [
          { required: true, message: "SWIFT CODE不能为空", trigger: "blur" }
        ],
        currency: [
          { required: true, message: "币别不能为空", trigger: "blur" }
        ],
        sourceCountry: [
          { required: true, message: "所属国别不能为空", trigger: "blur" }
        ]
      },
      // 表格集合
      tableData:[],
      // 表格集合
      headerStyle:{
        color:"#123456"
      },
      multipleSelection:[],
      type:"",
      clearTree:[]
    }
  },
  methods:{
    onScale(){
      this.isFullscreen = !this.isFullscreen
    },
    // 增加记录
    toAdd(tableName){
      if(tableName == 'tableData'){
        this[tableName].push({
          id:this.tableData.length+1,
          date: '',
          checked:false,
          name: '',
          fileList:[]
        })
      }
    },
    // 删除记录
    toDelete(tableName){
      if(this.clearTree.length==0){
        this.$message({
          message: '至少选择一条记录',
          type: 'warning'
        });
        return false
      }
      var arr = this[tableName].filter(item=>!this.clearTree.some(val=>item.id == val))
      this[tableName] = arr.map((val,index)=>{
        return {
          ...val,
          id: index+1
        }
      })
    },
    handleSelectionChange(val){
      this.clearTree = val.map(item=>{
        return item.id
      })
      console.log(this.clearTree)
    },
    add(){
      this.open = true;
      this.title = "添加";
      this.type = 'add'
      this.reset();
    },
    /** 审核按钮操作 */
    examine(row) {
      this.open = true;
      this.title = "审核";
      // const configId = row.configId || this.ids
      this.$nextTick(()=>{
        getConfig().then(response => {
          this.form = response.data;
        });
      })
    },
    /** 查看按钮操作 */
    checkData(row) {
      console.log(row)
      this.type = 'view'
      this.open = true;
      this.title = "查看";
      this.form = row
    },
    /** 修改按钮操作 */
    update(row) {
      this.open = true;
      this.type = 'edit'
      this.title = "修改";
      this.form = row
    },
    /** 提交按钮 */
    submitForm: function() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.id != undefined) {
            collection.updateCollection(this.form).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.$parent.getList();
            });
          } else {
            collection.addCollection(this.form).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.$parent.getList();
            });
          }
        }
      });
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        accountName:"",
        accountNo:"",
        bankName:"",
        bankSwiftCode:"",
        currency:"",
        sourceCountry:"",
      }
      this.resetForm("form");
    },
  }
}
</script>

<style>
  .title{
    font-size: 15px;
    color: #1890ff;
  }
  .el-table tr .heade-cell{
    color: #333;
    background-color:#eff3f8;
  }
</style>
<style scoped lang="scss">
.dialog-bar{
  position: relative;
  .icon-full{
    position: absolute;
    right: 30px;
    font-size: 12px;
    top: 2px;
    cursor: pointer;
  }
}
.form{
  overflow-x: hidden;
  overflow-y: scroll;
}
.form::-webkit-scrollbar{
  display: none;
}
.upload-demo{
  display: flex;
  align-items: center;
  justify-content: flex-start;
}
.date-select{
  /*display: flex;*/
  align-items: center;
  justify-content: flex-start;
}
</style>
