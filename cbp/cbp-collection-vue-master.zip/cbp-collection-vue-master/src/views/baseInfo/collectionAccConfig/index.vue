<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="68px">
        <el-form-item label="收汇账户名称" label-width="100px" prop="accountName">
          <el-input
            v-model="queryParams.accountName"
            placeholder="请输入收汇账户名称"
            clearable
            style="width: 240px"
          />
        </el-form-item>
      <el-form-item label="收汇账号" label-width="100px" prop="accountNo">
        <el-input
            v-model="queryParams.accountNo"
            placeholder="请输入收汇账号"
            clearable
            style="width: 240px"
          />
      </el-form-item>
      <el-form-item label="创建时间">
        <el-date-picker
          v-model="dateRange"
          style="width: 240px"
          value-format="yyyy-MM-dd"
          type="daterange"
          range-separator="-"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
        ></el-date-picker>
      </el-form-item>
      <el-form-item>
        <el-button v-hasPermi="['baseInfo:collectionAccConfig:query']" type="primary" icon="el-icon-search" size="mini" @click="handleQuery">查询</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>
    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="el-icon-plus"
          size="mini"
          @click="handleAdd"
          v-hasPermi="['baseInfo:collectionAccConfig:add']"
        >添加</el-button>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="configList" @selection-change="handleSelectionChange">
      <el-table-column width="200px" label="收汇账户名称" fixed="left"  align="center" prop="accountName"  />
      <el-table-column width="200px" label="收汇账号" align="center" prop="accountNo" :show-overflow-tooltip="true"/>
      <el-table-column width="150px" label="收汇银行名称" align="center" prop="bankName"/>
      <el-table-column width="160px" label="收汇银行SWIFT CODE" align="center" prop="bankSwiftCode" />
      <el-table-column width="150px" label="创建时间" align="center" prop="crtTime"  />
      <el-table-column width="150px" label="更新时间" align="center" prop="uptTime"  />
      <el-table-column label="操作" fixed="right" width="150px" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            @click="handleView(scope.row)"
            v-hasPermi="['baseInfo:collectionAccConfig:details']"
          >详情</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            v-hasPermi="['baseInfo:collectionAccConfig:edit']"
            @click="handleUpdate(scope.row)"
          >修改</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />
    <dialogView ref="dialog"></dialogView>
  </div>
</template>

<script>
import { collection } from "@/api/merchant/infactor";
import dialogView from "./dialogView";
export default {
  name: "Config",
  components:{
    dialogView
  },
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 参数表格数据
      configList: [
        {}
      ],
      // 日期范围
      dateRange: [],
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        accountNo: undefined,
        accountName: undefined,
      },
      // 表单校验
      rules: {
        accountName: [
          { required: true, message: "收汇账户名称不能为空", trigger: "blur" }
        ],
        accountNo: [
          { required: true, message: "收汇账号不能为空", trigger: "blur" }
        ],
        bankName: [
          { required: true, message: "收汇银行名称不能为空", trigger: "blur" }
        ],
        bankSwiftCode: [
          { required: true, message: "SWIFT CODE不能为空", trigger: "blur" }
        ],
        currency: [
          { required: true, message: "币别不能为空", trigger: "blur" }
        ],
        sourceCountry: [
          { required: true, message: "所属国别不能为空", trigger: "blur" }
        ]
      }
    };
  },
  created() {
    this.getList();
  },
  methods: {
    /** 查询商户信息列表 */
    getList() {
      this.loading = true;
      collection.listCollection(this.addDateRange(this.queryParams, this.dateRange,"crtTimeBegin","crtTimeEnd")).then(response => {
          this.configList = response.data;
          this.total = response.total;
          this.loading = false;
        }
      ).catch(e=>{
        this.loading = false;
      });
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.dateRange = [];
      this.resetForm("queryForm");
      this.handleQuery();
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.$refs.dialog.add()
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.configId)
      this.single = selection.length!=1
      this.multiple = !selection.length
    },
    /** 查看按钮操作 */
    handleView(row) {
      // const configId = row.configId || this.ids
      this.$refs.dialog.checkData(row)
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      // const configId = row.configId || this.ids
      this.$refs.dialog.update(row)
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const configIds = row.configId || this.ids;
      this.$modal.confirm('是否确认删除参数编号为"' + configIds + '"的数据项？').then(function() {
        return delConfig(configIds);
      }).then(() => {
        this.getList();
        this.$modal.msgSuccess("删除成功");
      }).catch(() => {});
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download('system/config/export', {
        ...this.queryParams
      }, `config_${new Date().getTime()}.xlsx`)
    },
    /** 刷新缓存按钮操作 */
    handleRefreshCache() {
      refreshCache().then(() => {
        this.$modal.msgSuccess("刷新成功");
      });
    }
  }
};
</script>
