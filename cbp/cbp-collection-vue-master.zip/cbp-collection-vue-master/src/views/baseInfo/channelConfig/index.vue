<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="68px">
      <el-form-item label="通道名称" label-width="100px" prop="channelCode">
        <el-select v-model="queryParams.channelCode" placeholder="请选择" clearable>
          <el-option
            v-for="dict in channelMenu"
            :key="dict.channelCode"
            :label="dict.channelName"
            :value="dict.channelCode"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="状态" prop="channelStatus">
        <el-select v-model="queryParams.channelStatus" placeholder="状态" clearable>
          <el-option
            v-for="dict in dict.type.pro_common_status"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="创建时间">
        <el-date-picker
          v-model="dateRange"
          style="width: 240px"
          value-format="yyyy-MM-dd"
          type="daterange"
          range-separator="-"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
        ></el-date-picker>
      </el-form-item>
      <el-form-item>
        <el-button v-hasPermi="['baseInfo:channelConfig:query']" type="primary" icon="el-icon-search" size="mini" @click="handleQuery">查询</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>
    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="el-icon-plus"
          size="mini"
          @click="handleAdd"
          v-hasPermi="['baseInfo:channelConfig:add']"
        >添加</el-button>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="configList" @selection-change="handleSelectionChange">
      <el-table-column width="150px" label="通道编号" fixed="left"  align="center" prop="channelCode"  />
      <el-table-column label="通道名称" align="center" prop="channelName" :show-overflow-tooltip="true"/>
      <el-table-column label="一级产品名称" align="center" prop="parentProductName"/>
      <el-table-column label="状态" align="center" prop="channelStatus"  >
        <template slot-scope="scope">
          <dict-tag :options="dict.type.pro_common_status" :value="scope.row.channelStatus"/>
        </template>
      </el-table-column>
      <el-table-column label="创建时间" align="center" prop="crtTime"  />
      <el-table-column label="更新时间" align="center" prop="uptTime"  />
      <el-table-column width="150px" label="操作" fixed="right" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            v-hasPermi="['baseInfo:channelConfig:details']"
            @click="handleView(scope.row)"
          >详情</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            v-hasPermi="['baseInfo:channelConfig:edit']"
            @click="handleUpdate(scope.row)"
          >修改</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />
    <dialogView ref="dialog"></dialogView>
  </div>
</template>

<script>
import {channel, product} from "@/api/merchant/infactor";
import dialogView from "./dialogView";
export default {
  name: "Config",
  components:{
    dialogView
  },
  dicts: ['pro_common_status'],
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 参数表格数据
      configList: [],
      // 日期范围
      dateRange: [],
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        channelCode: undefined,
        channelStatus: undefined,
      },
      // 表单校验
      rules: {
        memberNo: [
          { required: true, message: "参数名称不能为空", trigger: "blur" }
        ],
        configKey: [
          { required: true, message: "参数键名不能为空", trigger: "blur" }
        ],
        configValue: [
          { required: true, message: "参数键值不能为空", trigger: "blur" }
        ]
      },
      channelMenu:[]
    };
  },
  created() {
    this.getList();
    channel.getChannelMenu().then(res=>{
      this.channelMenu = res.data
    })
  },
  methods: {
    /** 查询商户信息列表 */
    getList() {
      this.loading = true;
      channel.listChannel(this.addDateRange(this.queryParams, this.dateRange,"crtTimeBegin","crtTimeEnd")).then(response => {
          this.configList = response.data;
          this.total = response.total;
          this.loading = false;
        }
      ).catch(e=>{
        this.loading = false;
      });
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.dateRange = [];
      this.resetForm("queryForm");
      this.handleQuery();
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.$refs.dialog.add()
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.configId)
      this.single = selection.length!=1
      this.multiple = !selection.length
    },
    /** 查看按钮操作 */
    handleView(row) {
      this.$refs.dialog.checkData(row)
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.$refs.dialog.update(row)
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const configIds = row.configId || this.ids;
      this.$modal.confirm('是否确认删除参数编号为"' + configIds + '"的数据项？').then(function() {
        return delConfig(configIds);
      }).then(() => {
        this.getList();
        this.$modal.msgSuccess("删除成功");
      }).catch(() => {});
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download('system/config/export', {
        ...this.queryParams
      }, `config_${new Date().getTime()}.xlsx`)
    },
    /** 刷新缓存按钮操作 */
    handleRefreshCache() {
      refreshCache().then(() => {
        this.$modal.msgSuccess("刷新成功");
      });
    },
    handleExamine(){
      // 操作状态 1-待审核 2-审核拒绝 3-审核通过

    }
  }
};
</script>
