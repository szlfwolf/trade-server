<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" size="small" v-show="showSearch"
             label-width="110px">
      <el-row :gutter="24">
        <el-col :lg="6" :md="8">
          <el-form-item label="商户号" prop="configName">
            <el-input
              v-model="queryParams.configName"
              placeholder="请输入商户号"
              clearable
              style="width: 100%"
              @keyup.enter.native="handleQuery"
            />
          </el-form-item>
        </el-col>
        <el-col :lg="6" :md="8">
          <el-form-item label="商户名称" prop="configKey">
            <el-input
              v-model="queryParams.configKey"
              placeholder="请输入商户名称"
              clearable
              style="width: 100%"
              @keyup.enter.native="handleQuery"
            />
          </el-form-item>
        </el-col>

        <el-col :lg="6" :md="8">
          <el-form-item label="创建时间">
            <el-date-picker
              style="width: 100%"
              v-model="dateRange"
              value-format="yyyy-MM-dd"
              type="daterange"
              range-separator="-"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
            ></el-date-picker>
          </el-form-item>
        </el-col>
        <el-col :lg="6" :md="8">
          <el-form-item label="处理状态" prop="configType">
            <el-select style="width: 100%" v-model="queryParams.configType" placeholder="处理状态" clearable>
              <el-option
                v-for="dict in dict.type.sys_yes_no"
                :key="dict.value"
                :label="dict.label"
                :value="dict.value"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :lg="6" :md="8">
          <el-form-item label="银行业务流水号" prop="configType">
            <el-input
              v-model="queryParams.configKey"
              placeholder="请输入银行业务流水号"
              clearable
              style="width: 100%"
              @keyup.enter.native="handleQuery"
            />
          </el-form-item>
        </el-col>
        <el-col :lg="6" :md="8">
          <el-form-item label="还原状态" prop="configType">
            <el-select style="width: 100%" v-model="queryParams.configType" placeholder="还原状态" clearable>
              <el-option
                label="所有"
                :value="1"
              />
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>

      <el-row :gutter="10" class="mb8">
        <el-col :span="1.5">
          <el-button type="primary" icon="el-icon-search" size="small" @click="handleQuery">查询</el-button>
        </el-col>
        <el-col :span="1.5">
          <el-button icon="el-icon-refresh" size="small" @click="resetQuery">重置</el-button>
        </el-col>
        <el-col :span="1.5">
          <el-button type="primary" icon="el-icon-download" size="small" @click="handleExport">导出</el-button>
        </el-col>
        <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
      </el-row>
    </el-form>
    <el-table v-loading="loading" :data="configList" @selection-change="handleSelectionChange">
      <el-table-column width="150px" fixed="left" label="商户号" align="center" prop="merchantNo" />
      <el-table-column width="150px" label="商户名称" align="center" prop="merchantName" :show-overflow-tooltip="true" />
      <el-table-column width="200px" label="银行业务流水号" align="center" prop="bocomNo" :show-overflow-tooltip="true" />
      <el-table-column width="100px" label="汇款人名称" align="center" prop="remittorName" />
      <el-table-column width="150px" label="汇款人账户" align="center" prop="remittorAccount" />
      <el-table-column width="100px" label="汇款币种" align="center" prop="remitCurrency" />
      <el-table-column width="100px" label="汇款金额" align="center" prop="remitAmount"/>
      <el-table-column width="150px" label="汇款完成时间" align="center" prop="remitCompleteTime" :show-overflow-tooltip="true" />
      <el-table-column width="100px" label="状态" align="center" prop="status" :show-overflow-tooltip="true" />
      <el-table-column width="100px" label="还原状态" align="center" prop="restoreStatus" :show-overflow-tooltip="true" />
      <el-table-column width="150px" label="还原报错原因" align="center" prop="restoreErrorMsg" :show-overflow-tooltip="true" />
      <el-table-column width="150px" label="创建时间" align="center" prop="crtTime" :show-overflow-tooltip="true" />
      <el-table-column width="160px" label="更新时间" align="center" prop="uptTime" :show-overflow-tooltip="true" />
      <el-table-column width="150px" label="操作人" align="center" prop="operatorName" :show-overflow-tooltip="true" />
      <el-table-column width="150px" label="审核人" align="center" prop="verifierName" :show-overflow-tooltip="true" />
      <el-table-column width="150px" label="操作" fixed="right" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            @click="handleDetails(scope.row)"
            v-hasPermi="['system:config:edit']"
          >详情</el-button>
          <el-button
            size="mini"
            type="text"
            @click="handleRuOrder(scope.row)"
            v-hasPermi="['system:config:edit']"
          >入账操作</el-button>
          <el-button
            size="mini"
            type="text"
            @click="handleExamineOrder(scope.row)"
            v-hasPermi="['system:config:edit']"
          >入账审核</el-button>
          <el-button
            size="mini"
            type="text"
            @click="handleNotice(scope.row)"
            v-hasPermi="['system:config:edit']"
          >补发通知</el-button>
          <el-button
            size="mini"
            type="text"
            @click="handleDownload(scope.row)"
            v-hasPermi="['system:config:edit']"
          >还原下载</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加或修改参数配置对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="1000px" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="120px">
        <el-row :gutter="24">
          <el-col :span="12">
            <el-form-item label="资金申报编号" prop="busCode">
              <p class="border-bottom">{{form.busCode}}</p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="银行业务流水号" prop="bocomNo">
              <p class="border-bottom">{{form.bocomNo}}</p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="汇款人名称" prop="remittorName">
              <p class="border-bottom">{{form.remittorName}}</p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="汇款人账户" prop="remittorAccount">
              <p class="border-bottom">{{form.remittorAccount}}</p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="汇款行BIC" prop="remittingBankBic">
              <p class="border-bottom">{{form.remittingBankBic}}</p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="汇款行业务编号" prop="remittingBankBusinessNum">
              <p class="border-bottom">{{form.remittingBankBusinessNum}}</p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="收款人名称" prop="payeeName">
              <p :title="form.payeeName" class="border-bottom">{{form.payeeName}}</p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="收款人账户" prop="payeeAccount">
              <p class="border-bottom">{{form.payeeAccount}}</p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="汇款金额" prop="remitAmount">
              <p class="border-bottom">{{form.remitAmount}}</p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="汇款币种" prop="remitCurrency">
              <p class="border-bottom">{{form.remitCurrency}}</p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="汇款完成时间" prop="remitCompleteTime">
              <p class="border-bottom">{{form.remitCompleteTime}}</p>
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="汇款附言" prop="remitPostscript">
              <p class="border-bottom">{{form.remitPostscript}}</p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="商户名称" prop="merchantName">
              <p v-if="type!='operation'" class="border-bottom">{{ form.merchantName }}</p>
              <el-select
                v-else
                clearable
                v-model="form.merchantName"
                placeholder="选择"
                style="width:100%"
                remote
                :remote-method="remoteMethod"
                @focus="onFocus"
                @change="onChange"
                filterable
                :loading="xlloading"
                v-loadmore="loadmore"
              >
                <el-option
                  v-for="(item, index) in departmentList"
                  :key="index"
                  :label="item.merchantName"
                  :value="item"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="商户号" prop="merchantNo">
              <p class="border-bottom">{{form.merchantNo}}</p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="商户汇款账号" prop="remittanceAccountId">
              <p v-if="type!='operation'" class="border-bottom">{{form.remittanceAccountId}}</p>
              <el-select v-else style="width: 100%" v-model="form.remittanceAccountId" placeholder="商户汇款账号" clearable>
                <el-option
                  v-for="dict in accountList"
                  :key="dict.accountNo"
                  :label="dict.accountNo+'-'+dict.accountName"
                  :value="dict.accountNo"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="申报方式" prop="declareType">
              <p v-if="type!='operation'"  class="border-bottom">
                <dict-tag :options="dict.type.declare_type" :value="form.declareType"/>
              </p>
              <el-select v-else style="width: 100%" v-model="form.declareType" placeholder="申报方式" clearable>
                <el-option
                  v-for="dict in dict.type.declare_type"
                  :key="dict.value"
                  :label="dict.label"
                  :value="dict.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="交易编码" prop="productBusinessTypeId">
              <p v-if="type!='operation'" class="border-bottom">{{form.productBusinessTypeId}}</p>
              <el-select v-else style="width: 100%" v-model="form.productBusinessTypeId" placeholder="交易编码" clearable>
                <el-option
                  v-for="dict in dict.type.trad_code"
                  :key="dict.value"
                  :label="dict.value+'-'+dict.label"
                  :value="dict.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="汇款批次号" prop="remitBatchNo">
              <p v-if="type!='operation'" class="border-bottom">{{form.remitBatchNo}}</p>
              <el-input
                v-else
                v-model="form.remitBatchNo"
                placeholder="汇款批次号"
                clearable
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="平台名称" prop="platformName">
              <p v-if="type!='operation'" class="border-bottom">{{form.platformName}}</p>
              <el-input
                v-else
                v-model="form.platformName"
                placeholder="平台名称"
                clearable
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="创建时间" prop="crtTime">
              <p class="border-bottom">{{form.crtTime}}</p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="更新时间" prop="uptTime">
              <p class="border-bottom">{{form.uptTime}}</p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="处理状态" prop="status">
              <p class="border-bottom">
                <dict-tag :options="dict.type.notice_status" :value="form.status"/>
              </p>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="还原状态" prop="restoreStatus">
              <p class="border-bottom">
                <dict-tag :options="dict.type.restore_status" :value="form.restoreStatus"/>
              </p>
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="还原失败原因" prop="restoreErrorMsg">
              <p class="border-bottom">{{form.restoreErrorMsg}}</p>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button v-if="type=='examine'" type="danger" @click="submitJect(false)">审核拒绝</el-button>
        <el-button v-if="type=='examine'" type="primary" @click="submitJect(true)">审核通过</el-button>
        <el-button v-if="type!='view' && type!='examine'" type="primary" @click="submitForm">确定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { merInfo, noticeInfoRequest, receiptInfoExport } from '@/api/merchant/infactor'

export default {
  name: "Config",
  dicts: ['restore_status','notice_status','declare_type','accoun_adjust_status','trad_code'],
  data() {
    return {
      type: 'add',
      accountList:[],
      departmentList:[],
      xlloading: false,
      // 遮罩层
      loading: true,
      // 内层dialog遮罩层
      innerVisible: false,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 参数表格数据
      configList: [
        {
          id:1
        }
      ],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 日期范围
      dateRange: [],
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
      }
    };
  },
  created() {
    this.getList();
  },
  methods: {
    // remoteMethod
    remoteMethod(query) {
      if (query !== '') {
        this.xlloading = true;
        this.merNum = 1
        this.departmentList = []
        this.getMerchantList(query);
      } else {
        this.getMerchantList();
      }
    },
    onFocus(){
      if (!this.queryParams.merchantNo) {
        this.xlloading = true;
        this.merNum = 1
        this.departmentList = []
        this.getMerchantList();
      }
    },
    getMerchantList(query){
      let params = {
        pageNum: this.merNum,
        pageSize: this.merSize,
      }
      if(Number(query)){
        params["merchantNo"] = query
      } else {
        params["merchantName"] = query
      }
      merInfo.getMerchantInfo(params).then(response => {
          this.departmentList = [...this.departmentList,...response.data]
          this.merTotal = Math.ceil(response.total / this.merSize)
        }
      ).catch(e=>{
        this.loading = false;
      }).finally(e=>{
        this.xlloading = false;
      });
    },
    //滑动触底的相关操作
    loadmore(){
      if(this.merNum<this.merTotal){
        this.merNum+=1
        this.getMerchantList()
      }
      console.log(this.merNum,this.merTotal);

      //数据页面更新，数据请求操作
    },
    onChange(val){
      console.log(val)
      this.form.merchantName = val.merchantName
      this.form.merchantNo = val.merchantNo
    },
    /** 查询参数列表 */
    getList() {
      this.loading = true;
      noticeInfoRequest.list(this.addDateRange(this.queryParams, this.dateRange)).then(response => {
          this.configList = response.data;
          this.total = response.total;
          this.loading = false;
        }
      ).catch((e)=>{
        this.loading = false
      });
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        configId: undefined,
        configName: undefined,
        configKey: undefined,
        configValue: undefined,
        configType: "Y",
        remark: undefined
      };
      this.resetForm("form");
    },
    // 获取汇款账户列表
    getAccountList(merchantNo){
      noticeInfoRequest.merchantRemitAll({
        merchantNo
      }).then(res=>{
          this.accountList = res.data
      })
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.dateRange = [];
      this.resetForm("queryForm");
      this.queryParams.configType = ""
      // this.handleQuery();
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.reset();
      this.open = true;
      this.title = "添加参数";
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.configId)
      this.single = selection.length!=1
      this.multiple = !selection.length
    },
    /** 明细 */
    handleDetails(row) {
      this.reset();
      this.open = true;
      this.title = "查看详情";
      this.type = "view";
      const configId = row.id || ''
      noticeInfoRequest.getDetails({
        id:configId
      }).then(response => {
        this.form = response.data;
        this.open = true;
        this.getAccountList(this.form.merchantNo)
      });
    },
    /** 补发 */
    handleNotice(row) {
    },
    /** 下载按钮操作 */
    handleDownload(row) {
      this.reset();
      this.open = true;
      const configId = row.configId || this.ids
      getConfig(configId).then(response => {
        this.form = response.data;
        this.open = true;
        this.title = "修改参数";
      });
    },
    /** 入账审核按钮 */
    handleExamineOrder(row){
      this.open = true;
      this.type = 'examine'
      this.reset();
      const configId = row.id || ''
      noticeInfoRequest.getDetails({
        id:configId
      }).then(response => {
        this.form = response.data;
        this.open = true;
        this.getAccountList(this.form.merchantNo)
      });
    },
    /** 入账操作按钮 */
    handleRuOrder(row){
      this.open = true;
      this.type = 'operation'
      this.reset();
      const configId = row.id || ''
      noticeInfoRequest.getDetails({
        id:configId
      }).then(response => {
        this.form = response.data;
        this.open = true;
        this.getAccountList(this.form.merchantNo)
      });
    },
    /** 拒绝按钮 */
    submitJect(auditIsPassed){
      let type = "success"
      if(auditIsPassed) type = "success"
      else  type = "error"
      this.$confirm('是否继续此操作?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: type
      }).then(() => {
        noticeInfoRequest.pass({
          receiptInfoId:this.form.id,
          auditIsPassed: auditIsPassed,
        }).then(res=>{
          this.$modal.msgSuccess("操作成功");
          this.open = false;
          this.getList();
        })
      }).catch(() => {

      });
    },
    submitForm: function() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.configId != undefined) {
            noticeInfoRequest.entryAccountOperate({
              declareType:this.form.declareType,
              merchantName:this.form.merchantName,
              merchantNo:this.form.merchantNo,
              remittanceAccountId:this.form.remittanceAccountId,
              remittanceAccountName:this.form.remittanceAccountName,
              platformName:this.form.platformName,
              productBusinessTypeId:this.form.productBusinessTypeId,
              receiptInfoId:this.form.receiptInfoId,
              remitBatchNo:this.form.remitBatchNo,
            }).then(response => {
              this.$modal.msgSuccess("操作成功");
              this.open = false;
              this.getList();
            });
          } else {
            noticeInfoRequest.entryAccountOperate(this.form).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.getList();
            });
          }
        }
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const configIds = row.configId || this.ids;
      this.$modal.confirm('是否确认删除参数编号为"' + configIds + '"的数据项？').then(function() {
          return delConfig(configIds);
        }).then(() => {
          this.getList();
          this.$modal.msgSuccess("删除成功");
        }).catch(() => {});
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download(receiptInfoExport, {
        ...this.queryParams
      }, `到账通知列表_${new Date().getTime()}.xlsx`)
    },
    /** 刷新缓存按钮操作 */
    handleRefreshCache() {
      refreshCache().then(() => {
        this.$modal.msgSuccess("刷新成功");
      });
    }
  }
};
</script>
<style scoped>
.border-bottom{
  height: 36px;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
</style>
