package com.smartpay.cbp.system.api;

import com.smartpay.cbp.common.core.constant.SecurityConstants;
import com.smartpay.cbp.common.core.constant.ServiceNameConstants;
import com.smartpay.cbp.common.core.domain.Result;
import com.smartpay.cbp.system.api.domain.SysUser;
import com.smartpay.cbp.system.api.factory.RemoteUserFallbackFactory;
import com.smartpay.cbp.system.api.model.LoginUser;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Set;

/**
 * 用户服务
 *
 * @author ruoyi
 */
@FeignClient(contextId = "remoteUserService", value = ServiceNameConstants.SYSTEM_SERVICE, fallbackFactory = RemoteUserFallbackFactory.class)
public interface RemoteUserService {
    /**
     * 通过用户名查询用户信息
     *
     * @param username 用户名
     * @param source   请求来源
     * @return 结果
     */
    @GetMapping("/user/info/{username}")
    public Result<LoginUser> getUserInfo(@PathVariable("username") String username, @RequestHeader(SecurityConstants.FROM_SOURCE) String source);

    /**
     * 注册用户信息
     *
     * @param sysUser 用户信息
     * @param source  请求来源
     * @return 结果
     */
    @PostMapping("/user/register")
    public Result<Boolean> registerUserInfo(@RequestBody SysUser sysUser, @RequestHeader(SecurityConstants.FROM_SOURCE) String source);

    /**
     * 根据用户ids查询用户信息
     *
     * @param userIds 用户ids
     * @param source 请求来源
     * @return
     */
    @GetMapping("/user/mapByUserIds")
    Result<Map<Long, SysUser>> mapByUserIds(@RequestBody Set<Long> userIds, @RequestHeader(SecurityConstants.FROM_SOURCE) String source);
}
