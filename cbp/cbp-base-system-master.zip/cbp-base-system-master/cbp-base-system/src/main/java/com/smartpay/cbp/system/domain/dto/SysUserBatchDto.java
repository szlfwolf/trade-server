package com.smartpay.cbp.system.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Set;

/**
 * @Description: 用户批量查询
 * @Author: Guogangqiang
 * @CreateDate: 2022/11/22 9:06
 * @Version: 1.0
 */
@Data
public class SysUserBatchDto {

    @ApiModelProperty("用户集合")
    private Set<Long> userIds;

}
